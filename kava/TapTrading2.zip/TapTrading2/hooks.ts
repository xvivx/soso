import { useEffect, useMemo } from 'react';
import { useTranslation } from 'react-i18next';
import { useDispatch, useSelector } from 'react-redux';
import useSWR from 'swr';
import bridge from '@store/bridge';
import { useActivePrice } from '@store/symbol';
import { useMuted } from '@store/system';
import {
  setPresentOrderType,
  updateProgressingOrders,
  useActiveTradingPairInfo,
  useProgressingAndTempOrders,
  type TapOrder,
  type TempOrder,
} from '@store/tap';
import { useBalance, useCurrency } from '@store/wallet';
import useMemoCallback from '@hooks/useMemoCallback';
import { message } from '@components';
import { request } from '@utils';
import { Sound, SoundType } from '@utils/sound';
import { GridSize, Kline, KlineGap, ViewBounding } from './utils';

export function usePlaySound() {
  const muted = useMuted();
  return useMemo(() => {
    return {
      place() {
        !muted && Sound.play(SoundType.CLICK);
      },
      success() {
        !muted && Sound.play(SoundType.SUCCESS);
      },
      fail() {
        !muted && Sound.play(SoundType.FAIL);
      },
    };
  }, [muted]);
}

export function useCreateOrder() {
  const { t } = useTranslation();
  const currency = useCurrency();
  const activePair = useSelector((state) => state.system.tap.activePair);
  const dispatch = useDispatch();
  const sound = usePlaySound();
  const amount = useSelector((state) => state.tap.amount);
  const balance = useBalance();
  return useMemoCallback(async (timeAndPrice: { lowerTimeLimit: number; lowerPriceLimit: number }) => {
    if (Number(amount) > balance) return message.error(t('Balance is not enough'));
    const data = {
      ...timeAndPrice,
      amount,
      currency: currency.name,
      symbol: activePair,
    };
    const tempOrder = { ...data, id: Math.random().toString(32) } as TempOrder;
    try {
      updateProgressingOrders(tempOrder, 'add');
      const order = await request.post<TapOrder>('/api/transaction/tapOrder/create', data, {
        silence: !bridge.get().micro,
      });
      updateProgressingOrders(order, 'update', tempOrder.id);
      dispatch(setPresentOrderType('PROGRESSING'));
      sound.place();
    } catch {
      updateProgressingOrders(tempOrder, 'cancel');
      sound.fail();
    }
  });
}

type OrderRect = { key: string; x: number; y: number; orders: TapOrder[] };
export function useMixinOrdersRects() {
  const { data: orders } = useProgressingAndTempOrders();
  return useMemo(() => {
    const rects: OrderRect[] = [];
    const temps: Record<string, TapOrder[]> = {};
    orders.forEach((order) => {
      const key = `${order.lowerTimeLimit}-${order.lowerPriceLimit}`;
      const isReal = 'odds' in order;
      if (temps[key]) {
        isReal && temps[key].unshift(order as TapOrder);
      } else {
        temps[key] = isReal ? [order as TapOrder] : [];
        rects.push({ key, orders: temps[key], x: order.lowerTimeLimit, y: order.lowerPriceLimit });
      }
    });
    return rects;
  }, [orders]);
}

function useKlineHistory(bounding: ViewBounding) {
  const { symbol: tradingPair, xGap } = useActiveTradingPairInfo();
  return useSWR(
    bounding.width > 0 ? ['tap-trading-kline-history', tradingPair] : null,
    async () => {
      const data = await request.get<{ s: string; p: string; t: number }[]>(
        `/api/data/kline/history/ticker/latest?symbol=${tradingPair.replace('/', '-')}&seconds=${Math.ceil(((bounding.width / GridSize) * xGap) / 1000)}`
      );
      return data.map((it) => [it.t, Number(it.p)] as Kline);
    },
    { fallbackData: [], revalidateOnFocus: false }
  );
}

export function useKlines(bounding: ViewBounding) {
  const latest = useActivePrice();
  const { xGap, symbol: tradingPair } = useActiveTradingPairInfo();
  const { data: klines, mutate, isValidating } = useKlineHistory(bounding);
  const xMaxPoints = useMemo(() => {
    return Math.ceil(((bounding.width / GridSize) * xGap) / KlineGap);
  }, [bounding.width, xGap]);

  useEffect(() => {
    return () => {
      mutate(undefined);
    };
  }, [mutate]);

  useEffect(() => {
    if (!latest.symbol || isValidating || latest.symbol !== tradingPair) return;

    mutate((prev) => {
      if (!prev || !prev.length) return [];
      if (latest.time <= prev[prev.length - 1][0]) return prev;
      const data = [...prev, [latest.time, latest.price]] as Kline[];
      return data;
    }, false);
  }, [mutate, latest, xMaxPoints, tradingPair, isValidating]);

  return klines;
}
