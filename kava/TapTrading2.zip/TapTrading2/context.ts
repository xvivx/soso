import { RefObject, useMemo } from 'react';
import { scaleLinear } from 'd3';
import { useActiveTradingPairInfo } from '@store/tap';
import { useKlines } from './hooks';
import { Domain, GridSize, ViewBounding } from './utils';

export function useContext(bounding: ViewBounding, svgRef: RefObject<SVGSVGElement>) {
  const { xGap, yGap } = useActiveTradingPairInfo();
  const klines = useKlines(bounding);
  const factor = (bounding.width / GridSize) * xGap;
  const last = klines.slice(-1)[0] || [0, 0];
  const first = klines[0] || [0, 0];
  const xDomain: Domain = [last[0] - factor / 2, last[0]];
  const xScale = useMemo(() => {
    return scaleLinear().domain(xDomain).range([0, bounding.width]);
    // .range(xDomain.map((it) => (it / xGap) * GridSize));
  }, [xDomain, bounding.width, xGap, GridSize]);

  const ys = useMemo(() => klines.map((it) => it[1]), [klines]);
  const yMin = useMemo(() => Math.min(...ys), [ys]);
  const yMax = useMemo(() => Math.max(...ys), [ys]);
  const yDomain = [yMin, yMax];

  const yScale = useMemo(() => {
    return scaleLinear().domain(yDomain).range([bounding.height, 0]);
    // .range(yDomain.map((it) => (it / yGap) * GridSize));
  }, [yDomain, bounding.height, yGap, GridSize]);

  return {
    xDomain,
    yDomain,
    xScale,
    yScale,
    klines,
  };
}
