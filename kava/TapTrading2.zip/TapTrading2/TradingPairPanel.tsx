import { memo } from 'react';
import { useDispatch } from 'react-redux';
import { setTapConfig } from '@store/system';
import { useActiveTradingPairInfo, useTradingPairs } from '@store/tap';
import TradingPair from '@pages/components/TradingPair';

function TradingPairPanel() {
  const { data: tradingPairs } = useTradingPairs();
  const tradingPair = useActiveTradingPairInfo();
  const dispatch = useDispatch();
  return (
    <TradingPair
      onChange={(activePair) => dispatch(setTapConfig({ activePair }))}
      symbols={tradingPairs}
      tradingPair={tradingPair}
      gameType={5}
    />
  );
}

export default memo(TradingPairPanel);
