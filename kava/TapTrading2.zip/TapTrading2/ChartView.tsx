import { memo, useEffect, useRef, useState } from 'react';
import { HtmlLabel } from '@visx/annotation';
// import { curveMonotoneX } from '@visx/curve';
// import { LinePath } from '@visx/shape';
import { motion } from 'framer-motion';
import { mutate } from 'swr';
import { useActiveTradingPairInfo } from '@store/tap';
import { useAccountType } from '@store/wallet';
import useDocumentVisible from '@hooks/useDocumentVisible';
import { Loading } from '@components';
import WaterMark from '@pages/components/WaterMark';
import { Line } from './Chart/Line';
import CheckoutEffect from './CheckoutEffect';
import { useContext } from './context';
import Grids from './Grids';
import { useKlines } from './hooks';
import OrderRects from './OrderRects';
import Ripple from './Ripple';
import { Kline, ViewBounding } from './utils';

function ChartView() {
  const svgRef = useRef<SVGSVGElement>(null);
  const [bounding, setBounding] = useState<ViewBounding>({ width: 0, height: 0 });
  useEffect(() => {
    const svg = svgRef.current!;
    const observer = new ResizeObserver(() => setBounding(svg.getBoundingClientRect()));
    observer.observe(svg);
    return () => observer.disconnect();
  }, [svgRef]);

  useEffect(() => {
    return () => {
      mutate(['tap-history-orders']);
      mutate(['tap-progressing-orders']);
    };
  }, []);

  const { xDomain, yDomain, xScale, yScale, klines } = useContext(bounding, svgRef);
  const last = klines[klines.length - 1];

  return (
    <svg ref={svgRef} className="size-full touch-pan-y" viewBox={`0 0 ${bounding.width} ${bounding.height}`}>
      {klines.length ? (
        <>
          <OrderRects xScale={xScale} yScale={yScale} />
          <Line xScale={xScale} yScale={yScale} data={klines} />
          <Ripple xScale={xScale} yScale={yScale} />
        </>
      ) : (
        <HtmlLabel
          x={bounding.width / 2}
          y={bounding.height / 2}
          showAnchorLine={false}
          horizontalAnchor="middle"
          verticalAnchor="middle"
        >
          <Loading.Svg className="size-5" />
        </HtmlLabel>
      )}
    </svg>
  );
}

function ChartContainer() {
  const visible = useDocumentVisible();
  const accountType = useAccountType();
  const tradingPair = useActiveTradingPairInfo();
  return (
    <div className="relative rounded-2 select-none bg-layer3 h-96 s768:h-[578px]">
      {visible && <ChartView key={`${accountType}-${tradingPair.symbol}`} />}
      <WaterMark className="absolute left-3 bottom-3" />
      <CheckoutEffect />
    </div>
  );
}

export default memo(ChartContainer, () => true);
