import { useEffect } from 'react';
import { usePlaceAmount, usePlaceLimit } from '@store/tap';
import { FormItem } from '@components';
import PlaceInput from '@pages/components/PlaceInput';

export default function PlacePanel() {
  const {
    data: { minAmount, maxAmount, currency },
  } = usePlaceLimit();
  const [amount, setAmount] = usePlaceAmount();

  useEffect(() => {
    minAmount && setAmount(String(minAmount));
  }, [setAmount, minAmount]);

  return (
    <FormItem className="detrade-card" label={null}>
      <PlaceInput
        value={amount}
        onChange={setAmount}
        min={minAmount}
        max={maxAmount}
        limitCurrency={currency}
        shortcuts
      />
    </FormItem>
  );
}
