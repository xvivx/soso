import { scaleLinear } from '@visx/scale';

export type XY = [number, number];
export type Scale = ReturnType<typeof scaleLinear<number>>;
export type Domain = [number, number];
export type Range = [number, number];
export type Kline = [number, number];
