import { useEffect, useLayoutEffect, useMemo, useRef, useState, type Ref, type RefObject } from 'react';
import { curveMonotoneX, curveNatural, line } from 'd3';
import { motion, MotionValue, useAnimate, useMotionValue, type SVGMotionProps } from 'framer-motion';
import usePrevious from '@hooks/usePrevious';
import { Kline, Scale } from './types';

export function Line(props: { xScale: Scale; yScale: Scale; data: Kline[] }) {
  const { xScale, yScale, data } = props;
  const shadowRef = useRef<SVGPathElement>(null);
  const curve = useMemo(() => {
    return line()
      .x((d) => xScale(d[0]))
      .y((d) => yScale(d[1]))
      .curve(curveNatural);
  }, [xScale, yScale]);

  const [scope, animate] = useAnimate<SVGPathElement>();
  const prevData = usePrevious(data);
  const shadowData = data.slice(0, -1);
  const offset = useMotionValue(0);
  useEffect(() => {
    if (!data.length || !shadowRef.current) return;
    const shadowPathLength = shadowRef.current.getTotalLength();
    const motionPathLength = scope.current.getTotalLength();

    offset.set(motionPathLength - shadowPathLength);
    scope.current.style.strokeDasharray = String(motionPathLength);

    const controller = animate(offset, 0, { duration: 0.5, ease: 'linear' });
    return () => controller.stop();
  }, [data]);

  return (
    <>
      <path className="fill-transparent stroke-transparent" ref={shadowRef} d={curve(shadowData) || ''} />
      <motion.path
        ref={scope}
        className="stroke-[#D7ED47] light:stroke-[#A8C200] fill-transparent"
        d={curve(data) || ''}
        style={{ strokeDashoffset: offset }}
      />
    </>
  );
}
