import { memo, useMemo } from 'react';
import { Annotation, HtmlLabel } from '@visx/annotation';
import { AnimatePresence, motion, Variants } from 'framer-motion';
import { useExchanges } from '@store/wallet';
import { AnimateNumber } from '@components';
import { Systems } from '@utils';
import { useMixinOrdersRects } from './hooks';
import { GridSize, Scale } from './utils';

function Orders(props: { xScale: Scale; yScale: Scale }) {
  const { xScale, yScale } = props;
  const orderRects = useMixinOrdersRects();
  const exchanges = useExchanges();
  const mergeRects = useMemo(() => {
    return orderRects.map((item) => {
      const last = item.orders[item.orders.length - 1];
      return {
        ...item,
        amount: item.orders.reduce((curr, next) => (curr += next.amount * exchanges[next.currency]), 0),
        odds: last ? last.odds : 0,
      };
    });
  }, [orderRects, exchanges]);

  const annOptions = useMemo(() => {
    if (Systems.browser.isChrome) {
      return {
        whileTap: { scale: 1.1 },
        variants: variants,
      };
    }
  }, []);

  return (
    <AnimatePresence>
      {mergeRects.map((merge) => {
        const x = xScale(merge.x);
        const y = yScale(merge.y);
        return (
          <Annotation key={merge.key} x={x} y={y} dy={-GridSize}>
            <HtmlLabel
              className="pointer-events-auto text-0"
              showAnchorLine={false}
              horizontalAnchor="start"
              verticalAnchor="start"
            >
              <motion.div
                className="flex-center flex-col truncate bg-colorful1 border-input border-dashed border text-primary_brand"
                style={{ width: GridSize, height: GridSize, fontSize: 8 }}
                initial="initial"
                animate="animate"
                exit="exit"
                {...annOptions}
              >
                {merge.amount > 0 && <AnimateNumber value={merge.amount} currency="USDFIAT" immediate={false} />}
                {merge.amount > 0 && `${merge.odds}x`}
              </motion.div>
            </HtmlLabel>
          </Annotation>
        );
      })}
    </AnimatePresence>
  );
}

export default memo(Orders);

const variants: Variants = {
  initial: { scale: 0.2, borderRadius: GridSize, opacity: 0.2 },
  animate: { scale: 1, borderRadius: 0, opacity: 1 },
  exit: { opacity: 0.2 },
};
