import { memo } from 'react';
import { useSubscribeGame } from '@store/tap';
import ChartView from './ChartView';
import Orders from './Orders';
import PlacePanel from './PlacePanel';
import TradingPairPanel from './TradingPairPanel';

function TapTrading() {
  useSubscribeGame();
  return (
    <>
      <TradingPairPanel />
      <ChartView />
      <PlacePanel />
      <Orders />
    </>
  );
}

export default memo(TapTrading);
