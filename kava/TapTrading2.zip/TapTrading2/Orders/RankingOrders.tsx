import { useMemo, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { TapOrder, useRankingOrders } from '@store/tap';
import { Column, Table } from '@components';
import { formatter } from '@utils';
import GameOrderFilter, { OrderFilter, SortType, TimeType } from '@pages/components/GameOrderFilter';
import Player from '@pages/components/TablePlayer';
import useOrderFields from './useOrderFields';

export default function RankingOrders() {
  const { t } = useTranslation();
  const [filters, setFilters] = useState<OrderFilter>({ timeType: TimeType.Day, sort: SortType.PNL });
  const { data: orders, isValidating: loading } = useRankingOrders(filters);
  const commons = useOrderFields();
  const columns = useMemo<Column<TapOrder>[]>(() => {
    const columns = [...commons];
    columns.splice(commons.length - 1, 0, {
      title: t('ROI'),
      dataIndex: 'roi',
      align: 'right',
      render: ({ roi }) => (
        <div className={roi > 0 ? 'text-up' : 'text-down'}>{formatter.percent(roi / 100, true)}</div>
      ),
    });
    return [
      {
        title: t('Trader'),
        dataIndex: 'user',
        render(order) {
          return <Player {...order} />;
        },
      },
      ...columns,
    ];
  }, [commons, t]);

  return (
    <>
      <GameOrderFilter filters={filters} onChange={setFilters} />
      <Table columns={columns} dataSource={orders} loading={loading} />
    </>
  );
}
