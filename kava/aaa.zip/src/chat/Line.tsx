import { line, curveMonotoneX } from 'd3';
import { useEffect, useRef, useState } from "react";
import { motion, MotionValue, useAnimate, useMotionValue, type SVGMotionProps } from 'motion/react';
import { useScaleX, useScaleY } from './Context';

export function Line (props: LineProps) {
  const {
    line: propsLine,
    point = useMotionValue(0),
    data, ...others
  } = props;
  const prev = useRef({
    latest: 0
  });

  const offset = useMotionValue(0);

  const [scope, animate] = useAnimate<SVGPathElement>();
  const xScale = useScaleX();
  const yScale = useScaleY();

  const [lineFn] = useState(() => {
    return propsLine || line()
      .x(d => xScale(d[0]))
      .y(d => yScale(d[1]))
      .curve(curveMonotoneX);
  });

  useEffect(() => {
    const pathEl = scope.current!;
    const { latest } = prev.current;
    const newLength = pathEl.getTotalLength();
    pathEl.style.strokeDasharray = String(newLength);
    offset.jump(newLength - latest);
    animate(offset, 0, {
      duration: .5,
      ease: 'linear',
      onUpdate(x) {
        point.set(pathEl.getPointAtLength(x).x);
        // console.log(pathEl.getPointAtLength(x))
      }
    });
    prev.current.latest = newLength;

  }, [data]);


  return (
    <motion.path ref={scope} {...others} d={lineFn(data)!}
      // style={{strokeDashoffset: offset}}
    />
  );

}


interface LineProps extends SVGMotionProps<SVGPathElement> {
  data: [number, number][];
  line?: d3.Line<[number, number]>;
  point?: MotionValue<number>;
}