import { scaleLinear, type ScaleLinear } from 'd3';
import { motion } from 'motion/react';
import type { SVGMotionProps } from 'motion/react';
import { createContext, useContext, type PropsWithChildren } from "react";

export function Chart (props: PropsWithChildren<ChartProps>) {
  const {
    width = 900,
    height = 500,
    xScale = scaleLinear().domain([0, 100]).range([0, width]),
    yScale = scaleLinear().domain([0, 100]).range([height, 0]),
    ...others
  } = props;

  return (
    <motion.svg {...others} viewBox={`0 0 ${width} ${height}`}>
      <XScale.Provider value={xScale}>
        <YScale.Provider value={yScale}>
          { props.children }
        </YScale.Provider>
      </XScale.Provider>
    </motion.svg>
  );
}

export interface ChartProps extends SVGMotionProps<SVGSVGElement> {
  width?: number;
  height?: number;
  yScale?: ScaleLinear<number, number>;
  xScale?: ScaleLinear<number, number>;
}


// const Context = createContext<SVGSVGElement>(null as unknown as SVGSVGElement);
const XScale = createContext<ScaleLinear<number, number>>(null as unknown as ScaleLinear<number, number>);
const YScale = createContext<ScaleLinear<number, number>>(null as unknown as ScaleLinear<number, number>);

export function useScaleX () {
  return useContext(XScale);
}

export function useScaleY () {
  return useContext(YScale);
}
