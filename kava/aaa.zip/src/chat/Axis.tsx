import { select, axisBottom, axisLeft, axisRight, axisTop } from "d3";
import type { Selection } from 'd3';
import { memo, useEffect, useMemo, useRef } from "react";
import { motion, type SVGMotionProps } from 'motion/react';
import { useScaleX, useScaleY } from "./Context";

export default memo(function Axis (props: AxisProps) {
  const { direction = 'bottom', ticks = 10, ...others } = props;
  const ref = useRef<Selection<SVGGElement, unknown, null, undefined>>(null);
  const axis = useAxis(direction ?? 'bottom');

  useEffect(() => {
    const axisEl = ref.current!;
    axisEl.call(axis.ticks(ticks));
  }, [ticks]);

  return (
    <motion.g className="axis y-axis" {...others} ref={el => {
      ref.current = el && select(el)
    }} />
  );
});

function useAxis (direction: Direction) {
  const isX = direction === 'bottom' || direction === 'top';
  const scale = isX ? useScaleX() : useScaleY();

  const axis = useMemo(() => {
    switch (direction) {
      case 'left':
        return axisLeft(scale);
      case 'right':
        return axisRight(scale);
      case 'top':
        return axisTop(scale);
      default:
        return axisBottom(scale);
    }
  }, [scale]);

  return axis;
}

type Direction = 'bottom' | 'left' | 'top' | 'right';

export interface AxisProps extends SVGMotionProps<SVGGElement> {
  direction?: Direction,
  ticks?: number;
}
