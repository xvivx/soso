import { useEffect, useState } from 'react'
import './App.css'
import { Chart } from './chat/Context'
import { Line } from './chat/Line'
import Axis from './chat/Axis';
import { scaleLinear } from 'd3';
import { motion, useMotionValue, type TargetAndTransition } from 'motion/react';

function App() {

  const [data, setData] = useState<[number, number][]>(sourceData);
  const pointX = useMotionValue(0);

  useEffect(() => {
    const yMin = 0, yMax = 100;
    const last = data[data.length - 1];
    const timer = setTimeout(() => {
      const delta = (Math.random() * 0.3 - 0.15) * last[1];
      const newData = Math.max(yMin, Math.min(yMax, last[1] + delta));
      setData([...data, [last[0]+1, newData]]);
    }, 1000);
    return () => {
      clearTimeout(timer);
    }
  }, [data]);
  const scale = scaleLinear().domain([0, 100]).range([0, 1e4]);

  const moveX: TargetAndTransition = {
    x: -scale(data[data.length-1][0])+500,
    transition: {
      ease: 'linear',
      duration: .5
    }
  };

  return (
    <Chart xScale={scale}>
      <Line data={data}
        fill='none' stroke='#66d9e8'
        strokeWidth={2}
        transform='translate(-450,0)'
        animate={{
          x: -scale(data[data.length-1][0])+500,
          y: Math.random()*300-150,
          transition: {
            ease: 'linear',
            duration: .5
          }
        }}
        point={pointX}
      />
      <Axis direction='bottom' ticks={100} animate={moveX} />
      <Axis direction='left' ticks={6} />
      <motion.foreignObject x={100} y={30} width={120} height={60} style={{
        x: pointX
      }}>
        0000000
      </motion.foreignObject>
      <motion.foreignObject x={100} y={80} width={120} height={60} style={{
        x: pointX
      }}>
        0000000
      </motion.foreignObject>
    </Chart>
  )
}


function Tooltip () {
  const [count, setCount] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setCount(Date.now())
    }, 1000);
    return () => clearInterval(timer);
  })

  return (
    <foreignObject x={100} y={30} width={120} height={60}>
      {count}
    </foreignObject>
  )
}

export default App

const sourceData: [number, number][] = [
  [0, 46.45889659154335],
  [1, 46.13133194467011],
  [2, 45.072347235971854],
  [3, 40.110668330319136],
  [4, 38.71356330715831],
  [5, 41.15355710587292],
  [6, 42.3190143273753],
  [7, 41.5246318804715],
  [8, 45.53740581791818],
  [9, 47.64947082436963]
];