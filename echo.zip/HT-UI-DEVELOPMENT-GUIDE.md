# HT-UI 组件开发规范

## 项目背景

**HT-UI** 是一个 Vue 3 H5 移动端组件库，采用 Headless UI + 自定义样式的架构。

**技术栈**：
- Vue 3 + TypeScript + Vite
- **Reka UI** (Radix Vue) - Headless UI，提供无障碍逻辑
- Tailwind CSS 4 + CSS 变量（三级 Token 系统）
- **核心目标**：复刻 **Vant UI** 的 API，实现相同的功能和用户体验

## 开发原则

### 1. API 设计

- ✅ **必须兼容 Vant UI 的 API**（props、events、slots）
- ✅ 可以扩展 shadcn-vue 风格的属性（如 `variant`, `asChild`）
- ✅ 使用 `v-model` 进行双向绑定
- ✅ 事件命名遵循 Vant 规范（如 `change`, `click`）

### 2. 技术选型指南

#### 优先使用 Reka UI 的场景

- ✅ **表单组件**：Switch, Checkbox, Radio, Select
- ✅ **交互组件**：需要键盘导航、焦点管理
- ✅ **无障碍要求**：需要 ARIA 属性支持
- ✅ **状态管理**：需要复杂的状态同步（如 Group）

#### 不使用 Reka UI 的场景

- ❌ **纯展示组件**：Skeleton, Empty, Loading
- ❌ **无交互组件**：Image, Icon
- ❌ **简单容器**：Cell, Group, Row, Col

### 3. 组件结构规范

```
component/
├── Component.vue          # 主组件
├── index.ts              # 导出：export { default as HTComponent }
├── types.ts              # TypeScript 类型定义
├── styles/               # 样式系统（复杂组件）
│   ├── tokens.css        # 基于 token.md 的 CSS 变量
│   ├── animations.css    # 动画（如需要）
│   └── index.css         # 样式入口
└── token.md             # 设计 Token 文档（已提供）
```

## 代码模板

### 组件主文件（Component.vue）

```vue
<script setup lang="ts">
import { computed } from 'vue';
import { ComponentRoot } from 'reka-ui'; // 使用 Reka UI
import { cn } from '@/utils/index';
import { useCustomFieldValue, useParent } from '@/hooks';
import type { ComponentProps, ComponentEmits } from './types';
import './styles/index.css'; // 如果有单独样式文件

const props = withDefaults(defineProps<ComponentProps>(), {
  // Vant 的默认值
});

const emit = defineEmits<ComponentEmits>();

const model = defineModel<Type>('modelValue');

// 与 HTForm 集成（必须）
useCustomFieldValue(() => model.value);

// 如果在 Group 中使用，用 useParent
const { parent: parentGroup } = useParent(COMPONENT_GROUP_KEY);
</script>

<template>
  <ComponentRoot
    v-model="model"
    :disabled="disabled"
    :class="cn('ht-component', className)"
  >
    <!-- 内容 -->
  </ComponentRoot>
</template>

<style>
:root {
  /* 从 token.md 转换的 CSS 变量 */
  --component-property: value;
}

@layer components {
  .ht-component {
    /* BEM 类名样式 */
  }
  
  /* 使用 data-* 属性支持 Reka UI 的状态 */
  .ht-component[data-state='checked'] {
    /* 选中状态 */
  }
  
  .ht-component[data-disabled] {
    /* 禁用状态 */
  }
}
</style>
```

### 类型定义（types.ts）

```typescript
export interface ComponentProps {
  modelValue?: Type;
  disabled?: boolean;
  // Vant API 属性
}

export interface ComponentEmits {
  'update:modelValue': [value: Type];
  change: [value: Type];
  click?: [event: MouseEvent];
}
```

### 导出文件（index.ts）

```typescript
export { default as HTComponent } from './Component.vue';
export type { ComponentProps, ComponentEmits } from './types';
```

## 样式开发规范

### Token 系统

```css
/* 从 token.md 转换 */
:root {
  --component-container-width-default: 100px;
  --component-container-height-default: 40px;
  --component-bg-color-default: #ffffff;
  --component-text-color-default: #333333;
  --component-transition-duration: 0.3s;
}
```

### BEM 类名规范

```css
.ht-component {                      /* Block */
  /* 基础样式 */
}

.ht-component__element {             /* Element */
  /* 元素样式 */
}

.ht-component__element--modifier {   /* Modifier */
  /* 修饰符样式 */
}

/* 状态样式（支持 Reka UI） */
.ht-component[data-state='checked'] {
  /* 选中状态 */
}

.ht-component[data-disabled] {
  /* 禁用状态 */
}
```

## 文档开发规范

### 文档结构

```
docs/components/component/
├── examples/
│   ├── Basic.vue           # 基础用法（必须）
│   ├── Disabled.vue        # 禁用状态（常用）
│   ├── Size.vue            # 尺寸（如适用）
│   ├── CustomColor.vue     # 自定义颜色（如适用）
│   └── ...                 # 至少 5-7 个示例
└── index.md               # 组件文档
```

### 示例文件规范

```vue
<script setup lang="ts">
import { ref } from 'vue';
import { HTComponent, HTButton } from 'ht-ui'; // ✅ 使用 ht-ui 别名

const value = ref(defaultValue);
</script>

<template>
  <!-- 使用项目组件，如 HTButton 触发 -->
  <HTButton type="primary" @click="...">操作</HTButton>
  <HTComponent v-model="value" />
</template>
```

### 文档模板（index.md）

````markdown
# Component 组件名

组件的简短描述。

## 基础用法
通过 v-model 绑定状态。
<demo vue="./examples/Basic.vue" codesandbox="true" />

## 禁用状态
通过 disabled 属性禁用组件。
<demo vue="./examples/Disabled.vue" codesandbox="true" />

## API

### Props

| 参数        | 说明           | 类型      | 默认值  |
| ----------- | -------------- | --------- | ------- |
| v-model     | 绑定值         | `Type`    | -       |
| disabled    | 是否禁用       | `boolean` | `false` |

### Events

| 事件名 | 说明         | 参数         |
| ------ | ------------ | ------------ |
| change | 值变化时触发 | `value: Type` |
| click  | 点击时触发   | `event: MouseEvent` |

### Slots

| 名称    | 说明         | 参数                    |
| ------- | ------------ | ----------------------- |
| default | 自定义内容   | `{ value, disabled }`   |

### 类型定义

```ts
import type {
  ComponentProps,
  ComponentEmits
} from 'ht-ui';
```
````

## 集成配置

### 1. 组件导出（src/components/index.ts）

```typescript
// Component
export { HTComponent } from './component';
export type * from './component';
```

### 2. 文档配置（docs/.vitepress/config.ts）

```typescript
sidebar: [
  {
    text: '表单组件',
    items: [
      { text: 'Component 组件', link: '/components/component' },
    ],
  },
]
```

## 常见模式参考

### 1. Form 集成模式（必须）

```typescript
import { useCustomFieldValue } from '@/hooks';

const model = defineModel<Type>('modelValue');
useCustomFieldValue(() => model.value);
```

### 2. Group 父子通信模式

```typescript
// Parent (Group 组件)
import { useChildren } from '@/hooks';
import { COMPONENT_GROUP_KEY } from '@/utils/injectionKey';

const { linkChildren } = useChildren(COMPONENT_GROUP_KEY);
const updateValue = (value) => { model.value = value; };
linkChildren({ props, updateValue });

// Child (Item 组件)
import { useParent } from '@/hooks';
import { COMPONENT_GROUP_KEY } from '@/utils/injectionKey';

const { parent } = useParent(COMPONENT_GROUP_KEY);
const groupDisabled = computed(() => parent?.props.disabled);
```

### 3. 双向绑定与值转换模式

```typescript
// 适用于 Switch 等支持自定义值的组件
const checked = computed({
  get: () => model.value === props.activeValue,
  set: (value: boolean) => {
    const newValue = value ? props.activeValue : props.inactiveValue;
    model.value = newValue;
    emit('update:modelValue', newValue);
    emit('change', newValue);
  },
});
```

### 4. 动态尺寸计算模式（Vant 风格）

```typescript
const componentSize = computed(() => {
  const size = typeof props.size === 'number' ? `${props.size}px` : props.size;
  const sizeNum = parseInt(size);
  
  return {
    width: `${sizeNum}px`,
    height: `${sizeNum}px`,
    '--custom-var': `${sizeNum - 4}px`,
  };
});
```

## 验收清单

### 功能验收
- [ ] API 与 Vant 完全兼容
- [ ] v-model 双向绑定工作正常
- [ ] 所有 props、events、slots 都实现
- [ ] 支持键盘导航（如适用）
- [ ] 支持无障碍（ARIA 属性）

### 代码质量
- [ ] 无 TypeScript 错误
- [ ] 无 ESLint 错误
- [ ] 使用 Reka UI（如适用）
- [ ] 使用 useCustomFieldValue
- [ ] BEM 类名规范

### 文档完整性
- [ ] 至少 5-7 个示例
- [ ] API 文档完整
- [ ] 已添加到 VitePress 配置
- [ ] 示例使用 HTButton 等项目组件

### 导出配置
- [ ] index.ts 使用命名导出
- [ ] 已添加到 src/components/index.ts
- [ ] 无重复导出

## 快速开始

```bash
# 1. 创建组件目录
mkdir -p src/components/component
mkdir -p src/components/component/styles
mkdir -p docs/components/component/examples

# 2. 创建必要文件
touch src/components/component/Component.vue
touch src/components/component/types.ts
touch src/components/component/index.ts
touch docs/components/component/index.md

# 3. 运行开发服务器
pnpm run dev

# 4. 查看文档
pnpm run docs:dev
```

## 常用工具函数

```typescript
import { cn } from '@/utils';                    // 类名合并
import { addUnit } from '@/utils';              // 添加单位（如 px）
import { useCustomFieldValue } from '@/hooks';  // Form 集成
import { useParent, useChildren } from '@/hooks'; // 父子通信
```

## 项目已完成组件参考

| 组件 | Reka UI | 复杂度 | 参考价值 |
|------|---------|--------|----------|
| Radio + RadioGroup | ✅ RadioGroupItem | ⭐⭐ | 父子通信模式 |
| Switch | ✅ SwitchRoot | ⭐⭐ | 值转换、动态尺寸 |
| Checkbox + CheckboxGroup | ✅ CheckboxRoot | ⭐⭐⭐ | 半选状态、最大选择 |
| Button | ❌ | ⭐ | 样式系统、variants |
| Select | ✅ HTPopover | ⭐⭐ | Popover 使用 |
| ActionSheet | ✅ HTPopover | ⭐⭐ | 底部弹出 |
| Skeleton | ❌ | ⭐ | 纯展示组件 |
| DatePicker | ❌ | ⭐⭐⭐ | 滚动选择器 |

---

**遵循此规范开发，确保组件质量和一致性！**

