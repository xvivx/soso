import tailwindcss from '@tailwindcss/postcss';
import autoprefixer from 'autoprefixer';

export default {
  plugins: [
    tailwindcss(),
    autoprefixer(),
    {
      postcssPlugin: 'remove-tailwind-layer',
      AtRule(atRule) {
        if (atRule.name === 'layer') {
          atRule.replaceWith(atRule.nodes);
        }
      },
    },
  ],
};
