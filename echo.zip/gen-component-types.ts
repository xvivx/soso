import fs from 'fs';

const components = [
  'HTButton',
  'HTSelect',
  'HTOption',
  'HTModal',
  'HTPopover',
  'HTCellGroup',
  'HTCell',
  'HTField',
  'HTCollapseItem',
  'HTCollapse',
  'HTRadio',
  'HTRadioGroup',
  'HTList',
  'HTForm',
  'HTRow',
  'HTCol',
  'HTDivider',
  'HTSticky',
  'HTSwipe',
  'HTSwipeItem',
  'HTPullRefresh',
  'HTLoading',
  'HTImage',
  'HTTabs',
  'HTTab',
  'HTToast',
  'HTTooltip',
  'HTCheckboxGroup',
  'HTSwitch',
  'HTActionSheet',
  'HTDatePicker',
  'HTNumberKeyboard',
  'HTSkeleton',
  'HTTag',
  'HTPinInput',
];

const types = components.map((component) => {
  const name = component;
  const pascal = 'Ht' + component.slice(2);
  const kebab = 'ht' + component.slice(2).replace(/[A-Z]/g, (match) => `-${match.toLowerCase()}`);

  return {
    vue: [
      `${pascal}: typeof import('@hytech/ht-ui')['${name}']`,
      `'${kebab}': typeof import('@hytech/ht-ui')['${name}']`,
    ],
    jsx: `const ${pascal}: (typeof import('@hytech/ht-ui'))['${name}'];`,
  };
});

const content = `/* eslint-disable */
// 自动生成的文件, 不要修改它, 会被覆盖
import type { GlobalComponents } from 'vue';

export {};

/* prettier-ignore */
declare module 'vue' {
  export interface GlobalComponents {
    ${types
      .map((item) => item.vue)
      .flat()
      .join('\n    ')}
  }
}

// For TSX support
declare global {
  ${types.map((item) => item.jsx).join('\n  ')}
}`;

fs.writeFileSync('./src/component-list.d.ts', content);
