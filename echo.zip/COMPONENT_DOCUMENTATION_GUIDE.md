# 组件文档生成指南

本指南提供了一套完整的组件文档生成标准，确保 AI 能够按照项目规范生成高质量、一致的组件文档。

## 目录

1. [文档类型与结构](#文档类型与结构)
2. [VitePress 静态文档模板](#vantpress-静态文档模板)
3. [Vue Demo 文档模板](#vue-demo-文档模板)
4. [Demo 示例文件模板](#demo-示例文件模板)
5. [内容组织标准](#内容组织标准)
6. [API 文档规范](#api-文档规范)
7. [示例代码规范](#示例代码规范)
8. [AI 生成指导模板](#ai-生成指导模板)
9. [文档更新流程](#文档更新流程)
10. [质量检查清单](#质量检查清单)

---

## 文档类型与结构

本项目采用三层文档架构：

### 1. VitePress 静态文档 (`docs/components/[name]/index.md`)
- **用途**: 组件的静态说明文档，用于 VitePress 站点展示
- **特点**: 使用 Markdown 格式，包含 demo 组件引用
- **结构**:
  ```
  docs/components/[component-name]/
  ├── index.md              # 主文档
  ├── [demo-name].vue       # Demo 示例文件
  └── [demo-name].vue       # 其他 Demo 文件
  docs/.vitepress/config.ts # VitePress 路由配置
  ```

### 2. Vue Demo 文档 (`src/docs/[name].vue`)
- **用途**: 交互式演示文档，自动生成路由
- **特点**: 完整的 Vue 组件，展示所有功能特性
- **结构**: 单文件包含多个演示区块

### 3. 组件内部文档 (`src/components/[name]/README.md`)
- **用途**: 组件的详细 API 文档
- **特点**: 面向开发者的技术文档

---

## VitePress 静态文档模板

### 基础模板结构

```markdown
# HT[ComponentName] 组件名称

一句话描述组件的主要功能和用途。参照 Element 与 Vant 的结合式用法。

## 基础用法

<demo vue="./[component-basic.vue]" codesandbox="true" />

## [功能特性1]

<demo vue="./[component-feature1].vue" codesandbox="true" />

## [功能特性2]

<demo vue="./[component-feature2].vue" codesandbox="true" />

## 高级特性

<demo vue="./[component-advanced.vue]" codesandbox="true" />

## Attributes

| Attribute | Description | Type | Default |
| --- | --- | --- | --- |
| `prop1` | 属性说明 | `type` | `defaultValue` |
| `prop2` | 属性说明 | `type | union` | `defaultValue` |

## Events

| Event | Description | Parameters |
| --- | --- | --- |
| `event1` | 事件说明 | `(param1: Type1, param2: Type2)` |

## Slots

| Slot | Description |
| --- | --- |
| `default` | 默认插槽说明 |
| `icon` | 图标插槽说明 |

## Methods

| Method | Description | Parameters |
| --- | --- | --- |
| `method1` | 方法说明 | `(param: Type)` |

## 主题定制

要求：
- 读取 ./H5组件三级token.md 中的 token 变量规范，和该文件对齐，确保组件的主题定制与 token 变量一致

```css
.ht-component {
  --ht-component-property: value;
}
```

## Vant API 兼容性

| Vant API | HT 实现 | 说明 |
| --- | --- | --- |
| 属性名 | ✅ 完全兼容 | 无差异 |
| 属性名 | ⚠️ 部分兼容 | 有细微差异 |
| 属性名 | ❌ 不支持 | 使用替代方案 |
```

### 实际示例

```markdown
# HTButton 按钮

基础按钮组件，支持多种类型、尺寸和状态。参照 Element 与 Vant 的结合式用法。

## 基础用法

<demo vue="./button-basic.vue" codesandbox="true" />

## 按钮类型

<demo vue="./button-types.vue" codesandbox="true" />

## 按钮尺寸

<demo vue="./button-sizes.vue" codesandbox="true" />

## 加载状态

<demo vue="./button-loading.vue" codesandbox="true" />

## Attributes

| Attribute | Description | Type | Default |
| --- | --- | --- | --- |
| `type` | 按钮类型 | `'primary' \| 'success' \| 'warning' \| 'danger' \| 'default'` | `'default'` |
| `size` | 按钮尺寸 | `'large' \| 'normal' \| 'small' \| 'mini'` | `'normal'` |
| `disabled` | 是否禁用 | `boolean` | `false` |
| `loading` | 是否加载中 | `boolean` | `false` |
| `text` | 按钮文本 | `string` | - |
| `icon` | 左侧图标 | `string` | - |

## Events

| Event | Description | Parameters |
| --- | --- | --- |
| `click` | 点击按钮时触发 | `(event: MouseEvent)` |

## Slots

| Slot | Description |
| --- | --- |
| `default` | 按钮内容 |
| `icon` | 自定义图标 |
| `loading` | 自定义加载状态 |

## 主题定制

```css
.ht-button {
  --ht-button-primary-bg: #1677ff;
  --ht-button-border-radius: 4px;
  --ht-button-padding-horizontal: 16px;
}
```

## Vant API 兼容性

| Vant API | HT 实现 | 说明 |
| --- | --- | --- |
| type | ✅ 完全兼容 | 支持 default, primary, success, warning, danger |
| size | ✅ 完全兼容 | 支持 large, normal, small, mini |
| plain | ❌ 不支持 | 使用 variant="outline" 替代 |
| round | ✅ 完全兼容 | 通过 CSS 变量控制 |
```

---

## Vue Demo 文档模板

### 基础结构

```vue
<template>
  <div class="[component-name]-demo space-y-8 p-6">
    <h1 class="mb-6 text-2xl font-bold">HT[ComponentName] 组件标题</h1>

    <!-- 基础用法 -->
    <section class="space-y-4">
      <h2 class="text-xl font-semibold">基础用法</h2>
      <div class="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-4">
        <div class="rounded-lg border p-4">
          <h3 class="mb-2 text-sm font-medium">示例1名称</h3>
          <HTComponent prop="value" />
        </div>
        <div class="rounded-lg border p-4">
          <h3 class="mb-2 text-sm font-medium">示例2名称</h3>
          <HTComponent prop="value2" />
        </div>
      </div>
    </section>

    <!-- 高级特性 -->
    <section class="space-y-4">
      <h2 class="text-xl font-semibold">高级特性</h2>
      <div class="rounded-lg border p-4">
        <h3 class="mb-2 text-sm font-medium">特性说明</h3>
        <HTComponent :advanced-prop="advancedValue" @event="handleEvent" />
      </div>
    </section>

    <!-- Vant API 兼容性演示 -->
    <section class="space-y-4">
      <h2 class="text-xl font-semibold">Vant API 兼容性</h2>
      <div class="rounded-lg border bg-gray-50 p-4">
        <h3 class="mb-2 text-sm font-medium">完全兼容 Vant [ComponentName] API</h3>
        <pre class="overflow-x-auto rounded border bg-white p-2 text-xs"><code>{{ vantApiExample }}</code></pre>
      </div>
    </section>

    <!-- 响应式测试 -->
    <section class="space-y-4">
      <h2 class="text-xl font-semibold">响应式测试</h2>
      <div class="rounded-lg border p-4">
        <p class="mb-2 text-sm text-gray-600">调整浏览器大小查看响应式效果</p>
        <HTComponent responsive-prop="value" />
      </div>
    </section>

    <!-- 无障碍演示 -->
    <section class="space-y-4">
      <h2 class="text-xl font-semibold">无障碍支持</h2>
      <div class="rounded-lg border p-4">
        <p class="mb-2 text-sm text-gray-600">屏幕阅读器支持说明</p>
        <HTComponent
          :aria-label="accessibilityLabel"
          accessibility-prop="value"
        />
        <p class="mt-2 text-xs text-gray-500">支持键盘导航和屏幕阅读器</p>
      </div>
    </section>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import { HTComponent } from '@/components/[component-path]';

// 响应式数据
const basicValue = ref('默认值');
const advancedValue = ref('高级值');
const accessibilityLabel = ref('组件用途说明');

// 事件处理
const handleEvent = (params: any) => {
  console.log('事件触发:', params);
};

// Vant API 示例代码
const vantApiExample = `// Vant 兼容的 API
<HTComponent
  basic-prop="value"
  :advanced-prop="advancedValue"
  @event="handleEvent"
  class="custom-class"
/>

// 完全兼容 Vant 的 props 命名和默认值`;
</script>

<style scoped>
/* 仅需要少量自定义样式,其他使用 Tailwind */
.[component-name]-demo {
  max-width: 1200px;
  margin: 0 auto;
}

/* 如有特殊需求的自定义样式,使用原生 CSS + CSS 变量 */
.custom-style {
  /* 使用项目的 CSS 变量 */
  padding: var(--ht-spacing-lg);
  border-radius: var(--ht-border-radius-md);
}
</style>
```

---

## Demo 示例文件模板

### 基础示例文件

```vue
<template>
  <div class="demo-[component-name]-basic">
    <HTComponent
      :prop="value"
      @event="handleEvent"
    >
      <template #default>默认内容</template>
    </HTComponent>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import { HTComponent } from 'ht-ui';

const value = ref('示例值');
const handleEvent = () => {
  console.log('事件触发');
};
</script>

<style scoped>
.demo-[component-name]-basic {
  width: 100%;
  max-width: 800px;
  margin: 0 auto;
  padding: 20px;
}
</style>
```

---

## 内容组织标准

### 必含章节

1. **基础用法** - 最简单的使用示例
2. **API 文档** - Props、Events、Slots、Methods
3. **Vant API 兼容性** - 兼容性对照表

### 推荐章节

1. **高级特性** - 复杂功能展示
2. **主题定制** - CSS Token 使用说明
3. **响应式设计** - 不同设备适配
4. **无障碍支持** - ARIA 和键盘导航

### 可选章节

1. **性能优化** - 最佳实践
2. **常见问题** - FAQ
3. **迁移指南** - 从其他组件库迁移

### 章节命名规范

- 使用中文标题，简洁明了
- 按照从简单到复杂的顺序组织
- 每个章节都应该有对应的实际示例

---

## API 文档规范

### Props 表格格式

```markdown
| Attribute | Description | Type | Default | Vant 兼容 |
| --- | --- | --- | --- | --- |
| `prop-name` | 属性说明，简洁明了 | `'type1' \| 'type2'` | `'defaultValue'` | ✅ |
| `advanced-prop` | 复杂属性说明 | `ComplexType \| union` | `complexDefault` | ⚠️ |
```

**规范要求:**
- 属性名使用反引号包围
- 类型使用 TypeScript 语法
- 默认值明确标注
- Vant 兼容性使用图标标识

### Events 表格格式

```markdown
| Event | Description | Parameters | Vant 兼容 |
| --- | --- | --- | --- |
| `event-name` | 事件说明 | `(param1: Type1, param2: Type2)` | ✅ |
| `complex-event` | 复杂事件说明 | `(event: CustomEvent)` | ✅ |
```

### Slots 表格格式

```markdown
| Slot | Description | Parameters | Vant 兼容 |
| --- | --- | --- | --- |
| `default` | 默认插槽说明 | - | ✅ |
| `named-slot` | 命名插槽说明 | `{ prop: Type }` | ✅ |
```

### Methods 表格格式

```markdown
| Method | Description | Parameters | Return | Vant 兼容 |
| --- | --- | --- | --- | --- |
| `methodName` | 方法说明 | `(param: Type)` | `ReturnType` | ✅ |
```

---

## 示例代码规范

### Vue 模板规范

```vue
<template>
  <!-- 使用语义化的 HTML 标签 -->
  <section class="demo-section">
    <h2 class="section-title">标题</h2>

    <!-- 组件示例 -->
    <div class="demo-container">
      <HTComponent
        :prop="value"
        @event="handleEvent"
      />
    </div>

    <!-- 说明文字 -->
    <p class="demo-description">说明文字</p>
  </section>
</template>
```

### Script Setup 规范

```typescript
<script setup lang="ts">
import { ref, computed, onMounted } from 'vue';
import { HTComponent } from '@/components/[component-path]';

// 1. 导入和类型定义
interface CustomType {
  prop: string;
}

// 2. 响应式数据
const value = ref('默认值');
const isVisible = ref(false);

// 3. 计算属性
const computedValue = computed(() => {
  return value.value.toUpperCase();
});

// 4. 事件处理函数
const handleEvent = (params: CustomType) => {
  console.log('事件触发:', params);
};

// 5. 生命周期
onMounted(() => {
  console.log('组件挂载');
});
</script>
```

### 样式规范

```css
<style scoped>
/* 1. 使用 BEM 命名规范 + Tailwind CSS */
.demo-component {
  /* 2. 使用 CSS 变量 */
  --demo-padding: var(--ht-spacing-lg);

  /* 3. 布局属性 - 优先使用 Tailwind */
  @apply flex flex-col;
  padding: var(--demo-padding);
}

/* 4. 子元素样式 */
.demo-component__header {
  @apply font-semibold;
  margin-bottom: var(--ht-spacing-md);
}

/* 5. 状态样式 */
.demo-component--active {
  background-color: var(--ht-color-primary);
}

/* 6. 响应式设计 - 使用 Tailwind 或原生 CSS */
@media (max-width: 768px) {
  .demo-component {
    padding: var(--ht-spacing-md);
  }
}
</style>
```

---

## AI 生成指导模板

### 完整提示词模板

```
你是一个专业的 Vue 组件文档专家，需要为 HT[ComponentName] 组件生成完整的文档套件。

## 组件信息
- 组件名称: HT[ComponentName]
- 组件用途: [一句话描述组件功能]
- 兼容标准: 完全兼容 Vant [ComponentName] API
- 技术栈: Vue 3 + TypeScript + Tailwind CSS

## 需要生成的文档

### 1. VitePress 静态文档
路径: docs/components/[component-name]/index.md
要求:
- 使用标准的 VitePress 文档模板
- 包含基础用法和所有功能特性
- 添加 <demo> 标签引用示例文件
- 包含完整的 API 表格
- 添加 Vant API 兼容性对照表

### 2. Vue Demo 文档
路径: src/docs/[component-name].vue
要求:
- 创建完整的交互式演示页面
- 展示所有 Props、Events、Slots 的用法
- 包含响应式设计和无障碍支持演示
- 添加 Vant API 兼容性说明
- 使用 Tailwind CSS 进行样式设计

### 3. Demo 示例文件
路径: docs/components/[component-name]/[demo-name].vue
要求:
- 为每个主要功能创建独立的 demo 文件
- 文件命名遵循 [component]-[feature].vue 格式
- 每个文件都应该有清晰的注释和说明
- 样式使用 Tailwind CSS 为主,配合 CSS 变量

### 4. 路由信息更新
路径：docs/.vitepress/config.ts
要求：
- 添加新路由项，指向新的 Vue Demo 文档
- 在 docs/components.md 中添加新组件路由项

## API 信息
基于以下 API 信息生成文档:

Props:
[列出所有 Props，包括类型、默认值、说明]

Events:
[列出所有 Events，包括参数、说明]

Slots:
[列出所有 Slots，包括说明]

Methods:
[列出所有 Methods，包括参数、返回值、说明]

## 文档结构要求

### VitePress 文档结构:
1. 组件介绍
2. 基础用法
3. 主要功能特性（3-5个）
4. 高级特性
5. API 文档（Props、Events、Slots、Methods）
6. 主题定制
7. Vant API 兼容性

### Vue Demo 文档结构:
1. 组件标题
2. 基础用法演示
3. 功能特性演示（网格布局）
4. 高级特性演示
5. Vant API 兼容性演示
6. 响应式测试
7. 无障碍支持演示

## 质量要求
1. 所有代码示例都必须是可运行的
2. 使用 TypeScript 进行类型标注
3. 遵循 Vue 3 Composition API 最佳实践
4. 代码注释清晰明了
5. 样式使用 Tailwind CSS + 原生 CSS(禁用 SCSS)
6. CSS 变量用于主题定制
7. 确保响应式设计
8. 包含无障碍支持

## 输出格式
请按照以下顺序输出:
1. VitePress 静态文档 (index.md)
2. Vue Demo 文档 ([component-name].vue)
3. Demo 示例文件列表和内容

每完成一个文档，请说明文件路径和主要内容。
```

### 分步骤生成提示词

```
## 第一步: 生成 VitePress 静态文档

为 HT[ComponentName] 组件生成 VitePress 静态文档，包含:
- 组件介绍和基础用法
- 3-5个主要功能特性的 demo 引用
- 完整的 API 表格
- Vant API 兼容性对照表
- 主题定制说明

请输出完整的 index.md 文件内容。

## 第二步: 生成 Vue Demo 文档

为 HT[ComponentName] 组件生成交互式演示页面，包含:
- 完整的 Vue 3 组件结构
- 响应式设计演示
- 无障碍支持演示
- Vant API 兼容性说明代码示例
- Tailwind CSS + 原生 CSS 样式(不使用 SCSS)

请输出完整的 [component-name].vue 文件内容。

## 第三步: 生成 Demo 示例文件

为每个主要功能生成独立的 demo 文件，包含:
- [component-basic.vue] - 基础用法
- [component-feature1.vue] - 功能特性1
- [component-feature2.vue] - 功能特性2
- [component-advanced.vue] - 高级特性

请输出所有 demo 文件的内容。
```

---

## 文档更新流程

### 新组件文档创建步骤

1. **创建目录结构**
   ```bash
   mkdir -p docs/components/[component-name]
   ```

2. **生成 VitePress 文档**
   - 创建 `docs/components/[component-name]/index.md`
   - 生成相应的 demo 文件

3. **创建 Vue Demo 文档**
   - 创建 `src/docs/[component-name].vue`
   - 确保路由自动生成

4. **更新组件索引**
   - 更新 `docs/components.md`
   - 添加新组件链接

5. **验证文档**
   - 检查所有链接是否正确
   - 确保代码示例可运行

### 文档更新维护规范

1. **版本同步**
   - 组件 API 变更时同步更新文档
   - 新增功能时添加对应示例
   - 移除废弃 API 时更新文档

2. **质量检查**
   - 定期检查代码示例的准确性
   - 验证链接的有效性
   - 确保文档格式一致

3. **内容审核**
   - 技术准确性审核
   - 文档规范性检查
   - 用户体验测试

### 版本同步要求

1. **API 变更同步**
   - 新增 Props: 在文档中添加对应说明
   - 修改 Props: 更新类型、默认值、说明
   - 移除 Props: 标记为废弃并提供迁移方案

2. **功能变更同步**
   - 新功能: 添加新的 demo 和文档章节
   - 功能修改: 更新相关示例和说明
   - 功能移除: 提供替代方案和迁移指南

3. **兼容性更新**
   - Vant API 变更: 更新兼容性对照表
   - 浏览器兼容: 更新支持说明
   - 依赖库升级: 检查示例代码兼容性

---

## 质量检查清单

### 文档完整性检查

- [ ] 组件介绍清晰明了
- [ ] 基础用法示例完整
- [ ] 所有 Props 都有文档说明
- [ ] 所有 Events 都有参数说明
- [ ] 所有 Slots 都有用途说明
- [ ] Vant API 兼容性对照表完整
- [ ] 主题定制说明清晰

### 代码示例检查

- [ ] 所有示例代码都可以正常运行
- [ ] TypeScript 类型标注正确
- [ ] Vue 3 Composition API 语法正确
- [ ] 响应式设计适配良好
- [ ] 无障碍属性设置正确
- [ ] 错误处理机制完善

### 文档格式检查

- [ ] Markdown 语法正确
- [ ] 表格格式规范
- [ ] 代码块语言标注正确
- [ ] 链接引用有效
- [ ] 图片资源存在
- [ ] 文件路径正确

### 用户体验检查

- [ ] 文档层次结构清晰
- [ ] 内容由简到难组织
- [ ] 示例实用性强
- [ ] 查找信息便捷
- [ ] 移动端阅读体验良好

### 技术准确性检查

- [ ] API 描述准确无误
- [ ] 类型定义正确
- [ ] 示例代码与实际组件一致
- [ ] 兼容性信息准确
- [ ] 最佳实践建议合理

---

## 常见问题解决方案

### Q: 如何处理复杂的 Props 类型？

A: 使用 TypeScript 语法清晰地定义复杂类型：

```markdown
| `complex-prop` | 复杂属性说明 | `Array<{ id: string; name: string; value: number }>` | `[]` |
```

### Q: 如何展示动态内容？

A: 在 demo 文件中使用响应式数据和计算属性：

```vue
<script setup lang="ts">
import { ref, computed } from 'vue';

const items = ref(['item1', 'item2']);
const computedItems = computed(() => items.value.map(item => item.toUpperCase()));
</script>
```

### Q: 如何确保响应式设计？

A: 在样式中使用 Tailwind CSS 的响应式类：

```css
<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4">
```

### Q: 如何添加无障碍支持？

A: 使用 ARIA 属性和语义化 HTML：

```vue
<button
  :aria-label="buttonLabel"
  :aria-pressed="isPressed"
  @click="handleClick"
>
  按钮文本
</button>
```

---

通过遵循本指南，AI 可以生成高质量、标准化、易维护的组件文档，确保文档的一致性和实用性。