import { configureVueProject, defineConfigWithVueTs, vueTsConfigs } from '@vue/eslint-config-typescript';
import prettier from 'eslint-plugin-prettier';
import pluginVue from 'eslint-plugin-vue';
import { globalIgnores } from 'eslint/config';

configureVueProject({ scriptLangs: ['ts', 'tsx'] });
// More info at https://github.com/vuejs/eslint-config-typescript/#advanced-setup

export default defineConfigWithVueTs(
  {
    name: 'app/files-to-lint',
    files: ['**/*.{ts,mts,tsx,vue}'],
  },

  globalIgnores(['**/dist/**', '**/dist-ssr/**', '**/docs-dist/**']),

  pluginVue.configs['flat/essential'],
  vueTsConfigs.recommended,
  {
    plugins: {
      prettier,
    },
    rules: {
      'prettier/prettier': 'warn',
      '@typescript-eslint/no-unused-expressions': 'off',
      'vue/multi-word-component-names': 'off',
      '@typescript-eslint/no-unused-vars': [
        'warn',
        {
          varsIgnorePattern: '^_', // ✅ 忽略以 _ 开头的变量
          caughtErrorsIgnorePattern: '^_', // ✅ 忽略 try/catch 中以 _ 开头的错误变量
        },
      ],
      // 允许使用显式 any（避免因实验性快速迭代被阻塞）
      '@typescript-eslint/no-explicit-any': 'off',
    },
  }
);
