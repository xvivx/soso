import type { ComponentResolver } from 'unplugin-vue-components';
import Components from 'unplugin-vue-components/vite';

function htResolver(): ComponentResolver {
  return {
    type: 'component',
    resolve: (name: string) => {
      if (name.toLowerCase().startsWith('ht')) {
        const componentName = 'HT' + name.slice(2);
        return {
          name: componentName,
          from: '@hytech/ht-ui',
        };
      }
    },
  };
}

export default function htAutoImportPlugin() {
  return Components({
    dts: false,
    dtsTsx: false,
    syncMode: 'overwrite',
    resolvers: [htResolver()],
  });
}
