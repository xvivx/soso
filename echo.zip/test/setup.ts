import { h } from 'vue';
import { config } from '@vue/test-utils';
import { vi } from 'vitest';
import '@testing-library/jest-dom';

// 全局 Vue 测试配置
config.global.mocks = {
  // 模拟国际化函数
  $t: (key: string) => key,
  $i18n: {
    t: (key: string) => key,
    locale: 'en',
    availableLocales: ['en', 'zh'],
  },
};

// DOM API 模拟
global.ResizeObserver = vi.fn().mockImplementation(() => ({
  observe: vi.fn(),
  unobserve: vi.fn(),
  disconnect: vi.fn(),
}));

global.IntersectionObserver = vi.fn().mockImplementation(() => ({
  observe: vi.fn(),
  unobserve: vi.fn(),
  disconnect: vi.fn(),
}));

// 模拟 window.getComputedStyle
Object.defineProperty(window, 'getComputedStyle', {
  value: vi.fn(() => ({
    getPropertyValue: vi.fn(() => ''),
  })),
});

// 模拟 matchMedia
Object.defineProperty(window, 'matchMedia', {
  writable: true,
  value: vi.fn().mockImplementation((query) => ({
    matches: false,
    media: query,
    onchange: null,
    addListener: vi.fn(), // deprecated
    removeListener: vi.fn(), // deprecated
    addEventListener: vi.fn(),
    removeEventListener: vi.fn(),
    dispatchEvent: vi.fn(),
  })),
});

// 模拟 HTMLElement.prototype.scrollIntoView
HTMLElement.prototype.scrollIntoView = vi.fn();

// 模拟 HTMLElement.prototype.scrollTo
HTMLElement.prototype.scrollTo = vi.fn();

// 模拟 localStorage
const localStorageMock = {
  getItem: vi.fn(),
  setItem: vi.fn(),
  removeItem: vi.fn(),
  clear: vi.fn(),
};
vi.stubGlobal('localStorage', localStorageMock);

// 模拟 sessionStorage
const sessionStorageMock = {
  getItem: vi.fn(),
  setItem: vi.fn(),
  removeItem: vi.fn(),
  clear: vi.fn(),
};
vi.stubGlobal('sessionStorage', sessionStorageMock);

// 模拟 requestAnimationFrame
global.requestAnimationFrame = vi.fn((cb: FrameRequestCallback) => {
  // setTimeout returns a NodeJS.Timeout in Node; cast to number to satisfy the browser typedef
  const id = setTimeout(() => cb(performance?.now?.() ?? Date.now()), 0) as unknown as number;
  return id;
});
global.cancelAnimationFrame = vi.fn((id: number) => {
  clearTimeout(id as unknown as number);
});

// 模拟 CSS.supports
Object.defineProperty(window, 'CSS', {
  value: {
    supports: vi.fn(() => true),
  },
});

// 模拟 @vueuse/core - 保留原始模块的其他导出
vi.mock('@vueuse/core', async (importOriginal) => {
  const original = (await importOriginal()) as typeof import('@vueuse/core');
  return {
    ...original,
    useIntersectionObserver: vi.fn(),
  };
});

// 模拟 ConfigProvider 注入
vi.mock('@/components/config-provider/useConfigProvider', () => ({
  ConfigProviderKey: Symbol('config-provider'),
  useConfigProvider: () => ({
    theme: { value: 'light' },
    iconPrefix: { value: 'ht-icon' },
    zIndex: { value: undefined },
    locale: { value: 'zh-CN' },
    localeMessages: { value: {} },
  }),
}));

// 模拟 HTIcon 组件
vi.mock('@/components/icon', () => {
  const HTIcon = {
    name: 'HTIcon',
    props: ['name', 'size', 'color', 'classPrefix', 'tag'],
    emits: ['click'],
    setup(props: any, { emit, attrs }: any) {
      const onClick = (event: MouseEvent) => {
        emit('click', event);
      };

      const onKeydown = (event: KeyboardEvent) => {
        // For Vue Test Utils, trigger click directly for keyboard events
        if (event.key === 'Enter' || event.key === ' ') {
          event.preventDefault();
          const mouseEvent = new MouseEvent('click', {
            bubbles: true,
            cancelable: true,
          });
          emit('click', mouseEvent);
        }
      };

      return () => {
        if (props.name === 'cross') {
          return h(
            'span',
            {
              class: ['ht-tag__close', attrs.class],
              onClick,
              onKeydown,
              'aria-label': '关闭',
              role: 'button',
              tabindex: '0',
              ...attrs,
            },
            '×'
          );
        }
        return h('i', {
          class: ['ht-icon', attrs.class],
          onClick,
          ...attrs,
        });
      };
    },
  };

  return { default: HTIcon };
});

// 清理函数
afterEach(() => {
  vi.clearAllMocks();
});
