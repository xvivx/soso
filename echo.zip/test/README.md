# 测试文档

## 📋 目录

- [概述](#概述)
- [测试架构](#测试架构)
- [运行测试](#运行测试)
- [编写测试](#编写测试)
- [最佳实践](#最佳实践)
- [故障排除](#故障排除)

## 概述

本项目使用 **Vitest** 作为测试框架，为 Vue 3 组件库提供全面的测试覆盖。测试体系包括：

- **单元测试**: 测试单个组件的功能
- **集成测试**: 测试组件间的交互
- **快照测试**: 确保组件结构稳定
- **可访问性测试**: 验证 ARIA 属性和键盘导航

### 测试覆盖率目标

- **组件覆盖率**: 90%+
- **工具函数覆盖率**: 100%
- **整体项目覆盖率**: 85%+

## 测试架构

```
test/
├── setup.ts              # 全局测试环境设置
├── types.d.ts             # 测试类型定义
├── utils/                 # 测试工具函数
│   ├── index.ts           # 通用测试工具
│   └── component-testing.ts # 组件测试工具
├── mocks/                 # 模拟文件
│   ├── dom.ts             # DOM API 模拟
│   ├── @hytech/ht-ui.ts           # @hytech/ht-ui 组件依赖模拟
│   └── vue.ts             # Vue 相关模拟
└── README.md              # 本文档
```

### 组件测试结构

每个组件都有独立的测试目录：

```
src/components/[component]/
├── index.ts/vue           # 组件实现
├── Component.vue          # Vue 组件
└── test/                  # 测试文件
    ├── Component.test.ts  # 主测试文件
    ├── fixtures/          # 测试数据
    │   └── test-data.ts
    └── utils/             # 组件测试工具
        └── test-helpers.ts
```

## 运行测试

### 开发模式

```bash
# 运行测试（监听模式）
pnpm test

# 运行所有测试（单次）
pnpm test:run

# 启动可视化测试界面
pnpm test:ui
```

### 覆盖率报告

```bash
# 生成覆盖率报告
pnpm test:coverage

# CI 环境运行（详细输出）
pnpm test:ci
```

### 调试测试

```bash
# 只运行特定测试文件
pnpm test Button.test.ts

# 运行匹配特定模式的测试
pnpm test --grep "Button"

# 监听模式下只运行相关测试
pnpm test --reporter=verbose
```

## 编写测试

### 基础测试结构

```typescript
import { render, screen } from '@testing-library/vue';
import { beforeEach, describe, expect, it } from 'vitest';
import { renderWithMounting } from '@/test/utils';
import YourComponent from '../index.vue';

describe('YourComponent', () => {
  beforeEach(() => {
    // 清理 DOM
    document.body.innerHTML = '';
  });

  describe('基础渲染', () => {
    it('应该正确渲染默认状态', () => {
      renderWithMounting(YourComponent);

      const element = screen.getByTestId('your-component');
      expect(element).toBeInTheDocument();
    });
  });
});
```

### 测试工具函数

使用我们提供的测试工具函数：

```typescript
import { cleanupPortalContainer, click, createPortalContainer, renderWithMounting, sleep } from '@/test/utils';

// 渲染组件
const { getByRole } = renderWithMounting(YourComponent, {
  props: { theme: 'primary' },
  slots: { default: 'Click me' },
});

// 模拟点击
await click(getByRole('button'));

// 等待异步操作
await sleep(100);

// 创建 portal 环境
const container = createPortalContainer();
// ... 测试 portal 组件
cleanupPortalContainer(container);
```

### 组件测试模式

#### 1. 基础渲染测试

```typescript
it('应该正确渲染组件', () => {
  renderWithMounting(YourComponent, {
    props: { variant: 'primary' },
    slots: { default: 'Content' },
  });

  expect(screen.getByRole('button')).toBeInTheDocument();
  expect(screen.getByText('Content')).toBeInTheDocument();
});
```

#### 2. Props 测试

```typescript
it('应该响应 props 变化', async () => {
  const { rerender } = renderWithMounting(YourComponent, {
    props: { disabled: false },
  });

  expect(screen.getByRole('button')).not.toBeDisabled();

  await rerender({ disabled: true });
  expect(screen.getByRole('button')).toBeDisabled();
});
```

#### 3. 事件测试

```typescript
it('应该响应点击事件', async () => {
  const handleClick = vi.fn();

  renderWithMounting(YourComponent, {
    props: { onClick: handleClick },
  });

  await click(screen.getByRole('button'));
  expect(handleClick).toHaveBeenCalledTimes(1);
});
```

#### 4. 可访问性测试

```typescript
it('应该有正确的 ARIA 属性', () => {
  renderWithMounting(YourComponent, {
    props: { 'aria-label': 'Custom Label' },
  });

  const element = screen.getByRole('button');
  expect(element).toHaveAttribute('aria-label', 'Custom Label');
});
```

#### 5. 快照测试

```typescript
it('应该匹配快照', () => {
  const { container } = renderWithMounting(YourComponent, {
    props: { theme: 'primary', size: 'large' },
  });

  expect(container).toMatchSnapshot();
});
```

### 测试数据管理

使用 fixtures 管理测试数据：

```typescript
// fixtures/test-data.ts
export const testVariants = ['primary', 'secondary', 'danger'] as const;
export const testSizes = ['small', 'medium', 'large'] as const;

export const testCombinations = [
  { variant: 'primary', size: 'small' },
  { variant: 'secondary', size: 'medium' },
  // ... 更多组合
];
```

在测试中使用：

```typescript
import { testCombinations, testVariants } from './fixtures/test-data';

it.each(testVariants)('应该支持 %s 变体', (variant) => {
  renderWithMounting(YourComponent, { props: { variant } });
  expect(screen.getByRole('button')).toHaveClass(`btn-${variant}`);
});
```

## 最佳实践

### 1. 测试组织

- 使用 `describe` 分组相关测试
- 使用 `it` 描述具体测试场景
- 使用 `beforeEach`/`afterEach` 进行设置和清理

```typescript
describe('ComponentName', () => {
  beforeEach(() => {
    // 全局设置
  });

  describe('Rendering', () => {
    it('renders default state', () => {});
    it('renders with props', () => {});
  });

  describe('Interactions', () => {
    it('responds to clicks', () => {});
    it('handles keyboard events', () => {});
  });
});
```

### 2. 测试命名

- 使用清晰、描述性的测试名称
- 采用 "应该 [期望行为]" 的格式
- 包含测试的具体条件

```typescript
it('应该在 disabled 属性为 true 时禁用按钮', () => {
  // 测试实现
});

it('应该支持主题和尺寸的组合', () => {
  // 测试实现
});
```

### 3. 选择器策略

- 优先使用可访问性选择器（`getByRole`, `getByLabelText`）
- 谨慎使用 `data-testid`（仅在没有合适选择器时使用）
- 避免使用 CSS 类名作为选择器

```typescript
// ✅ 好的做法
const button = screen.getByRole('button', { name: /submit/i });
const input = screen.getByLabelText('Email address');

// ⚠️ 谨慎使用
const element = screen.getByTestId('submit-button');

// ❌ 避免使用
const element = container.querySelector('.btn-primary');
```

### 4. 异步测试

- 使用 `await` 处理异步操作
- 使用 `waitFor` 等待元素出现
- 使用 `sleep` 处理动画和延迟

```typescript
it('应该异步加载内容', async () => {
  renderWithMounting(AsyncComponent);

  // 等待元素出现
  const element = await screen.findByTestId('loaded-content');
  expect(element).toBeInTheDocument();
});

it('应该处理动画延迟', async () => {
  renderWithMounting(AnimatedComponent);

  // 等待动画完成
  await sleep(300);

  expect(screen.getByTestId('animated-element')).toHaveClass('animate-complete');
});
```

### 5. Mock 策略

- 只 mock 必要的外部依赖
- 优先使用测试友好的组件版本
- 在 `test/mocks` 中统一管理 mock

```typescript
// 模拟 reka-ui 组件（@hytech/ht-ui 组件库的底层依赖）
vi.mock('reka-ui', () => ({
  Button: { template: '<button><slot /></button>' },
  // ... 其他组件
}));

// 模拟 API 调用
vi.mock('@/api/service', () => ({
  fetchUser: vi.fn(() => Promise.resolve({ id: 1, name: 'Test User' })),
}));
```

### 6. 错误处理测试

```typescript
it('应该处理无效 props', () => {
  expect(() => {
    renderWithMounting(YourComponent, {
      props: { invalidProp: 'invalid' as any },
    });
  }).not.toThrow();
});

it('应该处理网络错误', async () => {
  vi.mocked(apiCall).mockRejectedValue(new Error('Network error'));

  renderWithMounting(ComponentThatFetches);

  const errorMessage = await screen.findByText(/network error/i);
  expect(errorMessage).toBeInTheDocument();
});
```

## 故障排除

### 常见问题

#### 1. 测试超时

```bash
# 增加测试超时时间
vitest --timeout=10000
```

```typescript
// 在特定测试中设置超时
it('should handle long operation', { timeout: 5000 }, async () => {
  // 测试实现
});
```

#### 2. DOM 清理问题

```typescript
// 在测试文件中添加全局清理
afterEach(() => {
  document.body.innerHTML = '';
  document.querySelectorAll('[data-portal]').forEach((el) => el.remove());
});
```

#### 3. Mock 不生效

```typescript
// 确保在测试文件顶部进行 mock
vi.mock('module-name', () => ({
  // mock 实现
}));

// 清除 mock
vi.clearAllMocks();
vi.resetAllMocks();
```

#### 4. 组件渲染问题

```typescript
// 检查组件是否正确导出
import YourComponent from '../YourComponent.vue'; // 确保路径正确

// 使用调试工具
screen.debug(); // 打印当前 DOM 状态
```

### 调试技巧

1. **使用 screen.debug()**

```typescript
renderWithMounting(YourComponent);
screen.debug(); // 打印当前 DOM
```

2. **使用 logRoles**

```typescript
import { logRoles } from '@testing-library/vue';

const { container } = renderWithMounting(YourComponent);
logRoles(container); // 打印可用的角色
```

3. **使用 VS Code 调试**

```json
// .vscode/launch.json
{
  "version": "0.2.0",
  "configurations": [
    {
      "name": "Debug Vitest",
      "type": "node",
      "request": "launch",
      "program": "${workspaceFolder}/node_modules/vitest/vitest.mjs",
      "args": ["run", "--reporter=verbose"],
      "console": "integratedTerminal",
      "internalConsoleOptions": "neverOpen"
    }
  ]
}
```

## 贡献指南

### 添加新测试

1. 为新组件创建测试文件
2. 遵循现有的测试结构和命名约定
3. 确保测试覆盖率达到要求
4. 运行测试确保通过

### 更新现有测试

1. 先修复或更新组件代码
2. 更新相关测试
3. 确保所有测试通过
4. 检查覆盖率是否变化

### 性能考虑

- 避免在测试中创建不必要的组件
- 使用 `beforeEach`/`afterEach` 进行适当的清理
- 定期检查测试运行时间，优化慢速测试

---

## 🔗 相关链接

- [Vitest 官方文档](https://vitest.dev/)
- [Vue Test Utils 文档](https://test-utils.vuejs.org/)
- [Testing Library 文档](https://testing-library.com/docs/vue-testing-library/intro/)
- [Jest DOM 匹配器](https://github.com/testing-library/jest-dom)
