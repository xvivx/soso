import type { ComponentPublicInstance } from 'vue';
import { render } from '@testing-library/vue';
import { VueWrapper } from '@vue/test-utils';

/**
 * 增强的 render 函数，提供额外的测试工具
 */
export function renderWithMounting(
  component: Parameters<typeof render>[0],
  options: Parameters<typeof render>[1] = {}
): ReturnType<typeof render> {
  return render(component, {
    ...options,
    global: {
      ...options?.global,
      // 添加全局配置
      stubs: {
        ...options?.global?.stubs,
        // 默认存根所有外部组件
        transition: false,
        'transition-group': false,
      },
    },
  });
}

/**
 * 创建 portal 容器
 */
export function createPortalContainer(id: string = 'portal-container'): HTMLElement {
  const portalContainer = document.createElement('div');
  portalContainer.id = id;
  portalContainer.setAttribute('data-portal-container', 'true');
  document.body.appendChild(portalContainer);
  return portalContainer;
}

/**
 * 清理 portal 容器
 */
export function cleanupPortalContainer(id: string = 'portal-container'): void {
  const portalContainer = document.getElementById(id);
  if (portalContainer) {
    portalContainer.remove();
  }
}

/**
 * 模拟用户点击事件
 */
export async function click(
  element: Element | VueWrapper<ComponentPublicInstance> | null,
  options: MouseEventInit = {}
): Promise<void> {
  if (!element) {
    throw new Error('Element not found');
  }

  const el = 'element' in element ? element.element : element;
  el.dispatchEvent(new MouseEvent('click', { bubbles: true, ...options }));
}

/**
 * 模拟键盘事件
 */
export async function keyDown(
  element: Element | VueWrapper<ComponentPublicInstance> | null,
  key: string,
  options: KeyboardEventInit = {}
): Promise<void> {
  if (!element) {
    throw new Error('Element not found');
  }

  const el = 'element' in element ? element.element : element;
  el.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true, key, ...options }));
}

/**
 * 模拟键盘事件（keyUp）
 */
export async function keyUp(
  element: Element | VueWrapper<ComponentPublicInstance> | null,
  key: string,
  options: KeyboardEventInit = {}
): Promise<void> {
  if (!element) {
    throw new Error('Element not found');
  }

  const el = 'element' in element ? element.element : element;
  el.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true, key, ...options }));
}

/**
 * 模拟表单输入事件
 */
export async function input(
  element: Element | VueWrapper<ComponentPublicInstance> | null,
  value: string
): Promise<void> {
  if (!element) {
    throw new Error('Element not found');
  }

  const el = 'element' in element ? element.element : element;
  if (el instanceof HTMLInputElement || el instanceof HTMLTextAreaElement) {
    el.value = value;
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
  } else {
    throw new Error('Element is not an input or textarea');
  }
}

/**
 * 等待 Vue 组件更新
 */
export async function waitForUpdate<T = unknown>(callback: () => T | Promise<T>, timeout: number = 5000): Promise<T> {
  const start = Date.now();
  const maxTime = start + timeout;

  while (Date.now() < maxTime) {
    try {
      const result = await callback();
      return result;
    } catch (_error) {
      // 继续等待
      await new Promise((resolve) => setTimeout(resolve, 10));
    }
  }

  // 最后一次尝试
  return await callback();
}

/**
 * 模拟鼠标悬停事件
 */
export async function hover(element: Element | VueWrapper<ComponentPublicInstance> | null): Promise<void> {
  if (!element) {
    throw new Error('Element not found');
  }

  const el = 'element' in element ? element.element : element;
  el.dispatchEvent(new MouseEvent('mouseenter', { bubbles: true }));
}

/**
 * 模拟鼠标离开事件
 */
export async function unhover(element: Element | VueWrapper<ComponentPublicInstance> | null): Promise<void> {
  if (!element) {
    throw new Error('Element not found');
  }

  const el = 'element' in element ? element.element : element;
  el.dispatchEvent(new MouseEvent('mouseleave', { bubbles: true }));
}

/**
 * 等待元素出现
 */
export async function waitForElement(selector: string, timeout: number = 5000): Promise<Element> {
  const start = Date.now();
  const maxTime = start + timeout;

  while (Date.now() < maxTime) {
    const element = document.querySelector(selector);
    if (element) {
      return element;
    }
    await new Promise((resolve) => setTimeout(resolve, 10));
  }

  throw new Error(`Element ${selector} not found within ${timeout}ms`);
}

/**
 * 等待元素消失
 */
export async function waitForElementToBeRemoved(selector: string, timeout: number = 5000): Promise<void> {
  const start = Date.now();
  const maxTime = start + timeout;

  while (Date.now() < maxTime) {
    const element = document.querySelector(selector);
    if (!element) {
      return;
    }
    await new Promise((resolve) => setTimeout(resolve, 10));
  }

  throw new Error(`Element ${selector} still present after ${timeout}ms`);
}

/**
 * 模拟异步操作
 */
export function createAsyncMock<T = void>(): {
  mock: ReturnType<typeof vi.fn>;
  resolve: (value: T) => void;
  reject: (error: Error) => void;
} {
  let resolve: (value: T) => void;
  let reject: (error: Error) => void;

  const mock = vi.fn(() => {
    return new Promise<T>((res, rej) => {
      resolve = res;
      reject = rej;
    });
  });

  return {
    mock,
    resolve: (value: T) => resolve(value),
    reject: (error: Error) => reject(error),
  };
}

/**
 * 等待动画完成
 */
export async function waitForAnimation(element: Element, timeout: number = 1000): Promise<void> {
  return new Promise((resolve) => {
    const handleAnimationEnd = () => {
      element.removeEventListener('animationend', handleAnimationEnd);
      element.removeEventListener('transitionend', handleAnimationEnd);
      resolve();
    };

    element.addEventListener('animationend', handleAnimationEnd, { once: true });
    element.addEventListener('transitionend', handleAnimationEnd, { once: true });

    // 超时处理
    setTimeout(() => {
      element.removeEventListener('animationend', handleAnimationEnd);
      element.removeEventListener('transitionend', handleAnimationEnd);
      resolve();
    }, timeout);
  });
}

/**
 * 获取计算样式
 */
export function getComputedStyle(element: Element, property: string): string {
  return window.getComputedStyle(element).getPropertyValue(property);
}

/**
 * 检查元素是否可见
 */
export function isElementVisible(element: Element): boolean {
  const style = window.getComputedStyle(element);
  return style.display !== 'none' && style.visibility !== 'hidden' && style.opacity !== '0';
}

/**
 * 模拟用户输入延迟
 */
export async function simulateUserDelay(ms: number = 100): Promise<void> {
  await new Promise((resolve) => setTimeout(resolve, ms));
}
