/// <reference types="vitest" />
/// <reference types="@testing-library/jest-dom" />

// Vitest 全局类型
declare global {
  const vi: typeof import('vitest').vi;
  const describe: typeof import('vitest').describe;
  const it: typeof import('vitest').it;
  const test: typeof import('vitest').test;
  const expect: typeof import('vitest').expect;
  const beforeEach: typeof import('vitest').beforeEach;
  const afterEach: typeof import('vitest').afterEach;
  const beforeAll: typeof import('vitest').beforeAll;
  const afterAll: typeof import('vitest').afterAll;
  const vi: typeof import('vitest').vi;
}

// Testing Library 扩展类型
declare module '@testing-library/vue' {
  // No additional types needed for @testing-library/vue
}

// 扩展 Jest-DOM 匹配器类型
declare global {
  namespace Vi {
    // Assertion and AsymmetricMatchersContaining extend jest.Matchers - no additional members needed
  }
}

export {};
