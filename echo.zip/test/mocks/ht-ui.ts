import { h } from 'vue';
import { vi } from 'vitest';

// 模拟 lucide-vue-next 图标库
vi.mock('lucide-vue-next', () => ({
  Loader2Icon: {
    name: 'Loader2Icon',
    props: ['class', 'role', 'aria-label', 'data-testid'],
    setup(props: Record<string, unknown>, { attrs }: { attrs?: Record<string, unknown> }) {
      return () =>
        h('div', {
          class: `loader-icon ${props['class'] || ''}`,
          'data-testid': props['data-testid'] || attrs?.['data-testid'] || 'loader-icon',
          role: props['role'] || attrs?.role || 'status',
          'aria-label': props['aria-label'] || attrs?.['aria-label'] || 'Loading',
          ...(attrs || {}),
        });
    },
  },
}));

// 模拟 HTIcon 组件
const HTIcon = {
  name: 'HTIcon',
  props: ['name', 'size', 'color', 'classPrefix', 'tag'],
  setup(props: any) {
    return () => {
      if (props.name === 'cross') {
        return '×'; // 渲染关闭图标
      }
      return `<i class="${props.classPrefix}-${props.name}"></i>`;
    };
  },
};

// 模拟 ht-ui 组件库依赖的 reka-ui 组件
export const mockHtUIComponents = {
  // HTIcon 组件
  HTIcon,

  // Button 组件
  Button: {
    name: 'Button',
    template: '<button><slot /></button>',
    props: ['as', 'asChild', 'type', 'variant', 'size', 'disabled'],
  },

  // Popover 组件
  PopoverRoot: {
    name: 'PopoverRoot',
    template: '<div><slot /></div>',
    props: ['defaultOpen', 'open', 'modal'],
  },

  PopoverTrigger: {
    name: 'PopoverTrigger',
    template: '<button><slot /></button>',
    props: ['as', 'asChild'],
  },

  PopoverContent: {
    name: 'PopoverContent',
    template: '<div data-state="open"><slot /></div>',
    props: ['as', 'asChild', 'forceMount', 'side', 'align', 'sideOffset', 'alignOffset'],
  },

  PopoverAnchor: {
    name: 'PopoverAnchor',
    template: '<div><slot /></div>',
    props: ['as', 'asChild'],
  },

  // Tabs 组件
  TabsRoot: {
    name: 'TabsRoot',
    template: '<div><slot /></div>',
    props: ['defaultValue', 'value', 'orientation', 'dir', 'activationMode'],
  },

  TabsList: {
    name: 'TabsList',
    template: '<div role="tablist"><slot /></div>',
    props: ['as', 'asChild', 'loop'],
  },

  TabsTrigger: {
    name: 'TabsTrigger',
    template: '<button role="tab"><slot /></button>',
    props: ['as', 'asChild', 'value', 'disabled'],
  },

  TabsContent: {
    name: 'TabsContent',
    template: '<div role="tabpanel"><slot /></div>',
    props: ['as', 'asChild', 'value', 'forceMount'],
  },

  // Dialog 组件 (用于 Modal)
  DialogRoot: {
    name: 'DialogRoot',
    template: '<div><slot /></div>',
    props: ['open', 'modal', 'defaultOpen'],
  },

  DialogTrigger: {
    name: 'DialogTrigger',
    template: '<button><slot /></button>',
    props: ['as', 'asChild'],
  },

  DialogContent: {
    name: 'DialogContent',
    template: '<div role="dialog"><slot /></div>',
    props: ['as', 'asChild', 'forceMount', 'trapFocus'],
  },

  DialogOverlay: {
    name: 'DialogOverlay',
    template: '<div data-state="open"><slot /></div>',
    props: ['as', 'asChild', 'forceMount'],
  },

  DialogPortal: {
    name: 'DialogPortal',
    template: '<div><slot /></div>',
    props: ['forceMount', 'container'],
  },

  DialogTitle: {
    name: 'DialogTitle',
    template: '<h2><slot /></h2>',
    props: ['as', 'asChild'],
  },

  DialogDescription: {
    name: 'DialogDescription',
    template: '<p><slot /></p>',
    props: ['as', 'asChild'],
  },

  DialogClose: {
    name: 'DialogClose',
    template: '<button><slot /></button>',
    props: ['as', 'asChild'],
  },
};

// 模拟 reka-ui 工具函数
export const mockRekaUIUtils = {
  // 模拟 useId hook
  useId: vi.fn(() => 'test-id-1'),

  // 模拟 forwardRef
  forwardRef: vi.fn((component) => component),

  // 模拟 createPortal
  createPortal: vi.fn((element) => element),

  // 模拟 dismissible 层相关
  useDismissibleLayer: vi.fn(() => ({
    dismiss: vi.fn(),
    isDismissed: false,
  })),

  // 模拟 focus trap
  useFocusTrap: vi.fn(() => ({
    activate: vi.fn(),
    deactivate: vi.fn(),
  })),

  // 模拟 roving focus
  useRovingFocus: vi.fn(() => ({
    elements: [],
    focusNext: vi.fn(),
    focusPrevious: vi.fn(),
    focusFirst: vi.fn(),
    focusLast: vi.fn(),
  })),
};

// 在 Vitest setup 中注册这些模拟
export function setupHtUIMocks(): void {
  // 注册组件模拟
  Object.entries(mockHtUIComponents).forEach(([name, component]) => {
    vi.hoisted(() => ({
      [`__mock_${name}`]: component,
    }));
  });

  // 注册工具函数模拟
  Object.entries(mockRekaUIUtils).forEach(([name, fn]) => {
    vi.mock(`reka-ui/${name.toLowerCase()}`, () => fn);
  });
}
