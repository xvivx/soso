import { vi } from 'vitest';

/**
 * 创建模拟的 DOM 事件
 */
export function createMockEvent(type: string, options: EventInit = {}): Event {
  return new Event(type, {
    bubbles: true,
    cancelable: true,
    ...options,
  });
}

/**
 * 创建模拟的鼠标事件
 */
export function createMouseEvent(type: string, options: MouseEventInit = {}): MouseEvent {
  return new MouseEvent(type, {
    bubbles: true,
    cancelable: true,
    view: window,
    ...options,
  });
}

/**
 * 创建模拟的键盘事件
 */
export function createKeyboardEvent(type: string, key: string, options: KeyboardEventInit = {}): KeyboardEvent {
  return new KeyboardEvent(type, {
    bubbles: true,
    cancelable: true,
    key,
    ...options,
  });
}

/**
 * 创建模拟的触摸事件
 */
export function createTouchEvent(type: string, options: TouchEventInit = {}): TouchEvent {
  return new TouchEvent(type, {
    bubbles: true,
    cancelable: true,
    ...options,
  });
}

/**
 * 模拟元素的 getBoundingClientRect
 */
export function mockGetBoundingClientRect(rect: Partial<DOMRect>): void {
  Object.defineProperty(Element.prototype, 'getBoundingClientRect', {
    value: vi.fn(() => ({
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
      width: 0,
      height: 0,
      x: 0,
      y: 0,
      toJSON: vi.fn(),
      ...rect,
    })),
    writable: true,
  });
}

/**
 * 模拟元素的 offsetParent
 */
export function mockOffsetParent(element: Element | null): void {
  Object.defineProperty(HTMLElement.prototype, 'offsetParent', {
    value: element,
    writable: true,
  });
}

/**
 * 模拟元素的 clientRects
 */
export function mockClientRects(rects: DOMRect[]): void {
  Object.defineProperty(Element.prototype, 'getClientRects', {
    value: vi.fn(() => rects),
    writable: true,
  });
}

/**
 * 模拟元素的 offsetWidth 和 offsetHeight
 */
export function mockOffsetSize(width: number, height: number): void {
  Object.defineProperty(HTMLElement.prototype, 'offsetWidth', {
    value: width,
    writable: true,
  });
  Object.defineProperty(HTMLElement.prototype, 'offsetHeight', {
    value: height,
    writable: true,
  });
}

/**
 * 模拟元素的 clientWidth 和 clientHeight
 */
export function mockClientSize(width: number, height: number): void {
  Object.defineProperty(HTMLElement.prototype, 'clientWidth', {
    value: width,
    writable: true,
  });
  Object.defineProperty(HTMLElement.prototype, 'clientHeight', {
    value: height,
    writable: true,
  });
}

/**
 * 模拟元素的 scrollWidth 和 scrollHeight
 */
export function mockScrollSize(width: number, height: number): void {
  Object.defineProperty(HTMLElement.prototype, 'scrollWidth', {
    value: width,
    writable: true,
  });
  Object.defineProperty(HTMLElement.prototype, 'scrollHeight', {
    value: height,
    writable: true,
  });
}

/**
 * 模拟元素的 scrollTop 和 scrollLeft
 */
export function mockScrollPosition(top: number, left: number): void {
  Object.defineProperty(HTMLElement.prototype, 'scrollTop', {
    value: top,
    writable: true,
  });
  Object.defineProperty(HTMLElement.prototype, 'scrollLeft', {
    value: left,
    writable: true,
  });
}

/**
 * 创建模拟的 CSSStyleDeclaration
 */
export function createMockStyle(overrides: Partial<CSSStyleDeclaration> = {}): CSSStyleDeclaration {
  // Build a minimal base object with common methods and a Proxy fallback so we don't need
  // to enumerate hundreds of CSS properties (and risk duplicate keys).
  const base: Record<string, unknown> = {
    ...overrides,
    getPropertyValue: vi.fn((property: string) => (overrides as any).getPropertyValue?.(property) || ''),
    setProperty: vi.fn(() => {}),
    removeProperty: vi.fn(() => ''),
    item: vi.fn(() => ''),
    length: 0,
    parentRule: null,
    cssText: '',
  };

  const proxy = new Proxy(base, {
    get(target, prop) {
      if (prop in target) return (target as any)[prop];
      // Return empty string for any unknown CSS property access to mimic CSSStyleDeclaration
      return '';
    },
  });

  return proxy as unknown as CSSStyleDeclaration;
}

/**
 * 模拟 window.computedStyle
 */
export function mockComputedStyle(style: Partial<CSSStyleDeclaration> = {}): void {
  Object.defineProperty(window, 'getComputedStyle', {
    value: vi.fn(() => createMockStyle(style)),
    writable: true,
  });
}
