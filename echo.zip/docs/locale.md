# 国际化 (Locale)

组件库内置了完整的国际化系统，支持 40+ 种语言，提供类型安全的消息翻译和智能回退机制。

## 概述

### 特性

- 🌍 **广泛的语言支持** - 11 种语言已实现，40+ 种语言规划中
- 🎯 **类型安全** - 完整的 TypeScript 支持和自动补全
- 🔄 **响应式切换** - 实时语言切换，无需重新加载
- 🛡️ **智能回退** - 基于语言族系的回退链机制
- 📱 **RTL 支持** - 内置从右到左语言支持（阿拉伯语等）
- ⚡ **高性能** - 优化的消息解析和缓存机制
- 🧪 **完整测试** - 400+ 行的测试覆盖

### 支持的语言

#### 已实现语言 (11 种)

| 语言代码 | 语言名称 | 原生名称 | 完整度 |
|---------|---------|---------|--------|
| zh-CN | Chinese (Simplified) | 简体中文 | ✅ 完整 |
| en-US | English (US) | English | ✅ 完整 |
| es-ES | Spanish | Español | ✅ 完整 |
| fr-FR | French | Français | ✅ 完整 |
| de-DE | German | Deutsch | ✅ 完整 |
| it-IT | Italian | Italiano | ✅ 完整 |
| pt-PT | Portuguese | Português | ✅ 完整 |
| nl-NL | Dutch | Nederlands | ✅ 完整 |
| ru-RU | Russian | Русский | ✅ 完整 |
| ja-JP | Japanese | 日本語 | ✅ 完整 |
| ko-KR | Korean | 한국어 | ✅ 完整 |

#### 计划中的语言 (29 种)

包括 th-TH（泰语）、ar-SA（阿拉伯语）、hi-IN（印地语）等，涵盖亚洲、欧洲、中东、非洲等主要语言。

## 核心概念

### 语言代码规范

使用标准的 `语言代码-地区代码` 格式：

```typescript
// 标准格式
'zh-CN'    // 简体中文
'en-US'    // 美国英语
'es-ES'    // 西班牙语
'ar-SA'    // 阿拉伯语（沙特）
```

### 消息键命名约定

采用 `htComponentName.messageKey` 格式：

```typescript
// 通用 UI 元素
'name'           // "姓名" / "Name"
'save'           // "保存" / "Save"
'cancel'         // "取消" / "Cancel"

// 组件特定消息
'htLoading.loading'      // 加载中... / Loading...
'htList.loadingText'     // 加载中... / Loading...
'htButton.loading'       // 加载中... / Loading...
'htModal.confirm'        // 确认 / Confirm
```

### 智能回退机制

当目标语言缺少某个翻译时，系统会按以下优先级回退：

1. **地区变体回退**：`zh-TW` → `zh-CN`
2. **语言族系回退**：`es-MX` → `es-ES` → `en-US`
3. **通用回退**：任何语言 → `en-US` 或 `zh-CN`

## 使用方法

### useLocale 组合式函数（推荐）

在 Vue 组件中使用 `useLocale` 获取国际化功能：

```vue
<script setup lang="ts">
import { computed } from 'vue'
import { useLocale } from '@/locale'

const props = defineProps<{
  text?: string
}>()

const { t, lang, setLang, isRTL } = useLocale()

// 获取翻译文本
const loadingText = computed(() => {
  if (props.text) return props.text
  return t('htLoading.loading', '加载中...')
})

// 获取当前语言
console.log(lang.value) // 'zh-CN'

// 切换语言
const switchToEnglish = () => {
  setLang('en-US')
}

// 检查是否为 RTL 语言
const rtlClass = computed(() => {
  return isRTL.value ? 'direction-rtl' : 'direction-ltr'
})
</script>

<template>
  <div :class="rtlClass">
    {{ loadingText }}
  </div>
</template>
```

### 直接 API 调用

在组件外部或非响应式场景中使用：

```typescript
import { Locale } from '@/locale'

// 设置语言
Locale.use('es-ES')

// 获取翻译
const saveText = Locale.message('save') // "Guardar"

// 检查 RTL 语言
const isArabic = Locale.isRTL('ar-SA') // true

// 自动检测浏览器语言
Locale.autoDetect()

// 获取浏览器语言
const browserLang = Locale.getBrowserLocale() // 'zh-CN'
```

### useLocale 组合式函数返回值

```typescript
interface UseLocaleReturn {
  lang: ComputedRef<string>              // 当前语言代码
  messages: ComputedRef<Message>         // 当前语言的消息对象
  t: (key: string, fallback?: string) => string  // 翻译函数
  setLang: (newLang: string) => void     // 设置语言
  addMessages: (newMessages: Messages) => void  // 添加消息
  metadata: ComputedRef<LanguageMetadata | null>  // 语言元数据
  family: ComputedRef<LanguageFamily | null>      // 语言族系
  isRTL: ComputedRef<boolean>            // 是否为 RTL 语言
  availableLanguages: ComputedRef<LanguageMetadata[]>  // 可用语言列表
  fallbackChain: ComputedRef<string[]>   // 回退链
}
```

## 组件开发指南

### 标准实现模式

每个组件都应该按照以下模式集成国际化：

```vue
<script setup lang="ts">
import { computed } from 'vue'
import { useLocale } from '@/locale'

const props = defineProps<{
  loadingText?: string
  errorText?: string
}>()

const { t } = useLocale()

// 计算属性：优先使用 props，回退到 locale，最后使用默认值
const computedLoadingText = computed(() => {
  if (props.loadingText) return props.loadingText
  return t('htList.loadingText', '加载中...')
})

const computedErrorText = computed(() => {
  if (props.errorText) return props.errorText
  return t('htList.errorText', '加载失败')
})
</script>

<template>
  <div>
    <span v-if="loading">{{ computedLoadingText }}</span>
    <span v-if="error">{{ computedErrorText }}</span>
  </div>
</template>
```

### 组件消息定义

在语言文件中为组件添加翻译：

```typescript
// src/locale/lang/zh-CN.ts
export default {
  // ... 通用消息

  htList: {
    loadingText: '加载中...',
    errorText: '加载失败',
    finishedText: '没有更多了',
    emptyText: '暂无数据'
  },

  htButton: {
    loading: '加载中...',
    disabled: '已禁用'
  }
}

// src/locale/lang/en-US.ts
export default {
  // ... 通用消息

  htList: {
    loadingText: 'Loading...',
    errorText: 'Load failed',
    finishedText: 'No more data',
    emptyText: 'No data'
  },

  htButton: {
    loading: 'Loading...',
    disabled: 'Disabled'
  }
}
```

### TypeScript 类型定义

为组件定义 locale 类型：

```typescript
// src/locale/types.ts
export interface HTListLocale {
  loadingText: string
  errorText: string
  finishedText: string
  emptyText: string
}

export interface HTButtonLocale {
  loading: string
  disabled: string
}
```

### 最佳实践

1. **始终提供有意义的回退文本**
2. **使用 `htComponentName.messageKey` 命名约定**
3. **Props 优先于 locale 值**
4. **在组件中使用计算属性**
5. **测试多种语言的显示效果**

```vue
<!-- ✅ 好的实现 -->
<script setup>
const { t } = useLocale()

const confirmText = computed(() => {
  return props.confirmText ||
         t('htModal.confirm', '确认')  // 提供回退文本
})
</script>

<!-- ❌ 避免的实现 -->
<script setup>
const { t } = useLocale()

const confirmText = computed(() => {
  return t('htModal.confirm')  // 缺少回退文本
})
</script>
```

## 语言文件结构

### 文件组织

```
src/locale/
├── index.ts              # 主入口和实现
├── types.ts              # TypeScript 类型定义
├── lang/
│   ├── metadata.ts       # 语言元数据
│   ├── zh-CN.ts         # 简体中文
│   ├── en-US.ts         # 英语
│   ├── es-ES.ts         # 西班牙语
│   └── ...              # 其他语言文件
└── __tests__/
    └── locale.test.ts    # 测试文件
```

### 语言文件结构

每个语言文件包含两部分：

```typescript
// src/locale/lang/zh-CN.ts
export default {
  // === 通用 UI 元素 ===
  name: '姓名',
  tel: '电话',
  save: '保存',
  cancel: '取消',
  confirm: '确认',
  delete: '删除',
  loading: '加载中...',
  // ... 35+ 通用元素

  // === 组件特定翻译 ===
  htLoading: {
    loading: '加载中...',
    text: '加载中...'
  },

  htList: {
    loadingText: '加载中...',
    errorText: '加载失败',
    finishedText: '没有更多了',
    emptyText: '暂无数据'
  },

  htButton: {
    loading: '加载中...',
    disabled: '已禁用'
  },

  // ... 50+ 组件接口
}
```

### 语言元数据

```typescript
// src/locale/lang/metadata.ts
export const languageMetadata: Record<string, LanguageMetadata> = {
  'zh-CN': {
    code: 'zh-CN',
    name: 'Chinese (Simplified)',
    nativeName: '简体中文',
    region: 'China',
    rtl: false,
    completeness: 'complete'
  },

  'ar-SA': {
    code: 'ar-SA',
    name: 'Arabic (Saudi Arabia)',
    nativeName: 'العربية',
    region: 'Saudi Arabia',
    rtl: true,  // RTL 语言
    completeness: 'minimal'
  }
}
```

## 高级特性

### RTL 语言支持

系统内置了对从右到左语言的支持：

```vue
<script setup>
import { computed } from 'vue'
import { useLocale } from '@/locale'

const { isRTL, lang } = useLocale()

const directionClass = computed(() => ({
  'rtl-layout': isRTL.value,
  'ltr-layout': !isRTL.value
}))

const textAlign = computed(() => {
  return isRTL.value ? 'text-right' : 'text-left'
})
</script>

<template>
  <div :class="directionClass">
    <h1 :class="textAlign">标题</h1>
    <p :class="textAlign">内容文本</p>
  </div>
</template>
```

### 语言族系支持

系统支持基于语言族系的智能回退：

```typescript
// 德语族系：de-DE → de-AT → de
// 罗曼语族系：es-MX → es-ES → pt-PT → en-US
// 斯拉夫语族系：ru-RU → uk-UA → en-US

const { fallbackChain } = useLocale()
console.log(fallbackChain.value)
// ['es-MX', 'es-ES', 'pt-PT', 'en-US']
```

### 动态消息添加

可以在运行时动态添加翻译：

```typescript
const { addMessages } = useLocale()

// 添加新的翻译
addMessages({
  'en-US': {
    'custom.message': 'Custom message'
  },
  'zh-CN': {
    'custom.message': '自定义消息'
  }
})
```

### 性能优化

系统内置了多项性能优化：

- **消息缓存**：解析后的消息会被缓存
- **延迟加载**：语言文件按需加载
- **智能回退**：避免重复查找
- **类型优化**：编译时类型检查

## 实用示例

### 基础组件示例

```vue
<!-- HTButton.vue -->
<script setup lang="ts">
import { computed } from 'vue'
import { useLocale } from '@/locale'

const props = defineProps<{
  loading?: boolean
  disabled?: boolean
  loadingText?: string
}>()

const { t } = useLocale()

const buttonText = computed(() => {
  if (props.loading) {
    return props.loadingText || t('htButton.loading', '加载中...')
  }
  if (props.disabled) {
    return t('htButton.disabled', '已禁用')
  }
  return '默认按钮'  // 实际实现中应该使用插槽或 props
})
</script>

<template>
  <button :disabled="disabled || loading">
    {{ buttonText }}
  </button>
</template>
```

### 列表组件示例

```vue
<!-- HTList.vue -->
<script setup lang="ts">
import { computed } from 'vue'
import { useLocale } from '@/locale'

const props = defineProps<{
  loading?: boolean
  error?: boolean
  finished?: boolean
  empty?: boolean
  loadingText?: string
  errorText?: string
  finishedText?: string
  emptyText?: string
}>()

const { t } = useLocale()

const statusText = computed(() => {
  if (props.loading) {
    return props.loadingText || t('htList.loadingText', '加载中...')
  }
  if (props.error) {
    return props.errorText || t('htList.errorText', '加载失败')
  }
  if (props.finished) {
    return props.finishedText || t('htList.finishedText', '没有更多了')
  }
  if (props.empty) {
    return props.emptyText || t('htList.emptyText', '暂无数据')
  }
  return ''
})
</script>

<template>
  <div class="ht-list">
    <div v-if="statusText" class="ht-list__status">
      {{ statusText }}
    </div>
    <slot />
  </div>
</template>
```

### 语言切换器示例

```vue
<!-- LanguageSwitcher.vue -->
<script setup lang="ts">
import { useLocale } from '@/locale'

const { lang, availableLanguages, setLang } = useLocale()

const switchLanguage = (langCode: string) => {
  setLang(langCode)
}
</script>

<template>
  <div class="language-switcher">
    <select
      :value="lang"
      @change="switchLanguage(($event.target as HTMLSelectElement).value)"
    >
      <option
        v-for="language in availableLanguages"
        :key="language.code"
        :value="language.code"
      >
        {{ language.nativeName }} ({{ language.name }})
      </option>
    </select>
  </div>
</template>

<style scoped>
.language-switcher select {
  padding: 8px 12px;
  border: 1px solid #ddd;
  border-radius: 4px;
  background: white;
  cursor: pointer;
}
</style>
```

### 错误处理示例

```vue
<!-- ErrorHandlingExample.vue -->
<script setup lang="ts">
import { ref, computed } from 'vue'
import { useLocale } from '@/locale'

const { t, lang } = useLocale()

const errorKey = ref('nonexistent.key')

const safeTranslation = computed(() => {
  // 安全的翻译获取，总是提供回退
  return t(errorKey.value, '默认回退文本')
})

const hasTranslation = computed(() => {
  // 检查是否有翻译
  const translation = t(errorKey.value, '')
  return translation !== ''
})
</script>

<template>
  <div>
    <p>当前语言: {{ lang }}</p>
    <p>翻译键: {{ errorKey }}</p>
    <p>翻译结果: {{ safeTranslation }}</p>
    <p>是否有翻译: {{ hasTranslation ? '是' : '否' }}</p>
  </div>
</template>
```

## API 参考

### useLocale()

返回当前 locale 状态和方法的组合式函数。

```typescript
const locale = useLocale()
```

### 返回值

| 属性/方法 | 类型 | 描述 |
|---------|------|------|
| `lang` | `ComputedRef<string>` | 当前语言代码 |
| `messages` | `ComputedRef<Message>` | 当前语言的消息对象 |
| `t` | `(key: string, fallback?: string) => string` | 获取翻译文本 |
| `setLang` | `(newLang: string) => void` | 设置当前语言 |
| `addMessages` | `(newMessages: Messages) => void` | 添加翻译消息 |
| `metadata` | `ComputedRef<LanguageMetadata \| null>` | 当前语言元数据 |
| `family` | `ComputedRef<LanguageFamily \| null>` | 当前语言族系 |
| `isRTL` | `ComputedRef<boolean>` | 是否为 RTL 语言 |
| `availableLanguages` | `ComputedRef<LanguageMetadata[]>` | 可用语言列表 |
| `fallbackChain` | `ComputedRef<string[]>` | 语言回退链 |

### Locale 类

全局 locale 系统，用于组件外部使用。

```typescript
import { Locale } from '@/locale'
```

#### 静态方法

| 方法 | 描述 |
|------|------|
| `Locale.use(lang: string)` | 设置全局语言 |
| `Locale.message(key: string)` | 获取翻译文本 |
| `Locale.isRTL(lang?: string)` | 检查是否为 RTL 语言 |
| `Locale.autoDetect()` | 自动检测并设置浏览器语言 |
| `Locale.getBrowserLocale()` | 获取浏览器语言代码 |

### 类型定义

```typescript
// 语言元数据
interface LanguageMetadata {
  code: string           // 语言代码
  name: string           // 英文名称
  nativeName: string     // 原生名称
  region: string         // 地区
  rtl: boolean          // 是否为 RTL
  completeness: 'complete' | 'partial' | 'minimal'
}

// 消息类型
type Message = Record<string, string | Message>
type Messages = Record<string, Message>

// 支持的语言
type SupportedLocale =
  | 'zh-CN' | 'en-US' | 'es-ES' | 'fr-FR' | 'de-DE'
  | 'it-IT' | 'pt-PT' | 'nl-NL' | 'ru-RU' | 'ja-JP' | 'ko-KR'
  // ... 40+ 更多语言
```

## 测试

系统包含完整的测试套件，覆盖：

- 语言切换功能
- 消息翻译准确性
- 回退机制正确性
- RTL 语言支持
- 性能基准测试
- 类型安全检查

运行测试：

```bash
pnpm test locale
```

## 常见问题

### Q: 如何添加新语言？

A: 在 `src/locale/lang/` 目录下创建新的语言文件，并在 `metadata.ts` 中添加语言元数据。

### Q: 如何为组件添加新的翻译键？

A: 在所有语言文件中添加相同的键值对，并在 `types.ts` 中定义相应的类型。

### Q: 如何处理动态内容的翻译？

A: 使用 `t()` 函数的参数插值功能，或根据需要动态构建消息键。

### Q: 如何实现语言切换时的动画效果？

A: 结合 Vue 的过渡系统，在 `lang` 变化时添加过渡动画。

### Q: 为什么某些翻译没有生效？

A: 检查消息键格式、语言代码是否正确，以及是否提供了回退文本。