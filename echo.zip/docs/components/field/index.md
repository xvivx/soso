# Field 输入框

表单输入组件，支持单行、多行输入、清除、字数统计、错误提示、插槽扩展，风格与 Vant4 保持一致。

## 基础用法

可以通过 `v-model` 双向绑定输入框的值，通过 placeholder 设置占位提示文字。

<demo vue="./demos/Basic.vue" codesandbox="true" />

## 尺寸 size 属性

通过 `size` 属性可切换输入框尺寸，支持 normal 和 large，默认是 `large`。

<demo vue="./demos/Size.vue" codesandbox="true" />

## 自定义类型

根据 `type` 属性定义不同类型的输入框，默认值为 text。

<demo vue="./demos/Types.vue" codesandbox="true" />

## 禁用与只读

通过 `readonly` 将输入框设置为只读状态,通过 disabled 将输入框设置为禁用状态。

<demo vue="./demos/DisabledReadonly.vue" codesandbox="true" />

## 输入内容对齐

通过 `input-align` 属性可以设置输入内容的对齐方式,支持 `left`(默认)、`center`、`right` 三种对齐方式。

<demo vue="./demos/InputAlign.vue" codesandbox="true" />


## 格式化时机 formatTrigger

通过 `formatTrigger` 属性可以控制输入内容格式化的时机，支持 `onChange`（输入时格式化）和 `onBlur`（失焦时格式化）。

<demo vue="./demos/FormatTrigger.vue" codesandbox="true" />

## 字数统计

设置 `maxlength` 和 `show-word-limit` 属性后会在底部显示字数统计。

<demo vue="./demos/WordLimit.vue" codesandbox="true" />

## 错误提示

设置 `required` 属性表示这是一个必填项，可以配合 `error` 或 `error-message` 属性显示对应的错误提示。

<demo vue="./demos/Error.vue" codesandbox="true" />

## 必填项演示

通过 `required` 属性或校验规则自动显示必填星号。

<demo vue="./demos/Required.vue" codesandbox="true" />

## 可选标记 optional

当字段不是必填时，可通过 `optional` 属性展示一个“可选”标记，也可以自定义文本内容：

<demo vue="./demos/Optional.vue" codesandbox="true" />

## 辅助提示 tips

开启 `tips` 属性后，在标签区域右侧或指定位置显示一个提示触发点

<demo vue="./demos/Tips.vue" codesandbox="true" />

## 辅助信息 message

使用 `message` 属性在输入区域下方展示一段辅助描述文字；与 `errorMessage` 共存时，错误信息会优先以错误样式展示。

<demo vue="./demos/Message.vue" codesandbox="true" />

## 插入左侧和右侧内容

<demo vue="./demos/LeftRight.vue" codesandbox="true" />

## 图标与清除

通过 `left-icon` 和 `right-icon` 配置输入框两侧的图标，通过设置 `clearable` 在输入过程中展示清除图标。

<demo vue="./demos/Icons.vue" codesandbox="true" />

## 密码输入

设置 `type="password"` 可以开启密码输入框，支持密码可见性切换。

<demo vue="./demos/Password.vue" codesandbox="true" />

## 搜索框

设置 `type="search"` 可以开启搜索框模式，具有圆角边框和搜索图标。

<demo vue="./demos/SearchDemo.vue" codesandbox="true" />

## Textarea 自动高度

对于 textarea，可以通过 `autosize` 属性设置高度自适应。

<demo vue="./demos/Autosize.vue" codesandbox="true" />

## 自定义 input 插槽

可以通过 `#input` 插槽自定义输入区域内容。

<demo vue="./demos/inputSlot.vue" codesandbox="true" />

## Vant4 API 兼容性

| Vant 属性           | HTField 支持 | 备注/差异说明                 |
| ------------------- | :----------: | ----------------------------- |
| v-model             |      ✅      | 完全支持                      |
| type                |      ✅      | 完全支持                      |
| label               |      ✅      | 完全支持                      |
| label-width         |      ❌      | 不支持                        |
| label-class         |      ✅      | 完全支持                      |
| label-align         |      ❌      | 不支持                      |
| input-align         |      ✅      | 完全支持                      |
| placeholder         |      ✅      | 完全支持                      |
| left-icon           |      ✅      | 完全支持                      |
| right-icon          |      ✅      | 完全支持                      |
| icon-prefix         |      ✅      | 完全支持                      |
| clearable           |      ✅      | 完全支持                      |
| clear-icon          |      ✅      | 完全支持                      |
| clear-trigger       |      ✅      | 完全支持                      |
| maxlength           |      ✅      | 完全支持                      |
| show-word-limit     |      ✅      | 完全支持                      |
| autosize            |      ✅      | 完全支持                      |
| formatter           |      ✅      | 完全支持                      |
| format-trigger      |      ✅      | 完全支持                      |
| error               |      ✅      | 完全支持                      |
| error-message       |      ✅      | 完全支持                      |
| disabled            |      ✅      | 完全支持                      |
| readonly            |      ✅      | 完全支持                      |
| required            |      ✅      | 完全支持                      |
| rules               |      ✅      | 完全支持                      |
| model-value         |      ✅      | 完全支持                      |
| name                |      ✅      | 完全支持                      |
| id                  |      ✅      | 完全支持                      |
| autocomplete        |      ✅      | 完全支持                      |
| autocapitalize      |      ✅      | 完全支持                      |
| autocorrect         |      ✅      | 完全支持                      |
| spellcheck          |      ✅      | 完全支持                      |
| inputmode           |      ✅      | 完全支持                      |
| enterkeyhint        |      ✅      | 完全支持                      |
| colon               |      ✅      | 完全支持                      |
| optional            |      ✅      | 完全支持                      |
| message             |      ✅      | 完全支持                      |
| tips                |      ✅      | 完全支持                      |
| rows                |      ✅      | 完全支持                      |
| max/min             |      ✅      | 完全支持                      |
| show-error          |      ❌      | 通过 error/error-message 控制 |
| value               |      ✅      | 等价于 v-model/modelValue     |
| on-blur             |      ✅      | 完全支持                      |
| on-focus            |      ✅      | 完全支持                      |
| on-clear            |      ✅      | 完全支持                      |
| on-keypress         |      ✅      | 完全支持                      |
| on-click-input      |      ✅      | 完全支持                      |
| on-click-left-icon  |      ✅      | 完全支持                      |
| on-click-right-icon |      ✅      | 完全支持                      |
| on-change           |      ✅      | 完全支持                      |

> 注：部分属性命名略有不同，HTField 支持 kebab-case 和 camelCase 两种写法。

## 属性

| 属性                   | 说明                                   | 类型                                     | 默认值       |
| ---------------------- | -------------------------------------- | ---------------------------------------- | ------------ |
| `v-model`/`modelValue` | 输入框绑定值                           | `string \| number`                       | `''`         |
| `id`                   | 原生 `id`                              | `string`                                 | -            |
| `name`                 | 原生 `name`                            | `string`                                 | -            |
| `label`                | 左侧文本/数字标签                      | `string \| number`                       | -            |
| `labelWidth`           | 标签宽度 (数字或带单位字符串)          | `number \| string`                       | -            |
| `labelClass`           | 自定义标签区域类名                     | `any`                                    | -            |
| `labelAlign`           | 标签对齐方式                           | `'left' \| 'center' \| 'right'`          | -            |
| `inputAlign`           | 输入内容对齐方式                       | `'left' \| 'center' \| 'right'`          | -            |
| `size`                 | 尺寸                                   | `'normal' \| 'large'`                    | `'large'`    |
| `type`                 | 输入类型                               | `'text' \| 'textarea' \| 'password' ...` | `'text'`     |
| `rows`                 | 多行输入行数 (textarea)                | `number \| string`                       | `3` (示例)   |
| `maxlength`            | 最大输入长度                           | `number \| string`                       | -            |
| `placeholder`          | 占位符                                 | `string`                                 | -            |
| `leftIcon`             | 左侧图标名称                           | `string`                                 | -            |
| `rightIcon`            | 右侧图标名称                           | `string`                                 | -            |
| `iconPrefix`           | 图标前缀 (用于统一命名空间)            | `string`                                 | -            |
| `autofocus`            | 自动聚焦                               | `boolean`                                | `false`      |
| `clearable`            | 是否显示清除按钮                       | `boolean`                                | `false`      |
| `clearIcon`            | 清除按钮图标名称                       | `string`                                 | `'clear'`    |
| `clearTrigger`         | 清除图标出现时机                       | `'focus' \| 'always'`                    | `'focus'`    |
| `formatter`            | 展示值格式化函数                       | `(value: string) => string`              | -            |
| `formatTrigger`        | 格式化触发时机                         | `'onChange' \| 'onBlur'`                 | `'onChange'` |
| `showWordLimit`        | 是否显示字数统计                       | `boolean`                                | `false`      |
| `rules`                | 校验规则数组                           | `FieldRule[]`                            | -            |
| `autosize`             | textarea 自动高度配置/开关             | `boolean \| FieldAutosizeConfig`         | `false`      |
| `max`                  | 最大值 (number 类型时生效)             | `number`                                 | -            |
| `min`                  | 最小值 (number 类型时生效)             | `number`                                 | -            |
| `required`             | 是否必填 / `'auto'` 自动根据规则标星   | `boolean \| 'auto'`                      | `null`       |
| `optional`             | 非必填标记文本                         | `string`                                 | -            |
| `message`              | 底部辅助描述文字                       | `string`                                 | -            |
| `errorMessage`         | 错误提示文本                           | `string`                                 | -            |
| `error`                | 错误状态（受控）                       | `boolean \| null`                        | `null`       |
| `disabled`             | 禁用状态（受控）                       | `boolean \| null`                        | `null`       |
| `readonly`             | 只读状态（受控）                       | `boolean \| null`                        | `null`       |
| `spellcheck`           | 拼写检查（受控）                       | `boolean \| null`                        | `null`       |
| `colon`                | 是否显示分隔冒号（表单布局场景）       | `boolean \| null`                        | `null`       |
| `tips`                 | 是否显示提示触发点 (配合 `#tips` 插槽) | `boolean`                                | `false`      |
| `inputmode`            | 原生输入模式                           | `string`                                 | -            |
| `enterkeyhint`         | 虚拟键盘回车键样式提示                 | `string`                                 | -            |
| `autocomplete`         | 原生自动完成                           | `string`                                 | -            |
| `autocapitalize`       | 首字母大小写自动处理                   | `string`                                 | -            |
| `autocorrect`          | 自动纠错                               | `string`                                 | -            |

## 插槽

| 名称          | 说明              |
| ------------- | ----------------- |
| input         | 自定义输入区域    |
| label         | 自定义 label 区域 |
| left          | 输入框左侧内容    |
| right         | 输入框右侧内容    |
| error-message | 错误提示区域      |

## 事件

| 名称              | 说明         | 回调参数             |
| ----------------- | ------------ | -------------------- |
| update:modelValue | 输入值变化   | value: string        |
| blur              | 失焦事件     | event: Event         |
| focus             | 聚焦事件     | event: Event         |
| clear             | 清除按钮点击 | event: Event         |
| keypress          | 键盘按下事件 | event: KeyboardEvent |
| clickInput        | 输入框点击   | event: MouseEvent    |
| clickTips         | 触发提示     | event: MouseEvent    |
