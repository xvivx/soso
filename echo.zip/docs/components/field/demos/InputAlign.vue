<template>
  <div class="demo-field">
    <HTField v-model="text1" label="左对齐" placeholder="默认左对齐" input-align="left" />
    <HTField v-model="text2" label="居中对齐" placeholder="文本居中" input-align="center" />
    <HTField v-model="text3" label="右对齐" placeholder="文本右对齐" input-align="right" />
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import { HTField } from '@hytech/ht-ui';

const text1 = ref('');
const text2 = ref('');
const text3 = ref('');
</script>

<style scoped>
.demo-field {
  padding: 16px;
}
</style>
