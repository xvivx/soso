<template>
  <div class="required-demo">
    <div class="demo-section">
      <HTField v-model="value1" label="姓名" required placeholder="请输入姓名" />
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import { HTField } from '@hytech/ht-ui';

const value1 = ref('');
</script>

<style scoped></style>
