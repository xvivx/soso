<script setup lang="ts">
import { ref } from 'vue';
import { HTField, HTPopover } from '@hytech/ht-ui';

// 控制一个简单的浮层显示
const show = ref(false);

function toggle() {
  show.value = !show.value;
}
const valueTips1 = ref('');
</script>
<template>
  <HTField v-model="valueTips1" label="用户名" tips placeholder="请输入用户名" @clickTips="toggle"> </HTField>
  <HTPopover v-model:open="show" title="弹出提示">
    <template #default>
      <div>tips内容</div>
    </template>
  </HTPopover>
</template>
