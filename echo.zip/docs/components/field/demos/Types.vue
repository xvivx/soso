<script setup lang="ts">
import { ref } from 'vue';
import { HTField } from '@hytech/ht-ui';

const valueTxt = ref('');
const valuePhone = ref('');
const valueDigit = ref('');
const valueNumber = ref('');
const valuePassword = ref('');
</script>
<template>
  <div class="demo-types">
    <HTField v-model="valueTxt" type="text" label="文本" placeholder="请输入文本" />
    <div class="h-[8px]"></div>
    <HTField v-model="valuePhone" type="tel" label="手机号" placeholder="请输入手机号" />
    <div class="h-[8px]"></div>
    <HTField v-model="valueDigit" type="digit" label="整数" placeholder="请输入整数" />
    <div class="h-[8px]"></div>
    <HTField v-model="valueNumber" type="number" label="数字" placeholder="请输入数字" />
    <div class="h-[8px]"></div>
    <HTField v-model="valuePassword" type="password" label="密码" placeholder="请输入密码" clearable />
  </div>
</template>
