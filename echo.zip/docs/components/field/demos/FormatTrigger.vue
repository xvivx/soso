<template>
  <div>
    <Field
      v-model="value"
      :formatter="formatter"
      :format-trigger="formatTrigger"
      label="手机号"
      placeholder="请输入手机号"
    />
    <div style="margin-top: 16px">
      <span>当前 formatTrigger: </span>
      <select v-model="formatTrigger">
        <option value="onChange">onChange</option>
        <option value="onBlur">onBlur</option>
      </select>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import { HTField as Field } from '@hytech/ht-ui';

const value = ref('');
const formatTrigger = ref<'onChange' | 'onBlur'>('onBlur');

const formatter = (val: string) => {
  // 只保留数字
  return val.replace(/[^\d]/g, '');
};
</script>
