<script setup lang="ts">
import { ref } from 'vue';
import { HTField } from '@hytech/ht-ui';

const valueError = ref('');
</script>
<template>
  <HTField v-model="valueError" label="错误" errorMessage="输入有误" />
</template>
