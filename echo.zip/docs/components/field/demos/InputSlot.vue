<script setup lang="ts">
// 演示自定义 input 插槽
import { ref } from 'vue';
import { HTField } from '@hytech/ht-ui';

const customValue = ref('');
</script>

<template>
  <HTField label="插槽自定义输入" :model-value="customValue" @update:modelValue="customValue = $event">
    <template #input>
      <input v-model="customValue" placeholder="插槽输入框，可编辑" />
    </template>
  </HTField>
  <div style="margin-top: 12px; color: #888; font-size: 13px">当前值：{{ customValue }}</div>
</template>
