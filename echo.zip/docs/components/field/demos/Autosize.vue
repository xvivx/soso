<script setup lang="ts">
import { ref } from 'vue';
import { HTField } from '@hytech/ht-ui';

const valueAuto = ref('首行\n第二行');
const valueAuto2 = ref();
</script>
<template>
  <HTField v-model="valueAuto" type="textarea" label="简介(自动高度)" autosize placeholder="输入并换行试试" />

  <div class="m-[20px]"></div>

  <HTField
    v-model="valueAuto2"
    type="textarea"
    label="简介(限制高度)"
    :autosize="{ minHeight: 60, maxHeight: 120 }"
    placeholder="输入并换行试试"
  />
</template>
