<script setup lang="ts">
import { ref } from 'vue';
import { HTField } from '@hytech/ht-ui';

const valueDesc = ref('');
</script>
<template>
  <HTField v-model="valueDesc" label="简介" showWordLimit :maxlength="50" :row="5" />
</template>
