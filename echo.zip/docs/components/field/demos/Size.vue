<template>
  <HTField v-model="value1" label="普通尺寸" size="normal" placeholder="normal size" />
  <div class="h-[8px]"></div>
  <HTField v-model="value2" label="大尺寸" size="large" placeholder="large size" />
</template>

<script setup lang="ts">
import { ref } from 'vue';
import { HTField } from '@hytech/ht-ui';

const value1 = ref('');
const value2 = ref('');
</script>
