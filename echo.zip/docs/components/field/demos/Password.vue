<script setup lang="ts">
import { ref } from 'vue';
import { HTField } from '@hytech/ht-ui';

const password = ref('');
const confirmPassword = ref('');
</script>

<template>
  <div class="demo-password">
    <div class="demo-section">
      <HTField v-model="password" type="password" label="密码" placeholder="请输入密码" clearable />
    </div>
    <div class="h-[8px]"></div>
    <div class="demo-section">
      <HTField v-model="confirmPassword" type="password" label="确认密码" placeholder="请再次输入密码" clearable />
    </div>
  </div>
</template>

<style scoped></style>
