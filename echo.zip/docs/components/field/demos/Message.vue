<script setup lang="ts">
import { ref } from 'vue';
import { HTField } from '@hytech/ht-ui';

const valueMsg1 = ref('');
const valueMsg2 = ref('');
</script>
<template>
  <div class="demo-message">
    <!-- message: 底部辅助文字 -->
    <HTField v-model="valueMsg1" label="手机号" placeholder="请输入手机号" message="用于接收短信验证码" />
    <div class="h-[8px]"></div>
    <!-- message + errorMessage 共存，错误优先展示红色 -->
    <HTField
      v-model="valueMsg2"
      label="邮箱"
      placeholder="请输入邮箱"
      message="我们不会向你发送垃圾邮件"
      errorMessage="邮箱格式不正确"
      :error="true"
    />
  </div>
</template>

<style scoped>
.demo-message {
  display: flex;
  flex-direction: column;
  gap: 12px;
}
</style>
