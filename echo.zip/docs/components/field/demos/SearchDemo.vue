<template>
  <div class="search-demo">
    <!-- 基础搜索框 -->
    <div class="demo-section">
      <HTField v-model="searchValue1" label="基础搜索框" type="search" placeholder="请输入搜索内容" clearable />
    </div>
    <div class="h-[8px]"></div>
    <!-- 带左侧图标的搜索框 -->
    <div class="demo-section">
      <HTField
        v-model="searchValue2"
        label="带左侧图标的搜索框"
        type="search"
        placeholder="搜索商品"
        left-icon="hot-o"
        clearable
      />
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import { HTField } from '@hytech/ht-ui';

const searchValue1 = ref('');
const searchValue2 = ref('');
</script>
