<script setup lang="ts">
import { ref } from 'vue';
import { HTField } from '@hytech/ht-ui';

const valueDisabled = ref('不可编辑内容');
const valueReadonly = ref('只读内容');
</script>
<template>
  <div class="demo-disabled-readonly">
    <HTField v-model="valueDisabled" label="禁用" disabled />
    <div class="h-[8px]"></div>
    <HTField v-model="valueReadonly" label="只读" readonly />
  </div>
</template>
