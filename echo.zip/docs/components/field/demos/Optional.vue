<script setup lang="ts">
import { ref } from 'vue';
import { HTField } from '@hytech/ht-ui';

const valueOpt = ref('');
</script>
<template>
  <div class="demo-optional">
    <!-- optional: 显示“可选”或自定义文字；required 为 false 时展示 -->
    <HTField v-model="valueOpt" label="邮箱" optional="可选" placeholder="请输入邮箱 (可选)" />
    <div class="h-[8px]"></div>
    <!-- 可自定义 optional 为任意字符串 -->
    <HTField v-model="valueOpt" label="公司" optional="(非必须)" placeholder="请输入公司名称" />
  </div>
</template>

<style scoped></style>
