<template>
  <HTField v-model="sms" center clearable label="短信验证码" placeholder="请输入短信验证码">
    <template #right> <HTButton size="mini">发送验证码</HTButton> </template>
  </HTField>
  <div class="h-[8px]"></div>
  <div class="field-dropdown">
    <HTField v-model="phone" center clearable label="手机号" placeholder="请输入手机号">
      <template #left>
        <HTSelect class="w-full md:w-60" v-model:value="country" placeholder="请选择国家" :options="options" />
      </template>
    </HTField>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import { HTButton, HTField, HTSelect } from '@hytech/ht-ui';
import { mock } from 'mockjs';

const sms = ref('');
const { options } = mock({
  'options|5-10': [
    {
      label: '@word(5,10)',
      value: '@uuid',
    },
  ],
});
const country = ref<string>();
const phone = ref('');
</script>
<style>
.field-dropdown .ht-select {
  border: none;
  width: auto;
  border-radius: 0%;
  border-right: 1px solid #d5d7da;
  height: 24px;
  padding-left: 0;
  background: transparent;
}
</style>
