<script setup lang="ts">
import { ref } from 'vue';
import { HTField } from '@hytech/ht-ui';

const valueIcon1 = ref('');
const valueIcon2 = ref('');
</script>
<template>
  <div class="demo-icons">
    <HTField v-model="valueIcon1" label="文本" right-icon="user" left-icon="warn-o" placeholder="显示图标" />
    <div class="h-[8px]"></div>
    <HTField v-model="valueIcon2" label="文本" left-icon="refund-o" clearable placeholder="显示清除图标" />
  </div>
</template>
