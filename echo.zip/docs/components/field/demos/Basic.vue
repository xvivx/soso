<script setup lang="ts">
import { ref } from 'vue';
import { HTField } from '@hytech/ht-ui';

const valueBasic = ref('');
</script>
<template>
  <HTField label="文本" placeholder="Enter your username" :clearable="true" v-model="valueBasic" />
</template>
