# Radio 单选框
在一组备选项中进行单选。

## 基础用法
通过 v-model 绑定值当前选中项的 name。
<demo vue="./examples/Basic.vue" codesandbox="true" />

## 排列方向
通过 direction 属性设置排列方向。。
<demo vue="./examples/Direction.vue" codesandbox="true" />

## 禁用状态
通过 disabled 属性禁止选项切换，在 Radio 上设置 disabled 可以禁用单个选项。
<demo vue="./examples/Disabled.vue" codesandbox="true" />

## 自定义颜色
通过 checked-color 属性设置选中状态的图标颜色。
<demo vue="./examples/CheckedColor.vue" codesandbox="true" />

## 自定义大小
通过 icon-size 属性可以自定义图标的大小。
<demo vue="./examples/IconSize.vue" codesandbox="true" />

## 自定义图标
通过 icon 插槽自定义图标，并通过 slotProps 判断是否为选中状态。
<demo vue="./examples/CustomIcon.vue" codesandbox="true" />

## 左侧文本
将 label-position 属性设置为 'left'，可以将文本位置调整到单选框左侧。
<demo vue="./examples/LabelPosition.vue" codesandbox="true" />

## 自定义形状
通过 shape 属性设置单选框的形状。`round` 为勾选图标样式（默认），`dot` 为圆点样式。
<demo vue="./examples/Shape.vue" codesandbox="true" />

## 颜色主题
通过 variant 属性设置单选框的颜色主题。`primary` 为蓝色主题（默认），`secondary` 为绿色主题。
<demo vue="./examples/Variant.vue" codesandbox="true" />

## RadioGroup

### Props

| 参数           | 说明                                | 类型                | 默认值         |
| -------------- | ----------------------------------- | ------------------- | -------------- | 
| v-model        | 当前选中项的标识符                  | `AcceptableValue`   | -              |
| disabled       | 是否禁用所有单选框                  | `boolean`           | -              |
| direction      | 排列方向，可选值为 horizontal       | `"vertical"`        | `"horizontal"` | vertical |
| label-position | 文本位置，可选值为 left             | `"left" \| "right"` | `"right"`      |
| icon-size      | 所有单选框的图标大小，可选值为 small 或自定义尺寸，默认单位为 px | `number \| string \| 'small'`  | -              |
| checked-color  | 所有单选框的选中状态颜色            | `string`            | -              |
| shape          | 形状，可选值为 dot                  | `"round" \| "dot"`  | `"round"`      |
| variant        | 颜色主题，可选值为 secondary        | `"primary" \| "secondary"`  | `"primary"`      |

### Events

| 事件名 | 说明                     | 参数           |
| ------ | ------------------------ | -------------- |
| change | 当绑定值变化时触发的事件 | `name: string` |

### Slots

| 名称    | 说明                |
| ------- | ------------------- |
| default | 放置 `HTRadio` 子项 |

---

## Radio

### Props

| 参数          | 说明                                 | 类型      | 默认值  |
| ------------- | ------------------------------------ | --------- | ------- |
| name          | 标识符，通常为一个唯一的字符串或数字 | `string   \| number` | -   |
| disabled      | 是否为禁用状态                       | `boolean` | false   |
| label-position | 文本位置，可选值为 left             | `"left" \| "right"` | `"right"`      |
| icon-size     | 图标大小，可选值为 small 或自定义尺寸，默认单位为 px | `number  \| string \| 'small'` | -   |
| checked-color | 选中状态颜色                         | `string`  | -       |
| shape         | 形状，可选值为 dot                   | `"round" \| "dot"`  | `"round"`      |
| variant       | 颜色主题，可选值为 secondary         | `"primary" \| "secondary"`  | `"primary"`      |

### Events

| 事件名 | 说明             | 参数                |
| ------ | ---------------- | ------------------- |
| click  | 点击单选框时触发 | `event: MouseEvent` |

### Slots

| 名称    | 说明                 |     参数       |
| ------- | -------------------- | -------------- |
| default | 自定义文本自定义文本 | `{ checked: boolean, disabled: boolean }` |
| icon    | 自定义图标   | `{ checked: boolean, disabled: boolean }` |

### 类型定义

组件导出以下类型定义：

```ts
import type {
  RadioGroupDirection,
  RadioGroupProps,
  RadioLabelPosition,
  RadioProps,
  RadioShape,
  RadioVariant
} from '@hytech/ht-ui';
```
