<script setup lang="ts">
import { ref } from 'vue';

const checked = ref('a');
</script>

<template>
  <HTRadioGroup v-model="checked">
    <HTRadio name="a" disabled>单选框 1</HTRadio>
    <HTRadio name="b">单选框 2</HTRadio>
  </HTRadioGroup>
</template>
