<script setup lang="ts">
import { ref } from 'vue';

const checked = ref('1');
</script>

<template>
  <HTRadioGroup v-model="checked">
    <HTRadio name="1" checked-color="#ee0a24">单选框 1</HTRadio>
    <HTRadio name="2" checked-color="#ee0a24">单选框 2</HTRadio>
  </HTRadioGroup>
</template>
