<script setup lang="ts">
import { ref } from 'vue';

const checked = ref('1');
</script>

<template>
  <HTRadioGroup v-model="checked">
    <HTRadio name="1" icon-size="24px">
      <template #icon="{ checked }">
        <HTIcon name="placeholder" :color="checked ? '#ee0a24' : ''" />
      </template>
      单选框 1
    </HTRadio>
    <HTRadio name="2" icon-size="24px">
      <template #icon="{ checked }">
        <HTIcon name="placeholder" :color="checked ? '#ee0a24' : ''" />
      </template>
      单选框 2
    </HTRadio>
  </HTRadioGroup>
</template>
