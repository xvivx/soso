<script setup lang="ts">
import { ref } from 'vue';
import { HTRadio, HTRadioGroup } from '@hytech/ht-ui';

const checked1 = ref('1');
const checked2 = ref('1');
const checked3 = ref('1');
</script>

<template>
  <div class="demo-block">
    <div class="demo-section">
      <p class="demo-label">默认尺寸</p>
      <HTRadioGroup v-model="checked1">
        <HTRadio name="1">单选框 1</HTRadio>
        <HTRadio name="2">单选框 2</HTRadio>
      </HTRadioGroup>
    </div>

    <div class="demo-section">
      <p class="demo-label">小尺寸</p>
      <HTRadioGroup v-model="checked2" icon-size="small">
        <HTRadio name="1">单选框 1</HTRadio>
        <HTRadio name="2">单选框 2</HTRadio>
      </HTRadioGroup>
    </div>

    <div class="demo-section">
      <p class="demo-label">自定义尺寸（24px）</p>
      <HTRadioGroup v-model="checked3">
        <HTRadio name="1" icon-size="24px">单选框 1</HTRadio>
        <HTRadio name="2" icon-size="24px">单选框 2</HTRadio>
      </HTRadioGroup>
    </div>
  </div>
</template>

<style scoped>
.demo-block {
  display: flex;
  flex-direction: column;
  gap: 24px;
}

.demo-section {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.demo-label {
  margin: 0;
  font-size: 14px;
  color: #666;
}
</style>
