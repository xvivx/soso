<template>
  <div class="demo-pull-refresh-complete">
    <div class="controls">
      <button @click="toggleDisabled" :class="{ active: disabled }">{{ disabled ? '启用' : '禁用' }} 下拉刷新</button>
      <button @click="manualRefresh" :disabled="disabled">手动触发刷新</button>
      <button @click="triggerError" :disabled="disabled">模拟刷新失败</button>
    </div>

    <HTPullRefresh
      ref="pullRefreshRef"
      v-model="loading"
      :disabled="disabled"
      :pull-distance="pullDistance"
      :success-duration="successDuration"
      :animation-duration="animationDuration"
      @refresh="onRefresh"
      @change="onChange"
      @status-change="onStatusChange"
    >
      <template #normal>
        <div class="custom-normal">
          <span>🔄</span>
          <span>下拉刷新数据</span>
        </div>
      </template>

      <div class="content">
        <div class="status-bar">
          <span>状态: {{ currentStatus }}</span>
          <span>下拉距离: {{ Math.round(currentDistance) }}px</span>
        </div>

        <div class="stats">
          <div class="stat-item">
            <div class="stat-value">{{ totalItems }}</div>
            <div class="stat-label">总条目</div>
          </div>
          <div class="stat-item">
            <div class="stat-value">{{ refreshCount }}</div>
            <div class="stat-label">刷新次数</div>
          </div>
          <div class="stat-item">
            <div class="stat-value">{{ lastRefreshTime }}</div>
            <div class="stat-label">最后刷新</div>
          </div>
        </div>

        <div v-for="item in items" :key="item.id" class="item">
          <div class="item-header">
            <span class="item-title">{{ item.title }}</span>
            <span class="item-time">{{ item.time }}</span>
          </div>
          <div class="item-content">{{ item.content }}</div>
        </div>
      </div>
    </HTPullRefresh>
  </div>
</template>

<script setup lang="ts">
import { computed, ref } from 'vue';
import { HTPullRefresh } from '@/components/pull-refresh';

const pullRefreshRef = ref();
const loading = ref(false);
const disabled = ref(false);
const pullDistance = ref(80);
const successDuration = ref(800);
const animationDuration = ref(400);
const currentStatus = ref('normal');
const currentDistance = ref(0);
const refreshCount = ref(0);
const shouldError = ref(false);

const items = ref([
  { id: 1, title: '项目进展', content: '本周项目进度正常，各项指标均达到预期', time: '10:30' },
  { id: 2, title: '系统更新', content: '系统已完成安全更新，性能有所提升', time: '09:15' },
  { id: 3, title: '用户反馈', content: '收到用户积极反馈，满意度有所提升', time: '昨天' },
]);

const totalItems = computed(() => items.value.length);
const lastRefreshTime = computed(() => new Date().toLocaleTimeString());

const onRefresh = () => {
  console.log('刷新触发');

  setTimeout(() => {
    if (shouldError.value) {
      shouldError.value = false;
      pullRefreshRef.value?.complete(false);
      return;
    }

    // 模拟添加新数据
    const newItem = {
      id: Date.now(),
      title: `新动态 ${refreshCount.value + 1}`,
      content: '这是刚刚通过下拉刷新获取的最新动态内容',
      time: '刚刚',
    };

    items.value.unshift(newItem);
    if (items.value.length > 10) {
      items.value = items.value.slice(0, 10);
    }

    refreshCount.value++;
    loading.value = false;
  }, 1500);
};

const onChange = (data: { status: string; distance: number }) => {
  currentDistance.value = data.distance;
};

const onStatusChange = (status: string) => {
  currentStatus.value = status;
};

const toggleDisabled = () => {
  disabled.value = !disabled.value;
};

const manualRefresh = () => {
  if (!disabled.value) {
    pullRefreshRef.value?.triggerRefresh();
  }
};

const triggerError = () => {
  shouldError.value = true;
  if (!disabled.value) {
    pullRefreshRef.value?.triggerRefresh();
  }
};
</script>

<style scoped>
.demo-pull-refresh-complete {
  height: 400px;
  border: 1px solid #eee;
  border-radius: 8px;
  overflow: hidden;
}

.controls {
  display: flex;
  gap: 8px;
  padding: 12px;
  background: #f5f5f5;
  border-bottom: 1px solid #eee;
}

.controls button {
  padding: 6px 12px;
  border: 1px solid #ddd;
  border-radius: 4px;
  background: white;
  cursor: pointer;
  font-size: 12px;
  transition: all 0.2s;
}

.controls button:hover:not(:disabled) {
  background: #f0f0f0;
  border-color: #1677ff;
  color: #1677ff;
}

.controls button.active {
  background: #ff4d4f;
  color: white;
  border-color: #ff4d4f;
}

.controls button:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.custom-normal {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  padding: 16px;
  color: #666;
  font-size: 14px;
}

.content {
  padding: 16px;
}

.status-bar {
  display: flex;
  justify-content: space-between;
  padding: 8px 12px;
  background: #f9f9f9;
  border-radius: 6px;
  margin-bottom: 16px;
  font-size: 12px;
  color: #666;
}

.stats {
  display: flex;
  gap: 16px;
  margin-bottom: 16px;
}

.stat-item {
  flex: 1;
  text-align: center;
  padding: 12px;
  background: #f8f9fa;
  border-radius: 8px;
}

.stat-value {
  font-size: 18px;
  font-weight: 600;
  color: #1677ff;
  margin-bottom: 4px;
}

.stat-label {
  font-size: 12px;
  color: #666;
}

.item {
  padding: 12px;
  margin-bottom: 8px;
  background: white;
  border: 1px solid #e8e8e8;
  border-radius: 8px;
}

.item-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 8px;
}

.item-title {
  font-weight: 500;
  color: #333;
}

.item-time {
  font-size: 12px;
  color: #999;
}

.item-content {
  color: #666;
  font-size: 14px;
  line-height: 1.4;
}
</style>
