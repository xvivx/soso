<template>
  <div class="demo-pull-refresh-success">
    <HTPullRefresh v-model="loading" success-text="数据更新成功！" @refresh="onRefresh">
      <div class="content">
        <p>下拉刷新，显示成功提示</p>
        <div class="update-time">最后更新: {{ updateTime }}</div>
        <div v-for="item in list" :key="item.id" class="list-item">
          {{ item.text }}
        </div>
      </div>
    </HTPullRefresh>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import { HTPullRefresh } from '@/components/pull-refresh';

const loading = ref(false);
const updateTime = ref(new Date().toLocaleTimeString());
const list = ref([
  { id: 1, text: '消息内容 1' },
  { id: 2, text: '消息内容 2' },
  { id: 3, text: '消息内容 3' },
]);

const onRefresh = () => {
  setTimeout(() => {
    // 模拟数据更新
    updateTime.value = new Date().toLocaleTimeString();
    const newId = Math.max(...list.value.map((item) => item.id)) + 1;
    list.value.unshift({ id: newId, text: `新消息 ${newId}` });
    loading.value = false;
  }, 1500);
};
</script>

<style scoped>
.demo-pull-refresh-success {
  height: 300px;
  border: 1px solid #eee;
  border-radius: 8px;
  overflow: hidden;
}

.content {
  padding: 16px;
  text-align: center;
}

.update-time {
  margin-bottom: 16px;
  color: #666;
  font-size: 14px;
}

.list-item {
  padding: 12px;
  margin: 8px 0;
  background: #f5f5f5;
  border-radius: 4px;
  text-align: left;
}
</style>
