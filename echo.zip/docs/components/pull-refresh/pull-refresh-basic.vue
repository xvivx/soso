<template>
  <div class="demo-pull-refresh-basic">
    <HTPullRefresh v-model="loading" @refresh="onRefresh">
      <div class="content">
        <p>下拉刷新列表内容</p>
        <div v-for="item in list" :key="item" class="list-item">列表项 {{ item }}</div>
      </div>
    </HTPullRefresh>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import { HTPullRefresh } from '@/components/pull-refresh';

const loading = ref(false);
const list = ref([1, 2, 3, 4, 5]);

const onRefresh = () => {
  setTimeout(() => {
    // 模拟数据刷新
    const newItem = Math.max(...list.value) + 1;
    list.value.unshift(newItem);
    loading.value = false;
  }, 1000);
};
</script>

<style scoped>
.demo-pull-refresh-basic {
  height: 300px;
  border: 1px solid #eee;
  border-radius: 8px;
  overflow: hidden;
}

.content {
  padding: 16px;
  text-align: center;
}

.list-item {
  padding: 12px;
  margin: 8px 0;
  background: #f5f5f5;
  border-radius: 4px;
}
</style>
