<template>
  <div class="demo-pull-refresh-custom-status">
    <HTPullRefresh v-model="loading" @refresh="onRefresh" @change="onChange" @status-change="onStatusChange">
      <!-- 自定义下拉中状态 -->
      <template #pulling>
        <div class="custom-status pulling">
          <div class="custom-icon">📱</div>
          <span class="custom-text">下拉距离: {{ Math.round(currentDistance) }}px</span>
        </div>
      </template>

      <!-- 自定义释放状态 -->
      <template #loosing>
        <div class="custom-status loosing">
          <div class="custom-icon">🎯</div>
          <span class="custom-text">准备刷新！</span>
        </div>
      </template>

      <!-- 自定义加载中状态 -->
      <template #loading>
        <div class="custom-status loading">
          <div class="custom-spinner"></div>
          <span class="custom-text">拼命加载中...</span>
        </div>
      </template>

      <!-- 自定义成功状态 -->
      <template #success>
        <div class="custom-status success">
          <div class="custom-icon">✨</div>
          <span class="custom-text">数据加载完成！</span>
        </div>
      </template>

      <div class="content">
        <p>自定义状态样式展示</p>
        <div v-for="item in cards" :key="item.id" class="card">
          <div class="card-header">{{ item.title }}</div>
          <div class="card-content">{{ item.content }}</div>
        </div>
      </div>
    </HTPullRefresh>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import { HTPullRefresh } from '@/components/pull-refresh';
import type { PullRefreshStatus } from '@/components/pull-refresh/types';

const loading = ref(false);
const currentDistance = ref(0);
const cards = ref([
  { id: 1, title: '卡片 1', content: '这是第一个卡片的内容' },
  { id: 2, title: '卡片 2', content: '这是第二个卡片的内容' },
  { id: 3, title: '卡片 3', content: '这是第三个卡片的内容' },
]);

const onRefresh = () => {
  setTimeout(() => {
    const newId = Math.max(...cards.value.map((item) => item.id)) + 1;
    cards.value.unshift({
      id: newId,
      title: `新卡片 ${newId}`,
      content: '这是刚刚加载的新卡片内容',
    });
    loading.value = false;
  }, 2000);
};

const onChange = (data: { status: PullRefreshStatus; distance: number }) => {
  currentDistance.value = data.distance;
};

const onStatusChange = (status: PullRefreshStatus) => {
  console.log(status, 'status');
  // 可以按需处理状态变化，这里仅保留距离展示逻辑在 onChange 中
};
</script>

<style scoped>
.demo-pull-refresh-custom-status {
  height: 350px;
  border: 1px solid #eee;
  border-radius: 8px;
  overflow: hidden;
}

.custom-status {
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 16px;
  gap: 8px;
}

.custom-icon {
  font-size: 20px;
}

.custom-text {
  font-size: 14px;
  font-weight: 500;
}

.custom-spinner {
  width: 20px;
  height: 20px;
  border: 2px solid #ddd;
  border-top: 2px solid #1677ff;
  border-radius: 50%;
  animation: spin 1s linear infinite;
}

@keyframes spin {
  0% {
    transform: rotate(0deg);
  }
  100% {
    transform: rotate(360deg);
  }
}

.pulling {
  color: #666;
}

.loosing {
  color: #1677ff;
}

.loading {
  color: #1677ff;
}

.success {
  color: #52c41a;
}

.content {
  padding: 16px;
}

.card {
  margin-bottom: 12px;
  background: white;
  border: 1px solid #e8e8e8;
  border-radius: 8px;
  overflow: hidden;
}

.card-header {
  padding: 12px 16px;
  background: #fafafa;
  font-weight: 500;
  border-bottom: 1px solid #e8e8e8;
}

.card-content {
  padding: 16px;
  color: #666;
}
</style>
