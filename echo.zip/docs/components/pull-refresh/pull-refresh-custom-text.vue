<template>
  <div class="demo-pull-refresh-custom-text">
    <HTPullRefresh
      v-model="loading"
      pulling-text="继续下拉获取最新内容"
      loosing-text="松开手指立即刷新"
      loading-text="正在努力加载中..."
      success-text="太棒了，内容已更新"
      @refresh="onRefresh"
    >
      <div class="content">
        <p>自定义状态提示文本</p>
        <div v-for="item in articles" :key="item.id" class="article-item">
          <h4>{{ item.title }}</h4>
          <p>{{ item.summary }}</p>
        </div>
      </div>
    </HTPullRefresh>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import { HTPullRefresh } from '@/components/pull-refresh';

const loading = ref(false);
const articles = ref([
  { id: 1, title: 'Vue 3 新特性解析', summary: '深入了解 Vue 3 的组合式 API' },
  { id: 2, title: 'TypeScript 最佳实践', summary: '提升代码质量的 TypeScript 技巧' },
  { id: 3, title: '组件设计模式', summary: '构建可复用的 Vue 组件' },
]);

const onRefresh = () => {
  setTimeout(() => {
    // 模拟获取新文章
    const newId = Math.max(...articles.value.map((item) => item.id)) + 1;
    articles.value.unshift({
      id: newId,
      title: `最新文章 ${newId}`,
      summary: '这是一篇刚刚发布的精彩文章内容',
    });
    loading.value = false;
  }, 1200);
};
</script>

<style scoped>
.demo-pull-refresh-custom-text {
  height: 300px;
  border: 1px solid #eee;
  border-radius: 8px;
  overflow: hidden;
}

.content {
  padding: 16px;
}

.article-item {
  margin-bottom: 16px;
  padding: 12px;
  background: #f9f9f9;
  border-radius: 8px;
  text-align: left;
}

.article-item h4 {
  margin: 0 0 8px 0;
  color: #333;
}

.article-item p {
  margin: 0;
  color: #666;
  font-size: 14px;
}
</style>
