# HTPullRefresh 下拉刷新

下拉刷新组件，支持触摸手势、多种状态展示和自定义样式。完全兼容 Vant PullRefresh API。

## 基础用法

<demo vue="./pull-refresh-basic.vue" codesandbox="true" />

## 成功提示

<demo vue="./pull-refresh-success.vue" codesandbox="true" />

## 自定义提示文本

<demo vue="./pull-refresh-custom-text.vue" codesandbox="true" />

## 自定义状态样式

<demo vue="./pull-refresh-custom-status.vue" codesandbox="true" />

## 完整示例

<demo vue="./pull-refresh-complete.vue" codesandbox="true" />

## Attributes

| Attribute | Description | Type | Default | Vant 兼容 |
| --- | --- | --- | --- | --- |
| `modelValue` | 是否处于加载中状态，支持 v-model 双向绑定 | `boolean` | `false` | ✅ |
| `disabled` | 是否禁用下拉刷新 | `boolean` | `false` | ✅ |
| `successText` | 下拉刷新成功提示文字 | `string` | `'刷新成功'` | ✅ |
| `errorText` | 下拉刷新失败提示文字 | `string` | `'刷新失败'` | ✅ |
| `loadingText` | 加载中状态提示文字 | `string` | `'加载中...'` | ✅ |
| `pullingText` | 下拉状态提示文字 | `string` | `'下拉刷新'` | ✅ |
| `loosingText` | 释放即可刷新时提示文字 | `string` | `'释放刷新'` | ✅ |
| `headHeight` | 顶部内容高度（像素） | `number \| string` | `50` | ✅ |
| `pullDistance` | 触发下拉刷新的距离（像素） | `number` | `50` | ✅ |
| `successDuration` | 成功提示的展示时长（毫秒） | `number` | `500` | ✅ |
| `animationDuration` | 动画时长（毫秒） | `number` | `300` | ✅ |
| `className` | 自定义类名 | `string` | - | ✅ |
| `style` | 自定义样式 | `string \| Record<string, string \| number>` | - | ✅ |
| `disablePullAnimation` | 是否禁用头部回弹动画 | `boolean` | `false` | ✅ |
| `dampingFactor` | 自定义下拉刷新的阻尼系数 | `number` | `0.85` | ✅ |

## Events

| Event | Description | Parameters | Vant 兼容 |
| --- | --- | --- | --- |
| `refresh` | 下拉刷新触发时调用 | - | ✅ |
| `change` | 下拉状态改变时调用 | `(data: { status: PullRefreshStatus; distance: number })` | ✅ |
| `update:modelValue` | 更新 modelValue，用于 v-model 双向绑定 | `(value: boolean)` | ✅ |
| `status-change` | 下拉状态改变时调用 | `(status: PullRefreshStatus)` | ✅ |
| `pull-start` | 开始下拉时调用 | - | ✅ |
| `pull-move` | 下拉移动时调用 | `(distance: number)` | ✅ |
| `pull-end` | 下拉结束但未触发刷新时调用 | - | ✅ |

## Slots

| Slot | Description | Parameters | Vant 兼容 |
| --- | --- | --- | --- |
| `default` | 自定义下拉刷新中的内容 | - | ✅ |
| `normal` | 自定义默认状态提示内容 | - | ✅ |
| `pulling` | 自定义下拉中状态提示内容 | - | ✅ |
| `loosing` | 自定义释放状态提示内容 | - | ✅ |
| `loading` | 自定义加载中状态提示内容 | - | ✅ |
| `success` | 自定义成功状态提示内容 | - | ✅ |
| `error` | 自定义失败状态提示内容 | - | ✅ |

## Methods

通过 ref 可以获取到 HTPullRefresh 实例并调用实例方法。

| Method | Description | Parameters | Return | Vant 兼容 |
| --- | --- | --- | --- |
| `triggerRefresh` | 手动触发刷新 | - | `void` | ✅ |
| `complete` | 完成刷新操作 | `(success?: boolean)` | `void` | ✅ |
| `getStatus` | 获取当前状态 | - | `PullRefreshStatus` | ✅ |
| `getDistance` | 获取当前下拉距离 | - | `number` | ✅ |

## 主题定制

基于 H5组件三级token.md 规范，支持以下 CSS 变量：

```css
.ht-pull-refresh {
  /* 容器样式 */
  --pull-refresh-container-height-default: auto;

  /* 下拉头部样式 */
  --pull-refresh-header-padding-default: 16px 0;
  --pull-refresh-header-icon-size-default: 20px;
  --pull-refresh-header-icon-color-default: #8C8C8C;
  --pull-refresh-header-icon-color-active: #1677FF;
  --pull-refresh-header-font-size-default: 12px;
  --pull-refresh-header-text-color-default: #8C8C8C;
  --pull-refresh-header-text-color-active: #1677FF;

  /* 加载状态样式 */
  --pull-refresh-loading-size-default: 20px;
  --pull-refresh-loading-color-default: #1677FF;

  /* 内容区域样式 */
  --pull-refresh-content-margin-default: 0;

  /* 动画时长 */
  --pull-refresh-transition-duration: 0.3s;
}
```

## 状态说明

PullRefreshStatus 包含以下状态：

- `normal`: 默认状态，未进行下拉操作
- `pulling`: 下拉中状态，未达到触发距离
- `loosing`: 释放即可刷新状态，达到触发距离
- `loading`: 加载中状态，正在执行刷新操作
- `success`: 刷新成功状态，显示成功提示
- `error`: 刷新失败状态，显示错误提示

## Vant API 兼容性

| Vant API | HT 实现 | 说明 |
| --- | --- | --- |
| v-model | ✅ 完全兼容 | 支持 `v-model:loading` 双向绑定 |
| disabled | ✅ 完全兼容 | 禁用下拉刷新功能 |
| success-text | ✅ 完全兼容 | 成功提示文本 |
| error-text | ✅ 完全兼容 | 失败提示文本 |
| loading-text | ✅ 完全兼容 | 加载提示文本 |
| pulling-text | ✅ 完全兼容 | 下拉提示文本 |
| loosing-text | ✅ 完全兼容 | 释放提示文本 |
| head-height | ✅ 完全兼容 | 头部高度设置 |
| pull-distance | ✅ 完全兼容 | 触发距离设置 |
| success-duration | ✅ 完全兼容 | 成功状态持续时间 |
| animation-duration | ✅ 完全兼容 | 动画持续时间 |
| @refresh | ✅ 完全兼容 | 刷新事件 |
| @change | ✅ 完全兼容 | 状态变化事件 |
| 所有插槽 | ✅ 完全兼容 | 支持所有状态的自定义插槽 |
| 所有方法 | ✅ 完全兼容 | 通过 ref 调用实例方法 |