<template>
  <div class="demo-container">
    <h3>垂直分割线</h3>
    <p>添加 vertical 属性来展示垂直分割线。</p>

    <div class="demo-section">
      <div class="vertical-demo">
        <span>文本</span>
        <HTDivider vertical />
        <a href="#">链接</a>
        <HTDivider vertical />
        <a href="#">链接</a>
      </div>
    </div>

    <div class="demo-section">
      <div class="vertical-demo">
        <span>选项一</span>
        <HTDivider vertical dashed />
        <span>选项二</span>
        <HTDivider vertical dashed />
        <span>选项三</span>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { HTDivider } from '@hytech/ht-ui';
</script>

<style scoped>
.demo-container {
  padding: 16px;
}

.demo-section {
  margin: 16px 0;
  padding: 16px;
  border: 1px solid hsl(var(--border));
  border-radius: 8px;
}

.vertical-demo {
  display: flex;
  align-items: center;
  color: hsl(var(--foreground));
}

.vertical-demo span,
.vertical-demo a {
  color: hsl(var(--foreground));
  text-decoration: none;
}

.vertical-demo a:hover {
  color: hsl(var(--primary));
}
</style>
