<template>
  <div class="demo-container">
    <h3>虚线</h3>
    <p>添加 dashed 属性使分割线渲染为虚线。</p>

    <div class="demo-section">
      <p>实线分割线</p>
      <HTDivider />
      <p>虚线分割线</p>
      <HTDivider dashed />
      <p>虚线分割线带文本</p>
      <HTDivider dashed>虚线文本</HTDivider>
      <p>底部内容</p>
    </div>
  </div>
</template>

<script setup lang="ts">
import { HTDivider } from '@hytech/ht-ui';
</script>

<style scoped>
.demo-container {
  padding: 16px;
}

.demo-section {
  margin: 16px 0;
  padding: 16px;
  border: 1px solid hsl(var(--border));
  border-radius: 8px;
}

.demo-section p {
  margin: 8px 0;
  color: hsl(var(--foreground));
}
</style>
