# Divider 分割线

用于将内容分隔为多个区域。

## 基础用法

默认渲染一条水平分割线。

<demo vue="./divider-basic.vue" />

## 展示文本

通过插槽在分割线中间插入内容。

<demo vue="./divider-content.vue" />

## 内容位置

通过 `content-position` 指定内容所在位置。

<demo vue="./divider-position.vue" />

## 虚线

添加 `dashed` 属性使分割线渲染为虚线。

<demo vue="./divider-dashed.vue" />

## 垂直分割线

添加 `vertical` 属性来展示垂直分割线。

<demo vue="./divider-vertical.vue" />

## 自定义样式

可以直接通过 style 设置分割线的样式。

<demo vue="./divider-custom.vue" />

## Props

| 参数 | 说明 | 类型 | 默认值 | Vant 兼容性 |
|------|------|------|--------|-------------|
| dashed | 是否使用虚线 | `boolean` | `false` | ✅ 完全兼容 |
| hairline | 是否使用 0.5px 线 | `boolean` | `true` | ✅ 完全兼容 |
| content-position | 内容位置，可选值为 `left` `center` `right` | `string` | `center` | ✅ 完全兼容 |
| vertical | 是否垂直显示 | `boolean` | `false` | ✅ 完全兼容 |

## Slots

| 名称 | 说明 | Vant 兼容性 |
|------|------|-------------|
| default | 内容 | ✅ 完全兼容 |

## 主题定制

### CSS 变量

组件提供了下列 CSS 变量，可用于自定义样式。

| 名称 | 默认值 | 说明 |
|------|--------|------|
| --ht-divider-margin | `16px 0` | 分割线边距 |
| --ht-divider-text-color | `hsl(var(--muted-foreground))` | 文本颜色 |
| --ht-divider-font-size | `14px` | 文本字号 |
| --ht-divider-line-height | `24px` | 文本行高 |
| --ht-divider-border-color | `hsl(var(--border))` | 分割线颜色 |
| --ht-divider-content-padding | `0 16px` | 内容内边距 |
| --ht-divider-content-left-width | `10%` | 左侧内容时左侧线条宽度 |
| --ht-divider-content-right-width | `10%` | 右侧内容时右侧线条宽度 |

### 自定义主题

```css
:root {
  --ht-divider-text-color: #1989fa;
  --ht-divider-border-color: #1989fa;
  --ht-divider-font-size: 16px;
}
```

## Vant API 兼容性

| API 类型 | 兼容性 | 说明 |
|----------|--------|------|
| **Props** | ✅ 完全兼容 | 所有 Props 完全对齐 Vant |
| **Slots** | ✅ 完全兼容 | 插槽使用方式完全一致 |
| **Styling** | ✅ 完全兼容 | CSS 变量命名对齐 Vant |

### 新增功能

- 🎨 **更好的主题集成**：与 shadcn/vue 主题系统完美集成
- 📱 **响应式设计**：在移动端自动调整样式
- 🎯 **TypeScript 支持**：完整的类型定义和智能提示
- ⚡ **性能优化**：使用 Tailwind CSS 和 CVA 优化样式

### 注意事项

1. **样式系统**：使用 Tailwind CSS 和 CSS 变量，与 Vant 的样式实现方式不同
2. **主题定制**：CSS 变量名称保持与 Vant 一致，但值使用 shadcn/vue 主题系统
3. **响应式**：在小屏幕设备上自动调整内边距和字体大小
4. **无障碍性**：遵循 ARIA 标准，提供更好的可访问性支持

## 迁移指南

### 从 Vant 迁移

HTDivider 与 Vant Divider 完全兼容，无需修改任何代码：

```vue
<!-- Vant 用法 -->
<van-divider>文本</van-divider>
<van-divider dashed>虚线</van-divider>
<van-divider content-position="left">左侧</van-divider>

<!-- HTDivider 用法（完全相同） -->
<Divider>文本</Divider>
<Divider dashed>虚线</Divider>
<Divider content-position="left">左侧</Divider>
```

### 迁移步骤

1. **更新导入**：
   ```ts
   // 替换
   import { Divider } from 'vant';
   // 为
   import { Divider } from '@/components';
   ```

2. **样式迁移**：
   - 原有的 CSS 变量名称保持不变
   - 可以利用新的主题系统进行更灵活的定制

3. **享受新特性**：
   - 更好的 TypeScript 支持
   - 与 shadcn/vue 主题系统集成
   - 响应式设计优化