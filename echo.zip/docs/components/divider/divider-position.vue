<template>
  <div class="demo-container">
    <h3>内容位置</h3>
    <p>通过 content-position 指定内容所在位置。</p>

    <div class="demo-section">
      <p>左侧内容</p>
      <HTDivider content-position="left">左侧</HTDivider>
      <p>中间内容</p>
      <HTDivider content-position="center">中间</HTDivider>
      <p>右侧内容</p>
      <HTDivider content-position="right">右侧</HTDivider>
      <p>下方内容</p>
    </div>
  </div>
</template>

<script setup lang="ts">
import { HTDivider } from '@hytech/ht-ui';
</script>

<style scoped>
.demo-container {
  padding: 16px;
}

.demo-section {
  margin: 16px 0;
  padding: 16px;
  border: 1px solid hsl(var(--border));
  border-radius: 8px;
}

.demo-section p {
  margin: 8px 0;
  color: hsl(var(--foreground));
}
</style>
