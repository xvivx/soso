<template>
  <div class="demo-container">
    <h3>自定义样式</h3>
    <p>可以直接通过 style 设置分割线的样式。</p>

    <div class="demo-section">
      <p>默认样式</p>
      <HTDivider />

      <p>自定义颜色和字体大小</p>
      <HTDivider style="color: #1989fa; border-color: #1989fa; font-size: 16px"> 蓝色分割线 </HTDivider>

      <p>自定义边距</p>
      <HTDivider style="margin: 24px 0"> 大边距 </HTDivider>

      <p>自定义线条粗细</p>
      <HTDivider :hairline="false"> 粗线条 </HTDivider>
    </div>
  </div>
</template>

<script setup lang="ts">
import { HTDivider } from '@hytech/ht-ui';
</script>

<style scoped>
.demo-container {
  padding: 16px;
}

.demo-section {
  margin: 16px 0;
  padding: 16px;
  border: 1px solid hsl(var(--border));
  border-radius: 8px;
}

.demo-section p {
  margin: 8px 0;
  color: hsl(var(--foreground));
}
</style>
