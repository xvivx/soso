<template>
  <div class="demo-container">
    <h3>基础用法</h3>
    <p>默认渲染一条水平分割线。</p>

    <div class="demo-section">
      <p>上方内容</p>
      <HTDivider />
      <p>下方内容</p>
    </div>
  </div>
</template>

<script setup lang="ts">
import { HTDivider } from '@hytech/ht-ui';
</script>

<style scoped>
.demo-container {
  padding: 16px;
}

.demo-section {
  margin: 16px 0;
  padding: 16px;
  border: 1px solid hsl(var(--border));
  border-radius: 8px;
}

.demo-section p {
  margin: 8px 0;
  color: hsl(var(--foreground));
}
</style>
