<template>
  <div class="demo-button-plain">
    <HTButton plain type="default">朴素默认</HTButton>
    <HTButton plain type="primary">朴素主要</HTButton>
    <HTButton plain type="success">朴素成功</HTButton>
    <HTButton plain type="warning">朴素警告</HTButton>
    <HTButton plain type="danger">朴素危险</HTButton>
  </div>
</template>

<script setup lang="ts">
import { HTButton } from '@hytech/ht-ui';
</script>

<style scoped>
.demo-button-plain {
  display: flex;
  gap: 12px;
  flex-wrap: wrap;
}
</style>
