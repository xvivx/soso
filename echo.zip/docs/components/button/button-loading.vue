<template>
  <div class="demo-button-loading">
    <div class="loading-group">
      <h4>加载状态</h4>
      <HTButton loading type="primary">加载中</HTButton>
      <HTButton loading type="success" loading-text="正在保存...">保存</HTButton>
      <HTButton loading type="warning" loading-text="上传中...">上传</HTButton>
      <HTButton loading type="danger" loading-text="删除中...">删除</HTButton>
    </div>

    <div class="loading-group">
      <h4>不同加载动画</h4>
      <HTButton loading loading-type="circular" type="primary">Circular</HTButton>
      <HTButton loading loading-type="spinner" type="success">Spinner</HTButton>
    </div>

    <div class="loading-group">
      <h4>自定义加载尺寸</h4>
      <HTButton loading :loading-size="16" type="primary">小加载图标</HTButton>
      <HTButton loading :loading-size="24" type="success">大加载图标</HTButton>
      <HTButton loading loading-size="32px" type="warning">超大加载图标</HTButton>
    </div>

    <div class="loading-group">
      <h4>自定义加载状态</h4>
      <HTButton loading type="primary">
        <template #loading>
          <div class="custom-loading">
            <div class="custom-dot"></div>
            <div class="custom-dot"></div>
            <div class="custom-dot"></div>
          </div>
        </template>
        自定义加载
      </HTButton>
    </div>
  </div>
</template>

<script setup lang="ts">
import { HTButton } from '@hytech/ht-ui';
</script>

<style scoped>
.demo-button-loading {
  display: flex;
  flex-direction: column;
  gap: 24px;
}

.loading-group {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.loading-group h4 {
  margin: 0;
  font-size: 14px;
  color: #666;
  font-weight: 500;
}

.loading-group > :not(h4) {
  margin-right: 12px;
}

.custom-loading {
  display: flex;
  gap: 4px;
  align-items: center;
}

.custom-dot {
  width: 6px;
  height: 6px;
  background-color: currentColor;
  border-radius: 50%;
  animation: custom-loading 1.4s ease-in-out infinite both;
}

.custom-dot:nth-child(1) {
  animation-delay: -0.32s;
}

.custom-dot:nth-child(2) {
  animation-delay: -0.16s;
}

@keyframes custom-loading {
  0%,
  80%,
  100% {
    transform: scale(0);
    opacity: 0.5;
  }
  40% {
    transform: scale(1);
    opacity: 1;
  }
}
</style>
