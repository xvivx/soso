# HTButton 按钮

基础按钮组件，支持多种类型、尺寸和状态。参照 Element 与 Vant 的结合式用法，完全兼容 Vant Button API。

## 基础用法

<demo vue="./button-basic.vue" codesandbox="true" />

## 按钮类型

支持 `default`、`primary`、`success`、`warning`、`danger` 五种类型。

<demo vue="./button-types.vue" codesandbox="true" />

## 按钮尺寸

支持 `large`、`normal`、`small`、`mini` 四种尺寸。

<demo vue="./button-sizes.vue" codesandbox="true" />

## 按钮状态

包含禁用状态和加载状态。

<demo vue="./button-states.vue" codesandbox="true" />

## 朴素按钮

通过 `plain` 属性设置为朴素按钮。

<demo vue="./button-plain.vue" codesandbox="true" />

## 按钮形状

支持圆形按钮和方形按钮。

<demo vue="./button-shapes.vue" codesandbox="true" />

## 块级按钮

通过 `block` 属性可以设置为块级元素，宽度会充满其父元素。

<demo vue="./button-block.vue" codesandbox="true" />

## 图标按钮

支持左侧图标、右侧图标和纯图标按钮。

<demo vue="./button-icons.vue" codesandbox="true" />

## 自定义颜色

支持自定义背景色和渐变色。

<demo vue="./button-custom.vue" codesandbox="true" />

## 加载状态

支持不同的加载动画和自定义加载文本。

<demo vue="./button-loading.vue" codesandbox="true" />

## 高级特性

演示组合属性和高级用法。

<demo vue="./button-advanced.vue" codesandbox="true" />

## Attributes

| Attribute | Description | Type | Default | Vant 兼容 |
| --- | --- | --- | --- | --- |
| `type` | 按钮类型 | `'default' \| 'primary' \| 'success' \| 'warning' \| 'danger'` | `'default'` | ✅ |
| `size` | 按钮尺寸 | `'large' \| 'normal' \| 'small' \| 'mini'` | `'normal'` | ✅ |
| `text` | 按钮文本 | `string` | - | ✅ |
| `color` | 自定义颜色 | `string` | - | ✅ |
| `icon` | 图标类名或图片链接 | `string` | - | ✅ |
| `icon-prefix` | 图标类名前缀 | `string` | `'ht-icon'` | ✅ |
| `icon-position` | 图标位置 | `'left' \| 'right'` | `'left'` | ✅ |
| `plain` | 是否为朴素按钮 | `boolean` | `false` | ✅ |
| `block` | 是否为块级元素 | `boolean` | `false` | ✅ |
| `round` | 是否为圆形按钮 | `boolean` | `false` | ✅ |
| `square` | 是否为方形按钮 | `boolean` | `false` | ✅ |
| `loading` | 是否显示加载状态 | `boolean` | `false` | ✅ |
| `disabled` | 是否禁用 | `boolean` | `false` | ✅ |
| `hairline` | 是否使用 0.5px 边框 | `boolean` | `false` | ✅ |
| `loading-text` | 加载时的提示文字 | `string` | - | ✅ |
| `loading-type` | 加载图标类型 | `'spinner' \| 'circular'` | `'circular'` | ✅ |
| `loading-size` | 加载图标大小 | `number \| string` | `20` | ✅ |
| `tag` | 按钮根节点的 HTML 标签 | `keyof HTMLElementTagNameMap` | `'button'` | ✅ |
| `native-type` | 原生 button 的 type 属性 | `'button' \| 'submit' \| 'reset'` | `'button'` | ✅ |
| `url` | 点击后跳转的链接（外部链接） | `string` | - | ✅ |
| `replace` | 是否在跳转时替换当前页面历史记录（仅对 url 有效） | `boolean` | `false` | ✅ |
| `variant` | shadcn-vue 样式变体 | `'default' \| 'destructive' \| 'outline' \| 'secondary' \| 'ghost' \| 'link'` | `'default'` | ⚠️ |
| `className` | 自定义类名 | `string` | - | ⚠️ |
| `asChild` | 是否作为子组件渲染 | `boolean` | `false` | ⚠️ |

## Events

| Event | Description | Parameters | Vant 兼容 |
| --- | --- | --- | --- |
| `click` | 点击按钮时触发 | `(event: MouseEvent)` | ✅ |
| `touchstart` | 触摸开始时触发 | `(event: TouchEvent)` | ✅ |

## Slots

| Slot | Description | Parameters | Vant 兼容 |
| --- | --- | --- | --- |
| `default` | 按钮内容 | - | ✅ |
| `icon` | 自定义图标 | - | ✅ |
| `loading` | 自定义加载状态 | - | ✅ |

## Methods

| Method | Description | Parameters | Return | Vant 兼容 |
| --- | --- | --- | --- | --- |
| - | 暂无暴露方法 | - | - | - |

## 主题定制

HTButton 组件使用 CSS 变量来定制主题，你可以通过修改这些变量来自定义按钮的外观：

```css
.ht-button {
  /* 按钮行高 */
  --button-line-height-default: var(--typography-body-xs-line-height);
  --button-line-height-large: var(--typography-body-l-line-height);
  --button-line-height-small: var(--typography-body-s-line-height);
  --button-line-height-mini: var(--typography-body-s-line-height);

  /* 按钮内边距 */
  --button-container-updown-padding-mini: var(--dimensions-spacing-inset-2xs);
  --button-container-left-right-padding-mini: var(--dimensions-spacing-inset-md);
  --button-container-updown-padding-small: var(--dimensions-spacing-inset-sm);
  --button-container-left-right-padding-small: var(--dimensions-spacing-inset-lg);
  --button-container-updown-padding-default: var(--dimensions-spacing-inset-md);
  --button-container-left-right-padding-default: var(--dimensions-spacing-inset-2xl);
  --button-container-updown-padding-large: var(--dimensions-spacing-inset-lg);
  --button-container-left-right-padding-large: var(--dimensions-spacing-inset-2xl);

  /* 组合内边距 */
  --button-container-padding-default: var(--button-container-updown-padding-default) var(--button-container-left-right-padding-default);
  --button-container-padding-large: var(--button-container-updown-padding-large) var(--button-container-left-right-padding-large);
  --button-container-padding-small: var(--button-container-updown-padding-small) var(--button-container-left-right-padding-small);
  --button-container-padding-mini: var(--button-container-updown-padding-mini) var(--button-container-left-right-padding-mini);

  /* 按钮圆角 */
  --button-container-border-radius-default: var(--dimensions-radius-md);
  --button-container-border-radius-round: var(--dimensions-radius-circle);
  --button-container-border-radius-square: var(--dimensions-radius-xs);

  /* 按钮文本 */
  --button-text-font-size-default: var(--typography-body-l-size);
  --button-text-font-size-large: var(--typography-heading-s-size);
  --button-text-font-size-small: var(--typography-body-m-size);
  --button-text-font-size-mini: var(--typography-body-s-size);
  --button-text-font-weight-default: var(--typography-body-l-weight-strong);

  /* 按钮图标 */
  --button-icon-size-default: var(--dimensions-sizing-icon-2xl);
  --button-icon-gap-default: var(--dimensions-spacing-inset-sm);

  /* 按钮背景色 - 主色调 */
  --button-bg-color-primary: var(--color-brand-background);
  --button-bg-color-primary-hover: color-mix(in srgb, var(--color-brand-background) 80%, black);
  --button-bg-color-primary-active: color-mix(in srgb, var(--color-brand-background) 70%, black);

  /* 按钮背景色 - 其他类型 */
  --button-bg-color-success: var(--color-feedback-success-background);
  --button-bg-color-success-hover: color-mix(in srgb, var(--color-feedback-success-background) 80%, black);
  --button-bg-color-success-active: color-mix(in srgb, var(--color-feedback-success-background) 70%, black);

  --button-bg-color-warning: var(--color-feedback-warning-background);
  --button-bg-color-warning-hover: color-mix(in srgb, var(--color-feedback-warning-background) 80%, black);
  --button-bg-color-warning-active: color-mix(in srgb, var(--color-feedback-warning-background) 70%, black);

  --button-bg-color-danger: var(--color-feedback-error-background);
  --button-bg-color-danger-hover: color-mix(in srgb, var(--color-feedback-error-background) 80%, black);
  --button-bg-color-danger-active: color-mix(in srgb, var(--color-feedback-error-background) 70%, black);

  --button-bg-color-info: var(--color-feedback-info-background);
  --button-bg-color-info-hover: var(--color-surface-secondary);
  --button-bg-color-info-active: var(--color-surface-tertiary);

  --button-bg-color-light: var(--color-feedback-info-background);
  --button-bg-color-plain: var(--color-surface-transparent);
  --button-bg-color-text: var(--color-surface-transparent);

  /* 按钮边框色 */
  --button-border-color-primary: var(--color-brand-border);
  --button-border-color-success: var(--color-feedback-success-border);
  --button-border-color-warning: var(--color-feedback-warning-border);
  --button-border-color-danger: var(--color-feedback-error-border);
  --button-border-color-default: var(--color-neutral-border);
  --button-border-color-plain: var(--color-surface-transparent);

  /* 按钮文本颜色 */
  --button-text-color-primary: var(--color-content-white);
  --button-text-color-success: var(--color-content-white);
  --button-text-color-warning: var(--color-content-white);
  --button-text-color-danger: var(--color-content-white);
  --button-text-color-info: var(--color-content-primary);
  --button-text-color-default: var(--color-content-primary);
  --button-text-color-plain: var(--color-brand-content);

  /* 按钮状态相关 */
  --button-bg-color-disabled: var(--color-surface-disabled);
  --button-text-color-disabled: var(--color-content-disabled);
  --button-border-color-disabled: var(--color-border-disabled);
  --button-opacity-disabled: 0.5;
  --button-transform-active: scale(0.96);
  --button-loading-size-default: 18px;
  --button-loading-color-default: var(--color-surface-primary);
  --button-loading-color-dark: #333333;

  /* 按钮过渡动画 */
  --button-transition-duration: 0.2s;
  --button-transition-timing-function: ease-in-out;

  /* 按钮阴影 */
  --button-shadow-default: none;
  --button-shadow-hover: 0 2px 4px rgba(0, 0, 0, 0.1);
  --button-shadow-active: 0 1px 2px rgba(0, 0, 0, 0.1);
}
```

## Vant API 兼容性

| Vant API | HT 实现 | 说明 |
| --- | --- | --- |
| type | ✅ 完全兼容 | 支持 default, primary, success, warning, danger |
| size | ✅ 完全兼容 | 支持 large, normal, small, mini |
| plain | ✅ 完全兼容 | 朴素按钮样式 |
| block | ✅ 完全兼容 | 块级按钮 |
| round | ✅ 完全兼容 | 圆形按钮 |
| square | ✅ 完全兼容 | 方形按钮 |
| loading | ✅ 完全兼容 | 加载状态 |
| disabled | ✅ 完全兼容 | 禁用状态 |
| hairline | ✅ 完全兼容 | 0.5px 边框 |
| icon | ✅ 完全兼容 | 支持图标类名和图片链接 |
| icon-prefix | ✅ 完全兼容 | 图标类名前缀 |
| icon-position | ✅ 完全兼容 | 支持左右位置 |
| loading-text | ✅ 完全兼容 | 加载文本 |
| loading-type | ✅ 完全兼容 | 支持 spinner, circular |
| loading-size | ✅ 完全兼容 | 加载图标尺寸 |
| color | ✅ 完全兼容 | 自定义颜色，支持渐变 |
| url | ✅ 完全兼容 | 跳转外部链接 |
| to | ❌ 不兼容 | 如需路由跳转，请自行使用 vue-router 实现 |
| replace | ✅ 完全兼容 | 替换历史记录（仅对 url 有效） |
| native-type | ✅ 完全兼容 | 原生按钮类型 |
| tag | ✅ 完全兼容 | 自定义标签 |

## 最佳实践

### 1. 选择合适的按钮类型

- `primary`: 主要操作，如提交、确认
- `success`: 成功状态的操作
- `warning`: 需要注意的操作
- `danger`: 危险操作，如删除
- `default`: 次要操作

### 2. 合理使用加载状态

在异步操作时使用 `loading` 属性，防止重复提交：

```vue
<template>
  <HTButton
    :loading="isSubmitting"
    @click="handleSubmit"
  >
    提交
  </HTButton>
</template>

<script setup>
const isSubmitting = ref(false);

const handleSubmit = async () => {
  isSubmitting.value = true;
  try {
    await submitData();
  } finally {
    isSubmitting.value = false;
  }
};
</script>
```

### 3. 图标使用建议

- 左侧图标用于说明按钮功能
- 右侧图标用于指示方向或展开状态
- 纯图标按钮需要提供 `aria-label` 属性以提高可访问性

### 4. 响应式设计

在移动端建议使用 `large` 尺寸以提供更好的点击体验：

```vue
<HTButton
  size="large"
  class="hidden sm:block sm:btn-normal"
>
  移动端大按钮
</HTButton>
```

### 5. 无障碍支持

按钮组件默认支持键盘导航和屏幕阅读器，可以通过以下方式增强可访问性：

```vue
<HTButton
  :aria-label="buttonAriaLabel"
  :aria-describedby="buttonDescription"
  @click="handleAction"
>
  按钮文本
</HTButton>
```