<template>
  <div class="demo-button-basic">
    <HTButton @click="handleClick">默认按钮</HTButton>
    <HTButton type="primary" @click="handleClick">主要按钮</HTButton>
    <HTButton type="success" @click="handleClick">成功按钮</HTButton>
    <HTButton type="warning" @click="handleClick">警告按钮</HTButton>
    <HTButton type="danger" @click="handleClick">危险按钮</HTButton>
  </div>
</template>

<script setup lang="ts">
import { HTButton } from '@hytech/ht-ui';

const handleClick = () => {
  console.log('按钮被点击');
};
</script>

<style scoped>
.demo-button-basic {
  display: flex;
  gap: 12px;
  flex-wrap: wrap;
}
</style>
