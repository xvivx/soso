<template>
  <div class="flex flex-wrap gap-3">
    <ht-button @click="handleClick">默认按钮</ht-button>
    <ht-button type="primary" @click="handleClick">主要按钮</ht-button>
    <ht-button type="success" @click="handleClick">成功按钮</ht-button>
    <ht-button type="warning" @click="handleClick">警告按钮</ht-button>
    <ht-button type="danger" @click="handleClick">危险按钮</ht-button>
  </div>
</template>

<script setup lang="ts">
const handleClick = () => {
  console.log('按钮被点击');
};
</script>
