<template>
  <div class="demo-button-block">
    <div class="block-demo">
      <h4>块级按钮</h4>
      <HTButton block type="primary">块级按钮</HTButton>
      <HTButton block type="success">成功块级按钮</HTButton>
      <HTButton block type="warning">警告块级按钮</HTButton>
    </div>

    <div class="block-demo">
      <h4>不同尺寸的块级按钮</h4>
      <HTButton block size="large" type="primary">大号块级按钮</HTButton>
      <HTButton block size="normal" type="primary">普通块级按钮</HTButton>
      <HTButton block size="small" type="primary">小号块级按钮</HTButton>
    </div>

    <div class="block-demo">
      <h4>块级图标按钮</h4>
      <HTButton block icon="plus" type="primary">添加新项目</HTButton>
      <HTButton block icon="download" type="success">下载文件</HTButton>
    </div>
  </div>
</template>

<script setup lang="ts">
import { HTButton } from '@hytech/ht-ui';
</script>

<style scoped>
.demo-button-block {
  display: flex;
  flex-direction: column;
  gap: 24px;
  max-width: 400px;
}

.block-demo {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.block-demo h4 {
  margin: 0;
  font-size: 14px;
  color: #666;
  font-weight: 500;
}
</style>
