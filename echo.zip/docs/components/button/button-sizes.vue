<template>
  <div class="demo-button-sizes">
    <div class="size-group">
      <h4>不同尺寸</h4>
      <HTButton size="large" type="primary">大号按钮</HTButton>
      <HTButton size="normal" type="primary">普通按钮</HTButton>
      <HTButton size="small" type="primary">小号按钮</HTButton>
      <HTButton size="mini" type="primary">迷你按钮</HTButton>
    </div>

    <div class="size-group">
      <h4>块级按钮</h4>
      <HTButton block size="large" type="primary">大号块级按钮</HTButton>
      <HTButton block size="normal" type="primary">普通块级按钮</HTButton>
    </div>
  </div>
</template>

<script setup lang="ts">
import { HTButton } from '@hytech/ht-ui';
</script>

<style scoped>
.demo-button-sizes {
  display: flex;
  flex-direction: column;
  gap: 24px;
}

.size-group {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.size-group h4 {
  margin: 0;
  font-size: 14px;
  color: #666;
  font-weight: 500;
}

.size-group > :not(h4) {
  margin-right: 12px;
}
</style>
