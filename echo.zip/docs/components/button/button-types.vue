<template>
  <div class="demo-button-types">
    <div class="type-group">
      <h4>按钮类型</h4>
      <HTButton type="default">默认按钮</HTButton>
      <HTButton type="primary">主要按钮</HTButton>
      <HTButton type="success">成功按钮</HTButton>
      <HTButton type="warning">警告按钮</HTButton>
      <HTButton type="danger">危险按钮</HTButton>
    </div>

    <div class="type-group">
      <h4>朴素按钮</h4>
      <HTButton plain type="default">朴素按钮</HTButton>
      <HTButton plain type="primary">朴素按钮</HTButton>
      <HTButton plain type="success">朴素按钮</HTButton>
      <HTButton plain type="warning">朴素按钮</HTButton>
      <HTButton plain type="danger">朴素按钮</HTButton>
    </div>
  </div>
</template>

<script setup lang="ts">
import { HTButton } from '@hytech/ht-ui';
</script>

<style scoped>
.demo-button-types {
  display: flex;
  flex-direction: column;
  gap: 24px;
}

.type-group {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.type-group h4 {
  margin: 0;
  font-size: 14px;
  color: #666;
  font-weight: 500;
}

.type-group > :not(h4) {
  margin-right: 12px;
}
</style>
