<template>
  <div class="demo-button-icons">
    <div class="icon-group">
      <h4>图标位置</h4>
      <HTButton icon="plus" type="primary">添加</HTButton>
      <HTButton icon="edit" type="warning">编辑</HTButton>
      <HTButton icon="delete" type="danger">删除</HTButton>
      <HTButton icon-position="right" icon="arrow" type="primary">下一步</HTButton>
    </div>

    <div class="icon-group">
      <h4>纯图标按钮</h4>
      <HTButton icon="plus" type="primary" />
      <HTButton icon="edit" type="warning" />
      <HTButton icon="delete" type="danger" />
      <HTButton icon="heart" type="default" />
    </div>

    <div class="icon-group">
      <h4>自定义图标</h4>
      <HTButton type="primary">
        <template #icon>
          <span class="custom-icon">✨</span>
        </template>
        自定义图标
      </HTButton>
      <HTButton type="success">
        <template #icon>
          <span class="custom-icon">🎉</span>
        </template>
        成功
      </HTButton>
    </div>
  </div>
</template>

<script setup lang="ts">
import { HTButton } from '@hytech/ht-ui';
</script>

<style scoped>
.demo-button-icons {
  display: flex;
  flex-direction: column;
  gap: 24px;
}

.icon-group {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.icon-group h4 {
  margin: 0;
  font-size: 14px;
  color: #666;
  font-weight: 500;
}

.icon-group > :not(h4) {
  margin-right: 12px;
}

.custom-icon {
  font-size: 16px;
  line-height: 1;
}
</style>
