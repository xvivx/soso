<template>
  <div class="demo-button-shapes">
    <div class="shape-group">
      <h4>按钮形状</h4>
      <HTButton type="primary">默认按钮</HTButton>
      <HTButton round type="primary">圆形按钮</HTButton>
      <HTButton square type="primary">方形按钮</HTButton>
    </div>

    <div class="shape-group">
      <h4>不同尺寸的形状</h4>
      <div class="size-row">
        <HTButton round size="large" type="primary">大号圆形</HTButton>
        <HTButton round size="normal" type="primary">普通圆形</HTButton>
        <HTButton round size="small" type="primary">小号圆形</HTButton>
        <HTButton round size="mini" type="primary">迷你圆形</HTButton>
      </div>
      <div class="size-row">
        <HTButton square size="large" type="primary">大号方形</HTButton>
        <HTButton square size="normal" type="primary">普通方形</HTButton>
        <HTButton square size="small" type="primary">小号方形</HTButton>
        <HTButton square size="mini" type="primary">迷你方形</HTButton>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { HTButton } from '@hytech/ht-ui';
</script>

<style scoped>
.demo-button-shapes {
  display: flex;
  flex-direction: column;
  gap: 24px;
}

.shape-group {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.shape-group h4 {
  margin: 0;
  font-size: 14px;
  color: #666;
  font-weight: 500;
}

.size-row {
  display: flex;
  gap: 12px;
  align-items: center;
  flex-wrap: wrap;
}

.size-row > :not(h4) {
  margin-right: 0;
}
</style>
