<template>
  <div class="demo-button-custom">
    <div class="custom-group">
      <h4>自定义颜色</h4>
      <HTButton color="#722ed1">紫色按钮</HTButton>
      <HTButton color="#13c2c2">青色按钮</HTButton>
      <HTButton color="#eb2f96">粉色按钮</HTButton>
      <HTButton color="#f5222d">红色按钮</HTButton>
    </div>

    <div class="custom-group">
      <h4>渐变按钮</h4>
      <HTButton color="linear-gradient(to right, #ff6b6b, #4ecdc4)">渐变按钮</HTButton>
      <HTButton color="linear-gradient(135deg, #667eea 0%, #764ba2 100%)">紫色渐变</HTButton>
      <HTButton color="linear-gradient(to bottom, #ff9a9e, #fecfef)">粉色渐变</HTButton>
    </div>

    <div class="custom-group">
      <h4>自定义颜色的朴素按钮</h4>
      <HTButton plain color="#722ed1">紫色朴素</HTButton>
      <HTButton plain color="#13c2c2">青色朴素</HTButton>
      <HTButton plain color="#eb2f96">粉色朴素</HTButton>
    </div>
  </div>
</template>

<script setup lang="ts">
import { HTButton } from '@hytech/ht-ui';
</script>

<style scoped>
.demo-button-custom {
  display: flex;
  flex-direction: column;
  gap: 24px;
}

.custom-group {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.custom-group h4 {
  margin: 0;
  font-size: 14px;
  color: #666;
  font-weight: 500;
}

.custom-group > :not(h4) {
  margin-right: 12px;
}
</style>
