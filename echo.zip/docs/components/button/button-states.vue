<template>
  <div class="demo-button-states">
    <div class="state-group">
      <h4>按钮状态</h4>
      <HTButton @click="handleNormalClick">正常按钮</HTButton>
      <HTButton disabled @click="handleDisabledClick">禁用按钮</HTButton>
      <HTButton loading @click="handleLoadingClick">加载中按钮</HTButton>
    </div>

    <div class="state-group">
      <h4>带加载文本</h4>
      <HTButton loading loading-text="正在提交..." @click="handleSubmit">提交</HTButton>
      <HTButton loading loading-text="保存中..." @click="handleSave">保存</HTButton>
    </div>
  </div>
</template>

<script setup lang="ts">
import { HTButton } from '@hytech/ht-ui';

const handleNormalClick = () => {
  console.log('正常按钮点击');
};

const handleDisabledClick = () => {
  console.log('禁用按钮不会触发点击事件');
};

const handleLoadingClick = () => {
  console.log('加载中按钮不会触发点击事件');
};

const handleSubmit = () => {
  console.log('提交按钮点击');
};

const handleSave = () => {
  console.log('保存按钮点击');
};
</script>

<style scoped>
.demo-button-states {
  display: flex;
  flex-direction: column;
  gap: 24px;
}

.state-group {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.state-group h4 {
  margin: 0;
  font-size: 14px;
  color: #666;
  font-weight: 500;
}

.state-group > :not(h4) {
  margin-right: 12px;
}
</style>
