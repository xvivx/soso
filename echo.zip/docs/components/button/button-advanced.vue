<template>
  <div class="demo-button-advanced">
    <div class="advanced-group">
      <h4>组合属性</h4>
      <HTButton round block type="primary" icon="plus">添加新项目</HTButton>
      <HTButton round plain type="danger" icon="delete">删除操作</HTButton>
      <HTButton square loading type="warning" loading-text="处理中...">处理</HTButton>
    </div>

    <div class="advanced-group">
      <h4>按钮组</h4>
      <div class="button-group">
        <HTButton type="primary">确定</HTButton>
        <HTButton type="default">取消</HTButton>
      </div>
      <div class="button-group">
        <HTButton icon="edit" type="warning">编辑</HTButton>
        <HTButton icon="delete" type="danger">删除</HTButton>
        <HTButton icon="copy" type="default">复制</HTButton>
      </div>
    </div>

    <div class="advanced-group">
      <h4>跳转按钮</h4>
      <HTButton url="https://example.com" type="primary">外部链接</HTButton>
      <HTButton url="https://example.com" replace type="warning">替换链接</HTButton>
      <div class="note">
        <p><strong>注意：</strong>内部路由跳转需要自行使用 vue-router 实现，例如：</p>
        <pre>
&lt;router-link to="/about"&gt;
  &lt;HTButton type="success"&gt;内部路由&lt;/HTButton&gt;
&lt;/router-link&gt;</pre
        >
      </div>
    </div>

    <div class="advanced-group">
      <h4>不同标签</h4>
      <HTButton tag="a" href="#" type="primary">链接按钮</HTButton>
      <HTButton tag="div" type="success">Div按钮</HTButton>
      <HTButton native-type="submit" type="warning">提交按钮</HTButton>
    </div>
  </div>
</template>

<script setup lang="ts">
import { HTButton } from '@hytech/ht-ui';
</script>

<style scoped>
.demo-button-advanced {
  display: flex;
  flex-direction: column;
  gap: 24px;
}

.advanced-group {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.advanced-group h4 {
  margin: 0;
  font-size: 14px;
  color: #666;
  font-weight: 500;
}

.button-group {
  display: flex;
  gap: 8px;
  align-items: center;
}

.button-group > :not(:last-child) {
  margin-right: 0;
}

.note {
  background-color: #f8f9fa;
  border-left: 4px solid #1677ff;
  padding: 12px;
  border-radius: 4px;
  margin-top: 8px;
}

.note p {
  margin: 0 0 8px 0;
  font-size: 14px;
  color: #666;
}

.note pre {
  margin: 0;
  background-color: #f5f5f5;
  padding: 8px;
  border-radius: 4px;
  font-size: 12px;
  overflow-x: auto;
}
</style>
