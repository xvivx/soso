<template>
  <div class="demo-cell">
    <HTCell title="标题" label="描述信息" size="large" />
    <HTCell title="标题" value="右侧内容" label="描述信息" size="large" />
  </div>
</template>

<script setup lang="ts">
import { HTCell } from '@hytech/ht-ui';
</script>

<style scoped>
.demo-cell {
  width: 100%;
  max-width: 600px;
  margin: 0 auto;
  background: var(--color-surface-primary);
  border-radius: var(--dimensions-radius-sm);
}
</style>
