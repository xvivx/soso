<template>
  <HTCell title="单元格" value="内容" :isBorder="false" />
  <HTCell title="单元格" value="内容" />
</template>

<script setup lang="ts">
import { HTCell } from '@hytech/ht-ui';
</script>
