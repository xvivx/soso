<template>
  <div class="demo-cell">
    <HTCell title="必填项" required label="请填写此项" />
    <HTCell title="图标插槽" label="支持自定义图标">
      <template #icon>
        <HTIcon name="eye-line" />
      </template>
      <template #right-icon>
        <i class="cell-icon-default">→</i>
      </template>
    </HTCell>
  </div>
</template>

<script setup lang="ts">
import { HTCell, HTIcon } from '@hytech/ht-ui';
</script>

<style scoped>
.demo-cell {
  width: 100%;
  max-width: 600px;
  margin: 0 auto;
  background: var(--color-surface-primary);
  border-radius: var(--dimensions-radius-sm);
}
</style>
