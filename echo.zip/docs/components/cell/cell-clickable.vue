<template>
  <div class="demo-cell">
    <HTCell title="普通项" value="内容" clickable />
    <HTCell title="链接项" label="描述" is-link clickable />
    <HTCell title="仅箭头" is-link />
  </div>
</template>

<script setup lang="ts">
import { HTCell } from '@hytech/ht-ui';
</script>

<style scoped>
.demo-cell {
  width: 100%;
  max-width: 600px;
  margin: 0 auto;
  background: var(--color-surface-primary);
  border-radius: var(--dimensions-radius-sm);
}
</style>
