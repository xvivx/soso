# HTCell 单元格

列表项容器，用于展示标题、描述、右侧箭头等，常见于设置页与信息展示页。参照 Element 与 Vant 的结合式用法。

## 基础用法

<demo vue="./cell-basic.vue" codesandbox="true" />

## 大号尺寸

<demo vue="./cell-large.vue" codesandbox="true" />

## 可点击态与链接箭头

<demo vue="./cell-clickable.vue" codesandbox="true" />

## 必填标记与图标插槽

<demo vue="./cell-extra.vue" codesandbox="true" />

## 展示分隔线

通过 `is-border` 属性可以控制是否显示单元格的下边框。

<demo vue="./cell-border.vue" codesandbox="true" />

## Attributes

| Attribute | Description | Type | Default | 与 Vant 差异 |
| --- | --- | --- | --- | --- |
| `class` | 自定义类名 | `string \| object \| array` | - | ✨ HTCell 独有 |
| `tag` | 根节点标签 | `string` | `'div'` | ✨ HTCell 独有 |
| `title` | 左侧标题 | `string` | - | ✅ 兼容 |
| `value` | 右侧值 | `string` | - | ✅ 兼容 |
| `label` | 标题下的描述 | `string` | - | ✅ 兼容 |
| `size` | 尺寸 | `'normal' \| 'large'` | `'normal'` | ⚠️ 类型差异：Vant 为 `string`，可选值 `large` |
| `icon` | 左侧图标类名 | `string` | - | ✅ 兼容 |
| `center` | 垂直居中 | `boolean` | `false` | ✅ 兼容 |
| `is-link` | 右侧展示箭头 | `boolean` | `false` | ✅ 兼容 |
| `required` | 左侧必填星号 | `boolean` | `false` | ✅ 兼容 |
| `clickable` | 点击态高亮 | `boolean` | `false` | ⚠️ 默认值差异：Vant 为 `null` |
| `arrow-direction` | 箭头方向 | `'up' \| 'down' \| 'left' \| 'right'` | `'right'` | ✅ 兼容 |
| `is-border` | 是否展示分隔线 | `boolean` | `true` | ⚠️ 属性名差异：Vant 为 `border` |

## Events

| Event | Description | Parameters | 与 Vant 差异 |
| --- | --- | --- | --- |
| `click` | 点击单元格触发 | `(event: MouseEvent)` | ✅ 兼容 |

## Slots

| Slot | Description | 与 Vant 差异 |
| --- | --- | --- |
| `icon` | 左侧图标区域 | ✅ 兼容 |
| `title` | 标题自定义 | ✅ 兼容 |
| `label` | 描述自定义 | ✅ 兼容 |
| `default` | 右侧值内容 | ⚠️ Vant 中为 `value` 插槽 |
| `right-icon` | 右侧箭头或自定义图标 | ✅ 兼容 |

## Methods

| Method | Description | Parameters | 返回值 |
| --- | --- | --- | --- |
| `focus` | 聚焦单元格 | - | `void` |

## 主题定制

```css
.ht-cell {
  --ht-cell-font-size: 14px;
  --ht-cell-line-height: 24px;
  --ht-cell-vertical-padding: 10px;
  --ht-cell-horizontal-padding: 16px;
  --ht-cell-text-color: var(--ht-text-color);
  --ht-cell-background: var(--ht-background-2);
  --ht-cell-border-color: var(--ht-border-color);
  --ht-cell-active-color: var(--ht-active-color);
  --ht-cell-required-color: var(--ht-danger-color);
  --ht-cell-label-color: var(--ht-text-color-2);
  --ht-cell-label-font-size: 12px;
  --ht-cell-label-line-height: 18px;
  --ht-cell-label-margin-top: 4px;
  --ht-cell-value-color: var(--ht-text-color-2);
  --ht-cell-icon-size: 16px;
  --ht-cell-right-icon-color: var(--ht-gray-6);
  --ht-cell-large-vertical-padding: 13px;
  --ht-cell-large-title-font-size: 16px;
}
```

## Vant API 兼容性

| Vant API | HT 实现 | 说明 |
| --- | --- | --- |
| `title` | ✅ 完全兼容 | 无差异 |
| `value` | ✅ 完全兼容 | 无差异 |
| `label` | ✅ 完全兼容 | 无差异 |
| `size` | ✅ 完全兼容 | 无差异 |
| `icon` | ✅ 完全兼容 | 无差异 |
| `center` | ✅ 完全兼容 | 无差异 |
| `is-link` | ✅ 完全兼容 | 无差异 |
| `required` | ✅ 完全兼容 | 无差异 |
| `clickable` | ✅ 完全兼容 | 无差异 |
| `arrow-direction` | ✅ 完全兼容 | 无差异 |
| `border` | ⚠️ 部分兼容 | HTCell 使用 `is-border` |
| `icon-prefix` | ❌ 不支持 | 使用 CSS 类名替代 |
| `title-style` | ❌ 不支持 | 使用 CSS 变量替代 |
| `title-class` | ❌ 不支持 | 使用全局 `class` 属性 |
| `value-class` | ❌ 不支持 | 使用全局 `class` 属性 |
| `label-class` | ❌ 不支持 | 使用全局 `class` 属性 |