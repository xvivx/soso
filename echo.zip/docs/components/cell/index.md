# HTCell 单元格

列表项容器，用于展示标题、描述、右侧箭头等，常见于设置页与信息展示页。参照 Element 与 Vant 的结合式用法。

## 基础用法

<demo vue="./cell-basic.vue" codesandbox="true" />

## 大号尺寸

<demo vue="./cell-large.vue" codesandbox="true" />

## 可点击态与链接箭头

<demo vue="./cell-clickable.vue" codesandbox="true" />

## 必填标记与图标插槽

<demo vue="./cell-extra.vue" codesandbox="true" />

## 展示分隔线

通过 `border` 属性可以控制是否显示单元格的下边框。

<demo vue="./cell-border.vue" codesandbox="true" />

## Attributes

| Attribute | Description | Type | Default | 与 Vant 差异 |
| --- | --- | --- | --- | --- |
| `tag` | 根节点标签 | `string` | `'div'` | ✨ HTCell 独有 |
| `title` | 左侧标题 | `string` | - | ✅ 兼容 |
| `value` | 右侧值 | `string` | - | ✅ 兼容 |
| `label` | 标题下的描述 | `string` | - | ✅ 兼容 |
| `size` | 尺寸 | `'normal' \| 'large'` | `'normal'` | ⚠️ 类型差异：Vant 为 `string`，可选值 `large` |
| `icon` | 左侧图标类名 | `string` | - | ✅ 兼容 |
| `center` | 垂直居中 | `boolean` | `false` | ✅ 兼容 |
| `is-link` | 右侧展示箭头 | `boolean` | `false` | ✅ 兼容 |
| `required` | 左侧必填星号 | `boolean` | `false` | ✅ 兼容 |
| `clickable` | 点击态高亮 | `boolean` | `false` | ⚠️ 默认值差异：Vant 为 `null` |
| `arrow-direction` | 箭头方向 | `'up' \| 'down' \| 'left' \| 'right'` | `'right'` | ✅ 兼容 |
| `border` | 是否展示分隔线 | `boolean` | `true` | ✅ 兼容 |

| - | 图标类名前缀 | - | - | ❌ 缺少 `icon-prefix` |
| - | 标题样式 | - | - | ❌ 缺少 `title-style` |
| - | 标题类名 | - | - | ❌ 缺少 `title-class` |
| - | 值类名 | - | - | ❌ 缺少 `value-class` |
| - | 描述类名 | - | - | ❌ 缺少 `label-class` |

## Events

| Event | Description | Parameters | 与 Vant 差异 |
| --- | --- | --- | --- |
| `click` | 点击单元格触发 | `(event: MouseEvent)` | ✅ 兼容 |

## Slots

| Slot | Description | 与 Vant 差异 |
| --- | --- | --- |
| `icon` | 左侧图标区域 | ✅ 兼容 |
| `title` | 标题自定义 | ✅ 兼容 |
| `label` | 描述自定义 | ✅ 兼容 |
| `default` | 右侧值内容 | ⚠️ Vant 中为 `value` 插槽 |
| `right-icon` | 右侧箭头或自定义图标 | ✅ 兼容 |
| - | 额外内容 | ❌ 缺少 `extra` 插槽 |