<template>
  <div class="demo-sticky">
    <HTSticky cssMode :offsetTop="0" :zIndex="99">
      <div class="header">CSS Sticky 模式（原生 position: sticky）</div>
    </HTSticky>

    <div class="content">
      <div v-for="i in 30" :key="i" class="item">内容块 {{ i }}</div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { HTSticky } from '@hytech/ht-ui';
</script>

<style scoped>
.demo-sticky {
  width: 100%;
  max-width: 800px;
  margin: 0 auto;
}
.header {
  padding: 8px 12px;
  border-radius: var(--dimensions-radius-sm);
  background: var(--color-surface-secondary);
  color: var(--color-content-primary);
}
.content {
  margin-top: 12px;
}
.item {
  border: 1px solid var(--color-border-default);
  border-radius: var(--dimensions-radius-sm);
  padding: 8px 12px;
  margin-bottom: 8px;
}
</style>
