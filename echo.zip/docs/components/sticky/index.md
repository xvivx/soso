# HTSticky 吸顶

用于将元素在滚动过程中吸附在顶部或底部。支持 CSS Sticky 模式与 JS 计算定位，参照 Element 与 Vant 的常见 API。

## 基础用法（顶部吸附）

<demo vue="./sticky-basic.vue" codesandbox="true" />

## 底部吸附

<demo vue="./sticky-bottom.vue" codesandbox="true" />

## CSS Sticky 模式

<demo vue="./sticky-css.vue" codesandbox="true" />

## Attributes

| Attribute | Description | Type | Default | 与 Vant 差异 |
| --- | --- | --- | --- | --- |
| `offset-top` | 顶部吸附距离（px） | `number \| string` | `0` | ✅ 兼容 |
| `offset-bottom` | 底部吸附距离（px） | `number \| string` | `0` | ✅ 兼容 |
| `css-mode` | 是否启用 CSS Sticky | `boolean` | `false` | ✨ HTSticky 独有 |
| `container` | 滚动容器选择器或元素 | `string \| HTMLElement` | `''` | ✅ 兼容 |
| `position` | 吸附位置 | `'top' \| 'bottom'` | `'top'` | ✅ 兼容 |
| `z-index` | 层叠顺序 | `number \| string` | `99` | ✅ 兼容 |

## Events

| Event | Description | Parameters | 与 Vant 差异 |
| --- | --- | --- | --- |
| `scroll` | 滚动时触发 | `{ scrollTop: number, isFixed: boolean }` | ✅ 兼容 |
| `change` | 吸附状态改变时触发 | `(isFixed: boolean)` | ✅ 兼容 |

## Methods

| Method | Description | Parameters | 返回值 |
| --- | --- | --- | --- |
| `updateSticky` | 手动触发吸附状态更新 | - | `void` |

## Slots

| Slot | Description | 与 Vant 差异 |
| --- | --- | --- |
| `default` | 吸顶内容 | ✅ 兼容 |

## 主题定制

```css
.ht-sticky {
  --ht-sticky-z-index: 99;
}
```

## Vant API 兼容性

| Vant API | HT 实现 | 说明 |
| --- | --- | --- |
| `offset-top` | ✅ 完全兼容 | 无差异 |
| `offset-bottom` | ✅ 完全兼容 | 无差异 |
| `container` | ✅ 完全兼容 | 无差异 |
| `position` | ✅ 完全兼容 | 无差异 |
| `z-index` | ✅ 完全兼容 | 无差异 |
| `css-mode` | ✨ HTSticky 独有 | 支持原生 CSS sticky |

## 注意事项

- 当 `css-mode` 为 `true` 时，使用原生 CSS `position: sticky` 实现，性能更好
- 当 `css-mode` 为 `false` 时，使用 JavaScript 监听滚动事件实现，兼容性更好
- 建议在现代浏览器中优先使用 CSS 模式