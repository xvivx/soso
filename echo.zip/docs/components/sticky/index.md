# HTSticky 吸顶

用于将元素在滚动过程中吸附在顶部或底部。支持 CSS Sticky 模式与 JS 计算定位，参照 Element 与 Vant 的常见 API。

## 基础用法（顶部吸附）

<demo vue="./sticky-basic.vue" codesandbox="true" />

## 底部吸附

<demo vue="./sticky-bottom.vue" codesandbox="true" />

## CSS Sticky 模式

<demo vue="./sticky-css.vue" codesandbox="true" />

## Attributes

| Attribute | Description | Type | Default |
| --- | --- | --- | --- |
| `offset-top` | 顶部吸附距离 | `number \| string` | `0` |
| `offset-bottom` | 底部吸附距离 | `number \| string` | `0` |
| `css-mode` | 是否启用 CSS Sticky | `boolean` | `false` |
| `container` | 滚动容器选择器或元素 | `string \| HTMLElement` | `''` |
| `position` | 吸附位置 | `'top' \| 'bottom'` | `'top'` |
| `z-index` | 层叠顺序 | `number \| string` | `99` |

## Methods

| Method | Description |
| --- | --- |
| `updateSticky` | 手动触发吸附状态更新 |

## Slots

| Slot | Description |
| --- | --- |
| `default` | 吸顶内容 |