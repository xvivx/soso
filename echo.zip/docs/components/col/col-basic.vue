<template>
  <div class="demo-col">
    <HTRow :gutter="16">
      <HTCol :span="12"><div class="box">span=12</div></HTCol>
      <HTCol :span="12"><div class="box">span=12</div></HTCol>
    </HTRow>

    <HTRow :gutter="16" :style="{ marginTop: '12px' }">
      <HTCol :span="8"><div class="box">span=8</div></HTCol>
      <HTCol :span="8"><div class="box">span=8</div></HTCol>
      <HTCol :span="8"><div class="box">span=8</div></HTCol>
    </HTRow>

    <HTRow :gutter="16" :style="{ marginTop: '12px' }">
      <HTCol :span="6" :offset="6"><div class="box">span=6, offset=6</div></HTCol>
      <HTCol :span="6"><div class="box">span=6</div></HTCol>
    </HTRow>
  </div>
</template>

<script setup lang="ts">
import { HTCol, HTRow } from '@hytech/ht-ui';
</script>

<style scoped>
.demo-col {
  width: 100%;
  max-width: 800px;
  margin: 0 auto;
}
.box {
  background: #f5f5f5;
  border: 1px solid #e0e0e0;
  border-radius: 4px;
  text-align: center;
  padding: 12px 0;
  color: #333;
}
</style>
