# HTCol 栅格列

栅格布局中的列，需置于 HTRow 中使用。支持 `span` 指定列宽（24 栅格）与 `offset` 指定偏移量。

## 基础用法

<demo vue="./col-basic.vue" codesandbox="true" />

## Attributes

| Attribute | Description | Type | Default |
| --- | --- | --- | --- |
| `tag` | 根节点标签 | `string` | `'div'` |
| `span` | 所占列数（1-24） | `number \| string` | `24` |
| `offset` | 左侧偏移列数（0-24） | `number \| string` | `0` |

## Slots

| Slot | Description |
| --- | --- |
| `default` | 列内容 |