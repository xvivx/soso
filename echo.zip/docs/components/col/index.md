# HTCol 栅格列

栅格布局中的列，需置于 HTRow 中使用。支持 `span` 指定列宽（24 栅格）与 `offset` 指定偏移量。

## 基础用法

<demo vue="./col-basic.vue" codesandbox="true" />

## Attributes

| Attribute | Description | Type | Default | 与 Vant 差异 |
| --- | --- | --- | --- | --- |
| `class` | 自定义类名 | `string \| object \| array` | - | ✨ HTCol 独有 |
| `tag` | 根节点标签 | `string` | `'div'` | ✨ HTCol 独有 |
| `span` | 所占列数（1-24） | `number \| string` | `24` | ✅ 兼容 |
| `offset` | 左侧偏移列数（0-24） | `number \| string` | `0` | ✅ 兼容 |

## Slots

| Slot | Description | 与 Vant 差异 |
| --- | --- | --- |
| `default` | 列内容 | ✅ 兼容 |

## 主题定制

```css
.ht-col {
  --ht-col-gutter: 0px;
}
```

## Vant API 兼容性

| Vant API | HT 实现 | 说明 |
| --- | --- | --- |
| `span` | ✅ 完全兼容 | 无差异 |
| `offset` | ✅ 完全兼容 | 无差异 |

## 注意事项

- HTCol 组件需要配合 HTRow 组件使用
- 通过 `inject` 接收来自 HTRow 的 `gutter` 间距配置
- 栅格系统基于 24 列布局