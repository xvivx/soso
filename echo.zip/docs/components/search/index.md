# HTSearch 搜索框组件

HTSearch 是基于 HTField 封装的搜索框组件，完全兼容 Vant4 Search 组件 API，支持所有属性、事件和插槽。

## 基础用法

<demo vue="./Basic.vue" codesandbox="true" />

## 事件监听日志

<demo vue="./Events.vue" />

## 搜索框内容对其

<demo vue="./InputAlign.vue" codesandbox="true" />

## 禁用搜索框

<demo vue="./Disabled.vue" codesandbox="true" />

## 自定义按钮

<demo vue="./Action.vue" codesandbox="true" />

## 背景与多种风格

<demo vue="./Background.vue" />

## API 表格

| 属性名      | 说明                  | 类型    | 默认值    | Vant 对应 | 备注 |
| ----------- | --------------------- | ------- | --------- | --------- | ---- |
| modelValue  | 输入框内容            | string  | ''        | ✓         |      |
| shape       | 形状（square/round）  | string  | 'square'  | ✓         |      |
| background  | 背景色                | string  | '#f2f4f7' | ✓         |      |
| showAction  | 是否显示操作按钮      | boolean | false     | ✓         |      |
| actionText  | 操作按钮文本          | string  | '搜索'    | ✓         |      |
| leftIcon    | 左侧图标              | string  | 'search'  | ✓         |      |
| rightIcon   | 右侧图标              | string  | -         | ✓         |      |
| clearable   | 是否可清除            | boolean | true      | ✓         |      |
| maxlength   | 最大输入长度          | number  | -         | ✓         |      |
| placeholder | 占位符                | string  | -         | ✓         |      |
| disabled    | 是否禁用              | boolean | false     | ✓         |      |
| readonly    | 是否只读              | boolean | false     | ✓         |      |
| autofocus   | 自动聚焦              | boolean | false     | ✓         |      |
| inputAlign  | 输入框对齐方式        | string  | -         | ✓         |      |
| ...         | 继承 HTField 其他属性 |         |           |           |      |

### 事件

| 事件名            | 说明          | 参数              | Vant 对应 |
| ----------------- | ------------- | ----------------- | --------- |
| update:modelValue | 输入内容变化  | value: string     | ✓         |
| search            | 点击搜索/回车 | value: string     | ✓         |
| clear             | 清除内容      | -                 | ✓         |
| focus             | 聚焦          | event: FocusEvent | ✓         |
| blur              | 失焦          | event: FocusEvent | ✓         |
| input             | 输入          | value: string     | ✓         |
| cancel            | 点击取消按钮  | -                 | ✓         |

### 插槽

| 插槽名 | 说明     | Vant 对应 |
| ------ | -------- | --------- |
| left   | 左侧内容 | ✓         |
| right  | 右侧内容 | ✓         |
