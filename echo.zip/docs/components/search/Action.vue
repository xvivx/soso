<template>
  <HTSearch v-model="value" show-action placeholder="定义按钮" @cancel="onCancel">
    <template #active>
      <div class="ht-search__action" type="button" @click="onSearch">搜索</div>
    </template>
  </HTSearch>
  {{ value }}
</template>
<script setup lang="ts">
import { ref } from 'vue';
import { Toast } from '@/components';

const value = ref('');
function onCancel() {
  Toast('取消搜索');
  value.value = '';
}
function onSearch() {
  Toast('搜索内容：' + value.value);
}
</script>
