<template>
  <HTSearch v-model="value" placeholder="请输入关键词" label="haha" />
</template>
<script setup lang="ts">
import { ref } from 'vue';

const value = ref('');
</script>
