<script setup lang="ts">
import { ref } from 'vue';
import { HTSearch } from '@hytech/ht-ui';

const valueDisabled = ref('不可编辑内容');
</script>
<template>
  <div class="demo-disabled-readonly">
    <HTSearch v-model="valueDisabled" disabled />
  </div>
</template>
