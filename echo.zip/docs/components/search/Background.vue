<template>
  <div class="demo-row">
    <HTSearch v-model="v1" background="#fff" placeholder="白色背景" />
    <HTSearch v-model="v2" background="#e6f4ff" placeholder="浅蓝背景" />
  </div>
</template>
<script setup lang="ts">
import { ref } from 'vue';

const v1 = ref('');
const v2 = ref('');
</script>
<style scoped>
.demo-row {
  display: flex;
  flex-direction: column;
  gap: 12px;
}
</style>
