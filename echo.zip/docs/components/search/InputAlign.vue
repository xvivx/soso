<template>
  <div class="demo-field">
    <HTSearch v-model="text1" placeholder="默认左对齐" input-align="left" />
    <div class="m-[16px]"></div>
    <HTSearch v-model="text2" placeholder="文本居中" input-align="center" />
    <div class="m-[16px]"></div>
    <HTSearch v-model="text3" placeholder="文本右对齐" input-align="right" />
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import { HTSearch } from '@hytech/ht-ui';

const text1 = ref('');
const text2 = ref('');
const text3 = ref('');
</script>

<style scoped>
.demo-field {
  padding: 16px;
}
</style>
