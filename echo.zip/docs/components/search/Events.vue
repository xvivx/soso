<template>
  <div class=""></div>
  <HTSearch show-action @search="onSearch" @cancel="onCancel" @focus="onFocus" @blur="onBlur"></HTSearch>
</template>

<script setup lang="ts">
import 'vue';
import { HTSearch, Toast } from '@hytech/ht-ui';

const onSearch = (value: string) => {
  Toast(`搜索内容：${value}`);
};
const onCancel = () => {
  Toast('取消搜索');
};
const onFocus = () => {
  Toast('搜索框获得焦点');
};
const onBlur = () => {
  Toast('搜索框失去焦点');
};
</script>

<style lang="scss" scoped></style>
