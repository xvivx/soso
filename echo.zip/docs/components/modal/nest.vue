<template>
  <HTButton @click="showDetail">嵌套弹窗</HTButton>
</template>

<script setup lang="tsx">
import { HTButton, HTModal } from '@hytech/ht-ui';
import { mock } from 'mockjs';

const showDetail = () => {
  HTModal.show({
    title: mock('@title'),
    children: <div>{mock('@paragraph')}</div>,
    confirm: {
      confirmText: '再打开一个弹窗',
      onConfirm: () => {
        HTModal.show({
          title: mock('@title'),
          children: mock('@paragraph(20,50)'),
        });
      },
    },
  });
};
</script>
