<template>
  <HTButton @click="showDetail">打开抽屉</HTButton>
</template>

<script setup lang="tsx">
import { HTButton, HTModal } from '@hytech/ht-ui';
import { mock } from 'mockjs';

const showDetail = () => {
  HTModal.show({
    title: mock('@title'),
    children: <div>{mock('@paragraph(20,50)')}</div>,
    drawer: true,
  });
};
</script>
