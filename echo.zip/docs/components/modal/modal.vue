<template>
  <div class="flex gap-4">
    <HTButton @click="show = !show">通过状态打开</HTButton>
    <HTButton @click="showDetail">通过方法打开</HTButton>
  </div>
  <HTModal v-model:show="show">
    <template #title>{{ mock('@title') }}</template>
    <div>{{ mock('@paragraph') }}</div>
  </HTModal>
</template>

<script setup lang="tsx">
import { ref } from 'vue';
import { HTButton, HTModal } from '@hytech/ht-ui';
import { mock } from 'mockjs';

const show = ref(false);
const showDetail = () => {
  HTModal.show({
    title: mock('@title'),
    children: <div>{mock('@paragraph(20,50)')}</div>,
  });
};
</script>
