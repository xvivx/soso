<template>
  <div class="flex flex-wrap gap-4">
    <ht-button @click="show = !show">通过状态打开</ht-button>
    <ht-button @click="showDetail(false)">通过方法打开</ht-button>
    <ht-button @click="showDetail(true)">居中的弹窗</ht-button>
  </div>
  <HTModal v-model:show="show">
    <template #title>{{ mock('@title') }}</template>
    <div>{{ mock('@paragraph') }}</div>
  </HTModal>
</template>

<script setup lang="tsx">
import { ref } from 'vue';
import { HTModal } from '@hytech/ht-ui';
import { mock } from 'mockjs';

const show = ref(false);
const showDetail = (center = false) => {
  HTModal.show({
    title: mock('@title'),
    children: <div>{mock('@paragraph(20,50)')}</div>,
    center,
  });
};
</script>
