# HTModal 弹窗

带有标题、内容区和遮罩。支持通过方法或者状态打开

## 弹窗

### 通用弹窗

<demo vue="./modal.vue" />

### 带确认操作的弹窗

<demo vue="./confirm.vue" />

### 弹窗嵌套

<demo vue="./nest.vue" />

## 抽屉

做为抽屉的使用场景, 抽屉拥有弹窗的所有配置

<demo vue="./drawer.vue" />

## Methods

### HTModal.show(options: Options)

通过`HTModal.show`调用的配置, 该方法会返回一个关闭函数, 也可以直接调用 `HTModal.close` 关闭当前弹窗。

#### 参数 Options

| 属性名   | 说明             | 类型                                | 默认值  |
| -------- | ---------------- | ----------------------------------- | ------- |
| title    | 弹窗标题         | `VNode` \| `string`                 | -       |
| children | 弹窗内容         | `VNode` \| `string`                 | -       |
| closable | 能否点击背景关闭 | `boolean`                           | `true`  |
| drawer   | 是否抽屉         | `boolean`                           | `false` |
| confirm  | 确认弹窗配置     | [`ConfirmOptions`](#confirmoptions) | -       |

#### ConfirmOptions

| 属性名      | 说明               | 类型                            | 默认值     |
| ----------- | ------------------ | ------------------------------- | ---------- |
| cancelText  | 取消按钮文字       | `string`                        | -          |
| confirmText | 确认按钮文字       | `string`                        | -          |
| onCancel    | 点击取消按钮的回调 | `(event: PointerEvent) => void` | -          |
| onConfirm   | 点击确认按钮的回调 | `(event: PointerEvent) => void` | `Required` |

### HTModal.close()

调用该方法会关闭最上层的弹窗

### HTModal.closeAll()

调用该方法会关闭所有的弹窗

## Props

| 属性名   | 说明               | 类型      | 默认值  |
| -------- | ------------------ | --------- | ------- |
| show     | 弹窗是否可见       | `boolean` | -       |
| closable | 点击遮罩层是否关闭 | `boolean` | `true`  |
| drawer   | 是否抽屉           | `boolean` | `false` |

## Events

| 事件名 | 说明         | 参数 |
| ------ | ------------ | ---- |
| close  | 关闭弹窗触发 | -    |

## Slots

| 名称    | 说明     |
| ------- | -------- |
| title   | 弹窗标题 |
| default | 弹窗内容 |
