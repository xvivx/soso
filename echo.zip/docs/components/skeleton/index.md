# Skeleton 骨架屏

在需要等待加载内容时显示的占位图形组合。

## 基础用法

通过 row 属性设置段落占位行数。 <demo vue="./examples/Basic.vue" codesandbox="true" />

## 显示标题

通过 title 属性可以显示标题占位。 <demo vue="./examples/WithTitle.vue" codesandbox="true" />

## 显示头像

通过 avatar 属性可以显示头像占位。 <demo vue="./examples/Avatar.vue" codesandbox="true" />

## 方形头像

通过 avatar-shape 属性可以设置头像形状为方形。 <demo vue="./examples/AvatarSquare.vue" codesandbox="true" />

## 自定义尺寸

通过 avatar-size 和 title-width 属性可以自定义头像和标题的尺寸。
<demo vue="./examples/CustomSize.vue" codesandbox="true" />

## 自定义行宽

通过 row-width 属性可以自定义每行的宽度。 <demo vue="./examples/RowWidth.vue" codesandbox="true" />

## 关闭动画

通过设置 animate 为 false 可以关闭动画效果。 <demo vue="./examples/NoAnimate.vue" codesandbox="true" />

## 自定义内容

通过默认插槽可以完全自定义骨架屏的内容。 <demo vue="./examples/CustomContent.vue" codesandbox="true" />

## 显示真实内容

通过 loading 属性控制是否显示骨架屏，加载完成后通过 template 插槽显示真实内容。
<demo vue="./examples/ShowContent.vue" codesandbox="true" />

## API

### Props

| 参数         | 说明                                         | 类型                                       | 默认值    |
| ------------ | -------------------------------------------- | ------------------------------------------ | --------- |
| row          | 段落占位行数                                 | `number`                                   | `3`       |
| row-width    | 段落占位每行宽度，可传数组来设置每一行的宽度 | `string \| number \| (string \| number)[]` | -         |
| title        | 是否显示标题占位                             | `boolean`                                  | `false`   |
| title-width  | 标题占位的宽度                               | `string \| number`                         | `40%`     |
| avatar       | 是否显示头像占位                             | `boolean`                                  | `false`   |
| avatar-size  | 头像占位的大小                               | `string \| number`                         | `40px`    |
| avatar-shape | 头像占位的形状，可选值为 square              | `'round' \| 'square'`                      | `'round'` |
| loading      | 是否显示骨架屏，传 false 时会展示子组件内容  | `boolean`                                  | `true`    |
| animate      | 是否开启动画                                 | `boolean`                                  | `true`    |

### Slots

| 名称     | 说明                         |
| -------- | ---------------------------- |
| default  | 自定义骨架屏的内容           |
| template | 用于显示加载完成后的真实内容 |

### 类型定义

组件导出以下类型定义：

```ts
import type { SkeletonAvatarShape, SkeletonProps } from '@hytech/ht-ui';
```
