<script setup lang="ts">
import { HTSkeleton } from '@hytech/ht-ui';
</script>

<template>
  <HTSkeleton avatar avatar-size="64px" title title-width="60%" :row="4" />
</template>
