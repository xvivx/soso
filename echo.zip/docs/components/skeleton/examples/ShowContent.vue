<script setup lang="ts">
import { ref } from 'vue';
import { HTSkeleton } from '@hytech/ht-ui';

const loading = ref(true);

const toggleLoading = () => {
  loading.value = !loading.value;
};
</script>

<template>
  <div>
    <button @click="toggleLoading" class="mb-4 rounded bg-blue-500 px-4 py-2 text-white hover:bg-blue-600">
      {{ loading ? '显示内容' : '显示骨架屏' }}
    </button>
    <HTSkeleton :loading="loading" avatar :row="3">
      <template #template>
        <div class="flex gap-4 rounded border border-gray-200 p-4">
          <img src="https://via.placeholder.com/40" alt="avatar" class="h-10 w-10 rounded-full" />
          <div>
            <h3 class="mb-2 font-bold">真实内容标题</h3>
            <p class="text-sm text-gray-600">这是加载完成后显示的真实内容。点击按钮可以切换骨架屏和真实内容。</p>
          </div>
        </div>
      </template>
    </HTSkeleton>
  </div>
</template>
