<script setup lang="ts">
import { HTSkeleton } from '@hytech/ht-ui';
</script>

<template>
  <HTSkeleton :row="4" :row-width="['100%', '90%', '70%', '50%']" />
</template>
