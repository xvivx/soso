<script setup lang="ts">
import { HTSkeleton } from '@hytech/ht-ui';
</script>

<template>
  <HTSkeleton title :row="3" />
</template>
