<script setup lang="ts">
import { HTSkeleton } from '@hytech/ht-ui';
</script>

<template>
  <HTSkeleton :row="3" :animate="false" />
</template>
