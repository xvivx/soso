<script setup lang="ts">
import { HTSkeleton } from '@hytech/ht-ui';
</script>

<template>
  <HTSkeleton>
    <div class="flex gap-4">
      <div class="h-16 w-16 rounded-lg bg-gray-200"></div>
      <div class="flex flex-1 flex-col gap-3">
        <div class="h-4 w-3/4 rounded bg-gray-200"></div>
        <div class="h-4 w-1/2 rounded bg-gray-200"></div>
        <div class="h-4 w-full rounded bg-gray-200"></div>
      </div>
    </div>
  </HTSkeleton>
</template>
