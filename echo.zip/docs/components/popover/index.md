# HTPopover 气泡

浮层类组件的基础, 如 [`Select`](/components/select/) 等

## 受控与非受控

<demo vue="./base.vue"></demo>

## Props

| 属性名 | 说明         | 类型      | 默认值 |
| ------ | ------------ | --------- | ------ |
| open   | 浮层是否打开 | `boolean` | -      |

## Events

| 事件名      | 说明                   | 参数      |
| ----------- | ---------------------- | --------- |
| update:open | 更新浮层的 `open` 属性 | `boolean` |

## Slots

| 插槽      | 说明               | 参数    | 类型         |
| --------- | ------------------ | ------- | ------------ |
| reference | 触发浮层打开的插槽 | `open`  | `boolean`    |
| default   | 浮层内容           | `close` | `() => void` |
