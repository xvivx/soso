# HTPopover 气泡

浮层类组件的基础, 如 [`Select`](/components/select/) 等

## 受控与非受控

<demo vue="./base.vue"></demo>

## Props

| 属性名      | 说明                                                                       | 类型               | 默认值  |
| ----------- | -------------------------------------------------------------------------- | ------------------ | ------- |
| open        | 浮层是否打开                                                               | `boolean`          | -       |
| defaultOpen | 浮层是否首次加载时打开                                                     | `boolean`          | -       |
| floating    | 是否用浮层打开, 默认情况下移动端是底部弹出, 传入 `true` 会用浮层的方式打开 | `boolean`          | -       |
| trigger     | 桌面端触发方式, 默认 `click`                                               | `hover` \| `click` | `click` |
| title       | 移动端打开时的标题                                                         | `string`           | -       |
| disabled    | 是否禁用                                                                   | `boolean`          | -       |
| showArrow   | 是否显示小箭头                                                             | `boolean`          | -       |
| fitWidth    | 桌面端面板是否和触发器等宽                                                 | `boolean`          | -       |
| asChild     | 是否合并触发器的标签, 这样可以减少一层 dom 标签                            | `boolean`          | `true`  |

## Events

| 事件名      | 说明                   | 参数      |
| ----------- | ---------------------- | --------- |
| update:open | 更新浮层的 `open` 属性 | `boolean` |

## Slots

| 插槽      | 说明               | 参数    | 类型         |
| --------- | ------------------ | ------- | ------------ |
| reference | 触发浮层打开的插槽 | `open`  | `boolean`    |
| default   | 浮层内容           | `close` | `() => void` |
