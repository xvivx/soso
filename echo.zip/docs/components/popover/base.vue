<template>
  <div class="flex gap-4">
    <HTPopover>
      <template #reference>
        <button class="text-primary">非受控</button>
      </template>

      <template #default="{ close }">
        <div @click="close">点击这个地方关闭</div>
        <div>{{ text }}</div>
      </template>
    </HTPopover>

    <HTPopover v-model:open="show" title="受控模式">
      <template #reference="{ open }">
        <button>受控({{ open ? '打开状态' : '关闭状态' }})</button>
      </template>
      <template #default>
        <div>{{ text }}</div>
      </template>
    </HTPopover>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import { HTPopover } from '@hytech/ht-ui';
import { mock } from 'mockjs';

const text = mock('@paragraph');
const show = ref(false);
</script>
