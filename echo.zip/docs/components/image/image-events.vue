<template>
  <div class="demo-image-events">
    <div class="events-container">
      <!-- 事件演示图片 -->
      <div class="image-section">
        <HTImage
          :src="currentImageSrc"
          width="200"
          height="200"
          alt="事件演示图片"
          @load="handleLoad"
          @error="handleError"
          @click="handleClick"
        />

        <!-- 控制按钮 -->
        <div class="controls">
          <button @click="loadValidImage" class="control-btn">加载有效图片</button>
          <button @click="loadInvalidImage" class="control-btn error">加载无效图片</button>
          <button @click="clearLogs" class="control-btn">清空日志</button>
        </div>
      </div>

      <!-- 事件日志 -->
      <div class="logs-section">
        <h4>事件日志</h4>
        <div class="logs-container">
          <div v-if="logs.length === 0" class="empty-logs">暂无事件日志</div>
          <div v-for="(log, index) in logs" :key="index" class="log-item" :class="`log-${log.type}`">
            <span class="log-time">{{ log.time }}</span>
            <span class="log-event">{{ log.event }}</span>
            <span class="log-message">{{ log.message }}</span>
          </div>
        </div>
      </div>
    </div>

    <!-- 事件说明 -->
    <div class="events-info">
      <h4>支持的事件</h4>
      <div class="event-list">
        <div class="event-item"><strong>@load</strong> - 图片加载成功时触发</div>
        <div class="event-item"><strong>@error</strong> - 图片加载失败时触发</div>
        <div class="event-item"><strong>@click</strong> - 点击图片时触发</div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import { HTImage } from '@/components';

interface LogItem {
  time: string;
  event: string;
  message: string;
  type: 'load' | 'error' | 'click' | 'info';
}

// 响应式数据
const currentImageSrc = ref('https://picsum.photos/200/200');
const logs = ref<LogItem[]>([]);

// 添加日志
const addLog = (event: string, message: string, type: LogItem['type']) => {
  const time = new Date().toLocaleTimeString();
  logs.value.unshift({ time, event, message, type });

  // 限制日志数量
  if (logs.value.length > 20) {
    logs.value = logs.value.slice(0, 20);
  }
};

// 事件处理函数
const handleLoad = (event: Event) => {
  console.log('图片加载成功:', event);
  addLog('load', '图片加载成功', 'load');
};

const handleError = (event: Event) => {
  console.log('图片加载失败:', event);
  addLog('error', '图片加载失败', 'error');
};

const handleClick = (event: Event) => {
  console.log('图片被点击:', event);
  addLog('click', '图片被点击', 'click');
};

// 控制函数
const loadValidImage = () => {
  currentImageSrc.value = `https://picsum.photos/200/200?t=${Date.now()}`;
  addLog('info', '开始加载有效图片', 'info');
};

const loadInvalidImage = () => {
  currentImageSrc.value = `https://invalid-url-${Date.now()}.jpg`;
  addLog('info', '开始加载无效图片', 'info');
};

const clearLogs = () => {
  logs.value = [];
  addLog('info', '日志已清空', 'info');
};
</script>

<style scoped>
.demo-image-events {
  padding: 20px;
}

.events-container {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 32px;
  margin-bottom: 32px;
}

@media (max-width: 768px) {
  .events-container {
    grid-template-columns: 1fr;
    gap: 24px;
  }
}

.image-section {
  text-align: center;
}

.controls {
  display: flex;
  gap: 12px;
  justify-content: center;
  margin-top: 20px;
  flex-wrap: wrap;
}

.control-btn {
  padding: 8px 16px;
  font-size: 14px;
  background: #3b82f6;
  color: white;
  border: none;
  border-radius: 6px;
  cursor: pointer;
  transition: all 0.2s;
}

.control-btn:hover {
  background: #2563eb;
  transform: translateY(-1px);
}

.control-btn.error {
  background: #ef4444;
}

.control-btn.error:hover {
  background: #dc2626;
}

.logs-section h4 {
  margin: 0 0 16px 0;
  font-size: 18px;
  font-weight: 600;
  color: #333;
}

.logs-container {
  border: 1px solid #e5e7eb;
  border-radius: 8px;
  background: #f9fafb;
  height: 400px;
  overflow-y: auto;
}

.empty-logs {
  display: flex;
  align-items: center;
  justify-content: center;
  height: 100%;
  color: #9ca3af;
  font-size: 14px;
}

.log-item {
  display: flex;
  align-items: center;
  padding: 8px 12px;
  border-bottom: 1px solid #f3f4f6;
  font-size: 12px;
  transition: background-color 0.2s;
}

.log-item:hover {
  background: #f3f4f6;
}

.log-item:last-child {
  border-bottom: none;
}

.log-time {
  color: #6b7280;
  margin-right: 8px;
  font-family: monospace;
  min-width: 80px;
}

.log-event {
  font-weight: 600;
  margin-right: 8px;
  min-width: 60px;
}

.log-message {
  color: #374151;
  flex: 1;
}

.log-load .log-event {
  color: #10b981;
}

.log-error .log-event {
  color: #ef4444;
}

.log-click .log-event {
  color: #f59e0b;
}

.log-info .log-event {
  color: #6b7280;
}

.events-info {
  background: #f0f9ff;
  border: 1px solid #bae6fd;
  border-radius: 8px;
  padding: 20px;
}

.events-info h4 {
  margin: 0 0 16px 0;
  font-size: 16px;
  font-weight: 600;
  color: #0284c7;
}

.event-list {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 12px;
}

.event-item {
  font-size: 14px;
  color: #0c4a6e;
  line-height: 1.5;
}

.event-item strong {
  color: #075985;
  font-family: monospace;
  background: #e0f2fe;
  padding: 2px 6px;
  border-radius: 4px;
}
</style>
