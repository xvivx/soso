<template>
  <div class="demo-image-states">
    <div class="states-grid">
      <!-- 正常加载状态 -->
      <div class="state-item">
        <h4>正常加载</h4>
        <HTImage src="https://picsum.photos/150/150" width="150" height="150" :show-loading="true" alt="正常加载" />
      </div>

      <!-- 自定义加载状态 -->
      <div class="state-item">
        <h4>自定义加载</h4>
        <HTImage src="https://picsum.photos/150/150" width="150" height="150" :show-loading="true" alt="自定义加载">
          <template #loading>
            <div class="custom-loading">
              <div class="loading-spinner"></div>
              <div class="loading-text">正在加载...</div>
            </div>
          </template>
        </HTImage>
      </div>

      <!-- 错误状态 -->
      <div class="state-item">
        <h4>错误状态</h4>
        <HTImage
          src="https://invalid-url-example.com/image.jpg"
          width="150"
          height="150"
          :show-error="true"
          alt="错误状态"
        />
      </div>

      <!-- 自定义错误状态 -->
      <div class="state-item">
        <h4>自定义错误</h4>
        <HTImage
          src="https://invalid-url-example.com/image.jpg"
          width="150"
          height="150"
          :show-error="true"
          alt="自定义错误"
        >
          <template #error>
            <div class="custom-error">
              <div class="error-icon">⚠️</div>
              <div class="error-text">图片加载失败</div>
              <button class="retry-btn" @click="retryImage">重试</button>
            </div>
          </template>
        </HTImage>
      </div>

      <!-- 完整状态演示 -->
      <div class="state-item full-state">
        <h4>状态切换演示</h4>
        <div class="state-controls">
          <button @click="triggerLoading" class="control-btn">模拟加载</button>
          <button @click="triggerError" class="control-btn">模拟错误</button>
          <button @click="resetState" class="control-btn">重置</button>
        </div>
        <HTImage
          :src="currentSrc"
          width="150"
          height="150"
          :show-loading="showLoading"
          :show-error="showError"
          @load="handleLoad"
          @error="handleError"
          alt="状态演示"
        />
        <div class="state-info">
          <span class="state-label">当前状态：</span>
          <span class="state-value" :class="currentStateClass">{{ currentState }}</span>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { computed, ref } from 'vue';
import { HTImage } from '@/components';

// 状态控制
const showLoading = ref(true);
const showError = ref(true);
const currentSrc = ref('https://picsum.photos/150/150');
const currentState = ref('loading');

const currentStateClass = computed(() => {
  return {
    'state-loading': currentState.value === 'loading',
    'state-loaded': currentState.value === 'loaded',
    'state-error': currentState.value === 'error',
  };
});

// 事件处理
const handleLoad = () => {
  currentState.value = 'loaded';
};

const handleError = () => {
  currentState.value = 'error';
};

// 控制函数
const triggerLoading = () => {
  currentState.value = 'loading';
  currentSrc.value = `https://picsum.photos/150/150?t=${Date.now()}`;
};

const triggerError = () => {
  currentState.value = 'error';
  currentSrc.value = 'https://invalid-url-example.com/error.jpg';
};

const resetState = () => {
  currentState.value = 'loading';
  currentSrc.value = 'https://picsum.photos/150/150';
};

const retryImage = () => {
  // 重新触发加载
  const tempSrc = currentSrc.value;
  currentSrc.value = '';
  setTimeout(() => {
    currentSrc.value = tempSrc;
  }, 100);
};
</script>

<style scoped>
.demo-image-states {
  padding: 20px;
}

.states-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
  gap: 24px;
}

.state-item {
  text-align: center;
}

.state-item.full-state {
  grid-column: 1 / -1;
  max-width: 400px;
  margin: 0 auto;
}

.state-item h4 {
  margin: 0 0 16px 0;
  font-size: 16px;
  font-weight: 500;
  color: #333;
}

/* 自定义加载样式 */
.custom-loading {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  height: 100%;
  background: linear-gradient(45deg, #f3f4f6, #e5e7eb);
}

.loading-spinner {
  width: 24px;
  height: 24px;
  border: 2px solid #d1d5db;
  border-top: 2px solid #3b82f6;
  border-radius: 50%;
  animation: spin 1s linear infinite;
  margin-bottom: 8px;
}

@keyframes spin {
  0% {
    transform: rotate(0deg);
  }
  100% {
    transform: rotate(360deg);
  }
}

.loading-text {
  font-size: 12px;
  color: #6b7280;
}

/* 自定义错误样式 */
.custom-error {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  height: 100%;
  background: #fef2f2;
  color: #dc2626;
}

.error-icon {
  font-size: 24px;
  margin-bottom: 8px;
}

.error-text {
  font-size: 12px;
  margin-bottom: 12px;
}

.retry-btn {
  padding: 4px 12px;
  font-size: 12px;
  background: #dc2626;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  transition: background-color 0.2s;
}

.retry-btn:hover {
  background: #b91c1c;
}

/* 状态控制 */
.state-controls {
  display: flex;
  gap: 8px;
  justify-content: center;
  margin-bottom: 16px;
}

.control-btn {
  padding: 6px 12px;
  font-size: 12px;
  background: #3b82f6;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  transition: background-color 0.2s;
}

.control-btn:hover {
  background: #2563eb;
}

.state-info {
  margin-top: 12px;
  font-size: 14px;
}

.state-label {
  color: #6b7280;
}

.state-value {
  font-weight: 500;
}

.state-value.state-loading {
  color: #3b82f6;
}

.state-value.state-loaded {
  color: #10b981;
}

.state-value.state-error {
  color: #dc2626;
}
</style>
