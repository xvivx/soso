<template>
  <div class="demo-image-basic">
    <HTImage src="https://picsum.photos/200/200" width="200" height="200" alt="基础图片用法" />
  </div>
</template>

<script setup lang="ts">
import { HTImage } from '@/components';
</script>

<style scoped>
.demo-image-basic {
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 250px;
  padding: 20px;
  background: #f8f9fa;
  border-radius: 8px;
}
</style>
