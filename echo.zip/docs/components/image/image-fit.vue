<template>
  <div class="demo-image-fit">
    <div class="fit-grid">
      <div class="fit-item" v-for="fit in fits" :key="fit">
        <h4>{{ fit }}</h4>
        <div class="image-container">
          <HTImage
            :src="`https://picsum.photos/150/100?random=${fit}`"
            width="150"
            height="100"
            :fit="fit"
            :alt="`填充模式: ${fit}`"
          />
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { HTImage } from '@/components';

const fits: ('fill' | 'contain' | 'cover' | 'none' | 'scale-down')[] = [
  'fill',
  'contain',
  'cover',
  'none',
  'scale-down',
];
</script>

<style scoped>
.demo-image-fit {
  padding: 20px;
}

.fit-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
  gap: 20px;
}

.fit-item {
  text-align: center;
}

.fit-item h4 {
  margin: 0 0 12px 0;
  font-size: 14px;
  font-weight: 500;
  color: #333;
}

.image-container {
  display: inline-block;
  border: 1px solid #e5e7eb;
  border-radius: 8px;
  overflow: hidden;
  background: #f9fafb;
}
</style>
