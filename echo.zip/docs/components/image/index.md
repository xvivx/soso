# HTImage 图片组件

基于 shadcn-vue 实现，完全兼容 Vant Image 组件 API 的图片组件。支持多种填充模式、懒加载、错误处理、自定义状态等功能。

## 基础用法

<demo vue="./image-basic.vue" />

## 填充模式

支持多种图片填充模式，适应不同的布局需求。

<demo vue="./image-fit.vue" />

## 圆形和圆角

支持圆形图片和自定义圆角。

<demo vue="./image-shape.vue" />

## 懒加载

内置懒加载功能，提升页面性能。

<demo vue="./image-lazy.vue" />

## 加载和错误状态

自定义加载和错误状态的显示。

<demo vue="./image-states.vue" />

## 定位控制

精确控制图片在容器中的位置。

<demo vue="./image-position.vue" />

## 事件处理

监听图片的加载、错误和点击事件。

<demo vue="./image-events.vue" />

## Attributes

| Attribute | Description | Type | Default | Vant 兼容 |
| --- | --- | --- | --- | --- |
| `src` | 图片链接 | `string` | - | ✅ |
| `alt` | 替代文本 | `string` | - | ✅ |
| `fit` | 填充模式 | `'fill' \| 'contain' \| 'cover' \| 'none' \| 'scale-down'` | `'fill'` | ✅ |
| `position` | 位置控制 | `'top' \| 'bottom' \| 'left' \| 'right' \| 'center'` | `'center'` | ✅ |
| `width` | 宽度 | `string \| number` | - | ✅ |
| `height` | 高度 | `string \| number` | - | ✅ |
| `round` | 是否为圆形图片 | `boolean` | `false` | ✅ |
| `block` | 是否为块级元素 | `boolean` | `false` | ✅ |
| `radius` | 圆角大小 | `string \| number` | - | ✅ |
| `lazyLoad` | 是否懒加载 | `boolean` | `false` | ✅ |
| `showError` | 是否显示错误提示 | `boolean` | `true` | ✅ |
| `showLoading` | 是否显示加载提示 | `boolean` | `true` | ✅ |
| `iconSize` | 图标大小 | `string \| number` | - | ✅ |
| `errorIcon` | 错误图标名称 | `string` | `'photo-fail'` | ✅ |
| `loadingIcon` | 加载图标名称 | `string` | `'photo'` | ✅ |
| `iconPrefix` | 图标类名前缀 | `string` | - | ✅ |
| `crossorigin` | 跨域设置 | `'anonymous' \| 'use-credentials' \| ''` | - | ✅ |
| `referrerpolicy` | 引用策略 | `string` | - | ✅ |
| `decoding` | 解码方式 | `'async' \| 'sync' \| 'auto'` | - | ✅ |
| `variant` | shadcn-vue 变体 | `'default' \| 'rounded' \| 'circle' \| 'cover'` | `'default'` | ❌ |
| `className` | 自定义类名 | `string` | - | ❌ |
| `asChild` | 是否作为子元素渲染 | `boolean` | `false` | ❌ |

## Events

| Event | Description | Parameters | Vant 兼容 |
| --- | --- | --- | --- |
| `load` | 图片加载成功时触发 | `(event: Event)` | ✅ |
| `error` | 图片加载失败时触发 | `(event: Event)` | ✅ |
| `click` | 点击图片时触发 | `(event: Event)` | ✅ |

## Slots

| Slot | Description | Parameters | Vant 兼容 |
| --- | --- | --- | --- |
| `default` | 默认插槽，可添加额外内容 | - | ✅ |
| `loading` | 自定义加载状态内容 | - | ✅ |
| `loadingText` | 自定义加载文本内容 | - | ✅ |
| `error` | 自定义错误状态内容 | - | ✅ |
| `errorText` | 自定义错误文本内容 | - | ✅ |
| `placeholder` | 自定义懒加载占位符内容 | - | ✅ |

## Methods

通过 ref 可以调用以下方法：

| Method | Description | Parameters | Return | Vant 兼容 |
| --- | --- | --- | --- | --- |
| `load` | 手动加载图片 | - | `void` | ✅ |
| `reset` | 重置所有状态 | - | `void` | ✅ |

### 暴露的状态

| Property | Description | Type | Vant 兼容 |
| --- | --- | --- | --- |
| `loading` | 是否正在加载 | `boolean` | ✅ |
| `loaded` | 是否加载完成 | `boolean` | ✅ |
| `error` | 是否加载失败 | `boolean` | ✅ |

## 主题定制

根据 H5组件三级token.md 规范，HTImage 组件支持以下 CSS 变量定制：

### 容器样式

```css
.ht-image {
  /* 基础容器样式 */
  --image-container-width-default: 100%;
  --image-container-height-default: auto;
  --image-container-border-radius-default: 0;
  --image-container-bg-color-default: #F5F5F5;

  /* 图片元素样式 */
  --image-img-object-fit-default: fill;
  --image-opacity-loading: 0.5;
  --image-transition-duration: 0.3s;
}
```

### 图标样式

```css
.ht-image {
  /* 占位图标 */
  --image-placeholder-size-default: 32px;
  --image-placeholder-color-default: #C9CDD4;

  /* 错误图标 */
  --image-error-icon-size-default: 32px;
  --image-error-icon-color-default: #C9CDD4;

  /* 预览图标 */
  --image-preview-icon-size-default: 24px;
  --image-preview-icon-color-default: #FFFFFF;
  --image-preview-icon-bg-color-default: rgba(0,0,0,0.5);
}
```

### 变体样式

```css
.ht-image {
  /* 圆形变体 */
  --image-circle-border-radius: 50%;

  /* 圆角变体 */
  --image-rounded-border-radius: 8px;

  /* 覆盖变体 */
  --image-cover-object-fit: cover;
}
```

## Vant API 兼容性

| Vant API | HT 实现 | 说明 |
| --- | --- | --- |
| src | ✅ 完全兼容 | 支持所有图片格式 |
| alt | ✅ 完全兼容 | 无障碍支持 |
| fit | ✅ 完全兼容 | 支持 fill、contain、cover、none、scale-down |
| position | ✅ 完全兼容 | 支持 top、bottom、left、right、center |
| width/height | ✅ 完全兼容 | 支持像素、百分比等单位 |
| round | ✅ 完全兼容 | 圆形图片 |
| radius | ✅ 完全兼容 | 自定义圆角 |
| lazy-load | ✅ 完全兼容 | 基于 IntersectionObserver |
| show-error/show-loading | ✅ 完全兼容 | 状态显示控制 |
| error-icon/loading-icon | ✅ 完全兼容 | 图标自定义 |
| icon-size | ✅ 完全兼容 | 图标尺寸控制 |
| crossorigin/referrerpolicy/decoding | ✅ 完全兼容 | HTML 标准属性 |
| load/error/click 事件 | ✅ 完全兼容 | 事件处理 |
| 插槽支持 | ✅ 完全兼容 | loading、error、placeholder 等 |
| load/reset 方法 | ✅ 完全兼容 | 组件方法 |

### 新增功能

HTImage 在 Vant 基础上增加了一些扩展功能：

| 功能 | 说明 | 示例 |
| --- | --- | --- |
| `variant` | shadcn-vue 风格变体 | `variant="rounded"` |
| `className` | 自定义 CSS 类名 | `className="custom-image"` |
| `asChild` | 作为子元素渲染 | `asChild={true}` |
| 更多的插槽 | 更灵活的内容定制 | `loadingText`、`errorText` 等 |

## 从 Vant 迁移

HTImage 组件完全兼容 Vant Image 的 API，可以直接替换：

```vue
<!-- Vant 用法 -->
<van-image
  src="https://example.com/image.jpg"
  width="200"
  height="200"
  fit="cover"
  round
  :lazy-load="true"
  @load="onLoad"
/>

<!-- HTImage 用法 - 完全兼容 -->
<HTImage
  src="https://example.com/image.jpg"
  width="200"
  height="200"
  fit="cover"
  round
  :lazy-load="true"
  @load="onLoad"
/>
```

### 扩展功能迁移

如果需要使用 HTImage 的扩展功能：

```vue
<!-- 使用 shadcn-vue 风格变体 -->
<HTImage
  src="image.jpg"
  variant="rounded"
  className="custom-class"
/>

<!-- 更丰富的插槽支持 -->
<HTImage src="image.jpg">
  <template #loading>
    <CustomLoadingSpinner />
  </template>
  <template #error>
    <CustomErrorMessage />
  </template>
  <template #placeholder>
    <CustomPlaceholder />
  </template>
</HTImage>
```