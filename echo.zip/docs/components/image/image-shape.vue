<template>
  <div class="demo-image-shape">
    <div class="shape-grid">
      <!-- 默认图片 -->
      <div class="shape-item">
        <h4>默认</h4>
        <HTImage src="https://picsum.photos/100/100" width="100" height="100" alt="默认图片" />
      </div>

      <!-- 圆形图片 (round属性) -->
      <div class="shape-item">
        <h4>圆形 (round)</h4>
        <HTImage src="https://picsum.photos/100/100" width="100" height="100" round alt="圆形图片" />
      </div>

      <!-- 圆形图片 (variant) -->
      <div class="shape-item">
        <h4>圆形 (variant)</h4>
        <HTImage src="https://picsum.photos/100/100" width="100" height="100" variant="circle" alt="变体圆形" />
      </div>

      <!-- 圆角图片 (radius属性) -->
      <div class="shape-item">
        <h4>圆角 (radius)</h4>
        <HTImage src="https://picsum.photos/100/100" width="100" height="100" :radius="12" alt="圆角图片" />
      </div>

      <!-- 圆角图片 (variant) -->
      <div class="shape-item">
        <h4>圆角 (variant)</h4>
        <HTImage src="https://picsum.photos/100/100" width="100" height="100" variant="rounded" alt="变体圆角" />
      </div>

      <!-- 覆盖模式 -->
      <div class="shape-item">
        <h4>覆盖 (cover)</h4>
        <HTImage src="https://picsum.photos/150/100" width="100" height="100" variant="cover" alt="覆盖模式" />
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { HTImage } from '@/components';
</script>

<style scoped>
.demo-image-shape {
  padding: 20px;
}

.shape-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(140px, 1fr));
  gap: 20px;
}

.shape-item {
  text-align: center;
}

.shape-item h4 {
  margin: 0 0 12px 0;
  font-size: 14px;
  font-weight: 500;
  color: #333;
}
</style>
