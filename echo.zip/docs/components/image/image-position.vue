<template>
  <div class="demo-image-position">
    <div class="position-grid">
      <div class="position-item" v-for="position in positions" :key="position">
        <h4>{{ position }}</h4>
        <div class="image-container">
          <HTImage
            :src="`https://picsum.photos/200/120?random=${position}`"
            width="200"
            height="120"
            fit="cover"
            :position="position"
            :alt="`定位: ${position}`"
          />
        </div>
        <p class="position-desc">{{ getPositionDescription(position) }}</p>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { HTImage } from '@/components';

const positions: ('top' | 'bottom' | 'left' | 'right' | 'center')[] = ['top', 'bottom', 'left', 'right', 'center'];

const getPositionDescription = (position: string): string => {
  const descriptions: Record<string, string> = {
    'top': '图片从顶部开始显示',
    'bottom': '图片从底部开始显示',
    'left': '图片从左侧开始显示',
    'right': '图片从右侧开始显示',
    'center': '图片居中显示',
  };
  return descriptions[position] || '';
};
</script>

<style scoped>
.demo-image-position {
  padding: 20px;
}

.position-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
  gap: 24px;
}

.position-item {
  text-align: center;
}

.position-item h4 {
  margin: 0 0 12px 0;
  font-size: 16px;
  font-weight: 500;
  color: #333;
}

.image-container {
  display: inline-block;
  border: 2px solid #e5e7eb;
  border-radius: 8px;
  overflow: hidden;
  background: #f9fafb;
  margin-bottom: 8px;
}

.position-desc {
  margin: 0;
  font-size: 12px;
  color: #6b7280;
  line-height: 1.4;
}
</style>
