<template>
  <div class="demo-image-lazy">
    <div class="lazy-container">
      <!-- 基础懒加载 -->
      <div class="lazy-item">
        <h4>基础懒加载</h4>
        <HTImage src="https://picsum.photos/200/200" width="200" height="200" :lazy-load="true" alt="懒加载图片" />
      </div>

      <!-- 自定义占位符 -->
      <div class="lazy-item">
        <h4>自定义占位符</h4>
        <HTImage
          src="https://picsum.photos/200/200"
          width="200"
          height="200"
          :lazy-load="true"
          alt="自定义占位符懒加载"
        >
          <template #placeholder>
            <div class="custom-placeholder">
              <div class="placeholder-icon">📷</div>
              <div class="placeholder-text">懒加载中...</div>
            </div>
          </template>
        </HTImage>
      </div>
    </div>

    <!-- 滚动说明 -->
    <div class="scroll-hint">
      <p>💡 提示：滚动页面查看懒加载效果</p>
    </div>
  </div>
</template>

<script setup lang="ts">
import { HTImage } from '@/components';
</script>

<style scoped>
.demo-image-lazy {
  padding: 20px;
}

.lazy-container {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
  gap: 40px;
  margin-bottom: 40px;
}

.lazy-item {
  text-align: center;
}

.lazy-item h4 {
  margin: 0 0 16px 0;
  font-size: 16px;
  font-weight: 500;
  color: #333;
}

.custom-placeholder {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  height: 100%;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  border-radius: 8px;
}

.placeholder-icon {
  font-size: 32px;
  margin-bottom: 8px;
}

.placeholder-text {
  font-size: 14px;
  opacity: 0.9;
}

.scroll-hint {
  text-align: center;
  padding: 20px;
  background: #f0f9ff;
  border-radius: 8px;
  border: 1px solid #bae6fd;
}

.scroll-hint p {
  margin: 0;
  color: #0284c7;
  font-size: 14px;
}

/* 添加一些高度以便演示滚动效果 */
.demo-image-lazy {
  min-height: 600px;
}
</style>
