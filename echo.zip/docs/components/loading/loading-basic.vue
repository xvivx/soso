<template>
  <div class="demo-loading-basic">
    <div class="demo-item">
      <h4>默认加载</h4>
      <HTLoading />
    </div>

    <div class="demo-item">
      <h4>带文本</h4>
      <HTLoading text="加载中..." />
    </div>

    <div class="demo-item">
      <h4>使用插槽</h4>
      <HTLoading>正在上传文件</HTLoading>
    </div>
  </div>
</template>

<script setup lang="ts">
import { HTLoading } from '@hytech/ht-ui';
</script>

<style scoped>
.demo-loading-basic {
  display: flex;
  flex-wrap: wrap;
  gap: 24px;
  padding: 20px;
}

.demo-item {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 8px;
  min-width: 120px;
}

.demo-item h4 {
  margin: 0;
  font-size: 14px;
  font-weight: 500;
  color: #666;
}
</style>
