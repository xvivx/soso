<template>
  <div class="demo-loading-colors">
    <div class="demo-item">
      <h4>默认颜色</h4>
      <HTLoading text="默认蓝色" />
    </div>

    <div class="demo-item">
      <h4>成功绿色</h4>
      <HTLoading color="#52c41a" text="成功加载" />
    </div>

    <div class="demo-item">
      <h4>警告橙色</h4>
      <HTLoading color="#faad14" text="警告加载" />
    </div>

    <div class="demo-item">
      <h4>危险红色</h4>
      <HTLoading color="#f5222d" text="危险加载" />
    </div>

    <div class="demo-item">
      <h4>自定义文本颜色</h4>
      <HTLoading color="#1677ff" textColor="#666" text="自定义文本色" />
    </div>

    <div class="demo-item">
      <h4>CSS 变量</h4>
      <HTLoading color="var(--color-brand-fill)" text="使用CSS变量" />
    </div>
  </div>
</template>

<script setup lang="ts">
import { HTLoading } from '@hytech/ht-ui';
</script>

<style scoped>
.demo-loading-colors {
  display: flex;
  flex-wrap: wrap;
  gap: 24px;
  padding: 20px;
}

.demo-item {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 8px;
  min-width: 120px;
}

.demo-item h4 {
  margin: 0;
  font-size: 14px;
  font-weight: 500;
  color: #666;
}
</style>
