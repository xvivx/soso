<template>
  <div class="demo-loading-types">
    <div class="demo-item">
      <h4>Circular 类型</h4>
      <HTLoading type="circular" text="圆形加载" />
    </div>

    <div class="demo-item">
      <h4>Spinner 类型</h4>
      <HTLoading type="spinner" text="旋转器加载" />
    </div>

    <div class="demo-item">
      <h4>Circular (大)</h4>
      <HTLoading type="circular" size="48px" text="大号圆形" />
    </div>

    <div class="demo-item">
      <h4>Spinner (大)</h4>
      <HTLoading type="spinner" size="48px" text="大号旋转器" />
    </div>
  </div>
</template>

<script setup lang="ts">
import { HTLoading } from '@hytech/ht-ui';
</script>

<style scoped>
.demo-loading-types {
  display: flex;
  flex-wrap: wrap;
  gap: 24px;
  padding: 20px;
}

.demo-item {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 8px;
  min-width: 120px;
}

.demo-item h4 {
  margin: 0;
  font-size: 14px;
  font-weight: 500;
  color: #666;
}
</style>
