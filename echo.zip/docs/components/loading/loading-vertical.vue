<template>
  <div class="demo-loading-vertical">
    <div class="demo-item">
      <h4>水平排列</h4>
      <HTLoading :vertical="false" text="水平排列" />
    </div>

    <div class="demo-item">
      <h4>垂直排列</h4>
      <HTLoading vertical text="垂直排列" />
    </div>

    <div class="demo-item">
      <h4>大号垂直</h4>
      <HTLoading vertical size="48px" textSize="18px" text="大号垂直" />
    </div>

    <div class="demo-item">
      <h4>自定义颜色</h4>
      <HTLoading vertical color="#52c41a" text="成功状态" />
    </div>

    <div class="demo-item">
      <h4>左对齐</h4>
      <HTLoading vertical text-align="left" text="左对齐文本" />
    </div>

    <div class="demo-item">
      <h4>右对齐</h4>
      <HTLoading vertical text-align="right" text="右对齐文本" />
    </div>
  </div>
</template>

<script setup lang="ts">
import { HTLoading } from '@hytech/ht-ui';
</script>

<style scoped>
.demo-loading-vertical {
  display: flex;
  flex-wrap: wrap;
  gap: 24px;
  padding: 20px;
}

.demo-item {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 8px;
  min-width: 120px;
}

.demo-item h4 {
  margin: 0;
  font-size: 14px;
  font-weight: 500;
  color: #666;
}
</style>
