<template>
  <div class="demo-loading-custom-icon">
    <div class="demo-item">
      <h4>默认图标</h4>
      <HTLoading text="默认图标" />
    </div>

    <div class="demo-item">
      <h4>自定义旋转方块</h4>
      <HTLoading text="旋转方块">
        <template #icon>
          <div class="custom-spinner-square"></div>
        </template>
      </HTLoading>
    </div>

    <div class="demo-item">
      <h4>自定义跳动点</h4>
      <HTLoading text="跳动点">
        <template #icon>
          <div class="custom-spinner-dots">
            <div class="dot"></div>
            <div class="dot"></div>
            <div class="dot"></div>
          </div>
        </template>
      </HTLoading>
    </div>

    <div class="demo-item">
      <h4>自定义渐变圆</h4>
      <HTLoading text="渐变圆">
        <template #icon>
          <div class="custom-spinner-gradient"></div>
        </template>
      </HTLoading>
    </div>

    <div class="demo-item">
      <h4>Tailwind 图标</h4>
      <HTLoading text="Tailwind样式">
        <template #icon>
          <div class="h-8 w-8 animate-spin rounded-full border-b-2 border-blue-500"></div>
        </template>
      </HTLoading>
    </div>
  </div>
</template>

<script setup lang="ts">
import { HTLoading } from '@hytech/ht-ui';
</script>

<style scoped>
.demo-loading-custom-icon {
  display: flex;
  flex-wrap: wrap;
  gap: 24px;
  padding: 20px;
}

.demo-item {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 8px;
  min-width: 120px;
}

.demo-item h4 {
  margin: 0;
  font-size: 14px;
  font-weight: 500;
  color: #666;
}

/* 自定义旋转方块 */
.custom-spinner-square {
  width: 24px;
  height: 24px;
  background: linear-gradient(45deg, #1677ff, #4096ff);
  animation: rotate 1s linear infinite;
  border-radius: 4px;
}

/* 自定义跳动点 */
.custom-spinner-dots {
  display: flex;
  gap: 4px;
  align-items: center;
}

.custom-spinner-dots .dot {
  width: 8px;
  height: 8px;
  background: #1677ff;
  border-radius: 50%;
  animation: bounce 1.4s ease-in-out infinite both;
}

.custom-spinner-dots .dot:nth-child(1) {
  animation-delay: -0.32s;
}
.custom-spinner-dots .dot:nth-child(2) {
  animation-delay: -0.16s;
}
.custom-spinner-dots .dot:nth-child(3) {
  animation-delay: 0s;
}

/* 自定义渐变圆 */
.custom-spinner-gradient {
  width: 24px;
  height: 24px;
  border: 3px solid transparent;
  border-top-color: #1677ff;
  border-radius: 50%;
  animation: spin 1s linear infinite;
  background: linear-gradient(45deg, #1677ff, transparent);
}

@keyframes rotate {
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
}

@keyframes bounce {
  0%,
  80%,
  100% {
    transform: scale(0);
  }
  40% {
    transform: scale(1);
  }
}

@keyframes spin {
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
}
</style>
