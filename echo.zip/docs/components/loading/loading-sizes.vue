<template>
  <div class="demo-loading-sizes">
    <div class="demo-item">
      <h4>小号 (16px)</h4>
      <HTLoading size="16px" text="小号" />
    </div>

    <div class="demo-item">
      <h4>默认 (30px)</h4>
      <HTLoading size="30px" text="默认" />
    </div>

    <div class="demo-item">
      <h4>大号 (48px)</h4>
      <HTLoading size="48px" text="大号" />
    </div>

    <div class="demo-item">
      <h4>特大号 (64px)</h4>
      <HTLoading size="64px" text="特大号" />
    </div>

    <div class="demo-item">
      <h4>自定义文本大小</h4>
      <HTLoading size="30px" textSize="20px" text="大文本" />
    </div>

    <div class="demo-item">
      <h4>数值尺寸</h4>
      <HTLoading :size="40" text="数值40" />
    </div>
  </div>
</template>

<script setup lang="ts">
import { HTLoading } from '@hytech/ht-ui';
</script>

<style scoped>
.demo-loading-sizes {
  display: flex;
  flex-wrap: wrap;
  gap: 24px;
  padding: 20px;
}

.demo-item {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 8px;
  min-width: 120px;
}

.demo-item h4 {
  margin: 0;
  font-size: 14px;
  font-weight: 500;
  color: #666;
}
</style>
