# HTLoading 加载中

加载动画组件，用于表示数据正在加载中，支持多种动画类型和自定义样式。完全兼容 Vant Loading API。

## 基础用法

<demo vue="./loading-basic.vue" codesandbox="true" />

## 加载类型

支持两种加载动画类型：circular（圆形）和 spinner（旋转器）。

<demo vue="./loading-types.vue" codesandbox="true" />

## 自定义颜色

可以自定义加载动画和文本的颜色。

<demo vue="./loading-colors.vue" codesandbox="true" />

## 自定义尺寸

支持设置加载动画的尺寸和文本大小。

<demo vue="./loading-sizes.vue" codesandbox="true" />

## 垂直排列

设置 vertical 属性可以让图标和文本垂直排列。

<demo vue="./loading-vertical.vue" codesandbox="true" />

## 自定义图标

通过 icon 插槽可以自定义加载图标。

<demo vue="./loading-custom-icon.vue" codesandbox="true" />

## Attributes

| Attribute | Description | Type | Default | Vant 兼容 |
| --- | --- | --- | --- | --- |
| `type` | 加载类型 | `'circular' \| 'spinner'` | `'circular'` | ✅ |
| `size` | 加载图标大小 | `string \| number` | `'30px'` | ✅ |
| `color` | 自定义颜色 | `string` | `''` | ✅ |
| `textSize` | 文本大小 | `string \| number` | `''` | ✅ |
| `textColor` | 文本颜色 | `string` | `''` | ✅ |
| `vertical` | 是否垂直排列 | `boolean` | `false` | ✅ |
| `text` | 加载文本 | `string` | `''` | ✅ |
| `textAlign` | 文本对齐方式 | `'left' \| 'center' \| 'right'` | `'center'` | ✅ |
| `class` | 自定义类名 | `string` | `''` | ✅ |

## Events

| Event | Description | Parameters | Vant 兼容 |
| --- | --- | --- | --- |
| - | 暂无事件 | - | - |

## Slots

| Slot | Description | Parameters | Vant 兼容 |
| --- | --- | --- | --- |
| `default` | 默认内容，用于自定义加载文本 | - | ✅ |
| `icon` | 自定义图标插槽 | - | ✅ |

## 主题定制

```css
.ht-loading {
  --loading-spinner-size-default: 24px;
  --loading-spinner-size-small: 16px;
  --loading-spinner-size-large: 32px;
  --loading-spinner-color-default: #1677ff;
  --loading-text-color-default: #8c8c8c;
  --loading-spinner-animation-duration: 0.8s;
}
```

## Vant API 兼容性

| Vant API | HT 实现 | 说明 |
| --- | --- | --- |
| type | ✅ 完全兼容 | 支持 circular、spinner 两种类型 |
| size | ✅ 完全兼容 | 支持数字或字符串，自动转换为标准尺寸 |
| color | ✅ 完全兼容 | 支持任意颜色值，包括十六进制、CSS 变量等 |
| textSize | ✅ 完全兼容 | 支持数字或字符串，默认基于图标尺寸自动调整 |
| textColor | ✅ 完全兼容 | 支持任意颜色值，未设置时继承 color |
| vertical | ✅ 完全兼容 | 控制图标和文本的排列方向 |
| text | ✅ 完全兼容 | 加载文本内容，支持插槽自定义 |
| textAlign | ✅ 完全兼容 | 文本对齐方式，支持 left、center、right |