<template>
  <div class="tag-types-demo">
    <h3>填充样式</h3>
    <div class="demo-container">
      <HTTag type="default">默认</HTTag>
      <HTTag type="primary">主要</HTTag>
      <HTTag type="success">成功</HTTag>
      <HTTag type="warning">警告</HTTag>
      <HTTag type="danger">危险</HTTag>
      <HTTag type="info">信息</HTTag>
    </div>

    <h3>朴素样式</h3>
    <div class="demo-container">
      <HTTag plain>默认</HTTag>
      <HTTag type="primary" plain>主要</HTTag>
      <HTTag type="success" plain>成功</HTTag>
      <HTTag type="warning" plain>警告</HTTag>
      <HTTag type="danger" plain>危险</HTTag>
      <HTTag type="info" plain>信息</HTTag>
    </div>

    <h3>自定义颜色</h3>
    <div class="demo-container">
      <HTTag color="#7232dd">自定义颜色</HTTag>
      <HTTag color="#7232dd" plain>朴素自定义</HTTag>
      <HTTag color="#ffe1e1" text-color="#ad0000">自定义文本色</HTTag>
      <HTTag color="#f0f5ff" text-color="#1677ff" plain>自定义边框色</HTTag>
    </div>

    <h3>渐变效果示例</h3>
    <div class="demo-container">
      <HTTag color="linear-gradient(45deg, #ff6b6b, #feca57)" text-color="white"> 渐变背景 </HTTag>
      <HTTag color="linear-gradient(135deg, #667eea, #764ba2)" text-color="white" round> 渐变圆角 </HTTag>
    </div>
  </div>
</template>

<script setup lang="ts">
import { HTTag } from '@/components';
</script>

<style scoped>
.tag-types-demo {
  width: 100%;
  max-width: 800px;
  margin: 0 auto;
  padding: 20px;
}

.demo-container {
  display: flex;
  flex-wrap: wrap;
  gap: 12px;
  margin-bottom: 24px;
  align-items: center;
}

h3 {
  font-size: 16px;
  font-weight: 500;
  margin-bottom: 12px;
  color: #333;
}
</style>
