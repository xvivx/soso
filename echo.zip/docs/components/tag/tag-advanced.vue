<template>
  <div class="tag-advanced-demo">
    <h3>可关闭标签</h3>
    <div class="demo-container">
      <HTTag v-for="tag in tags" :key="tag.name" :type="tag.type" closeable @close="handleClose(tag)">
        {{ tag.name }}
      </HTTag>
      <HTTag closeable @close="addTag">
        <HTIcon name="plus-line-sm" />
        添加标签
      </HTTag>
    </div>

    <h3>动态控制</h3>
    <div class="demo-container">
      <div class="control-group">
        <label>
          <input type="checkbox" v-model="showTag" />
          显示标签
        </label>
        <label>
          <input type="checkbox" v-model="isPlain" />
          朴素样式
        </label>
        <label>
          <input type="checkbox" v-model="isRound" />
          圆角样式
        </label>
        <label>
          <input type="checkbox" v-model="isMark" />
          标记样式
        </label>
      </div>
      <HTTag v-if="showTag" :type="selectedType" :plain="isPlain" :round="isRound" :mark="isMark"> 动态标签 </HTTag>
    </div>

    <h3>类型选择器</h3>
    <div class="demo-container">
      <div class="type-selector">
        <label v-for="type in types" :key="type.value">
          <input type="radio" :value="type.value" v-model="selectedType" />
          {{ type.label }}
        </label>
      </div>
      <HTTag :type="selectedType" round size="large"> {{ getTypeLabel(selectedType) }}标签 </HTTag>
    </div>

    <h3>自定义颜色</h3>
    <div class="demo-container">
      <div class="color-controls">
        <div class="control-item">
          <label>背景颜色:</label>
          <input type="color" v-model="customBgColor" @input="updateColors" />
          <input type="text" v-model="customBgColor" @input="updateColors" placeholder="#1677ff" />
        </div>
        <div class="control-item">
          <label>文本颜色:</label>
          <input type="color" v-model="customTextColor" @input="updateColors" />
          <input type="text" v-model="customTextColor" @input="updateColors" placeholder="#ffffff" />
        </div>
      </div>
      <HTTag :color="customBgColor" :text-color="customTextColor" round> 自定义颜色 </HTTag>
    </div>

    <h3>标签计数器</h3>
    <div class="demo-container">
      <div class="counter-controls">
        <HTTag type="primary">数量: {{ count }}</HTTag>
        <div class="buttons">
          <button @click="increment" class="btn-increment">+</button>
          <button @click="decrement" class="btn-decrement">-</button>
          <button @click="reset" class="btn-reset">重置</button>
        </div>
      </div>
    </div>

    <h3>标签列表管理</h3>
    <div class="demo-container">
      <div class="list-controls">
        <input v-model="newTagText" @keyup.enter="addNewTag" placeholder="输入标签名称" class="tag-input" />
        <button @click="addNewTag" class="btn-add">添加</button>
      </div>
      <div class="tag-list">
        <HTTag
          v-for="(tag, index) in tagList"
          :key="index"
          :type="tagTypes[index % tagTypes.length]"
          closeable
          @close="removeTag(index)"
          round
        >
          {{ tag }}
        </HTTag>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { reactive, ref } from 'vue';
import { HTIcon, HTTag } from '@/components';
import type { TagType } from '@/components/tag/types';

// 可关闭标签数据
const tags = reactive([
  { name: 'Vue.js', type: 'success' as TagType },
  { name: 'React', type: 'primary' as TagType },
  { name: 'Angular', type: 'warning' as TagType },
  { name: 'Svelte', type: 'info' as TagType },
]);

const handleClose = (tag: { name: string; type: TagType }) => {
  const index = tags.indexOf(tag);
  if (index > -1) {
    tags.splice(index, 1);
  }
};

const addTag = () => {
  const frameworks = ['Next.js', 'Nuxt.js', 'Solid.js', 'Alpine.js'];
  const colors: TagType[] = ['primary', 'success', 'warning', 'danger', 'info'];
  const randomFramework = frameworks[Math.floor(Math.random() * frameworks.length)];
  const randomColor = colors[Math.floor(Math.random() * colors.length)];

  if (tags.length < 8) {
    tags.push({ name: randomFramework!, type: randomColor! });
  }
};

// 动态控制
const showTag = ref(true);
const isPlain = ref(false);
const isRound = ref(false);
const isMark = ref(false);

// 类型选择器
const types = [
  { value: 'default', label: '默认' },
  { value: 'primary', label: '主要' },
  { value: 'success', label: '成功' },
  { value: 'warning', label: '警告' },
  { value: 'danger', label: '危险' },
  { value: 'info', label: '信息' },
];

const selectedType = ref<TagType>('primary');

const getTypeLabel = (type: TagType) => {
  const found = types.find((t) => t.value === type);
  return found ? found.label : '默认';
};

// 自定义颜色
const customBgColor = ref<string>('#1677ff');
const customTextColor = ref<string>('#ffffff');

const updateColors = () => {
  // 颜色更新通过 v-model 自动处理
};

// 计数器
const count = ref(0);

const increment = () => count.value++;
const decrement = () => (count.value > 0 ? count.value-- : 0);
const reset = () => (count.value = 0);

// 标签列表管理
const newTagText = ref('');
const tagList = ref(['标签1', '标签2', '标签3']);
const tagTypes: TagType[] = ['primary', 'success', 'warning', 'danger', 'info'];

const addNewTag = () => {
  if (newTagText.value.trim() && tagList.value.length < 10) {
    tagList.value.push(newTagText.value.trim());
    newTagText.value = '';
  }
};

const removeTag = (index: number) => {
  tagList.value.splice(index, 1);
};
</script>

<style scoped>
.tag-advanced-demo {
  width: 100%;
  max-width: 800px;
  margin: 0 auto;
  padding: 20px;
}

.demo-container {
  margin-bottom: 24px;
}

h3 {
  font-size: 16px;
  font-weight: 500;
  margin-bottom: 12px;
  color: #333;
}

/* 动态控制样式 */
.control-group {
  display: flex;
  flex-wrap: wrap;
  gap: 20px;
  margin-bottom: 16px;
}

.control-group label {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 14px;
  color: #666;
}

.control-group input[type='checkbox'] {
  margin: 0;
}

/* 类型选择器样式 */
.type-selector {
  display: flex;
  flex-wrap: wrap;
  gap: 16px;
  margin-bottom: 16px;
}

.type-selector label {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 14px;
  color: #666;
}

.type-selector input[type='radio'] {
  margin: 0;
}

/* 自定义颜色控制 */
.color-controls {
  margin-bottom: 16px;
}

.control-item {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-bottom: 12px;
}

.control-item label {
  font-size: 14px;
  color: #666;
  min-width: 80px;
}

.control-item input[type='color'] {
  width: 40px;
  height: 32px;
  border: 1px solid #d9d9d9;
  border-radius: 4px;
  cursor: pointer;
}

.control-item input[type='text'] {
  padding: 6px 12px;
  border: 1px solid #d9d9d9;
  border-radius: 4px;
  font-size: 14px;
  width: 120px;
}

/* 计数器样式 */
.counter-controls {
  display: flex;
  align-items: center;
  gap: 16px;
}

.buttons {
  display: flex;
  gap: 8px;
}

.buttons button {
  padding: 6px 12px;
  border: 1px solid #d9d9d9;
  border-radius: 4px;
  background: white;
  cursor: pointer;
  font-size: 14px;
  transition: all 0.2s;
}

.buttons button:hover {
  background: #f5f5f5;
}

.btn-increment {
  color: #52c41a;
  border-color: #52c41a;
}

.btn-decrement {
  color: #fa8c16;
  border-color: #fa8c16;
}

.btn-reset {
  color: #8c8c8c;
  border-color: #8c8c8c;
}

/* 标签列表管理样式 */
.list-controls {
  display: flex;
  gap: 12px;
  margin-bottom: 16px;
}

.tag-input {
  flex: 1;
  padding: 8px 12px;
  border: 1px solid #d9d9d9;
  border-radius: 4px;
  font-size: 14px;
  max-width: 200px;
}

.btn-add {
  padding: 8px 16px;
  background: #1677ff;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-size: 14px;
  transition: background 0.2s;
}

.btn-add:hover {
  background: #0958d9;
}

.tag-list {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
}
</style>
