# HTTag 标签

用于标记和分类的标签组件，支持多种类型、尺寸和样式变体。参照 Element 与 Vant 的结合式用法。

## 基础用法

<demo vue="./tag-basic.vue" codesandbox="true" />

## 标签类型

支持多种预设类型的标签，包括 primary、success、warning、danger、info 等。

<demo vue="./tag-types.vue" codesandbox="true" />

## 标签尺寸

提供 small、default、large 三种尺寸，满足不同场景的使用需求。

<demo vue="./tag-sizes.vue" codesandbox="true" />

## 样式变体

支持朴素样式、圆角样式、标记样式等多种外观变体。

<demo vue="./tag-features.vue" codesandbox="true" />

## 高级特性

包含可关闭标签、自定义颜色、动态控制等高级功能。

<demo vue="./tag-advanced.vue" codesandbox="true" />

## Attributes

| Attribute | Description | Type | Default | Vant 兼容 |
| --- | --- | --- | --- | --- |
| `type` | 标签类型 | `'default' \| 'primary' \| 'success' \| 'warning' \| 'danger' \| 'info'` | `'default'` | ✅ |
| `size` | 标签尺寸 | `'small' \| 'large'` | - | ✅ |
| `color` | 自定义标签颜色 | `string` | - | ✅ |
| `text-color` | 自定义文本颜色 | `string` | - | ✅ |
| `plain` | 是否为朴素样式 | `boolean` | `false` | ✅ |
| `round` | 是否为圆角样式 | `boolean` | `false` | ✅ |
| `mark` | 是否为标记样式 | `boolean` | `false` | ✅ |
| `closeable` | 是否可关闭 | `boolean` | `false` | ✅ |
| `show` | 是否显示标签 | `boolean` | `true` | ✅ |

## Events

| Event | Description | Parameters | Vant 兼容 |
| --- | --- | --- | --- |
| `close` | 关闭标签时触发 | `(event: MouseEvent)` | ✅ |

## Slots

| Slot | Description | Parameters | Vant 兼容 |
| --- | --- | --- | --- |
| `default` | 标签内容 | - | ✅ |

## 主题定制

基于 CSS Token 的主题定制系统，支持深度定制组件外观。

```css
.ht-tag {
  /* 容器样式 */
  --tag-container-padding-default: 2px 8px;
  --tag-container-padding-large: 4px 12px;
  --tag-container-padding-small: 1px 4px;
  --tag-container-border-radius-default: 4px;
  --tag-container-border-radius-round: 999px;

  /* 文本样式 */
  --tag-text-font-size-default: 12px;
  --tag-text-font-size-large: 14px;
  --tag-text-font-size-small: 10px;
  --tag-text-color-default: #333333;

  /* 类型颜色 */
  --tag-bg-color-primary: #E8F3FF;
  --tag-bg-color-success: #F6FFED;
  --tag-bg-color-warning: #FFF7E8;
  --tag-bg-color-danger: #FFF2F3;
  --tag-bg-color-info: #F2F3F5;

  /* 边框颜色 */
  --tag-border-color-primary: #1677FF;
  --tag-border-color-success: #52C41A;
  --tag-border-color-warning: #FAAD14;
  --tag-border-color-danger: #FF4D4F;

  /* 关闭图标 */
  --tag-close-icon-size-default: 12px;
  --tag-close-icon-color-default: #8C8C8C;
  --tag-close-icon-margin-default: 0 0 0 4px;
}
```

## Vant API 兼容性

| Vant API | HT 实现 | 说明 |
| --- | --- | --- |
| type | ✅ 完全兼容 | 支持 default、primary、success、warning、danger、info |
| size | ✅ 完全兼容 | 支持 small、default、large |
| color | ✅ 完全兼容 | 支持自定义背景色和文本色 |
| plain | ✅ 完全兼容 | 支持朴素样式，透明背景带边框 |
| round | ✅ 完全兼容 | 支持圆角样式 |
| mark | ✅ 完全兼容 | 支持标记样式，右侧圆角 |
| closeable | ✅ 完全兼容 | 支持关闭按钮和 close 事件 |
| show | ✅ 完全兼容 | 支持动态显示/隐藏 |
| close 事件 | ✅ 完全兼容 | 点击关闭按钮时触发 |