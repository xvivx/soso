# HTTag 标签

用于标记和分类的标签组件，支持多种类型、尺寸和样式变体。参照 Element 与 Vant 的结合式用法。

## 基础用法

<demo vue="./tag-basic.vue" codesandbox="true" />

## 标签类型

支持多种预设类型的标签，包括 primary、success、warning、danger、info 等。

<demo vue="./tag-types.vue" codesandbox="true" />

## 标签尺寸

提供 small、default、large 三种尺寸，满足不同场景的使用需求。

<demo vue="./tag-sizes.vue" codesandbox="true" />

## 样式变体

支持朴素样式、圆角样式、标记样式等多种外观变体。

<demo vue="./tag-features.vue" codesandbox="true" />

## 高级特性

包含可关闭标签、自定义颜色、动态控制等高级功能。

<demo vue="./tag-advanced.vue" codesandbox="true" />

## Attributes

| Attribute | Description | Type | Default | Vant 兼容 |
| --- | --- | --- | --- | --- |
| `type` | 标签类型 | `'default' \| 'primary' \| 'success' \| 'warning' \| 'danger' \| 'info'` | `'default'` | ✅ |
| `size` | 标签尺寸 | `'small' \| 'large'` | - | ✅ |
| `color` | 自定义标签颜色 | `string` | - | ✅ |
| `text-color` | 自定义文本颜色 | `string` | - | ✅ |
| `plain` | 是否为朴素样式 | `boolean` | `false` | ✅ |
| `round` | 是否为圆角样式 | `boolean` | `false` | ✅ |
| `mark` | 是否为标记样式 | `boolean` | `false` | ✅ |
| `closeable` | 是否可关闭 | `boolean` | `false` | ✅ |
| `show` | 是否显示标签 | `boolean` | `true` | ✅ |

## Events

| Event | Description | Parameters | Vant 兼容 |
| --- | --- | --- | --- |
| `close` | 关闭标签时触发 | `(event: MouseEvent)` | ✅ |

## Slots

| Slot | Description | Parameters | Vant 兼容 |
| --- | --- | --- | --- |
| `default` | 标签内容 | - | ✅ |

## 主题定制

HTTag 组件使用 CSS 变量来定制主题，你可以通过修改这些变量来自定义标签的外观：

```css
.ht-tag {
  /* 容器内边距 */
  --tag-container-padding-default: var(--dimensions-spacing-inset-md);
  --tag-container-padding-large: var(--dimensions-spacing-inset-lg);
  --tag-container-padding-small: var(--dimensions-spacing-inset-sm);

  /* 容器尺寸高度 */
  --tag-container-size-default: var(--dimensions-sizing-container-lg);
  --tag-container-size-large: var(--dimensions-sizing-container-xl);
  --tag-container-size-small: var(--dimensions-sizing-container-lg);

  /* 容器圆角 */
  --tag-container-border-radius-default: var(--dimensions-radius-xs);
  --tag-container-border-radius-large: var(--dimensions-radius-md);
  --tag-container-border-radius-round: var(--dimensions-radius-full);

  /* 类型背景色 */
  --tag-bg-color-default: var(--color-neutral-fill);
  --tag-bg-color-primary: var(--color-brand-background-subtle);
  --tag-bg-color-success: var(--color-feedback-success-background-secondary);
  --tag-bg-color-warning: var(--color-feedback-warning-background-secondary);
  --tag-bg-color-danger: var(--color-feedback-error-background-secondary);
  --tag-bg-color-info: var(--color-feedback-info-background);
  --tag-bg-color-disabled: var(--color-surface-disabled);

  /* 类型边框色 */
  --tag-border-color-default: var(--color-border-default);
  --tag-border-color-primary: var(--color-brand-border);
  --tag-border-color-success: var(--color-feedback-success-border);
  --tag-border-color-warning: var(--color-feedback-warning-border);
  --tag-border-color-danger: var(--color-feedback-error-border);
  --tag-border-color-info: var(--color-feedback-info-border);
  --tag-border-color-disabled: var(--color-border-disabled);

  /* 文本和图标颜色 */
  --tag-content-color-default: var(--color-neutral-content);
  --tag-content-color-primary: var(--color-brand-content);
  --tag-content-color-success: var(--color-feedback-success-content);
  --tag-content-color-warning: var(--color-feedback-warning-content);
  --tag-content-color-danger: var(--color-feedback-error-content);
  --tag-content-color-info: var(--color-feedback-info-content);
  --tag-content-color-disabled: var(--color-content-disabled);

  /* 文本字号 */
  --tag-font-size-default: var(--typography-body-sm-size);
  --tag-font-size-large: var(--typography-body-md-size);
  --tag-font-size-small: var(--typography-body-xs-size);

  /* 文本字重 */
  --tag-font-weight-default: var(--typography-control-s-weight);
  --tag-font-weight-large: var(--typography-control-m-weight);
  --tag-font-weight-small: var(--typography-control-s-weight);

  /* 图标尺寸 */
  --tag-icon-size-default: var(--dimensions-sizing-icon-sm);
  --tag-icon-size-large: var(--dimensions-sizing-icon-base);

  /* 图标间距 */
  --tag-icon-margin-right-default: var(--dimensions-spacing-inset-xs);

  /* 悬停状态背景色 */
  --tag-bg-color-default-hover: var(--color-surface-hover);
  --tag-bg-color-primary-hover: var(--color-brand-background-primary);
  --tag-bg-color-success-hover: var(--color-feedback-success-background-primary);
  --tag-bg-color-warning-hover: var(--color-feedback-warning-background-primary);
  --tag-bg-color-danger-hover: var(--color-feedback-error-background-primary);
  --tag-bg-color-info-hover: var(--color-neutral-fill);

  /* 悬停状态文本和图标颜色 */
  --tag-content-color-default-hover: var(--color-neutral-content);
  --tag-content-color-primary-hover: var(--color-brand-content);
  --tag-content-color-success-hover: var(--color-feedback-success-content);
  --tag-content-color-warning-hover: var(--color-feedback-warning-content);
  --tag-content-color-danger-hover: var(--color-feedback-error-content);
  --tag-content-color-info-hover: var(--color-feedback-info-content);

  /* 悬停状态边框色 */
  --tag-border-color-default-hover: var(--color-border-hover);
  --tag-border-color-primary-hover: var(--color-brand-border);
  --tag-border-color-success-hover: var(--color-feedback-success-border);
  --tag-border-color-warning-hover: var(--color-feedback-warning-border);
  --tag-border-color-danger-hover: var(--color-feedback-error-border);
  --tag-border-color-info-hover: var(--color-feedback-info-border);

  /* 激活状态边框色 */
  --tag-border-color-default-active: var(--color-border-active);
  --tag-border-color-primary-active: var(--color-brand-border-active);
  --tag-border-color-success-active: var(--color-feedback-success-border-active);
  --tag-border-color-warning-active: var(--color-feedback-warning-border-active);
  --tag-border-color-danger-active: var(--color-feedback-error-border-active);
  --tag-border-color-info-active: var(--color-feedback-info-border-active);

  /* 激活状态背景色 */
  --tag-bg-color-default-active: var(--color-surface-active);
  --tag-bg-color-primary-active: var(--color-brand-background-active);
  --tag-bg-color-success-active: var(--color-feedback-success-background-active);
  --tag-bg-color-warning-active: var(--color-feedback-warning-background-active);
  --tag-bg-color-danger-active: var(--color-feedback-error-background-active);
  --tag-bg-color-info-active: var(--color-feedback-info-background-active);

  /* 激活状态文本和图标颜色 */
  --tag-content-color-default-active: var(--color-neutral-content);
  --tag-content-color-primary-active: var(--color-brand-content);
  --tag-content-color-success-active: var(--color-feedback-success-content);
  --tag-content-color-warning-active: var(--color-feedback-warning-content);
  --tag-content-color-danger-active: var(--color-feedback-error-content);
  --tag-content-color-info-active: var(--color-feedback-info-content);

  /* 关闭图标 */
  --tag-close-icon-size-default: var(--dimensions-sizing-icon-sm);
  --tag-close-icon-size-small: var(--dimensions-sizing-icon-sm);
  --tag-close-icon-size-large: var(--dimensions-sizing-icon-base);
  --tag-close-icon-margin-left-default: var(--dimensions-spacing-inset-2xs);
}
```

## Vant API 兼容性

| Vant API | HT 实现 | 说明 |
| --- | --- | --- |
| type | ✅ 完全兼容 | 支持 default、primary、success、warning、danger、info |
| size | ✅ 完全兼容 | 支持 small、default、large |
| color | ✅ 完全兼容 | 支持自定义背景色和文本色 |
| plain | ✅ 完全兼容 | 支持朴素样式，透明背景带边框 |
| round | ✅ 完全兼容 | 支持圆角样式 |
| mark | ✅ 完全兼容 | 支持标记样式，右侧圆角 |
| closeable | ✅ 完全兼容 | 支持关闭按钮和 close 事件 |
| show | ✅ 完全兼容 | 支持动态显示/隐藏 |
| close 事件 | ✅ 完全兼容 | 点击关闭按钮时触发 |