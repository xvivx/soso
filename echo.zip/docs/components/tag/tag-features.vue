<template>
  <div class="tag-features-demo">
    <h3>圆角标签</h3>
    <div class="demo-container">
      <HTTag round type="primary">圆角主要</HTTag>
      <HTTag round type="success">圆角成功</HTTag>
      <HTTag round type="warning">圆角警告</HTTag>
      <HTTag round type="danger">圆角危险</HTTag>
      <HTTag round plain>圆角朴素</HTTag>
    </div>

    <h3>标记标签</h3>
    <div class="demo-container">
      <HTTag mark type="primary">标记主要</HTTag>
      <HTTag mark type="success">标记成功</HTTag>
      <HTTag mark type="warning">标记警告</HTTag>
      <HTTag mark type="danger">标记危险</HTTag>
      <HTTag mark plain>标记朴素</HTTag>
    </div>

    <h3>朴素样式标签</h3>
    <div class="demo-container">
      <HTTag plain>朴素默认</HTTag>
      <HTTag type="primary" plain>朴素主要</HTTag>
      <HTTag type="success" plain>朴素成功</HTTag>
      <HTTag type="warning" plain>朴素警告</HTTag>
      <HTTag type="danger" plain>朴素危险</HTTag>
      <HTTag type="info" plain>朴素信息</HTTag>
    </div>

    <h3>样式组合</h3>
    <div class="demo-container">
      <div class="combination-grid">
        <div class="combination-item">
          <span>圆角 + 朴素</span>
          <HTTag round plain type="primary">标签</HTTag>
        </div>
        <div class="combination-item">
          <span>标记 + 朴素</span>
          <HTTag mark plain type="success">标签</HTTag>
        </div>
        <div class="combination-item">
          <span>小号 + 圆角</span>
          <HTTag size="small" round type="warning">标签</HTTag>
        </div>
        <div class="combination-item">
          <span>大号 + 标记</span>
          <HTTag size="large" mark type="danger">标签</HTTag>
        </div>
        <div class="combination-item">
          <span>小号 + 朴素 + 圆角</span>
          <HTTag size="small" round plain>标签</HTTag>
        </div>
        <div class="combination-item">
          <span>大号 + 朴素 + 标记</span>
          <HTTag size="large" mark plain type="info">标签</HTTag>
        </div>
      </div>
    </div>

    <h3>带图标的标签</h3>
    <div class="demo-container">
      <HTTag round type="primary">
        <HTIcon name="star" />
        收藏
      </HTTag>
      <HTTag round type="success">
        <HTIcon name="check-circle" />
        已完成
      </HTTag>
      <HTTag round type="warning">
        <HTIcon name="clock-circle" />
        进行中
      </HTTag>
      <HTTag mark plain type="danger">
        <HTIcon name="close-circle" />
        已取消
      </HTTag>
    </div>

    <h3>文本内容示例</h3>
    <div class="demo-container">
      <HTTag round>短文本</HTTag>
      <HTTag round>中等长度的文本</HTTag>
      <HTTag round>这是一个比较长的标签文本内容</HTTag>
      <HTTag size="large" round>大号长文本标签内容展示</HTTag>
    </div>
  </div>
</template>

<script setup lang="ts">
import { HTIcon, HTTag } from '@/components';
</script>

<style scoped>
.tag-features-demo {
  width: 100%;
  max-width: 800px;
  margin: 0 auto;
  padding: 20px;
}

.demo-container {
  display: flex;
  flex-wrap: wrap;
  gap: 12px;
  margin-bottom: 24px;
  align-items: center;
}

h3 {
  font-size: 16px;
  font-weight: 500;
  margin-bottom: 12px;
  color: #333;
}

.combination-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 16px;
  width: 100%;
}

.combination-item {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 12px 16px;
  border: 1px solid #e8e8e8;
  border-radius: 8px;
  background-color: #fafafa;
}

.combination-item span {
  font-size: 14px;
  color: #666;
}
</style>
