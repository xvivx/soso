<template>
  <div class="tag-basic-demo">
    <h3>基础标签</h3>
    <div class="demo-container">
      <HTTag>默认标签</HTTag>
      <HTTag type="primary">主要标签</HTTag>
      <HTTag type="success">成功标签</HTTag>
      <HTTag type="warning">警告标签</HTTag>
      <HTTag type="danger">危险标签</HTTag>
      <HTTag type="info">信息标签</HTTag>
    </div>

    <h3>带内容</h3>
    <div class="demo-container">
      <HTTag>
        <HTIcon name="info-circle-line" />
        验证通过
      </HTTag>
      <HTTag type="warning">
        <HTIcon name="info-circle-line" />
        需要关注
      </HTTag>
      <HTTag type="danger">
        <HTIcon name="info-circle-line" />
        验证失败
      </HTTag>
    </div>
  </div>
</template>

<script setup lang="ts">
import { HTIcon, HTTag } from '@/components';
</script>

<style scoped>
.tag-basic-demo {
  width: 100%;
  max-width: 800px;
  margin: 0 auto;
  padding: 20px;
}

.demo-container {
  display: flex;
  flex-wrap: wrap;
  gap: 12px;
  margin-bottom: 24px;
  align-items: center;
}

h3 {
  font-size: 16px;
  font-weight: 500;
  margin-bottom: 12px;
  color: #333;
}
</style>
