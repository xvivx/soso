<template>
  <div class="tag-sizes-demo">
    <h3>标签尺寸对比</h3>
    <div class="demo-container">
      <div class="size-group">
        <h4>小号标签</h4>
        <div class="tag-group">
          <HTTag size="small" type="primary">小号主要</HTTag>
          <HTTag size="small" type="success">小号成功</HTTag>
          <HTTag size="small" type="warning">小号警告</HTTag>
          <HTTag size="small" plain>小号朴素</HTTag>
        </div>
      </div>

      <div class="size-group">
        <h4>默认标签</h4>
        <div class="tag-group">
          <HTTag type="primary">默认主要</HTTag>
          <HTTag type="success">默认成功</HTTag>
          <HTTag type="warning">默认警告</HTTag>
          <HTTag plain>默认朴素</HTTag>
        </div>
      </div>

      <div class="size-group">
        <h4>大号标签</h4>
        <div class="tag-group">
          <HTTag size="large" type="primary">大号主要</HTTag>
          <HTTag size="large" type="success">大号成功</HTTag>
          <HTTag size="large" type="warning">大号警告</HTTag>
          <HTTag size="large" plain>大号朴素</HTTag>
        </div>
      </div>
    </div>

    <h3>尺寸与样式组合</h3>
    <div class="demo-container">
      <div class="combination-grid">
        <div class="combination-item">
          <span>小号 + 圆角</span>
          <HTTag size="small" round type="primary">标签</HTTag>
        </div>
        <div class="combination-item">
          <span>默认 + 圆角</span>
          <HTTag round type="success">标签</HTTag>
        </div>
        <div class="combination-item">
          <span>大号 + 圆角</span>
          <HTTag size="large" round type="warning">标签</HTTag>
        </div>
        <div class="combination-item">
          <span>小号 + 标记</span>
          <HTTag size="small" mark type="danger">标签</HTTag>
        </div>
        <div class="combination-item">
          <span>默认 + 标记</span>
          <HTTag mark type="info">标签</HTTag>
        </div>
        <div class="combination-item">
          <span>大号 + 标记</span>
          <HTTag size="large" mark>标签</HTTag>
        </div>
      </div>
    </div>

    <h3>可关闭标签尺寸</h3>
    <div class="demo-container">
      <HTTag size="small" closeable @close="handleClose('small')">小号可关闭</HTTag>
      <HTTag closeable @close="handleClose('default')">默认可关闭</HTTag>
      <HTTag size="large" closeable @close="handleClose('large')">大号可关闭</HTTag>
    </div>
  </div>
</template>

<script setup lang="ts">
import { HTTag } from '@/components';

const handleClose = (size: string) => {
  console.log(`${size} 标签已关闭`);
};
</script>

<style scoped>
.tag-sizes-demo {
  width: 100%;
  max-width: 800px;
  margin: 0 auto;
  padding: 20px;
}

.demo-container {
  margin-bottom: 24px;
}

.size-group {
  margin-bottom: 20px;
}

h3 {
  font-size: 16px;
  font-weight: 500;
  margin-bottom: 12px;
  color: #333;
}

h4 {
  font-size: 14px;
  font-weight: 500;
  margin-bottom: 8px;
  color: #666;
}

.tag-group {
  display: flex;
  flex-wrap: wrap;
  gap: 12px;
  align-items: center;
}

.combination-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 16px;
}

.combination-item {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 12px 16px;
  border: 1px solid #e8e8e8;
  border-radius: 8px;
  background-color: #fafafa;
}

.combination-item span {
  font-size: 14px;
  color: #666;
}
</style>
