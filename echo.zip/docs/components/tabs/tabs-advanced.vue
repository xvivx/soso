<template>
  <div class="demo-tabs-advanced">
    <StickyInIframe />

    <div class="demo-section">
      <h3 class="demo-title">滑动切换</h3>
      <p class="demo-desc">支持手势左右滑动切换标签</p>
      <HTTabs v-model:active="active2" swipeable>
        <HTTab title="标签 1">
          <div class="demo-content">可以左右滑动切换内容 1</div>
        </HTTab>
        <HTTab title="标签 2">
          <div class="demo-content">可以左右滑动切换内容 2</div>
        </HTTab>
        <HTTab title="标签 3">
          <div class="demo-content">可以左右滑动切换内容 3</div>
        </HTTab>
        <HTTab title="标签 4">
          <div class="demo-content">可以左右滑动切换内容 4</div>
        </HTTab>
      </HTTabs>
    </div>

    <div class="demo-section">
      <h3 class="demo-title">动画切换</h3>
      <p class="demo-desc">开启切换动画效果</p>
      <HTTabs v-model:active="active3" animated :duration="0.5">
        <HTTab title="标签 1">
          <div class="demo-content">带切换动画的内容 1</div>
        </HTTab>
        <HTTab title="标签 2">
          <div class="demo-content">带切换动画的内容 2</div>
        </HTTab>
        <HTTab title="标签 3">
          <div class="demo-content">带切换动画的内容 3</div>
        </HTTab>
      </HTTabs>
    </div>

    <div class="demo-section">
      <h3 class="demo-title">滑动 + 动画</h3>
      <p class="demo-desc">同时开启滑动和动画效果</p>
      <HTTabs v-model:active="active4" swipeable animated :duration="0.6">
        <HTTab title="标签 1">
          <div class="demo-content">可滑动且带动画的内容 1</div>
        </HTTab>
        <HTTab title="标签 2">
          <div class="demo-content">可滑动且带动画的内容 2</div>
        </HTTab>
        <HTTab title="标签 3">
          <div class="demo-content">可滑动且带动画的内容 3</div>
        </HTTab>
        <HTTab title="标签 4">
          <div class="demo-content">可滑动且带动画的内容 4</div>
        </HTTab>
      </HTTabs>
    </div>

    <div class="demo-section">
      <h3 class="demo-title">滚动导航</h3>
      <p class="demo-desc">根据页面滚动位置自动切换标签</p>
      <HTTabs v-model:active="active5" scrollspy>
        <HTTab title="章节 1">
          <div class="scrollspy-content">
            <h4>章节 1</h4>
            <p>这是章节 1 的内容，滚动到此位置时标签会自动切换。</p>
            <div class="spacer"></div>
          </div>
        </HTTab>
        <HTTab title="章节 2">
          <div class="scrollspy-content">
            <h4>章节 2</h4>
            <p>这是章节 2 的内容，滚动到此位置时标签会自动切换。</p>
            <div class="spacer"></div>
          </div>
        </HTTab>
        <HTTab title="章节 3">
          <div class="scrollspy-content">
            <h4>章节 3</h4>
            <p>这是章节 3 的内容，滚动到此位置时标签会自动切换。</p>
            <div class="spacer"></div>
          </div>
        </HTTab>
      </HTTabs>
    </div>

    <div class="demo-section">
      <h3 class="demo-title">切换前确认</h3>
      <p class="demo-desc">通过 beforeChange 钩子阻止切换</p>
      <HTTabs v-model:active="active6" :before-change="beforeChange">
        <HTTab title="标签 1">
          <div class="demo-content">
            可以自由切换的内容 1
            <div class="control-panel">
              <label>
                <input v-model="allowSwitch" type="checkbox" />
                允许切换到其他标签
              </label>
            </div>
          </div>
        </HTTab>
        <HTTab title="标签 2">
          <div class="demo-content">需要确认才能切换的内容 2</div>
        </HTTab>
        <HTTab title="标签 3">
          <div class="demo-content">需要确认才能切换的内容 3</div>
        </HTTab>
      </HTTabs>
    </div>

    <div class="demo-section">
      <h3 class="demo-title">左右插槽</h3>
      <p class="demo-desc">在标签栏左侧和右侧添加自定义内容</p>
      <HTTabs v-model:active="active7">
        <template #nav-left>
          <div class="nav-extra">左侧</div>
        </template>
        <template #nav-right>
          <div class="nav-extra">右侧</div>
        </template>
        <HTTab title="标签 1">
          <div class="demo-content">带左右插槽的内容 1</div>
        </HTTab>
        <HTTab title="标签 2">
          <div class="demo-content">带左右插槽的内容 2</div>
        </HTTab>
        <HTTab title="标签 3">
          <div class="demo-content">带左右插槽的内容 3</div>
        </HTTab>
      </HTTabs>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import { HTTab, HTTabs } from '@/components/tabs';
import StickyInIframe from './StickyInIframe.vue';

const active2 = ref(0);
const active3 = ref(0);
const active4 = ref(0);
const active5 = ref(0);
const active6 = ref(0);
const active7 = ref(0);
const allowSwitch = ref(true);

const beforeChange = (name: string | number) => {
  if (!allowSwitch.value && name !== 0) {
    return false;
  }
  return true;
};
</script>

<style scoped>
.demo-tabs-advanced {
  width: 100%;
  max-width: 800px;
  margin: 0 auto;
  padding: 20px;
}

.demo-section {
  margin-bottom: 40px;
}

.demo-title {
  margin-bottom: 8px;
  font-size: 16px;
  font-weight: 500;
  color: #333;
}

.demo-desc {
  margin-bottom: 16px;
  font-size: 14px;
  color: #666;
}

.demo-content {
  padding: 20px;
  text-align: center;
  color: #666;
  background: #f9f9f9;
  border-radius: 8px;
  min-height: 100px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 14px;
}

.scrollspy-content {
  padding: 20px;
}

.scrollspy-content h4 {
  margin-bottom: 16px;
  font-size: 18px;
  font-weight: 600;
  color: #333;
}

.scrollspy-content p {
  margin-bottom: 16px;
  font-size: 14px;
  color: #666;
  line-height: 1.6;
}

.spacer {
  height: 400px;
  background: #f9f9f9;
  border-radius: 8px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #999;
  font-size: 14px;
}

.control-panel {
  margin-top: 16px;
  padding: 12px;
  background: #fff;
  border: 1px solid #e8e8e8;
  border-radius: 6px;
  font-size: 14px;
}

.control-panel label {
  display: flex;
  align-items: center;
  gap: 8px;
  cursor: pointer;
}

.control-panel input[type='checkbox'] {
  margin: 0;
}

.nav-extra {
  padding: 0 16px;
  display: flex;
  align-items: center;
  font-size: 14px;
  color: #1890ff;
  font-weight: 500;
}
</style>
