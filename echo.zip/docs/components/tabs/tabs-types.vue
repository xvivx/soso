<template>
  <div class="demo-tabs-types">
    <div class="demo-section">
      <h3 class="demo-title">线条类型（Line）</h3>
      <p class="demo-desc">默认类型，底部有指示器线条</p>
      <HTTabs v-model:active="active1" type="line">
        <HTTab title="标签 1">
          <div class="demo-content">线条类型内容 1</div>
        </HTTab>
        <HTTab title="标签 2">
          <div class="demo-content">线条类型内容 2</div>
        </HTTab>
        <HTTab title="标签 3">
          <div class="demo-content">线条类型内容 3</div>
        </HTTab>
      </HTTabs>
    </div>

    <div class="demo-section">
      <h3 class="demo-title">卡片类型（Card）</h3>
      <p class="demo-desc">卡片样式，选中标签有背景色</p>
      <HTTabs v-model:active="active2" type="card">
        <HTTab title="标签 1">
          <div class="demo-content">卡片类型内容 1</div>
        </HTTab>
        <HTTab title="标签 2">
          <div class="demo-content">卡片类型内容 2</div>
        </HTTab>
        <HTTab title="标签 3">
          <div class="demo-content">卡片类型内容 3</div>
        </HTTab>
      </HTTabs>
    </div>

    <div class="demo-section">
      <h3 class="demo-title">带边框的线条类型</h3>
      <p class="demo-desc">在 line 类型下可以显示底部边框</p>
      <HTTabs v-model:active="active3" type="line" border>
        <HTTab title="标签 1">
          <div class="demo-content">带边框内容 1</div>
        </HTTab>
        <HTTab title="标签 2">
          <div class="demo-content">带边框内容 2</div>
        </HTTab>
        <HTTab title="标签 3">
          <div class="demo-content">带边框内容 3</div>
        </HTTab>
      </HTTabs>
    </div>

    <div class="demo-section">
      <h3 class="demo-title">收缩布局</h3>
      <p class="demo-desc">在空间有限时使用收缩布局</p>
      <HTTabs v-model:active="active4" type="card" shrink>
        <HTTab title="标签 1">
          <div class="demo-content">收缩内容 1</div>
        </HTTab>
        <HTTab title="标签 2">
          <div class="demo-content">收缩内容 2</div>
        </HTTab>
        <HTTab title="标签 3">
          <div class="demo-content">收缩内容 3</div>
        </HTTab>
        <HTTab title="标签 4">
          <div class="demo-content">收缩内容 4</div>
        </HTTab>
        <HTTab title="标签 5">
          <div class="demo-content">收缩内容 5</div>
        </HTTab>
      </HTTabs>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import { HTTab, HTTabs } from '@/components/tabs';

const active1 = ref(0);
const active2 = ref(0);
const active3 = ref(0);
const active4 = ref(0);
</script>

<style scoped>
.demo-tabs-types {
  width: 100%;
  max-width: 800px;
  margin: 0 auto;
  padding: 20px;
}

.demo-section {
  margin-bottom: 40px;
}

.demo-title {
  margin-bottom: 8px;
  font-size: 16px;
  font-weight: 500;
  color: #333;
}

.demo-desc {
  margin-bottom: 16px;
  font-size: 14px;
  color: #666;
}

.demo-content {
  padding: 20px;
  text-align: center;
  color: #666;
  background: #f9f9f9;
  border-radius: 8px;
  min-height: 100px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 14px;
}
</style>
