# HTTabs 标签页

标签页组件，用于在同一内容区域切换不同场景，支持多种样式和交互方式。完全兼容 Vant Tabs API。

## 基础用法

通过 `v-model:active` 绑定当前激活的标签索引或名称。

<demo vue="./tabs-basic.vue" codesandbox="true" />

## 标签类型

支持 `line`（线条）和 `card`（卡片）两种标签类型。

<demo vue="./tabs-types.vue" codesandbox="true" />

## 功能特性

支持徽章、红点、禁用状态等功能特性。

<demo vue="./tabs-features.vue" codesandbox="true" />

## 样式定制

支持自定义颜色、指示器样式等视觉效果。

<demo vue="./tabs-style.vue" codesandbox="true" />

## 高级特性

支持粘性定位、滑动切换、动画效果等高级特性。

<demo vue="./tabs-advanced.vue" codesandbox="true" />

## 响应式和无障碍

提供响应式设计和完整的无障碍支持。

<demo vue="./tabs-responsive.vue" codesandbox="true" />

## Attributes

| Attribute | Description | Type | Default | Vant 兼容 |
| --- | --- | --- | --- | --- |
| `type` | 标签类型 | `'line' \| 'card'` | `'line'` | ✅ |
| `color` | 主题色 | `string` | `''` | ✅ |
| `border` | 是否显示边框 | `boolean` | `false` | ✅ |
| `sticky` |是否使用粘性定位 | `boolean` | `false` | ✅ |
| `shrink` | 是否收缩布局 | `boolean` | `false` | ✅ |
| `active` | 当前激活标签的名称或索引 | `string \| number` | `0` | ✅ |
| `duration` | 动画时间，单位秒 | `number \| string` | `0.3` | ✅ |
| `animated` | 是否开启切换动画 | `boolean` | `false` | ✅ |
| `ellipsis` | 是否省略过长的标题文字 | `boolean` | `true` | ✅ |
| `swipeable` | 是否开启手势滑动切换 | `boolean` | `false` | ✅ |
| `scrollspy` | 是否开启滚动导航 | `boolean` | `false` | ✅ |
| `offsetTop` | 粘性定位偏离的距离 | `number \| string` | `0` | ✅ |
| `background` | 标签栏背景色 | `string` | `''` | ✅ |
| `lazyRender` | 是否开启延迟渲染 | `boolean` | `true` | ✅ |
| `showHeader` | 是否显示标签栏 | `boolean` | `true` | ✅ |
| `lineWidth` | 指示器宽度 | `number \| string` | `40px` | ✅ |
| `lineHeight` | 指示器高度 | `number \| string` | `3px` | ✅ |
| `swipeThreshold` | 滚动阈值，标签数量超过阈值时开始横向滚动 | `number \| string` | `5` | ✅ |
| `titleActiveColor` | 标题激活态颜色 | `string` | `''` | ✅ |
| `titleInactiveColor` | 标题非激活态颜色 | `string` | `''` | ✅ |
| `beforeChange` | 切换标签前的回调函数，返回 `false` 或返回 `Promise` 且被 reject 可以阻止切换 | `(name: string \| number) => boolean \| Promise<boolean>` | - | ✅ |
| `className` | 自定义类名 | `string` | `''` | ⚠️ |

## Events

| Event | Description | Parameters | Vant 兼容 |
| --- | --- | --- | --- |
| `update:active` | 当前激活的标签改变时触发 | `name: string \| number` | ✅ |
| `change` | 当前激活的标签改变时触发 | `name: string \| number, title: string` | ✅ |
| `clickTab` | 点击标签时触发 | `{ name: string \| number, title: string, event: MouseEvent, disabled: boolean }` | ✅ |
| `scroll` | 滚动时触发（仅在 sticky 模式下） | `{ scrollTop: number, isFixed: boolean }` | ✅ |
| `rendered` | 标签内容渲染完成时触发 | `name: string \| number, title?: string` | ✅ |

## Slots

| Slot | Description | Parameters | Vant 兼容 |
| --- | --- | --- | --- |
| `default` | 标签页内容 | - | ✅ |
| `nav-left` | 标签栏左侧内容 | - | ✅ |
| `nav-right` | 标签栏右侧内容 | - | ✅ |

## Methods

通过 ref 可以获取到 Tabs 实例并调用实例方法。

| Method | Description | Parameters | Return | Vant 兼容 |
| --- | --- | --- | --- | --- |
| `resize` | 外层元素大小或组件显示状态变化时，可以调用此方法来触发重绘 | - | `void` | ✅ |
| `scrollTo` | 滚动到指定标签 | `name: string \| number` | `void` | ✅ |

## Tab 组件专用 Props

| Attribute | Description | Type | Default | Vant 兼容 |
| --- | --- | --- | --- | --- |
| `name` | 标签名称，作为匹配的标识符 | `string \| number` | - | ✅ |
| `title` | 标签标题 | `string` | `''` | ✅ |
| `disabled` | 是否禁用标签 | `boolean` | `false` | ✅ |
| `dot` | 是否显示右上角小红点 | `boolean` | `false` | ✅ |
| `badge` | 图标右上角徽标的内容 | `string \| number` | - | ✅ |
| `showZeroBadge` | 当 badge 为数字 0 时，是否显示徽标 | `boolean` | `true` | ✅ |
| `titleStyle` | 自定义标题样式 | `string \| CSSProperties` | `''` | ✅ |
| `titleClass` | 自定义标题类名 | `string` | `''` | ✅ |
| `className` | 自定义类名 | `string` | `''` | ⚠️ |

## 主题定制

基于 H5组件三级token.md 规范，支持以下 CSS Token：

```css
.ht-tabs {
  /* 标签容器 */
  --tabs-container-width-default: 100%;
  --tabs-container-height-default: auto;
  --tabs-tab-bar-height-default: 48px;
  --tabs-tab-bar-bg-color-default: #FFFFFF;
  --tabs-tab-bar-border-color-default: #EEEEEE;
  --tabs-tab-bar-border-height-default: 1px;

  /* 指示器 */
  --tabs-indicator-height-default: 3px;
  --tabs-indicator-color-default: #1677FF;
  --tabs-indicator-border-radius-default: 3px;
  --tabs-indicator-margin-default: 16px;

  /* 内容区 */
  --tabs-content-padding-default: 16px;
  --tabs-content-bg-color-default: #FFFFFF;

  /* 交互 */
  --tabs-arrow-size-default: 20px;
  --tabs-arrow-color-default: #8C8C8C;
  --tabs-transition-duration: 0.3s;
}

.ht-tab {
  /* 标签 */
  --tab-container-padding-default: 0 16px;
  --tab-container-min-width-default: 48px;
  --tab-text-font-size-default: 14px;
  --tab-text-color-default: #8C8C8C;
  --tab-text-color-active: #1677FF;
  --tab-text-font-weight-active: 500;
  --tab-text-transform-active: scale(1.1);
  --tab-badge-margin-default: 4px 0 0 4px;
  --tab-opacity-disabled: 0.5;
}
```

## Vant API 兼容性

| Vant API | HT 实现 | 说明 |
| --- | --- | --- |
| type | ✅ 完全兼容 | 支持 line、card 两种类型 |
| color | ✅ 完全兼容 | 支持任意颜色值，自动应用到指示器和文本 |
| border | ✅ 完全兼容 | 在 line 类型下显示底部边框 |
| sticky | ✅ 完全兼容 | 支持粘性定位，可设置偏移量 |
| shrink | ✅ 完全兼容 | 收缩布局，适应更多标签 |
| active | ✅ 完全兼容 | 支持数字索引和字符串名称 |
| duration | ✅ 完全兼容 | 动画持续时间，支持数字和字符串 |
| animated | ✅ 完全兼容 | 开启切换动画效果 |
| ellipsis | ✅ 完全兼容 | 标题文字省略显示 |
| swipeable | ✅ 完全兼容 | 支持手势滑动切换 |
| scrollspy | ✅ 完全兼容 | 滚动导航模式 |
| offsetTop | ✅ 完全兼容 | 粘性定位偏移距离 |
| background | ✅ 完全兼容 | 标签栏背景色 |
| lazyRender | ✅ 完全兼容 | 延迟渲染未激活标签内容 |
| showHeader | ✅ 完全兼容 | 控制标签栏显示/隐藏 |
| lineWidth | ✅ 完全兼容 | 指示器宽度自定义 |
| lineHeight | ✅ 完全兼容 | 指示器高度自定义 |
| swipeThreshold | ✅ 完全兼容 | 横向滚动阈值 |
| titleActiveColor | ✅ 完全兼容 | 激活态标题颜色 |
| titleInactiveColor | ✅ 完全兼容 | 非激活态标题颜色 |
| beforeChange | ✅ 完全兼容 | 切换前钩子函数 |
| clickTab 事件 | ✅ 完全兼容 | 点击标签事件，包含完整参数信息 |
| scroll 事件 | ✅ 完全兼容 | 滚动事件（sticky 模式） |
| rendered 事件 | ✅ 完全兼容 | 渲染完成事件 |
| nav-left 插槽 | ✅ 完全兼容 | 标签栏左侧插槽 |
| nav-right 插槽 | ✅ 完全兼容 | 标签栏右侧插槽 |
| resize 方法 | ✅ 完全兼容 | 手动触发重绘 |
| scrollTo 方法 | ✅ 完全兼容 | 滚动到指定标签 |

## 使用指南

### 基础使用

```vue
<template>
  <HTTabs v-model:active="active">
    <HTTab title="标签1">内容1</HTTab>
    <HTTab title="标签2">内容2</HTTab>
    <HTTab title="标签3">内容3</HTTab>
  </HTTabs>
</template>

<script setup lang="ts">
import { ref } from 'vue'

const active = ref(0)
</script>
```

### 配合路由使用

```vue
<template>
  <HTTabs :active="currentTab" @change="onTabChange">
    <HTTab name="home" title="首页">
      <router-view />
    </HTTab>
    <HTTab name="profile" title="个人中心">
      <router-view />
    </HTTab>
  </HTTabs>
</template>

<script setup lang="ts">
import { useRouter, useRoute } from 'vue-router'

const router = useRouter()
const route = useRoute()

const currentTab = computed(() => route.name)

const onTabChange = (name: string) => {
  router.push({ name })
}
</script>
```

### 动态标签

```vue
<template>
  <HTTabs v-model:active="active">
    <HTTab
      v-for="tab in tabs"
      :key="tab.name"
      :name="tab.name"
      :title="tab.title"
      :disabled="tab.disabled"
      :badge="tab.badge"
      :dot="tab.dot"
    >
      {{ tab.content }}
    </HTTab>
  </HTTabs>
</template>

<script setup lang="ts">
import { ref } from 'vue'

const active = ref('tab1')
const tabs = ref([
  { name: 'tab1', title: '标签1', content: '内容1', disabled: false },
  { name: 'tab2', title: '标签2', content: '内容2', badge: '5' },
  { name: 'tab3', title: '标签3', content: '内容3', dot: true, disabled: true },
])
</script>
```