<template>
  <div class="demo-tabs-basic">
    <div class="demo-section">
      <h3 class="demo-title">基础用法</h3>
      <HTTabs v-model:active="active1">
        <HTTab title="标签 1">
          <div class="demo-content">内容 1</div>
        </HTTab>
        <HTTab title="标签 2">
          <div class="demo-content">内容 2</div>
        </HTTab>
        <HTTab title="标签 3">
          <div class="demo-content">内容 3</div>
        </HTTab>
      </HTTabs>
    </div>

    <div class="demo-section">
      <h3 class="demo-title">通过名称匹配 + 收缩</h3>
      <HTTabs v-model:active="active2" shrink>
        <HTTab name="home" title="首页">
          <div class="demo-content">首页内容</div>
        </HTTab>
        <HTTab name="profile" title="个人中心">
          <div class="demo-content">个人中心内容</div>
        </HTTab>
        <HTTab name="settings" title="设置">
          <div class="demo-content">设置内容</div>
        </HTTab>
      </HTTabs>
    </div>

    <div class="demo-section">
      <h3 class="demo-title">监听切换事件</h3>
      <HTTabs v-model:active="active3" @change="onChange">
        <HTTab title="标签 1">
          <div class="demo-content">切换后会触发 change 事件</div>
        </HTTab>
        <HTTab title="标签 2">
          <div class="demo-content">当前激活标签：{{ currentTitle }}</div>
        </HTTab>
        <HTTab title="标签 3">
          <div class="demo-content">标签索引：{{ currentIndex }}</div>
        </HTTab>
      </HTTabs>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import { HTTab, HTTabs } from '@/components/tabs';

const active1 = ref(0);
const active2 = ref('home');
const active3 = ref(0);
const currentTitle = ref('标签 1');
const currentIndex = ref(0);

const onChange = (name: string | number, title: string) => {
  currentTitle.value = title;
  currentIndex.value = typeof name === 'number' ? name : 0;
  console.log('标签切换:', { name, title });
};
</script>

<style scoped>
.demo-tabs-basic {
  width: 100%;
  max-width: 800px;
  margin: 0 auto;
  padding: 20px;
}

.demo-section {
  margin-bottom: 40px;
}

.demo-title {
  margin-bottom: 16px;
  font-size: 16px;
  font-weight: 500;
  color: #333;
}

.demo-content {
  padding: 20px;
  text-align: center;
  color: #666;
  background: #f9f9f9;
  border-radius: 8px;
  min-height: 100px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 14px;
}
</style>
