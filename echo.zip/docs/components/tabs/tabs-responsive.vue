<template>
  <div class="demo-tabs-responsive">
    <div class="demo-section">
      <h3 class="demo-title">响应式标签页</h3>
      <p class="demo-desc">调整浏览器宽度查看响应式效果，标签会自动换行或滚动</p>
      <div class="responsive-demo">
        <HTTabs v-model:active="active1" :swipe-threshold="3">
          <HTTab v-for="i in 8" :key="i" :title="`标签 ${i}`">
            <div class="demo-content">响应式标签 {{ i }} 的内容</div>
          </HTTab>
        </HTTabs>
      </div>
      <div class="responsive-info">
        <p>💡 提示：调整浏览器窗口宽度，观察标签栏的响应式变化</p>
      </div>
    </div>

    <div class="demo-section">
      <h3 class="demo-title">移动端优化</h3>
      <p class="demo-desc">移动端会自动启用滚动模式，优化触摸体验</p>
      <div class="mobile-demo">
        <HTTabs v-model:active="active2" :swipe-threshold="4">
          <HTTab title="首页">
            <div class="demo-content">
              <div class="mobile-icon">🏠</div>
              首页内容 - 移动端优化
            </div>
          </HTTab>
          <HTTab title="发现">
            <div class="demo-content">
              <div class="mobile-icon">🔍</div>
              发现内容 - 移动端优化
            </div>
          </HTTab>
          <HTTab title="消息" badge="3">
            <div class="demo-content">
              <div class="mobile-icon">💬</div>
              消息内容 - 移动端优化
            </div>
          </HTTab>
          <HTTab title="我的">
            <div class="demo-content">
              <div class="mobile-icon">👤</div>
              我的页面 - 移动端优化
            </div>
          </HTTab>
          <HTTab title="设置">
            <div class="demo-content">
              <div class="mobile-icon">⚙️</div>
              设置页面 - 移动端优化
            </div>
          </HTTab>
        </HTTabs>
      </div>
    </div>

    <div class="demo-section">
      <h3 class="demo-title">无障碍支持</h3>
      <p class="demo-desc">支持键盘导航和屏幕阅读器</p>
      <div class="accessibility-demo">
        <div class="accessibility-info">
          <h4>键盘操作说明：</h4>
          <ul>
            <li><kbd>Tab</kbd> - 聚焦到标签栏</li>
            <li><kbd>←</kbd> / <kbd>→</kbd> - 在标签间切换</li>
            <li><kbd>Enter</kbd> / <kbd>Space</kbd> - 激活当前标签</li>
            <li><kbd>Home</kbd> - 跳转到第一个标签</li>
            <li><kbd>End</kbd> - 跳转到最后一个标签</li>
          </ul>
        </div>
        <HTTabs v-model:active="active3" class="accessible-tabs" @change="onAccessibleChange">
          <HTTab title="可访问标签 1" :aria-label="'第一个标签页，当前状态：' + (active3 === 0 ? '已激活' : '未激活')">
            <div class="demo-content">
              <p>这是一个支持屏幕阅读器的标签页</p>
              <p>当前标签：{{ currentTabName }}</p>
              <p>使用键盘进行导航测试</p>
            </div>
          </HTTab>
          <HTTab title="可访问标签 2" :aria-label="'第二个标签页，当前状态：' + (active3 === 1 ? '已激活' : '未激活')">
            <div class="demo-content">
              <p>屏幕阅读器会读取标签的状态</p>
              <p>包括标签名称和激活状态</p>
            </div>
          </HTTab>
          <HTTab title="可访问标签 3" :aria-label="'第三个标签页，当前状态：' + (active3 === 2 ? '已激活' : '未激活')">
            <div class="demo-content">
              <p>键盘用户可以完全通过键盘操作</p>
              <p>无需鼠标即可完成所有功能</p>
            </div>
          </HTTab>
        </HTTabs>
        <div class="screen-reader-info" role="status" aria-live="polite">
          {{ screenReaderAnnouncement }}
        </div>
      </div>
    </div>

    <div class="demo-section">
      <h3 class="demo-title">深色模式适配</h3>
      <p class="demo-desc">支持深色主题，自动适配系统主题设置</p>
      <div class="theme-demo">
        <div class="theme-controls">
          <button :class="['theme-btn', { active: theme === 'light' }]" @click="theme = 'light'">☀️ 浅色</button>
          <button :class="['theme-btn', { active: theme === 'dark' }]" @click="theme = 'dark'">🌙 深色</button>
          <button :class="['theme-btn', { active: theme === 'auto' }]" @click="theme = 'auto'">🎨 自动</button>
        </div>
        <div :class="['theme-container', theme]">
          <HTTabs v-model:active="active4" class="themed-tabs">
            <HTTab title="标签 1">
              <div class="demo-content">适配深色模式的内容 1</div>
            </HTTab>
            <HTTab title="标签 2">
              <div class="demo-content">适配深色模式的内容 2</div>
            </HTTab>
            <HTTab title="标签 3">
              <div class="demo-content">适配深色模式的内容 3</div>
            </HTTab>
          </HTTabs>
        </div>
      </div>
    </div>

    <div class="demo-section">
      <h3 class="demo-title">性能优化</h3>
      <p class="demo-desc">延迟渲染未激活的标签，提升页面性能</p>
      <div class="performance-demo">
        <HTTabs v-model:active="active5" lazy-render>
          <HTTab title="轻量标签">
            <div class="demo-content">这个标签总是很轻量</div>
          </HTTab>
          <HTTab title="重量标签">
            <div class="demo-content">
              <div class="heavy-content">
                <h5>模拟重量内容</h5>
                <div class="performance-stats">
                  <div class="stat-item">
                    <span>渲染时间:</span>
                    <strong>{{ renderTime }}ms</strong>
                  </div>
                  <div class="stat-item">
                    <span>内存使用:</span>
                    <strong>{{ memoryUsage }}MB</strong>
                  </div>
                  <div class="stat-item">
                    <span>DOM 节点:</span>
                    <strong>{{ domNodes }}</strong>
                  </div>
                </div>
                <p>这个标签包含大量内容，使用了延迟渲染优化</p>
              </div>
            </div>
          </HTTab>
          <HTTab title="图片标签">
            <div class="demo-content">
              <div class="image-gallery">
                <div v-for="i in 6" :key="i" class="image-placeholder">
                  <div class="placeholder-content">图片 {{ i }}</div>
                </div>
              </div>
            </div>
          </HTTab>
        </HTTabs>
        <div class="performance-info">
          <p>💡 只有激活的标签和相邻标签会被渲染，未激活的标签不会创建 DOM 节点</p>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { computed, ref, watch } from 'vue';
import { HTTab, HTTabs } from '@/components/tabs';

const active1 = ref(0);
const active2 = ref(0);
const active3 = ref(0);
const active4 = ref(0);
const active5 = ref(0);
const theme = ref('light');
const screenReaderAnnouncement = ref('');
const renderTime = ref(0);
const memoryUsage = ref(0);
const domNodes = ref(0);

const currentTabName = computed(() => {
  const names = ['可访问标签 1', '可访问标签 2', '可访问标签 3'];
  return names[active3.value] || '';
});

const onAccessibleChange = (name: string | number, title: string) => {
  screenReaderAnnouncement.value = `已切换到 ${title} 标签页`;
  setTimeout(() => {
    screenReaderAnnouncement.value = '';
  }, 3000);
};

// 模拟性能数据
watch(
  active5,
  (newValue) => {
    if (newValue === 1) {
      renderTime.value = Math.floor(Math.random() * 50) + 100;
      memoryUsage.value = Math.floor(Math.random() * 20) + 30;
      domNodes.value = Math.floor(Math.random() * 100) + 200;
    } else if (newValue === 2) {
      renderTime.value = Math.floor(Math.random() * 30) + 80;
      memoryUsage.value = Math.floor(Math.random() * 15) + 25;
      domNodes.value = Math.floor(Math.random() * 50) + 150;
    } else {
      renderTime.value = Math.floor(Math.random() * 10) + 5;
      memoryUsage.value = Math.floor(Math.random() * 5) + 2;
      domNodes.value = Math.floor(Math.random() * 10) + 10;
    }
  },
  { immediate: true }
);
</script>

<style scoped>
.demo-tabs-responsive {
  width: 100%;
  max-width: 800px;
  margin: 0 auto;
  padding: 20px;
}

.demo-section {
  margin-bottom: 40px;
}

.demo-title {
  margin-bottom: 8px;
  font-size: 16px;
  font-weight: 500;
  color: #333;
}

.demo-desc {
  margin-bottom: 16px;
  font-size: 14px;
  color: #666;
}

.demo-content {
  padding: 20px;
  text-align: center;
  color: #666;
  background: #f9f9f9;
  border-radius: 8px;
  min-height: 100px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  font-size: 14px;
}

.demo-content p {
  margin: 4px 0;
}

.responsive-demo {
  border: 1px dashed #d9d9d9;
  border-radius: 8px;
  padding: 16px;
  background: #fafafa;
}

.responsive-info {
  margin-top: 16px;
  padding: 12px;
  background: #e6f7ff;
  border: 1px solid #91d5ff;
  border-radius: 6px;
  font-size: 14px;
  color: #0050b3;
}

.mobile-demo {
  max-width: 400px;
  margin: 0 auto;
  border: 1px solid #e8e8e8;
  border-radius: 16px;
  overflow: hidden;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
}

.mobile-icon {
  font-size: 24px;
  margin-bottom: 8px;
}

.accessibility-demo {
  border: 2px solid #52c41a;
  border-radius: 8px;
  padding: 16px;
  background: #f6ffed;
}

.accessibility-info {
  margin-bottom: 20px;
  padding: 16px;
  background: #fff;
  border-radius: 6px;
}

.accessibility-info h4 {
  margin-bottom: 12px;
  font-size: 16px;
  color: #333;
}

.accessibility-info ul {
  margin: 0;
  padding-left: 20px;
}

.accessibility-info li {
  margin-bottom: 8px;
  font-size: 14px;
  color: #666;
}

.accessibility-info kbd {
  padding: 2px 6px;
  background: #f5f5f5;
  border: 1px solid #d9d9d9;
  border-radius: 3px;
  font-family: monospace;
  font-size: 12px;
}

.screen-reader-info {
  margin-top: 16px;
  padding: 12px;
  background: #fff;
  border: 1px solid #52c41a;
  border-radius: 6px;
  font-size: 14px;
  color: #52c41a;
  min-height: 20px;
}

.theme-demo {
  border: 1px solid #e8e8e8;
  border-radius: 8px;
  padding: 16px;
}

.theme-controls {
  display: flex;
  gap: 8px;
  margin-bottom: 16px;
  justify-content: center;
}

.theme-btn {
  padding: 8px 16px;
  border: 1px solid #d9d9d9;
  background: #fff;
  border-radius: 6px;
  cursor: pointer;
  transition: all 0.3s;
  font-size: 14px;
}

.theme-btn:hover {
  border-color: #40a9ff;
  color: #40a9ff;
}

.theme-btn.active {
  background: #1890ff;
  border-color: #1890ff;
  color: #fff;
}

.theme-container {
  border-radius: 8px;
  padding: 16px;
  transition: all 0.3s;
}

.theme-container.light {
  background: #fff;
  border: 1px solid #e8e8e8;
}

.theme-container.dark {
  background: #141414;
  border: 1px solid #434343;
}

.theme-container.dark .demo-content {
  background: #1f1f1f;
  color: #fff;
}

.theme-container.auto {
  background: #fff;
  border: 1px solid #e8e8e8;
}

@media (prefers-color-scheme: dark) {
  .theme-container.auto {
    background: #141414;
    border: 1px solid #434343;
  }

  .theme-container.auto .demo-content {
    background: #1f1f1f;
    color: #fff;
  }
}

.performance-demo {
  border: 1px solid #faad14;
  border-radius: 8px;
  padding: 16px;
  background: #fffbe6;
}

.heavy-content {
  width: 100%;
}

.performance-stats {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
  gap: 12px;
  margin: 16px 0;
}

.stat-item {
  padding: 12px;
  background: #fff;
  border: 1px solid #e8e8e8;
  border-radius: 6px;
  text-align: center;
}

.stat-item span {
  display: block;
  font-size: 12px;
  color: #666;
  margin-bottom: 4px;
}

.stat-item strong {
  font-size: 16px;
  color: #1890ff;
}

.image-gallery {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
  gap: 12px;
  width: 100%;
}

.image-placeholder {
  aspect-ratio: 1;
  background: #f0f0f0;
  border: 1px solid #e8e8e8;
  border-radius: 8px;
  display: flex;
  align-items: center;
  justify-content: center;
}

.placeholder-content {
  font-size: 12px;
  color: #999;
}

.performance-info {
  margin-top: 16px;
  padding: 12px;
  background: #fff7e6;
  border: 1px solid #ffd591;
  border-radius: 6px;
  font-size: 14px;
  color: #d46b08;
}

/* 响应式设计 */
@media (max-width: 768px) {
  .demo-tabs-responsive {
    padding: 16px;
  }

  .mobile-demo {
    max-width: 100%;
    border-radius: 0;
  }

  .theme-controls {
    flex-direction: column;
  }

  .performance-stats {
    grid-template-columns: 1fr;
  }

  .image-gallery {
    grid-template-columns: repeat(2, 1fr);
  }
}
</style>
