<template>
  <div class="demo-tabs-style">
    <div class="demo-section">
      <h3 class="demo-title">自定义主题色</h3>
      <p class="demo-desc">通过 color 属性自定义指示器和文本颜色</p>
      <HTTabs v-model:active="active1" color="#07c160">
        <HTTab title="标签 1">
          <div class="demo-content">绿色主题内容 1</div>
        </HTTab>
        <HTTab title="标签 2">
          <div class="demo-content">绿色主题内容 2</div>
        </HTTab>
        <HTTab title="标签 3">
          <div class="demo-content">绿色主题内容 3</div>
        </HTTab>
      </HTTabs>
    </div>

    <div class="demo-section">
      <h3 class="demo-title">自定义标题颜色</h3>
      <p class="demo-desc">分别设置激活态和非激活态的标题颜色</p>
      <HTTabs v-model:active="active2" color="#ee0a24" title-active-color="#ee0a24" title-inactive-color="#999">
        <HTTab title="标签 1">
          <div class="demo-content">红色主题内容 1</div>
        </HTTab>
        <HTTab title="标签 2">
          <div class="demo-content">红色主题内容 2</div>
        </HTTab>
        <HTTab title="标签 3">
          <div class="demo-content">红色主题内容 3</div>
        </HTTab>
      </HTTabs>
    </div>

    <div class="demo-section">
      <h3 class="demo-title">自定义指示器样式</h3>
      <p class="demo-desc">通过 lineWidth 和 lineHeight 自定义指示器的尺寸</p>
      <HTTabs v-model:active="active3" color="#1989fa" :line-width="60" :line-height="6">
        <HTTab title="标签 1">
          <div class="demo-content">宽指示器内容 1</div>
        </HTTab>
        <HTTab title="标签 2">
          <div class="demo-content">宽指示器内容 2</div>
        </HTTab>
        <HTTab title="标签 3">
          <div class="demo-content">宽指示器内容 3</div>
        </HTTab>
      </HTTabs>
    </div>

    <div class="demo-section">
      <h3 class="demo-title">卡片类型背景色</h3>
      <p class="demo-desc">通过 background 属性设置标签栏背景色</p>
      <HTTabs v-model:active="active4" type="card" background="#f5f5f5" color="#722ed1">
        <HTTab title="标签 1">
          <div class="demo-content">紫色卡片内容 1</div>
        </HTTab>
        <HTTab title="标签 2">
          <div class="demo-content">紫色卡片内容 2</div>
        </HTTab>
        <HTTab title="标签 3">
          <div class="demo-content">紫色卡片内容 3</div>
        </HTTab>
      </HTTabs>
    </div>

    <div class="demo-section">
      <h3 class="demo-title">圆角指示器</h3>
      <p class="demo-desc">通过 CSS 变量设置圆角指示器</p>
      <HTTabs v-model:active="active5" color="#fa8c16" :line-height="8" class="custom-rounded-tabs">
        <HTTab title="标签 1">
          <div class="demo-content">圆角指示器内容 1</div>
        </HTTab>
        <HTTab title="标签 2">
          <div class="demo-content">圆角指示器内容 2</div>
        </HTTab>
        <HTTab title="标签 3">
          <div class="demo-content">圆角指示器内容 3</div>
        </HTTab>
      </HTTabs>
    </div>

    <div class="demo-section">
      <h3 class="demo-title">渐变色主题</h3>
      <p class="demo-desc">通过 CSS 变量创建渐变色指示器</p>
      <HTTabs v-model:active="active6" class="custom-gradient-tabs">
        <HTTab title="标签 1">
          <div class="demo-content">渐变色内容 1</div>
        </HTTab>
        <HTTab title="标签 2">
          <div class="demo-content">渐变色内容 2</div>
        </HTTab>
        <HTTab title="标签 3">
          <div class="demo-content">渐变色内容 3</div>
        </HTTab>
      </HTTabs>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import { HTTab, HTTabs } from '@/components/tabs';

const active1 = ref(0);
const active2 = ref(0);
const active3 = ref(0);
const active4 = ref(0);
const active5 = ref(0);
const active6 = ref(0);
</script>

<style scoped>
.demo-tabs-style {
  width: 100%;
  max-width: 800px;
  margin: 0 auto;
  padding: 20px;
}

.demo-section {
  margin-bottom: 40px;
}

.demo-title {
  margin-bottom: 8px;
  font-size: 16px;
  font-weight: 500;
  color: #333;
}

.demo-desc {
  margin-bottom: 16px;
  font-size: 14px;
  color: #666;
}

.demo-content {
  padding: 20px;
  text-align: center;
  color: #666;
  background: #f9f9f9;
  border-radius: 8px;
  min-height: 100px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 14px;
}

/* 圆角指示器样式 */
.custom-rounded-tabs :deep(.ht-tabs__line) {
  border-radius: 4px;
}

/* 渐变色指示器样式 */
.custom-gradient-tabs :deep(.ht-tabs__line) {
  background: linear-gradient(90deg, #667eea 0%, #764ba2 100%);
  border-radius: 10px;
  height: 6px;
  width: 60px !important;
}

.custom-gradient-tabs :deep(.ht-tabs__tab--active .ht-tabs__tab-text) {
  background: linear-gradient(90deg, #667eea 0%, #764ba2 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
  font-weight: 600;
}
</style>
