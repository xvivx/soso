<template>
  <div class="sticky-iframe-demo">
    <h3 class="demo-title">粘性定位</h3>
    <p class="demo-desc">滚动时标签栏固定在顶部（iframe 隔离）</p>
    <iframe ref="iframeRef" class="sticky-demo-iframe" srcdoc="" frameborder="0" scrolling="no" @load="onIframeLoad" />
  </div>
</template>

<script setup lang="ts">
import { onMounted, ref } from 'vue';

const iframeRef = ref<HTMLIFrameElement>();

// 生成 iframe 内容
const getIframeContent = () => {
  return `<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Sticky Tabs Demo</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background: #fafafa; padding: 16px; }
    .app-container { width: 100%; max-width: 400px; margin: 0 auto; }
    .scroll-container { height: 280px; overflow: auto; border: 1px solid #e8e8e8; border-radius: 8px; background: #fafafa; }
    .scroll-content { padding: 0; }
    .ht-tabs { position: relative; background: #fff; }
    .ht-tabs__wrap { position: relative; overflow: hidden; }
    .ht-tabs__wrap--border { border-bottom: 1px solid #e8e8e8; }
    .ht-tabs__nav { position: relative; display: flex; background: #fff; user-select: none; white-space: nowrap; overflow-x: auto; overflow-y: hidden; scrollbar-width: none; }
    .ht-tabs__nav::-webkit-scrollbar { display: none; }
    .ht-tabs__tab { flex: 1; padding: 0 16px; height: 44px; line-height: 44px; text-align: center; cursor: pointer; color: #646566; font-size: 14px; background: #fff; border: none; outline: none; -webkit-appearance: none; -webkit-tap-highlight-color: transparent; transition: color 0.3s; }
    .ht-tabs__tab.active { color: #1989fa; font-weight: 500; }
    .ht-tabs__tab-text { display: inline-block; vertical-align: middle; }
    .ht-tabs__line { position: absolute; bottom: 0; left: 0; z-index: 1; height: 3px; background-color: #1989fa; border-radius: 3px; transition: transform 0.3s cubic-bezier(0.645, 0.045, 0.355, 1), width 0.3s cubic-bezier(0.645, 0.045, 0.355, 1); }
    .ht-tabs__content { overflow: hidden; background: #fff; }
    .ht-tabs__panel { display: none; }
    .ht-tabs__panel.active { display: block; }
    .sticky { position: relative; }
    .sticky-placeholder { width: 100%; }
    .tall-content { height: 600px; padding: 20px; display: flex; align-items: center; justify-content: center; color: #666; font-size: 14px; background: linear-gradient(180deg, #f9f9f9 0%, #e6e6e6 100%); }
  </style>
</head>
<body>
  <div id="app">
    <div class="app-container">
      <div class="scroll-container" id="scrollContainer">
        <div class="scroll-content">
          <div class="ht-tabs" id="tabsContainer">
            <div class="ht-tabs__wrap ht-tabs__wrap--border">
              <div class="sticky" id="stickyElement">
                <div class="ht-tabs__nav" id="navElement">
                  <div class="ht-tabs__tab active" data-index="0">
                    <span class="ht-tabs__tab-text">标签 1</span>
                  </div>
                  <div class="ht-tabs__tab" data-index="1">
                    <span class="ht-tabs__tab-text">标签 2</span>
                  </div>
                  <div class="ht-tabs__tab" data-index="2">
                    <span class="ht-tabs__tab-text">标签 3</span>
                  </div>
                  <div class="ht-tabs__line" id="lineElement"></div>
                </div>
              </div>
            </div>
            <div class="ht-tabs__content" id="contentElement">
              <div class="ht-tabs__panel active" data-panel="0">
                <div class="tall-content">向下滚动查看粘性效果 - 内容 1</div>
              </div>
              <div class="ht-tabs__panel" data-panel="1">
                <div class="tall-content">向下滚动查看粘性效果 - 内容 2</div>
              </div>
              <div class="ht-tabs__panel" data-panel="2">
                <div class="tall-content">向下滚动查看粘性效果 - 内容 3</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <script>
    const stickyElement = document.getElementById('stickyElement');
    const scrollContainer = document.getElementById('scrollContainer');
    const navElement = document.getElementById('navElement');
    const lineElement = document.getElementById('lineElement');
    const contentElement = document.getElementById('contentElement');
    const tabs = document.querySelectorAll('.ht-tabs__tab');
    const panels = document.querySelectorAll('.ht-tabs__panel');
    let currentIndex = 0;
    let isFixed = false;

    function updateSticky() {
      if (!stickyElement || !scrollContainer) return;
      const containerRect = scrollContainer.getBoundingClientRect();
      const stickyRect = stickyElement.getBoundingClientRect();
      const offsetTop = 50;
      const shouldBeFixed = stickyRect.top <= offsetTop;

      if (shouldBeFixed !== isFixed) {
        isFixed = shouldBeFixed;
        if (isFixed) {
          const placeholder = document.createElement('div');
          placeholder.className = 'sticky-placeholder';
          placeholder.style.height = stickyElement.offsetHeight + 'px';
          stickyElement.parentNode.insertBefore(placeholder, stickyElement);
          stickyElement.style.position = 'fixed';
          stickyElement.style.top = offsetTop + 'px';
          stickyElement.style.left = stickyRect.left + 'px';
          stickyElement.style.width = stickyRect.width + 'px';
          stickyElement.style.zIndex = '99';
        } else {
          const placeholder = document.querySelector('.sticky-placeholder');
          if (placeholder) placeholder.remove();
          stickyElement.style.position = '';
          stickyElement.style.top = '';
          stickyElement.style.left = '';
          stickyElement.style.width = '';
          stickyElement.style.zIndex = '';
        }
      }
    }

    function switchTab(index) {
      if (index === currentIndex) return;
      tabs[currentIndex].classList.remove('active');
      panels[currentIndex].classList.remove('active');
      currentIndex = index;
      tabs[currentIndex].classList.add('active');
      panels[currentIndex].classList.add('active');
      updateLine();
    }

    function updateLine() {
      if (!lineElement || !tabs[currentIndex]) return;
      const activeTab = tabs[currentIndex];
      const left = activeTab.offsetLeft + activeTab.offsetWidth / 2;
      lineElement.style.width = '40px';
      lineElement.style.backgroundColor = '#1989fa';
      lineElement.style.transform = 'translateX(' + left + 'px) translateX(-50%)';
      lineElement.style.transition = 'all 0.3s cubic-bezier(0.645, 0.045, 0.355, 1)';
    }

    tabs.forEach((tab, index) => {
      tab.addEventListener('click', () => switchTab(index));
    });

    scrollContainer.addEventListener('scroll', updateSticky);
    window.addEventListener('resize', updateSticky);
    updateLine();
    updateSticky();
  <\/script>
</body>
</html>`;
};

// iframe 加载完成后的处理
const onIframeLoad = () => {
  if (iframeRef.value) {
    try {
      const iframeDoc = iframeRef.value.contentDocument || iframeRef.value.contentWindow?.document;
      if (iframeDoc) {
        const body = iframeDoc.body;
        const html = iframeDoc.documentElement;
        const height = Math.max(
          body.scrollHeight,
          body.offsetHeight,
          html.clientHeight,
          html.scrollHeight,
          html.offsetHeight
        );
        iframeRef.value.style.height = height + 20 + 'px';
      }
    } catch (error) {
      console.warn('无法调整 iframe 高度:', error);
      iframeRef.value.style.height = '320px';
    }
  }
};

// 设置 iframe 内容
onMounted(() => {
  if (iframeRef.value) {
    iframeRef.value.srcdoc = getIframeContent();
  }
});
</script>

<style scoped>
.sticky-iframe-demo {
  width: 100%;
}

.demo-title {
  margin-bottom: 8px;
  font-size: 16px;
  font-weight: 500;
  color: #333;
}

.demo-desc {
  margin-bottom: 16px;
  font-size: 14px;
  color: #666;
}

.sticky-demo-iframe {
  width: 100%;
  border: 1px solid #e8e8e8;
  border-radius: 8px;
  background: #fff;
  min-height: 320px;
  transition: height 0.3s ease;
}
</style>
