<template>
  <div class="demo-tabs-features">
    <div class="demo-section">
      <h3 class="demo-title">徽章提示</h3>
      <p class="demo-desc">通过 badge 属性显示数字徽章</p>
      <HTTabs v-model:active="active1">
        <HTTab title="标签 1">
          <div class="demo-content">普通标签</div>
        </HTTab>
        <HTTab title="消息" badge="5">
          <div class="demo-content">带数字徽章的标签</div>
        </HTTab>
        <HTTab title="通知" badge="99+">
          <div class="demo-content">带大数字徽章的标签</div>
        </HTTab>
        <HTTab title="邮件" badge="新">
          <div class="demo-content">带文本徽章的标签</div>
        </HTTab>
      </HTTabs>
    </div>

    <div class="demo-section">
      <h3 class="demo-title">红点提示</h3>
      <p class="demo-desc">通过 dot 属性显示小红点</p>
      <HTTabs v-model:active="active2">
        <HTTab title="标签 1">
          <div class="demo-content">普通标签</div>
        </HTTab>
        <HTTab title="标签 2" dot>
          <div class="demo-content">带红点的标签</div>
        </HTTab>
        <HTTab title="标签 3">
          <div class="demo-content">普通标签</div>
        </HTTab>
        <HTTab title="标签 4" dot>
          <div class="demo-content">另一个带红点的标签</div>
        </HTTab>
      </HTTabs>
    </div>

    <div class="demo-section">
      <h3 class="demo-title">禁用标签</h3>
      <p class="demo-desc">通过 disabled 属性禁用某个标签</p>
      <HTTabs v-model:active="active3">
        <HTTab title="标签 1">
          <div class="demo-content">可用标签</div>
        </HTTab>
        <HTTab title="标签 2" disabled>
          <div class="demo-content">禁用的标签（无法点击）</div>
        </HTTab>
        <HTTab title="标签 3">
          <div class="demo-content">可用标签</div>
        </HTTab>
        <HTTab title="标签 4" disabled>
          <div class="demo-content">另一个禁用的标签</div>
        </HTTab>
      </HTTabs>
    </div>

    <div class="demo-section">
      <h3 class="demo-title">点击事件监听</h3>
      <p class="demo-desc">监听标签点击事件，包含详细信息</p>
      <HTTabs v-model:active="active4" @click-tab="onClickTab">
        <HTTab title="普通标签">
          <div class="demo-content">点击标签查看事件信息</div>
        </HTTab>
        <HTTab title="禁用标签" disabled>
          <div class="demo-content">禁用标签也会触发点击事件</div>
        </HTTab>
        <HTTab title="徽章标签" badge="3">
          <div class="demo-content">带徽章的标签</div>
        </HTTab>
        <HTTab title="红点标签" dot>
          <div class="demo-content">带红点的标签</div>
        </HTTab>
      </HTTabs>
      <div class="event-info"><strong>最后点击的标签：</strong>{{ eventInfo }}</div>
    </div>

    <div class="demo-section">
      <h3 class="demo-title">隐藏标题栏</h3>
      <p class="demo-desc">通过 showHeader=false 隐藏标签栏，通过编程方式切换</p>
      <div class="controls">
        <button
          v-for="tab in tabs"
          :key="tab.name"
          :class="['control-btn', { active: active5 === tab.name }]"
          @click="active5 = tab.name"
        >
          {{ tab.title }}
        </button>
      </div>
      <HTTabs v-model:active="active5" :show-header="false">
        <HTTab v-for="tab in tabs" :key="tab.name" :name="tab.name" :title="tab.title">
          <div class="demo-content">{{ tab.content }}</div>
        </HTTab>
      </HTTabs>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import { HTTab, HTTabs } from '@/components/tabs';

const active1 = ref(0);
const active2 = ref(0);
const active3 = ref(0);
const active4 = ref(0);
const active5 = ref('tab1');
const eventInfo = ref('点击标签查看事件信息');

const tabs = ref([
  { name: 'tab1', title: '标签 1', content: '通过编程方式切换的内容 1' },
  { name: 'tab2', title: '标签 2', content: '通过编程方式切换的内容 2' },
  { name: 'tab3', title: '标签 3', content: '通过编程方式切换的内容 3' },
]);

const onClickTab = (params: { name: string | number; title: string; event: MouseEvent; disabled: boolean }) => {
  eventInfo.value = `标题: ${params.title}, 名称: ${params.name}, 禁用: ${params.disabled}`;
  console.log('标签点击事件:', params);
};
</script>

<style scoped>
.demo-tabs-features {
  width: 100%;
  max-width: 800px;
  margin: 0 auto;
  padding: 20px;
}

.demo-section {
  margin-bottom: 40px;
}

.demo-title {
  margin-bottom: 8px;
  font-size: 16px;
  font-weight: 500;
  color: #333;
}

.demo-desc {
  margin-bottom: 16px;
  font-size: 14px;
  color: #666;
}

.demo-content {
  padding: 20px;
  text-align: center;
  color: #666;
  background: #f9f9f9;
  border-radius: 8px;
  min-height: 100px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 14px;
}

.event-info {
  margin-top: 16px;
  padding: 12px;
  background: #e6f7ff;
  border: 1px solid #91d5ff;
  border-radius: 6px;
  font-size: 14px;
  color: #0050b3;
}

.controls {
  display: flex;
  gap: 8px;
  margin-bottom: 16px;
  flex-wrap: wrap;
}

.control-btn {
  padding: 8px 16px;
  border: 1px solid #d9d9d9;
  background: #fff;
  border-radius: 6px;
  cursor: pointer;
  transition: all 0.3s;
  font-size: 14px;
}

.control-btn:hover {
  border-color: #40a9ff;
  color: #40a9ff;
}

.control-btn.active {
  background: #1890ff;
  border-color: #1890ff;
  color: #fff;
}
</style>
