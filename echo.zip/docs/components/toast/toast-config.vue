<template>
  <div class="demo-toast">
    <div class="demo-section">
      <h3>全局配置</h3>
      <div class="demo-buttons">
        <button @click="setGlobalConfig" class="demo-button">设置全局配置</button>
        <button @click="showWithGlobalConfig" class="demo-button">使用全局配置</button>
        <button @click="resetGlobalConfig" class="demo-button">重置全局配置</button>
        <button @click="showAfterReset" class="demo-button">重置后显示</button>
      </div>
    </div>

    <div class="demo-section">
      <h3>当前配置</h3>
      <div class="demo-config">
        <pre>{{ currentConfig }}</pre>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import { Toast } from '@hytech/ht-ui';

const currentConfig = ref({
  position: 'middle',
  duration: 2000,
  overlay: false,
  className: '',
});

function setGlobalConfig() {
  const config = {
    position: 'top' as const,
    duration: 10000,
    overlay: true,
    className: 'custom-toast',
  };

  Toast.setDefaultOptions(config);
  currentConfig.value = config;

  Toast.success('全局配置已设置');
}

function showWithGlobalConfig() {
  Toast.text('使用全局配置的提示');
}

function resetGlobalConfig() {
  Toast.resetDefaultOptions();
  currentConfig.value = {
    position: 'middle',
    duration: 2000,
    overlay: false,
    className: '',
  };

  Toast.success('全局配置已重置');
}

function showAfterReset() {
  Toast.text('重置后的提示');
}
</script>

<style scoped>
.demo-toast {
  width: 100%;
  max-width: 600px;
  margin: 0 auto;
  padding: 16px;
  background: var(--color-surface-primary);
  border-radius: var(--dimensions-radius-sm);
}

.demo-section {
  margin-bottom: 24px;
}

.demo-section:last-child {
  margin-bottom: 0;
}

.demo-section h3 {
  margin: 0 0 12px 0;
  font-size: 16px;
  font-weight: 600;
  color: var(--color-content-primary);
}

.demo-buttons {
  display: flex;
  flex-wrap: wrap;
  gap: 12px;
}

.demo-button {
  padding: 8px 16px;
  border: 1px solid var(--color-border-primary);
  border-radius: var(--dimensions-radius-xs);
  background: var(--color-surface-secondary);
  color: var(--color-text-primary);
  font-size: 14px;
  cursor: pointer;
  transition: all 0.2s ease;
}

.demo-button:hover {
  background: var(--color-surface-tertiary);
  border-color: var(--color-border-secondary);
}

.demo-button:active {
  transform: translateY(1px);
}

.demo-config {
  padding: 12px;
  background: var(--color-surface-secondary);
  border: 1px solid var(--color-border-default);
  border-radius: var(--dimensions-radius-xs);
  font-family: 'Monaco', 'Menlo', 'Ubuntu Mono', monospace;
}

.demo-config pre {
  margin: 0;
  font-size: 12px;
  color: var(--color-content-primary);
  white-space: pre-wrap;
  word-break: break-word;
}
</style>
