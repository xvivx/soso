<template>
  <div class="demo-toast">
    <div class="demo-section">
      <h3>手动控制</h3>
      <div class="demo-buttons">
        <button @click="showManualToast" class="demo-button">显示手动 Toast</button>
        <button @click="closeManualToast" class="demo-button" :disabled="!currentToast">手动关闭</button>
        <button @click="showWithCallback" class="demo-button">带回调的 Toast</button>
      </div>
    </div>

    <div class="demo-section">
      <h3>组件式用法</h3>
      <div class="demo-buttons">
        <button @click="toggleComponentToast" class="demo-button">
          {{ showComponent ? '隐藏' : '显示' }} 组件 Toast
        </button>
      </div>

      <!-- 组件式 Toast -->
      <HTToast
        v-model="showComponent"
        type="success"
        message="这是组件式 Toast"
        :duration="0"
        @opened="onToastOpened"
        @close="onToastClose"
      />
    </div>

    <div class="demo-section">
      <h3>事件日志</h3>
      <div class="demo-log">
        <div v-for="(log, index) in logs" :key="index" class="log-item">
          <span class="log-time">{{ log.time }}</span>
          <span class="log-message">{{ log.message }}</span>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import { HTToast, Toast } from '@hytech/ht-ui';

const currentToast = ref<any>(null);
const showComponent = ref(false);
const logs = ref<Array<{ time: string; message: string }>>([]);

function addLog(message: string) {
  const time = new Date().toLocaleTimeString();
  logs.value.unshift({ time, message });

  // 只保留最近 10 条日志
  if (logs.value.length > 10) {
    logs.value = logs.value.slice(0, 10);
  }
}

function showManualToast() {
  if (currentToast.value) {
    currentToast.value.close();
  }

  currentToast.value = Toast.text('手动控制的 Toast', {
    duration: 0, // 不自动关闭
    onOpened: () => {
      addLog('Toast 已显示');
    },
    onClose: () => {
      addLog('Toast 已关闭');
      currentToast.value = null;
    },
  });
}

function closeManualToast() {
  if (currentToast.value) {
    currentToast.value.close();
  }
}

function showWithCallback() {
  Toast.loading('处理中...', {
    onOpened: () => {
      addLog('加载 Toast 已显示');
    },
    onClose: () => {
      addLog('加载 Toast 已关闭');
    },
  });

  // 模拟异步操作
  setTimeout(() => {
    Toast.success('操作完成', {
      onOpened: () => {
        addLog('成功 Toast 已显示');
      },
      onClose: () => {
        addLog('成功 Toast 已关闭');
      },
    });
  }, 2000);
}

function toggleComponentToast() {
  showComponent.value = !showComponent.value;
}

function onToastOpened() {
  addLog('组件 Toast 已显示');
}

function onToastClose() {
  addLog('组件 Toast 已关闭');
  showComponent.value = false;
}
</script>

<style scoped>
.demo-toast {
  width: 100%;
  max-width: 600px;
  margin: 0 auto;
  padding: 16px;
  background: var(--color-surface-primary);
  border-radius: var(--dimensions-radius-sm);
}

.demo-section {
  margin-bottom: 24px;
}

.demo-section:last-child {
  margin-bottom: 0;
}

.demo-section h3 {
  margin: 0 0 12px 0;
  font-size: 16px;
  font-weight: 600;
  color: var(--color-content-primary);
}

.demo-buttons {
  display: flex;
  flex-wrap: wrap;
  gap: 12px;
}

.demo-button {
  padding: 8px 16px;
  border: 1px solid var(--color-border-default);
  border-radius: var(--dimensions-radius-xs);
  background: var(--color-surface-secondary);
  color: var(--color-content-primary);
  font-size: 14px;
  cursor: pointer;
  transition: all 0.2s ease;
}

.demo-button:hover:not(:disabled) {
  background: var(--color-surface-tertiary);
  border-color: var(--color-border-secondary);
}

.demo-button:active:not(:disabled) {
  transform: translateY(1px);
}

.demo-button:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.demo-log {
  max-height: 200px;
  overflow-y: auto;
  padding: 12px;
  background: var(--color-surface-secondary);
  border: 1px solid var(--color-border-default);
  border-radius: var(--dimensions-radius-xs);
  font-family: 'Monaco', 'Menlo', 'Ubuntu Mono', monospace;
}

.log-item {
  display: flex;
  gap: 12px;
  margin-bottom: 4px;
  font-size: 12px;
}

.log-item:last-child {
  margin-bottom: 0;
}

.log-time {
  color: var(--color-text-tertiary);
  flex-shrink: 0;
}

.log-message {
  color: var(--color-text-secondary);
}
</style>
