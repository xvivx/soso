<template>
  <div class="demo-toast">
    <div class="demo-section">
      <h3>基础用法</h3>
      <div class="demo-buttons">
        <button @click="showText" class="demo-button">文本提示</button>
        <button @click="showLongText" class="demo-button">长文本提示</button>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { Toast } from '@hytech/ht-ui';

function showText() {
  Toast({
    message: '这是一条提示信息',
    duration: 3000,
  });
}

function showLongText() {
  Toast({
    message: '这是一条很长很长很长很长很长很长很长很长的提示信息，用于测试文本换行效果和动态间距调整',
    duration: 4000,
  });
}
</script>

<style scoped>
.demo-toast {
  width: 100%;
  max-width: 600px;
  margin: 0 auto;
  padding: 16px;
  background: var(--color-surface-primary);
  border-radius: var(--dimensions-radius-sm);
}

.demo-section {
  margin-bottom: 24px;
}

.demo-section:last-child {
  margin-bottom: 0;
}

.demo-section h3 {
  margin: 0 0 12px 0;
  font-size: 16px;
  font-weight: 600;
  color: var(--color-content-primary);
}

.demo-buttons {
  display: flex;
  flex-wrap: wrap;
  gap: 12px;
}

.demo-button {
  padding: 8px 16px;
  border: 1px solid var(--color-border-default);
  border-radius: var(--dimensions-radius-xs);
  background: var(--color-surface-secondary);
  color: var(--color-content-primary);
  font-size: 14px;
  cursor: pointer;
  transition: all 0.2s ease;
}

.demo-button:hover {
  background: var(--color-surface-tertiary);
  border-color: var(--color-border-secondary);
}

.demo-button:active {
  transform: translateY(1px);
}
</style>
