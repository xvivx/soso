<template>
  <div class="demo-toast">
    <div class="demo-section">
      <h3>自定义图标</h3>
      <div class="demo-buttons">
        <button @click="showWithIcon" class="demo-button">自定义图标</button>
        <button @click="showWithImage" class="demo-button">自定义图片</button>
        <button @click="showWithoutIcon" class="demo-button">无图标</button>
        <button @click="showMixedContent" class="demo-button">混合内容测试</button>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { Toast } from '@hytech/ht-ui';

function showWithIcon() {
  Toast.text('自定义图标提示', {
    icon: 'star',
    iconSize: 24,
  });
}

function showWithImage() {
  Toast.text('自定义图片提示', {
    image:
      'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjQiIGhlaWdodD0iMjQiIHZpZXdCb3g9IjAgMCAyNCAyNCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHBhdGggZD0iTTEyIDJMMTMuMDkgOC4yNkwyMSA5TDEzLjA5IDE1Ljc0TDEyIDIyTDEwLjkxIDE1Ljc0TDMgOUwxMC45MSA4LjI2TDEyIDJaIiBmaWxsPSIjRkZENzAwIi8+Cjwvc3ZnPgo=',
  });
}

function showWithoutIcon() {
  Toast.success('无图标成功提示', {
    icon: '',
  });
}

function showMixedContent() {
  // 显示不同高度的 Toast 来测试间距效果
  Toast.text('带图标的短文本', {
    icon: 'star',
    iconSize: 24,
  });

  setTimeout(() => {
    Toast.success('这是一条带有自定义图片的较长文本提示，用于测试图片内容对 Toast 高度和间距的影响', {
      image:
        'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjQiIGhlaWdodD0iMjQiIHZpZXdCb3g9IjAgMCAyNCAyNCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHBhdGggZD0iTTEyIDJMMTMuMDkgOC4yNkwyMSA5TDEzLjA5IDE1Ljc0TDEyIDIyTDEwLjkxIDE1Ljc0TDMgOUwxMC45MSA4LjI2TDEyIDJaIiBmaWxsPSIjRkZENzAwIi8+Cjwvc3ZnPgo=',
    });
  }, 400);

  setTimeout(() => {
    Toast.fail('无图标的失败提示', {
      icon: '',
    });
  }, 800);
}
</script>

<style scoped>
.demo-toast {
  width: 100%;
  max-width: 600px;
  margin: 0 auto;
  padding: 16px;
  background: var(--color-surface-primary);
  border-radius: var(--dimensions-radius-sm);
}

.demo-section {
  margin-bottom: 24px;
}

.demo-section:last-child {
  margin-bottom: 0;
}

.demo-section h3 {
  margin: 0 0 12px 0;
  font-size: 16px;
  font-weight: 600;
  color: var(--color-content-primary);
}

.demo-buttons {
  display: flex;
  flex-wrap: wrap;
  gap: 12px;
}

.demo-button {
  padding: 8px 16px;
  border: 1px solid var(--color-border-default);
  border-radius: var(--dimensions-radius-xs);
  background: var(--color-surface-secondary);
  color: var(--color-content-primary);
  font-size: 14px;
  cursor: pointer;
  transition: all 0.2s ease;
}

.demo-button:hover {
  background: var(--color-surface-tertiary);
  border-color: var(--color-border-secondary);
}

.demo-button:active {
  transform: translateY(1px);
}
</style>
