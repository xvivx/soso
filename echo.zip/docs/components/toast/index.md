# HTToast 轻提示

在页面中间弹出黑色半透明提示，用于消息通知、加载提示、操作结果反馈等场景。

## 基础用法

<demo vue="./toast-basic.vue" codesandbox="true" />

## 不同类型

<demo vue="./toast-types.vue" codesandbox="true" />

## 自定义位置

<demo vue="./toast-position.vue" codesandbox="true" />

## 加载状态

<demo vue="./toast-loading.vue" codesandbox="true" />

## 自定义图标

<demo vue="./toast-icon.vue" codesandbox="true" />

## HTML 内容

<demo vue="./toast-html.vue" codesandbox="true" />

## 遮罩层

<demo vue="./toast-overlay.vue" codesandbox="true" />

## 全局配置

<demo vue="./toast-config.vue" codesandbox="true" />

## 多个 Toast

<demo vue="./toast-multiple.vue" codesandbox="true" />

## 手动控制

<demo vue="./toast-manual.vue" codesandbox="true" />

## API

### Toast 方法

| 方法 | 说明 | 参数 | 返回值 | 与 Vant 差异 |
| --- | --- | --- | --- | --- |
| `Toast(options)` | 显示 Toast | `string \| ToastOptions` | `ToastInstance` | ✅ 兼容 |
| `Toast.text(message, options?)` | 显示文本 Toast | `string, ToastOptions?` | `ToastInstance` | ✅ 兼容 |
| `Toast.loading(message?, options?)` | 显示加载 Toast | `string?, ToastOptions?` | `ToastInstance` | ✅ 兼容 |
| `Toast.success(message, options?)` | 显示成功 Toast | `string, ToastOptions?` | `ToastInstance` | ✅ 兼容 |
| `Toast.fail(message, options?)` | 显示失败 Toast | `string, ToastOptions?` | `ToastInstance` | ✅ 兼容 |
| `Toast.html(html, options?)` | 显示 HTML Toast | `string, ToastOptions?` | `ToastInstance` | ✅ 兼容 |
| `Toast.clear(all?)` | 清除 Toast | `boolean?` | `void` | ✅ 兼容 |
| `Toast.setDefaultOptions(options)` | 设置默认配置 | `ToastOptions` | `void` | ✅ 兼容 |
| `Toast.resetDefaultOptions()` | 重置默认配置 | - | `void` | ✅ 兼容 |
| `Toast.allowMultiple(allow?)` | 允许多个 Toast | `boolean?` | `void` | ✅ 兼容 |

### ToastOptions

| 参数 | 说明 | 类型 | 默认值 | 与 Vant 差异 |
| --- | --- | --- | --- | --- |
| `type` | Toast 类型 | `'text' \| 'loading' \| 'success' \| 'fail' \| 'html'` | `'text'` | ✅ 兼容 |
| `message` | 文本内容 | `string` | `''` | ✅ 兼容 |
| `position` | 显示位置 | `'top' \| 'middle' \| 'bottom'` | `'middle'` | ✅ 兼容 |
| `duration` | 显示时长(ms)，0 表示不自动关闭 | `number` | `2000` | ✅ 兼容 |
| `icon` | 自定义图标 | `string` | - | ✅ 兼容 |
| `iconPrefix` | 图标类名前缀 | `string` | `'van-icon'` | ✅ 兼容 |
| `iconSize` | 图标大小 | `number \| string` | - | ✅ 兼容 |
| `image` | 自定义图片 | `string` | - | ✅ 兼容 |
| `loadingType` | 加载图标类型 | `'circular' \| 'spinner'` | `'circular'` | ✅ 兼容 |
| `forbidClick` | 是否禁止点击 | `boolean` | `false` | ✅ 兼容 |
| `closeOnClick` | 是否在点击后关闭 | `boolean` | `false` | ✅ 兼容 |
| `closeOnClickOverlay` | 是否在点击遮罩层后关闭 | `boolean` | `false` | ✅ 兼容 |
| `overlay` | 是否显示遮罩层 | `boolean` | `false` | ✅ 兼容 |
| `overlayClass` | 遮罩层类名 | `string` | - | ✅ 兼容 |
| `overlayStyle` | 遮罩层样式 | `Record<string, any>` | - | ✅ 兼容 |
| `className` | 自定义类名 | `string` | - | ✅ 兼容 |
| `wordBreak` | 文本换行方式 | `'break-all' \| 'break-word' \| 'normal'` | `'break-all'` | ✅ 兼容 |
| `transition` | 动画类名 | `string` | - | ✅ 兼容 |
| `teleport` | 指定挂载的节点 | `string \| Element` | - | ✅ 兼容 |
| `zIndex` | 层级 | `number` | `2000` | ✅ 兼容 |
| `onOpened` | 完全展示后的回调函数 | `() => void` | - | ✅ 兼容 |
| `onClose` | 关闭时的回调函数 | `() => void` | - | ✅ 兼容 |
| `variant` | 样式变体 | `'default' \| 'destructive' \| 'success' \| 'warning'` | `'default'` | ✨ HTToast 独有 |
| `as` | 根元素标签 | `string \| object` | - | ✨ HTToast 独有 |
| `asChild` | 作为子元素渲染 | `boolean` | `false` | ✨ HTToast 独有 |

### ToastInstance

| 方法 | 说明 | 参数 | 返回值 | 与 Vant 差异 |
| --- | --- | --- | --- | --- |
| `close()` | 关闭当前 Toast | - | `void` | ✅ 兼容 |
| `clear()` | 清除所有 Toast | - | `void` | ✅ 兼容 |

### HTToast 组件 Props

| 参数 | 说明 | 类型 | 默认值 | 与 Vant 差异 |
| --- | --- | --- | --- | --- |
| `modelValue` | 是否显示 | `boolean` | `false` | ✨ HTToast 独有 |
| `visible` | 是否显示（兼容属性） | `boolean` | `false` | ✨ HTToast 独有 |
| 其他属性 | 继承 ToastOptions 所有属性 | - | - | - |

### HTToast 组件 Events

| 事件 | 说明 | 参数 | 与 Vant 差异 |
| --- | --- | --- | --- |
| `update:modelValue` | 显示状态改变 | `(value: boolean)` | ✨ HTToast 独有 |
| `update:visible` | 显示状态改变（兼容事件） | `(value: boolean)` | ✨ HTToast 独有 |
| `opened` | 完全展示后触发 | - | ✅ 兼容 |
| `close` | 关闭时触发 | - | ✅ 兼容 |

### ToastProvider 组件 Props

| 参数 | 说明 | 类型 | 默认值 | 与 Vant 差异 |
| --- | --- | --- | --- | --- |
| `duration` | 默认显示时长 | `number` | `2000` | ✨ HTToast 独有 |
| `position` | 默认显示位置 | `'top' \| 'middle' \| 'bottom'` | `'middle'` | ✨ HTToast 独有 |
| `className` | 容器类名 | `string` | - | ✨ HTToast 独有 |
| `disableSwipe` | 禁用滑动关闭 | `boolean` | `false` | ✨ HTToast 独有 |
| `swipeDirection` | 滑动方向 | `'right' \| 'left' \| 'up' \| 'down'` | `'right'` | ✨ HTToast 独有 |
| `swipeThreshold` | 滑动阈值 | `number` | - | ✨ HTToast 独有 |
| `label` | 无障碍标签 | `string` | `'Notification'` | ✨ HTToast 独有 |

## 样式定制

### CSS 变量

HTToast 提供了丰富的 CSS 变量用于样式定制：

```css
:root {
  /* 基础样式 */
  --toast-max-width: 70%;
  --toast-min-height: 44px;
  --toast-padding: 8px 12px;
  --toast-font-size: 14px;
  --toast-line-height: 20px;
  --toast-border-radius: 8px;
  --toast-background: rgba(0, 0, 0, 0.8);
  --toast-text-color: #ffffff;
  --toast-icon-size: 20px;
  --toast-loading-icon-color: #ffffff;
  --toast-z-index: 2000;
  
  /* 主题色 */
  --toast-success-color: #07c160;
  --toast-fail-color: #ee0a24;
  --toast-warning-color: #ff976a;
  --toast-info-color: #1989fa;
  
  /* 位置 */
  --toast-viewport-padding: 16px;
  --toast-viewport-gap: 8px;
  --toast-viewport-z-index: 2000;
  
  /* 遮罩层 */
  --toast-overlay-background: rgba(0, 0, 0, 0.7);
}
```

## 与 Vant 的差异

### API 对比

| 功能 | HTToast | Vant Toast | 差异说明 |
|------|---------|------------|----------|
| **基础调用** | `Toast.text('消息')` | `Toast('消息')` | HTToast 提供更明确的方法名 |
| **HTML 内容** | `Toast.html('<b>粗体</b>')` | `Toast({ type: 'html', message: '<b>粗体</b>' })` | HTToast 提供独立方法，更简洁 |
| **图标支持** | 支持 HTIcon 名称和 URL | 支持 Icon 名称和 URL | HTToast 集成自定义图标组件 |
| **位置选项** | `top/middle/bottom` | `top/middle/bottom` | 相同 |
| **遮罩层** | `overlay` | `overlay` | 相同 |
| **动画配置** | 内置动画，无需配置 | `transition` 属性自定义 | HTToast 简化配置 |
| **全局方法** | `this.$toast` | `this.$toast` | 相同 |
| **多实例** | `Toast.allowMultiple()` | `Toast.allowMultiple()` | 相同 |

### 配置选项对比

| 选项 | HTToast | Vant Toast | 差异说明 |
|------|---------|------------|----------|
| `type` | `text/loading/success/fail/html` | `text/loading/success/fail/html` | 相同 |
| `position` | `top/middle/bottom` | `top/middle/bottom` | 相同 |
| `message` | ✅ | ✅ | 相同 |
| `icon` | ✅ 支持 HTIcon | ✅ 支持 Icon 名称 | HTToast 集成自定义图标 |
| `iconPrefix` | ❌ | ✅ | HTToast 不支持图标前缀 |
| `overlay` | ✅ | ✅ | 相同 |
| `forbidClick` | ✅ | ✅ | 相同 |
| `closeOnClick` | ✅ | ✅ | 相同 |
| `closeOnClickOverlay` | ✅ | ✅ | 相同 |
| `loadingType` | ✅ `circular/spinner` | ✅ `circular/spinner` | 相同 |
| `duration` | ✅ | ✅ | 相同 |
| `className` | ✅ | ✅ | 相同 |
| `onOpened` | ✅ | ✅ | 相同 |
| `onClose` | ✅ | ✅ | 相同 |
| `transition` | ❌ 内置动画 | ✅ | HTToast 简化动画配置 |
| `getContainer/teleport` | ❌ | ✅ | HTToast 不支持自定义挂载节点 |

### HTToast 新增特性

1. **更好的 TypeScript 支持**：完整的类型定义和智能提示
2. **组件式用法**：支持 `v-model` 控制显示状态
3. **增强的图标系统**：集成 HTIcon 组件，支持更多图标
4. **简化的 API**：提供更直观的方法名（`text`, `html` 等）
5. **内置动画**：无需配置复杂的动画参数
6. **更好的样式定制**：提供更多 CSS 变量

### HTToast 缺少的功能

1. **图标前缀配置**：不支持 `iconPrefix` 属性
2. **自定义挂载节点**：不支持 `teleport/getContainer`
3. **自定义动画**：不支持 `transition` 属性自定义动画

### 使用差异

#### Vant Toast 用法
```javascript
// Vant 用法
Toast('提示内容');
Toast.loading('加载中...');
Toast.success('成功');
Toast.fail('失败');
Toast({ type: 'html', message: '<b>HTML内容</b>' });
```

#### HTToast 用法
```javascript
// HTToast 用法
Toast.text('提示内容');
Toast.loading('加载中...');
Toast.success('成功');
Toast.fail('失败');
Toast.html('<b>HTML内容</b>');
```

### 迁移指南

从 Vant Toast 迁移到 HTToast：

1. **基础文本提示**：
   ```javascript
   // Vant
   Toast('消息');
   // HTToast
   Toast.text('消息');
   ```

2. **HTML 内容**：
   ```javascript
   // Vant
   Toast({ type: 'html', message: '<b>粗体</b>' });
   // HTToast
   Toast.html('<b>粗体</b>');
   ```

3. **图标配置**：
   ```javascript
   // Vant
   Toast({ icon: 'like-o', message: '自定义图标' });
   // HTToast
   Toast.text({ icon: 'like', message: '自定义图标' });
   ```

4. **移除不支持的配置**：
   - 移除 `iconPrefix` 配置
   - 移除 `transition` 配置
   - 移除 `getContainer/teleport` 配置

## 样式定制

### CSS 变量

HTToast 提供了丰富的 CSS 变量用于样式定制：

```css
:root {
  /* 基础样式 */
  --ht-toast-max-width: 70%;
  --ht-toast-font-size: 14px;
  --ht-toast-text-color: #fff;
  --ht-toast-line-height: 20px;
  --ht-toast-border-radius: 8px;
  --ht-toast-background-color: rgba(0, 0, 0, 0.7);
  
  /* 图标样式 */
  --ht-toast-icon-size: 36px;
  --ht-toast-loading-icon-color: #fff;
  
  /* 布局样式 */
  --ht-toast-text-min-width: 96px;
  --ht-toast-text-padding: 8px 12px;
  --ht-toast-default-padding: 16px;
  --ht-toast-default-width: 88px;
  --ht-toast-default-min-height: 88px;
  
  /* 位置样式 */
  --ht-toast-position-top-distance: 20%;
  --ht-toast-position-bottom-distance: 20%;
  
  /* 动画样式 */
  --ht-toast-animation-duration: 0.3s;
  --ht-toast-animation-timing-function: ease-out;
}
```

### 自定义主题示例

```css
/* 自定义成功提示样式 */
.ht-toast--success {
  --ht-toast-background-color: #07c160;
  --ht-toast-text-color: #fff;
}

/* 自定义失败提示样式 */
.ht-toast--fail {
  --ht-toast-background-color: #ee0a24;
  --ht-toast-text-color: #fff;
}

/* 自定义加载提示样式 */
.ht-toast--loading {
  --ht-toast-background-color: rgba(0, 0, 0, 0.8);
  --ht-toast-loading-icon-color: #fff;
}
```

### ⚠️ 使用差异

1. **Provider 必需**: 需要在应用根组件中添加 `ToastProvider`
2. **导入方式**: 从 `@/components/toast` 导入而非 `vant`
3. **样式系统**: 使用 CSS 变量而非 Less 变量

### ✅ 完全兼容

- API 方法完全兼容 Vant Toast
- 配置选项完全兼容
- 事件回调完全兼容
- 样式效果基本一致

### 从 Vant 迁移

1. **安装依赖**
```bash
npm install @reka-ui/vue
```

2. **添加 Provider**
```vue
<template>
  <div id="app">
    <router-view />
    <ToastProvider />
  </div>
</template>

<script setup>
import { ToastProvider } from '@/components/toast'
</script>
```

3. **更新导入**
```diff
- import { showToast } from 'vant'
+ import { Toast } from '@/components/toast'

- showToast('Hello')
+ Toast.text('Hello')
```

4. **样式迁移**
```diff
- @import 'vant/lib/toast/style';
+ @import '@/components/toast/styles';
```

### 注意事项

1. **Provider 位置**: 确保 `ToastProvider` 在应用的最外层
2. **多实例**: 默认单实例，使用 `Toast.allowMultiple(true)` 开启多实例
3. **加载 Toast**: 需要手动调用 `close()` 方法关闭
4. **HTML 安全**: 使用 `Toast.html()` 时注意 XSS 防护