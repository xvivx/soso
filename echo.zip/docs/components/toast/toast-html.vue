<template>
  <div class="demo-toast">
    <div class="demo-section">
      <h3>HTML 内容</h3>
      <div class="demo-buttons">
        <button @click="showHtmlText" class="demo-button">HTML 文本</button>
        <button @click="showHtmlLink" class="demo-button">HTML 链接</button>
        <button @click="showHtmlList" class="demo-button">HTML 列表</button>
      </div>
      <div class="demo-warning">
        <p>⚠️ 注意：使用 HTML 内容时请确保内容安全，避免 XSS 攻击</p>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { Toast } from '@hytech/ht-ui';

function showHtmlText() {
  Toast.html('<strong>粗体</strong>和<em>斜体</em>文本');
}

function showHtmlLink() {
  Toast.html('点击<a href="#" style="color: #1989fa; text-decoration: underline;">链接</a>查看详情', {
    duration: 4000,
    closeOnClick: true,
  });
}

function showHtmlList() {
  Toast.html(
    `
    <div style="text-align: left;">
      <div style="margin-bottom: 8px;"><strong>操作结果：</strong></div>
      <ul style="margin: 0; padding-left: 16px;">
        <li>✅ 数据保存成功</li>
        <li>✅ 缓存已更新</li>
        <li>✅ 通知已发送</li>
      </ul>
    </div>
  `,
    {
      duration: 5000,
    }
  );
}
</script>

<style scoped>
.demo-toast {
  width: 100%;
  max-width: 600px;
  margin: 0 auto;
  padding: 16px;
  background: var(--color-surface-primary);
  border-radius: var(--dimensions-radius-sm);
}

.demo-section {
  margin-bottom: 24px;
}

.demo-section:last-child {
  margin-bottom: 0;
}

.demo-section h3 {
  margin: 0 0 12px 0;
  font-size: 16px;
  font-weight: 600;
  color: var(--color-content-primary);
}

.demo-buttons {
  display: flex;
  flex-wrap: wrap;
  gap: 12px;
  margin-bottom: 16px;
}

.demo-button {
  padding: 8px 16px;
  border: 1px solid var(--color-border-primary);
  border-radius: var(--dimensions-radius-xs);
  background: var(--color-surface-secondary);
  color: var(--color-text-primary);
  font-size: 14px;
  cursor: pointer;
  transition: all 0.2s ease;
}

.demo-button:hover {
  background: var(--color-surface-tertiary);
  border-color: var(--color-border-secondary);
}

.demo-button:active {
  transform: translateY(1px);
}

.demo-warning {
  padding: 12px;
  background: rgba(255, 193, 7, 0.1);
  border: 1px solid var(--color-border-default);
  border-radius: var(--dimensions-radius-xs);
}

.demo-warning p {
  margin: 0;
  font-size: 12px;
  color: #856404;
}
</style>
