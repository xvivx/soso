<template>
  <div class="demo-toast">
    <div class="demo-section">
      <h3>自定义位置</h3>
      <div class="demo-buttons">
        <button @click="showTop" class="demo-button">顶部</button>
        <button @click="showMiddle" class="demo-button">中间</button>
        <button @click="showBottom" class="demo-button">底部</button>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { Toast } from '@hytech/ht-ui';

function showTop() {
  Toast.text('顶部提示', {
    position: 'top',
  });
}

function showMiddle() {
  Toast.text('中间提示', {
    position: 'middle',
  });
}

function showBottom() {
  Toast.text('底部提示', {
    position: 'bottom',
    duration: 300000,
  });
}
</script>

<style scoped>
.demo-toast {
  width: 100%;
  max-width: 600px;
  margin: 0 auto;
  padding: 16px;
  background: var(--color-surface-primary);
  border-radius: var(--dimensions-radius-sm);
}

.demo-section {
  margin-bottom: 24px;
}

.demo-section:last-child {
  margin-bottom: 0;
}

.demo-section h3 {
  margin: 0 0 12px 0;
  font-size: 16px;
  font-weight: 600;
  color: var(--color-content-primary);
}

.demo-buttons {
  display: flex;
  flex-wrap: wrap;
  gap: 12px;
}

.demo-button {
  padding: 8px 16px;
  border: 1px solid var(--color-border-default);
  border-radius: var(--dimensions-radius-xs);
  background: var(--color-surface-secondary);
  color: var(--color-content-primary);
  font-size: 14px;
  cursor: pointer;
  transition: all 0.2s ease;
}

.demo-button:hover {
  background: var(--color-surface-tertiary);
  border-color: var(--color-border-secondary);
}

.demo-button:active {
  transform: translateY(1px);
}
</style>
