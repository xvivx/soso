<template>
  <div class="demo-toast">
    <div class="demo-section">
      <h3>加载状态</h3>
      <div class="demo-buttons">
        <button @click="showLoading" class="demo-button">默认加载</button>
        <button @click="showLoadingWithText" class="demo-button">带文字加载</button>
        <button @click="showSpinnerLoading" class="demo-button">Spinner 加载</button>
        <button @click="showAsyncOperation" class="demo-button">模拟异步操作</button>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { Toast } from '@hytech/ht-ui';

function showLoading() {
  const toast = Toast.loading();

  // 3秒后关闭
  setTimeout(() => {
    toast.close();
  }, 3000);
}

function showLoadingWithText() {
  const toast = Toast.loading('数据加载中...');

  // 3秒后关闭
  setTimeout(() => {
    toast.close();
  }, 3000);
}

function showSpinnerLoading() {
  const toast = Toast.loading('处理中...', {
    loadingType: 'spinner',
  });

  // 3秒后关闭
  setTimeout(() => {
    toast.close();
  }, 3000);
}

function showAsyncOperation() {
  const toast = Toast.loading('正在提交...');

  // 模拟异步操作
  setTimeout(() => {
    toast.close();

    // 显示成功提示
    setTimeout(() => {
      Toast.success('提交成功');
    }, 100);
  }, 2000);
}
</script>

<style scoped>
.demo-toast {
  width: 100%;
  max-width: 600px;
  margin: 0 auto;
  padding: 16px;
  background: var(--color-surface-primary);
  border-radius: var(--dimensions-radius-sm);
}

.demo-section {
  margin-bottom: 24px;
}

.demo-section:last-child {
  margin-bottom: 0;
}

.demo-section h3 {
  margin: 0 0 12px 0;
  font-size: 16px;
  font-weight: 600;
  color: var(--color-content-primary);
}

.demo-buttons {
  display: flex;
  flex-wrap: wrap;
  gap: 12px;
}

.demo-button {
  padding: 8px 16px;
  border: 1px solid var(--color-border-default);
  border-radius: var(--dimensions-radius-xs);
  background: var(--color-surface-secondary);
  color: var(--color-content-primary);
  font-size: 14px;
  cursor: pointer;
  transition: all 0.2s ease;
}

.demo-button:hover {
  background: var(--color-surface-tertiary);
  border-color: var(--color-border-secondary);
}

.demo-button:active {
  transform: translateY(1px);
}
</style>
