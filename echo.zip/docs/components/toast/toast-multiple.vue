<template>
  <div class="demo-toast">
    <div class="demo-section">
      <h3>多个 Toast</h3>
      <div class="demo-buttons">
        <button @click="enableMultiple" class="demo-button">允许多个 Toast</button>
        <button @click="showMultiple" class="demo-button">显示多个 Toast</button>
        <button @click="disableMultiple" class="demo-button">禁用多个 Toast</button>
        <button @click="clearAll" class="demo-button clear">清除所有</button>
      </div>
    </div>

    <div class="demo-section">
      <h3>状态</h3>
      <div class="demo-status">
        <p>
          多个 Toast 模式:
          <span :class="{ active: isMultipleEnabled }">{{ isMultipleEnabled ? '已启用' : '已禁用' }}</span>
        </p>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import { Toast } from '@hytech/ht-ui';

const isMultipleEnabled = ref(false);

function enableMultiple() {
  Toast.allowMultiple(true);
  isMultipleEnabled.value = true;
  Toast.success('已启用多个 Toast 模式');
}

function showMultiple() {
  if (!isMultipleEnabled.value) {
    Toast.fail('请先启用多个 Toast 模式');
    return;
  }

  // 显示多个不同高度的 Toast，测试间距效果
  Toast.text('短文本提示');

  setTimeout(() => {
    Toast.success('这是一条较长的成功提示信息，用于测试不同高度 Toast 的间距效果');
  }, 300);

  setTimeout(() => {
    Toast.fail('失败提示');
  }, 600);

  setTimeout(() => {
    Toast.text('这是一条非常长非常长非常长非常长非常长的文本提示，用于测试换行后的 Toast 间距是否正确调整');
  }, 900);

  setTimeout(() => {
    const loading = Toast.loading('加载中...');

    // 3秒后关闭加载提示
    setTimeout(() => {
      loading.close();
    }, 3000);
  }, 1200);
}

function disableMultiple() {
  Toast.allowMultiple(false);
  isMultipleEnabled.value = false;
  Toast.success('已禁用多个 Toast 模式');
}

function clearAll() {
  Toast.clear();
  Toast.success('已清除所有 Toast');
}
</script>

<style scoped>
.demo-toast {
  width: 100%;
  max-width: 600px;
  margin: 0 auto;
  padding: 16px;
  background: var(--color-surface-primary);
  border-radius: var(--dimensions-radius-sm);
}

.demo-section {
  margin-bottom: 24px;
}

.demo-section:last-child {
  margin-bottom: 0;
}

.demo-section h3 {
  margin: 0 0 12px 0;
  font-size: 16px;
  font-weight: 600;
  color: var(--color-content-primary);
}

.demo-buttons {
  display: flex;
  flex-wrap: wrap;
  gap: 12px;
}

.demo-button {
  padding: 8px 16px;
  border: 1px solid var(--color-border-primary);
  border-radius: var(--dimensions-radius-xs);
  background: var(--color-surface-secondary);
  color: var(--color-text-primary);
  font-size: 14px;
  cursor: pointer;
  transition: all 0.2s ease;
}

.demo-button:hover {
  background: var(--color-surface-tertiary);
  border-color: var(--color-border-secondary);
}

.demo-button:active {
  transform: translateY(1px);
}

.demo-button.clear {
  border-color: #ee0a24;
  color: #ee0a24;
}

.demo-button.clear:hover {
  background: rgba(238, 10, 36, 0.1);
}

.demo-status {
  padding: 12px;
  background: var(--color-surface-secondary);
  border: 1px solid var(--color-border-default);
  border-radius: var(--dimensions-radius-xs);
}

.demo-status p {
  margin: 0;
  font-size: 14px;
  color: var(--color-content-primary);
}

.demo-status span {
  font-weight: 600;
  color: #ee0a24;
}

.demo-status span.active {
  color: #07c160;
}
</style>
