<template>
  <div class="demo-toast">
    <div class="demo-section">
      <h3>遮罩层</h3>
      <div class="demo-buttons">
        <button @click="showWithOverlay" class="demo-button">显示遮罩层</button>
        <button @click="showForbidClick" class="demo-button">禁止点击</button>
        <button @click="showCloseOnOverlay" class="demo-button">点击遮罩关闭</button>
        <button @click="showCloseOnToast" class="demo-button">点击 Toast 关闭</button>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { Toast } from '@hytech/ht-ui';

function showWithOverlay() {
  Toast.text('带遮罩层的提示', {
    overlay: true,
    duration: 3000,
  });
}

function showForbidClick() {
  Toast.loading('禁止点击背景', {
    overlay: true,
    forbidClick: true,
    duration: 3000,
  });
}

function showCloseOnOverlay() {
  Toast.text('点击遮罩层关闭', {
    overlay: true,
    closeOnClickOverlay: true,
    duration: 0, // 不自动关闭
  });
}

function showCloseOnToast() {
  Toast.text('点击 Toast 关闭', {
    overlay: true,
    closeOnClick: true,
    duration: 0, // 不自动关闭
  });
}
</script>

<style scoped>
.demo-toast {
  width: 100%;
  max-width: 600px;
  margin: 0 auto;
  padding: 16px;
  background: var(--color-surface-primary);
  border-radius: var(--dimensions-radius-sm);
}

.demo-section {
  margin-bottom: 24px;
}

.demo-section:last-child {
  margin-bottom: 0;
}

.demo-section h3 {
  margin: 0 0 12px 0;
  font-size: 16px;
  font-weight: 600;
  color: var(--color-content-primary);
}

.demo-buttons {
  display: flex;
  flex-wrap: wrap;
  gap: 12px;
}

.demo-button {
  padding: 8px 16px;
  border: 1px solid var(--color-border-default);
  border-radius: var(--dimensions-radius-xs);
  background: var(--color-surface-secondary);
  color: var(--color-content-primary);
  font-size: 14px;
  cursor: pointer;
  transition: all 0.2s ease;
}

.demo-button:hover {
  background: var(--color-surface-tertiary);
  border-color: var(--color-border-secondary);
}

.demo-button:active {
  transform: translateY(1px);
}
</style>
