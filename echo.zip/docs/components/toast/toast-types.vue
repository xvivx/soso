<template>
  <div class="demo-toast">
    <div class="demo-section">
      <h3>不同类型</h3>
      <div class="demo-buttons">
        <button @click="showText" class="demo-button">文本</button>
        <button @click="showSuccess" class="demo-button success">成功</button>
        <button @click="showFail" class="demo-button fail">失败</button>
        <button @click="showLoading" class="demo-button loading">加载</button>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { Toast } from '@hytech/ht-ui';

function showText() {
  Toast.text('这是文本提示');
}

function showSuccess() {
  Toast.success('操作成功', {
    duration: 300000,
  });
}

function showFail() {
  Toast.fail('操作失败');
}

let loadingToast: any = null;

function showLoading() {
  // 如果已有加载中的 Toast，先关闭
  if (loadingToast) {
    loadingToast.close();
  }

  loadingToast = Toast.loading('加载中...', {
    duration: 300000,
  });

  // 3秒后自动关闭
  setTimeout(() => {
    if (loadingToast) {
      loadingToast.close();
      loadingToast = null;
      Toast.success('加载完成');
    }
  }, 300000);
}
</script>

<style scoped>
.demo-toast {
  width: 100%;
  max-width: 600px;
  margin: 0 auto;
  padding: 16px;
  background: var(--color-surface-primary);
  border-radius: var(--dimensions-radius-sm);
}

.demo-section {
  margin-bottom: 24px;
}

.demo-section:last-child {
  margin-bottom: 0;
}

.demo-section h3 {
  margin: 0 0 12px 0;
  font-size: 16px;
  font-weight: 600;
  color: var(--color-content-primary);
}

.demo-buttons {
  display: flex;
  flex-wrap: wrap;
  gap: 12px;
}

.demo-button {
  padding: 8px 16px;
  border: 1px solid var(--color-border-default);
  border-radius: var(--dimensions-radius-xs);
  background: var(--color-surface-secondary);
  color: var(--color-content-primary);
  font-size: 14px;
  cursor: pointer;
  transition: all 0.2s ease;
}

.demo-button:hover {
  background: var(--color-surface-tertiary);
  border-color: var(--color-border-secondary);
}

.demo-button:active {
  transform: translateY(1px);
}

.demo-button.success {
  border-color: #07c160;
  color: #07c160;
}

.demo-button.success:hover {
  background: rgba(7, 193, 96, 0.1);
}

.demo-button.fail {
  border-color: #ee0a24;
  color: #ee0a24;
}

.demo-button.fail:hover {
  background: rgba(238, 10, 36, 0.1);
}

.demo-button.loading {
  border-color: #1989fa;
  color: #1989fa;
}

.demo-button.loading:hover {
  background: rgba(25, 137, 250, 0.1);
}
</style>
