# Switch 开关

用于在打开和关闭状态之间进行切换。

## 基础用法

通过 v-model 绑定开关的选中状态。 <demo vue="./examples/Basic.vue" codesandbox="true" />

## 禁用状态

通过 disabled 属性禁用开关。 <demo vue="./examples/Disabled.vue" codesandbox="true" />

## 加载状态

通过 loading 属性设置开关为加载状态。 <demo vue="./examples/Loading.vue" codesandbox="true" />

## 自定义大小
通过 size 属性可以设置开关的大小，默认单位为 px。
<demo vue="./examples/Size.vue" codesandbox="true" />

## 自定义颜色

通过 active-color 和 inactive-color 属性可以自定义开关的颜色。
<demo vue="./examples/CustomColor.vue" codesandbox="true" />

## 自定义值

通过 active-value 和 inactive-value 属性可以自定义开关的值。
<demo vue="./examples/CustomValue.vue" codesandbox="true" />

## 搭配文本

通过默认插槽可以在开关旁边添加文本。 <demo vue="./examples/WithLabel.vue" codesandbox="true" />

## API

### Props

| 参数           | 说明                     | 类型                          | 默认值  |
| -------------- | ------------------------ | ----------------------------- | ------- |
| v-model        | 开关选中状态             | `boolean \| string \| number` | `false` |
| loading        | 是否为加载状态           | `boolean`                     | `false` |
| disabled       | 是否为禁用状态           | `boolean`                     | `false` |
| size           | 开关尺寸，默认单位为 px  | `string \| number`            | `26`    |
| active-color   | 打开时的背景色           | `string`                      | `#1677FF` |
| inactive-color | 关闭时的背景色           | `string`                      | `#E5E6EB` |
| active-value   | 打开时对应的值           | `boolean \| string \| number` | `true`  |
| inactive-value | 关闭时对应的值           | `boolean \| string \| number` | `false` |

### Events

| 事件名 | 说明                 | 参数                            |
| ------ | -------------------- | ------------------------------- |
| change | 开关状态切换时触发   | `value: boolean \| string \| number` |
| click  | 点击开关时触发       | `event: MouseEvent`             |

### Slots

| 名称       | 说明                 | 参数                                  |
| ---------- | -------------------- | ------------------------------------- |
| default    | 自定义文本           | `{ checked: boolean, disabled: boolean }` |
| node       | 自定义按钮的内容     | -                                     |
| background | 自定义开关的背景内容 | -                                     |

### 类型定义

组件导出以下类型定义：

```ts
import type {
  SwitchProps,
  SwitchEmits
} from 'ht-ui';
```
