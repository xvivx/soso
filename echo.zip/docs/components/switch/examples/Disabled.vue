<script setup lang="ts">
import { ref } from 'vue';
import { HTSwitch } from '@hytech/ht-ui';

const checked = ref(true);
</script>

<template>
  <div class="flex gap-4">
    <HTSwitch v-model="checked" disabled />
    <HTSwitch :model-value="false" disabled />
  </div>
</template>
