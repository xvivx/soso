<script setup lang="ts">
import { ref } from 'vue';
import { HTSwitch } from '@hytech/ht-ui';

const checked = ref(true);
</script>

<template>
  <HTSwitch v-model="checked" active-color="#07c160" inactive-color="#ee0a24" />
</template>
