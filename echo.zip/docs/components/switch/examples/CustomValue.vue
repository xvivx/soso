<script setup lang="ts">
import { ref } from 'vue';
import { HTSwitch } from '@hytech/ht-ui';

const value = ref('1');
</script>

<template>
  <div>
    <HTSwitch v-model="value" active-value="1" inactive-value="0" />
    <p class="mt-4 text-gray-600">当前值: {{ value }}</p>
  </div>
</template>
