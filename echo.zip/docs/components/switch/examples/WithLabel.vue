<script setup lang="ts">
import { ref } from 'vue';
import { HTSwitch } from '@hytech/ht-ui';

const checked = ref(true);
</script>

<template>
  <div class="flex flex-col gap-4">
    <HTSwitch v-model="checked">
      <template #default="{ checked }">
        {{ checked ? '开启' : '关闭' }}
      </template>
    </HTSwitch>

    <HTSwitch v-model="checked"> 开关按钮 </HTSwitch>
  </div>
</template>
