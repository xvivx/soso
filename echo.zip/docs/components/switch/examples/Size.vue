<script setup lang="ts">
import { ref } from 'vue';
import { HTSwitch } from '@hytech/ht-ui';

const checked = ref(true);
</script>

<template>
  <div class="flex items-center gap-4">
    <HTSwitch v-model="checked" :size="20" />
    <HTSwitch v-model="checked" :size="26" />
    <HTSwitch v-model="checked" :size="32" />
  </div>
</template>
