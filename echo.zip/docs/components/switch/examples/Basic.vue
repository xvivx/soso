<script setup lang="ts">
import { ref } from 'vue';
import { HTSwitch } from '@hytech/ht-ui';

const checked = ref(true);
</script>

<template>
  <HTSwitch v-model="checked" />
</template>
