# HTPinInput PIN 码输入框

用于输入 PIN 码、验证码等场景的输入框组件，基于 Reka UI 的 PinInput 实现。

## 基础用法

基本的 PIN 码输入框，默认 4 位。

<demo vue="./examples/Basic.vue" />

## 自定义长度

通过 `length` 属性设置输入框数量。

<demo vue="./examples/Length.vue" />

## 输入类型

通过 `type` 属性设置输入类型，支持 `text`、`number`。设置为 `number` 时只能输入数字。

<demo vue="./examples/Type.vue" />

## 掩码输入

通过 `mask` 属性启用掩码模式，适用于输入密码等敏感信息。

<demo vue="./examples/Mask.vue" />

## 自定义尺寸

通过 `size` 属性可以自定义输入框的尺寸，支持数字（单位 px）或字符串（支持各种 CSS 单位）。

<demo vue="./examples/Size.vue" />

## 自动聚焦

通过 `autoFocus` 属性可以在页面加载时自动聚焦到第一个输入框。

<demo vue="./examples/AutoFocus.vue" />

## 禁用状态

通过 `disabled` 属性设置禁用状态。

<demo vue="./examples/Disabled.vue" />

## 无效状态

通过 `invalid` 属性设置无效状态，通常用于验证失败时显示。

<demo vue="./examples/Invalid.vue" />

## 事件监听

组件提供了事件回调，可以监听输入完成等事件。

<demo vue="./examples/Events.vue" />

## 实例方法

通过 ref 可以获取到 PinInput 实例并调用实例方法。

<demo vue="./examples/Methods.vue" />

## API

### Props

| 参数 | 说明 | 类型 | 默认值 |
| --- | --- | --- | --- |
| v-model | 绑定的值 | `string[] \| null` | `null` |
| defaultValue | 默认值 | `string[]` | `[]` |
| dir | 输入框排列方向 | `'ltr' \| 'rtl'` | `'ltr'` |
| invalid | 是否无效状态 | `boolean` | `false` |
| disabled | 是否禁用状态 | `boolean` | `false` |
| length | 输入框数量 | `number` | `4` |
| separator | 输入框间隔符 | `string` | `''` |
| autoFocus | 是否自动聚焦第一个输入框 | `boolean` | `false` |
| placeholder | 占位符 | `string` | `''` |
| mask | 是否掩码输入内容 | `boolean` | `false` |
| type | 输入框类型 | `'text' \| 'number'` | `'text'` |
| size | 输入框尺寸，默认单位为 px | `number \| string` | `48px` |

### Events

| 事件名 | 说明 | 回调参数 |
| --- | --- | --- |
| update:modelValue | 当绑定值变化时触发 | `value: string[]` |
| complete | 当输入完成时触发（所有位已填满） | `value: string[]` |

### Methods

通过 ref 可以获取到 PinInput 实例并调用实例方法。

| 方法名 | 说明 | 参数 | 返回值 |
| --- | --- | --- | --- |
| focus | 聚焦到指定输入框 | `index?: number` | - |
| blur | 失焦所有输入框 | - | - |
| clear | 清空所有输入 | - | - |

```vue
<script setup lang="ts">
import { ref } from 'vue';
import type { PinInputExpose } from '@hytech/ht-ui';

const pinInputRef = ref<PinInputExpose>();

// 聚焦到第一个输入框
pinInputRef.value?.focus(0);

// 聚焦到最后一个输入框
pinInputRef.value?.focus(3);

// 失焦所有输入框
pinInputRef.value?.blur();

// 清空所有输入
pinInputRef.value?.clear();
</script>

<template>
  <HTPinInput ref="pinInputRef" />
</template>
```

### 类型定义

组件导出以下类型定义：

```ts
import type {
  PinInputProps,
  PinInputEmits,
  PinInputExpose,
  PinInputType,
  PinInputDir,
} from '@hytech/ht-ui';
```

## 样式变量

组件提供了以下 CSS 变量，可用于自定义样式。

| 名称 | 默认值 | 说明 |
| --- | --- | --- |
| --input-otp-gap-default | 8px | 输入框间距 |
| --input-otp-size-default | 48px | 输入框尺寸 |
| --input-otp-border-radius-default | 8px | 输入框圆角 |
| --input-otp-font-size-default | 14px | 字体大小 |
| --input-otp-border-color-default | #d9d9d9 | 默认边框颜色 |
| --input-otp-border-color-hover | #1890ff | 悬停边框颜色 |
| --input-otp-border-color-focus | #1890ff | 聚焦边框颜色 |
| --input-otp-border-color-invalid | #ff4d4f | 无效状态边框颜色 |
| --input-otp-bg-color-invalid | #fff1f0 | 无效状态背景色 |
| --input-otp-color-invalid | #ff4d4f | 无效状态文字颜色 |
| --input-otp-bg-color-disabled | #f5f5f5 | 禁用状态背景色 |
| --input-otp-color-disabled | #999999 | 禁用状态文字颜色 |
| --input-otp-caret-color-default | #1890ff | 输入框光标颜色 |

## 使用技巧

### 推荐配置

对于 PIN 码场景，推荐使用以下配置：

```vue
<HTPinInput
  v-model="pin"
  :length="4"
  type="number"
  autoFocus
  @complete="handleComplete"
/>
```

### 键盘快捷键

组件支持以下键盘操作：

- **Backspace**: 删除当前字符，如果当前为空则删除前一个字符并聚焦
- **Delete**: 删除当前字符
- **左右箭头**: 在输入框之间切换
- **Home**: 跳转到第一个输入框
- **End**: 跳转到最后一个输入框

### 粘贴支持

组件支持粘贴验证码，粘贴的内容会自动分配到各个输入框中。对于 `type="number"` 的输入框，会自动过滤非数字字符。

### 与 Form 集成

配合 Form 和 Field 组件使用时，可以实现完整的表单验证：

```vue
<HTForm @submit="onSubmit">
  <HTField
    v-model="formData.pin"
    name="pin"
    label="PIN 码"
    :rules="[
      { required: true, message: '请输入 PIN 码' },
      { validator: (v) => v?.every(char => char !== ''), message: 'PIN 码必须填写完整' }
    ]"
  >
    <template #input>
      <HTPinInput v-model="formData.pin" :length="4" type="number" />
    </template>
  </HTField>
</HTForm>
```
