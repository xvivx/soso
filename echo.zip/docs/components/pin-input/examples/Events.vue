<script setup lang="ts">
import { ref } from 'vue';

const pinValue = ref<string[]>(['1', '2', '3', '4']);

const handleComplete = (value: string[]) => {
  console.log('验证码输入完成:', value.join(''));
};
</script>

<template>
  <div class="demo-container">
    <h4 class="demo-title">事件监听</h4>
    <HTPinInput v-model="pinValue" @complete="handleComplete" />
    <p class="demo-result">当前值: {{ pinValue.join('') }}</p>
    <p class="demo-hint">输入完成后会在控制台打印</p>
  </div>
</template>

<style scoped>
.demo-container {
  padding: 20px;
}

.demo-title {
  margin: 0 0 12px 0;
  color: #333;
  font-size: 14px;
  font-weight: 500;
}

.demo-result {
  margin-top: 16px;
  color: #666;
  font-size: 14px;
}

.demo-hint {
  margin-top: 8px;
  color: #999;
  font-size: 12px;
}
</style>
