<script setup lang="ts">
import { ref } from 'vue';
import type { PinInputExpose } from '@/components/pin-input';

const pinValue = ref<string[]>(['1', '2', '3', '4']);
const pinInputRef = ref<PinInputExpose>();

const handleFocusFirst = () => {
  pinInputRef.value?.focus(0);
};

const handleFocusLast = () => {
  pinInputRef.value?.focus(3);
};

const handleBlur = () => {
  pinInputRef.value?.blur();
};

const handleClear = () => {
  pinInputRef.value?.clear();
};
</script>

<template>
  <div class="demo-container">
    <HTPinInput ref="pinInputRef" v-model="pinValue" />
    <p class="demo-result">当前值: {{ pinValue.join('') || '(空)' }}</p>

    <div class="button-group">
      <HTButton size="small" @click="handleFocusFirst">聚焦第一个</HTButton>
      <HTButton size="small" @click="handleFocusLast">聚焦最后一个</HTButton>
      <HTButton size="small" @click="handleBlur">失焦</HTButton>
      <HTButton size="small" @click="handleClear">清空</HTButton>
    </div>
  </div>
</template>

<style scoped>
.demo-container {
  padding: 20px;
}

.demo-result {
  margin-top: 16px;
  color: #666;
  font-size: 14px;
}

.button-group {
  display: flex;
  gap: 8px;
  margin-top: 16px;
  flex-wrap: wrap;
}
</style>
