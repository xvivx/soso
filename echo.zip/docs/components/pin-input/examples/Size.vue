<script setup lang="ts">
import { ref } from 'vue';

const pinValue1 = ref<string[]>(['', '', '', '']);
const pinValue2 = ref<string[]>(['', '', '', '']);
const pinValue3 = ref<string[]>(['', '', '', '']);
const pinValue4 = ref<string[]>(['', '', '', '']);
</script>

<template>
  <div class="demo-container">
    <div class="demo-item">
      <h4 class="demo-title">默认尺寸 (48px)</h4>
      <HTPinInput v-model="pinValue1" :length="4" />
      <p class="demo-result">当前值: {{ pinValue1.join('') || '(空)' }}</p>
    </div>

    <div class="demo-item">
      <h4 class="demo-title">使用数字 - 40px</h4>
      <HTPinInput v-model="pinValue2" :length="4" :size="40" />
      <p class="demo-result">当前值: {{ pinValue2.join('') || '(空)' }}</p>
    </div>

    <div class="demo-item">
      <h4 class="demo-title">使用数字 - 56px</h4>
      <HTPinInput v-model="pinValue3" :length="4" :size="56" />
      <p class="demo-result">当前值: {{ pinValue3.join('') || '(空)' }}</p>
    </div>

    <div class="demo-item">
      <h4 class="demo-title">使用字符串 - 3rem</h4>
      <HTPinInput v-model="pinValue4" :length="4" size="3rem" />
      <p class="demo-result">当前值: {{ pinValue4.join('') || '(空)' }}</p>
    </div>
  </div>
</template>

<style scoped>
.demo-container {
  padding: 20px;
}

.demo-item {
  margin-bottom: 32px;
}

.demo-item:last-child {
  margin-bottom: 0;
}

.demo-title {
  margin: 0 0 12px 0;
  color: #333;
  font-size: 14px;
  font-weight: 500;
}

.demo-result {
  margin-top: 16px;
  color: #666;
  font-size: 14px;
}
</style>
