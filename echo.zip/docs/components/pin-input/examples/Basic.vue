<script setup lang="ts">
import { ref } from 'vue';

const pinValue = ref<string[]>(['', '', '', '']);
</script>

<template>
  <div class="demo-container">
    <HTPinInput v-model="pinValue" />
    <p class="demo-result">当前值: {{ pinValue.join('') || '(空)' }}</p>
  </div>
</template>

<style scoped>
.demo-container {
  padding: 20px;
}

.demo-result {
  margin-top: 16px;
  color: #666;
  font-size: 14px;
}
</style>
