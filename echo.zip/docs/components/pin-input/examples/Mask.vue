<script setup lang="ts">
import { ref } from 'vue';

const pinValue = ref<string[]>(['', '', '', '']);
</script>

<template>
  <div class="demo-container">
    <h4 class="demo-title">掩码输入（密码模式）</h4>
    <HTPinInput v-model="pinValue" :mask="true" />
    <p class="demo-result">当前值: {{ pinValue.join('') || '(空)' }}</p>
  </div>
</template>

<style scoped>
.demo-container {
  padding: 20px;
}

.demo-title {
  margin: 0 0 12px 0;
  color: #333;
  font-size: 14px;
  font-weight: 500;
}

.demo-result {
  margin-top: 16px;
  color: #666;
  font-size: 14px;
}
</style>
