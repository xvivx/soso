<script setup lang="ts">
import { ref } from 'vue';
import { HTPinInput } from '@hytech/ht-ui';

const pinValue = ref<string[] | null>(null);
</script>

<template>
  <div class="space-y-4">
    <div>
      <p class="mb-2 text-sm text-gray-600">页面加载时自动聚焦到第一个输入框：</p>
      <HTPinInput v-model="pinValue" :length="4" auto-focus />
    </div>
    <div class="text-sm text-gray-500">当前值: {{ pinValue?.join('') || '空' }}</div>
  </div>
</template>
