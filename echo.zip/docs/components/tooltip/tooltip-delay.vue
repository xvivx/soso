<template>
  <div class="demo-tooltip">
    <div class="demo-section">
      <h3>延迟显示</h3>
      <div class="demo-buttons">
        <HTTooltip content="无延迟" :show-delay="0" :hide-delay="0">
          <HTButton>无延迟</HTButton>
        </HTTooltip>

        <HTTooltip content="延迟 500ms 显示" :show-delay="500">
          <HTButton>延迟显示</HTButton>
        </HTTooltip>

        <HTTooltip content="延迟 500ms 隐藏" :hide-delay="500">
          <HTButton>延迟隐藏</HTButton>
        </HTTooltip>

        <HTTooltip content="延迟 300ms 显示，延迟 300ms 隐藏" :show-delay="300" :hide-delay="300">
          <HTButton>延迟显示和隐藏</HTButton>
        </HTTooltip>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { HTButton, HTTooltip } from '@hytech/ht-ui';
</script>

<style scoped>
.demo-tooltip {
  width: 100%;
  max-width: 600px;
  margin: 0 auto;
  padding: 16px;
  background: var(--color-surface-primary);
  border-radius: var(--dimensions-radius-sm);
}

.demo-section {
  margin-bottom: 24px;
}

.demo-section:last-child {
  margin-bottom: 0;
}

.demo-section h3 {
  margin: 0 0 12px 0;
  font-size: 16px;
  font-weight: 600;
  color: var(--color-text-primary);
}

.demo-buttons {
  display: flex;
  flex-wrap: wrap;
  gap: 12px;
}

.demo-button {
  padding: 8px 16px;
  border: 1px solid var(--color-border-primary);
  border-radius: var(--dimensions-radius-xs);
  background: var(--color-surface-secondary);
  color: var(--color-text-primary);
  font-size: 14px;
  cursor: pointer;
  transition: all 0.2s ease;
}

.demo-button:hover {
  background: var(--color-surface-tertiary);
  border-color: var(--color-border-secondary);
}
</style>
