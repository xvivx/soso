<template>
  <div class="demo-tooltip">
    <div class="demo-section">
      <h3>移动端关闭按钮</h3>
      <p class="demo-description">
        在移动端或需要手动关闭的场景下，可以通过 <code>show-close-button</code> 属性显示关闭按钮。
      </p>

      <div class="demo-buttons">
        <HTTooltip
          content="这是一个带关闭按钮的提示信息。点击右上角的 × 按钮可以关闭提示。"
          :show-close-button="true"
          trigger="click"
          theme="dark"
        >
          <HTButton>深色主题 + 关闭按钮</HTButton>
        </HTTooltip>

        <HTTooltip
          content="浅色主题的提示信息，同样支持关闭按钮功能。"
          :show-close-button="true"
          trigger="click"
          theme="light"
        >
          <HTButton>浅色主题 + 关闭按钮</HTButton>
        </HTTooltip>

        <HTTooltip :show-close-button="true" trigger="click" theme="dark">
          <template #content>
            <div>
              <h4 style="margin: 0 0 8px 0; font-size: 14px">自定义内容</h4>
              <p style="margin: 0; font-size: 12px; opacity: 0.9">
                这是一个包含自定义内容的提示框，支持 HTML 内容和关闭按钮。
              </p>
            </div>
          </template>
          <HTButton>自定义内容 + 关闭按钮</HTButton>
        </HTTooltip>
      </div>

      <div class="demo-note">
        <p><strong>使用场景：</strong></p>
        <ul>
          <li>移动端触摸交互，用户需要手动关闭提示</li>
          <li>重要信息提示，确保用户主动关闭</li>
          <li>复杂内容展示，提供更好的用户控制</li>
        </ul>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { HTButton, HTTooltip } from '@hytech/ht-ui';
</script>

<style scoped>
.demo-tooltip {
  width: 100%;
  max-width: 600px;
  margin: 0 auto;
  padding: 16px;
  background: var(--color-surface-primary);
  border-radius: var(--dimensions-radius-sm);
}

.demo-section {
  margin-bottom: 24px;
}

.demo-section h3 {
  margin: 0 0 8px 0;
  font-size: 18px;
  font-weight: 600;
  color: var(--color-content-primary);
}

.demo-description {
  margin: 0 0 16px 0;
  font-size: 14px;
  color: var(--color-content-secondary);
  line-height: 1.5;
}

.demo-description code {
  padding: 2px 6px;
  background: var(--color-surface-secondary);
  border-radius: 4px;
  font-family: 'Monaco', 'Menlo', monospace;
  font-size: 13px;
}

.demo-buttons {
  display: flex;
  flex-wrap: wrap;
  gap: 16px;
  margin-bottom: 20px;
}

.demo-note {
  padding: 16px;
  background: var(--color-surface-secondary);
  border-radius: var(--dimensions-radius-sm);
  border-left: 4px solid var(--color-brand-primary);
}

.demo-note p {
  margin: 0 0 8px 0;
  font-size: 14px;
  color: var(--color-content-primary);
}

.demo-note ul {
  margin: 0;
  padding-left: 20px;
}

.demo-note li {
  margin-bottom: 4px;
  font-size: 13px;
  color: var(--color-content-secondary);
  line-height: 1.4;
}

/* 移动端适配 */
@media (max-width: 768px) {
  .demo-buttons {
    flex-direction: column;
  }

  .demo-tooltip {
    padding: 12px;
  }
}
</style>
