<template>
  <div class="demo-tooltip">
    <div class="demo-section">
      <h3>不同位置</h3>
      <div class="placement-grid">
        <div class="placement-row">
          <HTTooltip content="Top Left" placement="top-start">
            <HTButton>TL</HTButton>
          </HTTooltip>

          <HTTooltip content="Top" placement="top">
            <HTButton>Top</HTButton>
          </HTTooltip>

          <HTTooltip content="Top Right" placement="top-end">
            <HTButton>TR</HTButton>
          </HTTooltip>
        </div>

        <div class="placement-row">
          <div class="placement-left">
            <HTTooltip content="Left Top" placement="left-start">
              <HTButton>LT</HTButton>
            </HTTooltip>

            <HTTooltip content="Right Top" placement="right-start">
              <HTButton>RT</HTButton>
            </HTTooltip>
          </div>

          <div class="placement-center">
            <HTTooltip content="Left" placement="left">
              <HTButton>Left</HTButton>
            </HTTooltip>

            <HTTooltip content="Right" placement="right">
              <HTButton>Right</HTButton>
            </HTTooltip>
          </div>

          <div class="placement-right">
            <HTTooltip content="Left Bottom" placement="left-end">
              <HTButton>LB</HTButton>
            </HTTooltip>

            <HTTooltip content="Right Bottom" placement="right-end">
              <HTButton>RB</HTButton>
            </HTTooltip>
          </div>
        </div>

        <div class="placement-row">
          <HTTooltip content="Bottom Left" placement="bottom-start">
            <HTButton>BL</HTButton>
          </HTTooltip>

          <HTTooltip content="Bottom" placement="bottom">
            <HTButton>Bottom</HTButton>
          </HTTooltip>

          <HTTooltip content="Bottom Right" placement="bottom-end">
            <HTButton>BR</HTButton>
          </HTTooltip>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { HTButton, HTTooltip } from '@hytech/ht-ui';
</script>

<style scoped>
.demo-tooltip {
  width: 100%;
  max-width: 600px;
  margin: 0 auto;
  padding: 16px;
  background: var(--color-surface-primary);
  border-radius: var(--dimensions-radius-sm);
}

.demo-section h3 {
  margin: 0 0 12px 0;
  font-size: 16px;
  font-weight: 600;
  color: var(--color-text-primary);
}

.placement-grid {
  display: flex;
  flex-direction: column;
  gap: 8px;
  align-items: center;
  padding: 20px;
}

.placement-row {
  display: flex;
  gap: 8px;
  align-items: center;
}

.center-space {
  width: 80px;
}

.demo-button {
  padding: 8px 12px;
  border: 1px solid var(--color-border-primary);
  border-radius: var(--dimensions-radius-xs);
  background: var(--color-surface-secondary);
  color: var(--color-text-primary);
  font-size: 12px;
  cursor: pointer;
  transition: all 0.2s ease;
  min-width: 60px;
}

.demo-button:hover {
  background: var(--color-surface-tertiary);
  border-color: var(--color-border-secondary);
}
</style>
