<template>
  <div class="demo-tooltip">
    <div class="demo-section">
      <h3>手动控制</h3>
      <div class="demo-buttons">
        <HTTooltip content="手动控制的提示信息" trigger="manual" :visible="manualVisible" ref="tooltipRef">
          <HTButton>手动控制的按钮</HTButton>
        </HTTooltip>

        <HTButton type="primary" @click="showTooltip">显示提示</HTButton>

        <HTButton type="primary" @click="hideTooltip">隐藏提示</HTButton>

        <HTButton type="primary" @click="toggleTooltip">切换提示</HTButton>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import { HTButton, HTTooltip } from '@hytech/ht-ui';

const manualVisible = ref(false);
const tooltipRef = ref();

function showTooltip() {
  manualVisible.value = true;
  tooltipRef.value?.show();
}

function hideTooltip() {
  manualVisible.value = false;
  tooltipRef.value?.hide();
}

function toggleTooltip() {
  manualVisible.value = !manualVisible.value;
  tooltipRef.value?.toggle();
}
</script>

<style scoped>
.demo-tooltip {
  width: 100%;
  max-width: 600px;
  margin: 0 auto;
  padding: 16px;
  background: var(--color-surface-primary);
  border-radius: var(--dimensions-radius-sm);
}

.demo-section {
  margin-bottom: 24px;
}

.demo-section:last-child {
  margin-bottom: 0;
}

.demo-section h3 {
  margin: 0 0 16px 0;
  font-size: 16px;
  font-weight: 600;
  color: var(--color-content-primary);
}

.demo-buttons {
  display: flex;
  flex-wrap: wrap;
  gap: 12px;
  align-items: center;
}

.demo-button {
  padding: 8px 16px;
  border: 1px solid var(--color-border-default);
  border-radius: var(--dimensions-radius-sm);
  background: var(--color-surface-primary);
  color: var(--color-content-primary);
  font-size: 14px;
  cursor: pointer;
  transition: all 0.2s ease;
}

.demo-button:hover {
  border-color: var(--color-border-hover);
  background: var(--color-surface-hover);
}

.demo-button--primary {
  background: var(--color-primary);
  color: white;
  border-color: var(--color-primary);
}

.demo-button--primary:hover {
  background: var(--color-primary-hover);
  border-color: var(--color-primary-hover);
}
</style>
