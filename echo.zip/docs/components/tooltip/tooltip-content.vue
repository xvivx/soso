<template>
  <div class="demo-tooltip">
    <div class="demo-section">
      <h3>自定义内容</h3>
      <div class="demo-buttons">
        <HTTooltip>
          <template #content>
            <div class="custom-content">
              <div class="custom-title">自定义标题</div>
              <div class="custom-text">这是自定义的提示内容，可以包含更复杂的结构</div>
            </div>
          </template>
          <HTButton>自定义内容</HTButton>
        </HTTooltip>

        <HTTooltip>
          <template #content>
            <div class="custom-content">
              <div class="custom-icon">✨</div>
              <div class="custom-text">带图标的提示</div>
            </div>
          </template>
          <HTButton>带图标</HTButton>
        </HTTooltip>

        <HTTooltip>
          <template #content>
            <div class="custom-content">
              <div class="custom-title">操作提示</div>
              <div class="custom-text">按 Ctrl+C 复制</div>
              <div class="custom-text">按 Ctrl+V 粘贴</div>
            </div>
          </template>
          <HTButton>多行内容</HTButton>
        </HTTooltip>

        <HTTooltip theme="light">
          <template #content>
            <div class="custom-content">
              <div class="custom-badge">NEW</div>
              <div class="custom-text">这是一个新功能</div>
            </div>
          </template>
          <HTButton>带徽章</HTButton>
        </HTTooltip>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { HTButton, HTTooltip } from '@hytech/ht-ui';
</script>

<style scoped>
.demo-tooltip {
  width: 100%;
  max-width: 600px;
  margin: 0 auto;
  padding: 16px;
  background: var(--color-surface-primary);
  border-radius: var(--dimensions-radius-sm);
}

.demo-section {
  margin-bottom: 24px;
}

.demo-section:last-child {
  margin-bottom: 0;
}

.demo-section h3 {
  margin: 0 0 12px 0;
  font-size: 16px;
  font-weight: 600;
  color: var(--color-text-primary);
}

.demo-buttons {
  display: flex;
  flex-wrap: wrap;
  gap: 12px;
}

.demo-button {
  padding: 8px 16px;
  border: 1px solid var(--color-border-primary);
  border-radius: var(--dimensions-radius-xs);
  background: var(--color-surface-secondary);
  color: var(--color-text-primary);
  font-size: 14px;
  cursor: pointer;
  transition: all 0.2s ease;
}

.demo-button:hover {
  background: var(--color-surface-tertiary);
  border-color: var(--color-border-secondary);
}

.custom-content {
  display: flex;
  flex-direction: column;
  gap: 4px;
  align-items: flex-start;
}

.custom-title {
  font-weight: 600;
  font-size: 13px;
}

.custom-text {
  font-size: 12px;
  line-height: 1.4;
}

.custom-icon {
  font-size: 16px;
  margin-bottom: 2px;
}

.custom-badge {
  background: #f56c6c;
  color: white;
  font-size: 10px;
  padding: 2px 6px;
  border-radius: 10px;
  font-weight: 600;
}
</style>
