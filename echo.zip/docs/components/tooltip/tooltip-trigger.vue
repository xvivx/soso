<template>
  <div class="demo-tooltip">
    <div class="demo-section">
      <h3>触发方式</h3>
      <div class="demo-buttons">
        <HTTooltip content="鼠标悬停触发" trigger="hover">
          <HTButton>Hover 触发</HTButton>
        </HTTooltip>

        <HTTooltip content="点击触发" trigger="click">
          <HTButton>Click 触发</HTButton>
        </HTTooltip>

        <HTTooltip content="聚焦触发" trigger="focus">
          <HTButton>Focus 触发</HTButton>
        </HTTooltip>

        <HTTooltip content="手动控制显示" trigger="manual" :visible="manualVisible">
          <HTButton>Manual 触发</HTButton>
        </HTTooltip>

        <HTButton type="primary" @click="toggleManual"> {{ manualVisible ? '隐藏' : '显示' }} Manual Tooltip </HTButton>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import { HTButton, HTTooltip } from '@hytech/ht-ui';

const manualVisible = ref(false);

const toggleManual = () => {
  manualVisible.value = !manualVisible.value;
};
</script>

<style scoped>
.demo-tooltip {
  width: 100%;
  max-width: 600px;
  margin: 0 auto;
  padding: 16px;
  background: var(--color-surface-primary);
  border-radius: var(--dimensions-radius-sm);
}

.demo-section {
  margin-bottom: 24px;
}

.demo-section:last-child {
  margin-bottom: 0;
}

.demo-section h3 {
  margin: 0 0 12px 0;
  font-size: 16px;
  font-weight: 600;
  color: var(--color-text-primary);
}

.demo-buttons {
  display: flex;
  flex-wrap: wrap;
  gap: 12px;
}

.demo-button {
  padding: 8px 16px;
  border: 1px solid var(--color-border-primary);
  border-radius: var(--dimensions-radius-xs);
  background: var(--color-surface-secondary);
  color: var(--color-text-primary);
  font-size: 14px;
  cursor: pointer;
  transition: all 0.2s ease;
}

.demo-button:hover {
  background: var(--color-surface-tertiary);
  border-color: var(--color-border-secondary);
}

.demo-button--primary {
  background: var(--color-primary);
  color: white;
  border-color: var(--color-primary);
}

.demo-button--primary:hover {
  background: var(--color-primary-hover);
  border-color: var(--color-primary-hover);
}
</style>
