# HTTooltip 文字提示

在鼠标悬停时显示提示信息。

## 基础用法

最简单的用法，通过 `content` 属性设置提示内容。

<demo vue="./tooltip-basic.vue" codesandbox="true" />

## 不同位置

通过 `placement` 属性设置提示的显示位置。

<demo vue="./tooltip-placement.vue" codesandbox="true" />

## 主题风格

通过 `theme` 属性设置主题风格，支持 `dark` 和 `light` 两种主题。

<demo vue="./tooltip-theme.vue" codesandbox="true" />

## 触发方式

通过 `trigger` 属性设置触发方式，支持 `hover`、`click`、`focus` 和 `manual` 四种方式。

<demo vue="./tooltip-trigger.vue" codesandbox="true" />

## 延迟显示

通过 `show-delay` 和 `hide-delay` 属性设置延迟显示和隐藏的时间。

<demo vue="./tooltip-delay.vue" codesandbox="true" />

## 自定义内容

通过 `content` 插槽可以自定义提示内容。

<demo vue="./tooltip-content.vue" codesandbox="true" />

## 手动控制

当 `trigger` 为 `manual` 时，可以通过组件实例的方法手动控制显示和隐藏。

<demo vue="./tooltip-manual.vue" codesandbox="true" />

## 禁用状态

通过 `disabled` 属性禁用 Tooltip。

<demo vue="./tooltip-disabled.vue" codesandbox="true" />

## 移动端关闭按钮

在移动端或需要手动关闭的场景下，可以通过 `show-close-button` 属性显示关闭按钮。

<demo vue="./tooltip-close-button.vue" codesandbox="true" />

## API

### Props

| 参数 | 说明 | 类型 | 默认值 |
| --- | --- | --- | --- |
| content | 提示文字 | _string_ | `''` |
| placement | 出现位置 | _TooltipPlacement_ | `'top'` |
| visible | 是否显示 | _boolean_ | - |
| theme | 主题风格 | _'dark' \\| 'light'_ | `'dark'` |
| show-delay | 延迟显示，单位毫秒 | _number_ | `0` |
| hide-delay | 延迟隐藏，单位毫秒 | _number_ | `0` |
| offset | 偏移量 | _number_ | `8` |
| show-arrow | 是否显示箭头 | _boolean_ | `true` |
| show-close-button | 是否显示关闭按钮（移动端推荐） | _boolean_ | `false` |
| disabled | 是否禁用 | _boolean_ | `false` |
| trigger | 触发方式 | _'hover' \\| 'click' \\| 'focus' \\| 'manual'_ | `'hover'` |
| overlay-class | 自定义类名 | _string_ | `''` |
| overlay-style | 自定义样式 | _object_ | `{}` |
| close-on-click-outside | 是否在点击外部时关闭 | _boolean_ | `true` |

### TooltipPlacement

```ts
type TooltipPlacement = 
  | 'top' 
  | 'top-start' 
  | 'top-end'
  | 'bottom' 
  | 'bottom-start' 
  | 'bottom-end'
  | 'left' 
  | 'left-start' 
  | 'left-end'
  | 'right' 
  | 'right-start' 
  | 'right-end';
```

### Events

| 事件名 | 说明 | 回调参数 |
| --- | --- | --- |
| show | 显示时触发 | - |
| hide | 隐藏时触发 | - |
| update:visible | 显示状态改变时触发 | _visible: boolean_ |

### Slots

| 名称 | 说明 |
| --- | --- |
| default | 触发 Tooltip 的元素 |
| content | 自定义提示内容 |

### 方法

通过 ref 可以获取到 Tooltip 实例并调用实例方法。

| 方法名 | 说明 | 参数 | 返回值 |
| --- | --- | --- | --- |
| show | 显示 Tooltip | - | - |
| hide | 隐藏 Tooltip | - | - |
| toggle | 切换显示状态 | - | - |

## 主题定制

### CSS 变量

组件提供了下列 CSS 变量，可用于自定义样式。

| 名称 | 默认值 | 描述 |
| --- | --- | --- |
| --ht-tooltip-z-index | _2000_ | 层级 |
| --ht-tooltip-max-width | _300px_ | 最大宽度 |
| --ht-tooltip-padding-x | _12px_ | 水平内边距 |
| --ht-tooltip-padding-y | _6px_ | 垂直内边距 |
| --ht-tooltip-font-size | _12px_ | 字体大小 |
| --ht-tooltip-line-height | _1.4_ | 行高 |
| --ht-tooltip-border-radius | _6px_ | 圆角大小 |
| --ht-tooltip-arrow-size | _6px_ | 箭头大小 |
| --ht-tooltip-dark-bg | _#303133_ | 暗色主题背景色 |
| --ht-tooltip-dark-color | _#ffffff_ | 暗色主题文字颜色 |
| --ht-tooltip-light-bg | _#ffffff_ | 亮色主题背景色 |
| --ht-tooltip-light-color | _#606266_ | 亮色主题文字颜色 |
| --ht-tooltip-light-border | _#e4e7ed_ | 亮色主题边框颜色 |
| --ht-tooltip-light-shadow | _0 2px 12px 0 rgba(0, 0, 0, 0.1)_ | 亮色主题阴影 |
| --ht-tooltip-animation-duration | _0.15s_ | 动画持续时间 |
| --ht-tooltip-animation-timing | _cubic-bezier(0.4, 0, 0.2, 1)_ | 动画时间函数 |