# HTTooltip 文字提示

在鼠标悬停时显示提示信息。

## 基础用法

最简单的用法，通过 `content` 属性设置提示内容。

<demo vue="./tooltip-basic.vue" codesandbox="true" />

## 不同位置

通过 `placement` 属性设置提示的显示位置。

<demo vue="./tooltip-placement.vue" codesandbox="true" />

## 主题风格

通过 `theme` 属性设置主题风格，支持 `dark` 和 `light` 两种主题。

<demo vue="./tooltip-theme.vue" codesandbox="true" />

## 触发方式

通过 `trigger` 属性设置触发方式，支持 `hover`、`click`、`focus` 和 `manual` 四种方式。

<demo vue="./tooltip-trigger.vue" codesandbox="true" />

## 延迟显示

通过 `show-delay` 和 `hide-delay` 属性设置延迟显示和隐藏的时间。

<demo vue="./tooltip-delay.vue" codesandbox="true" />

## 自定义内容

通过 `content` 插槽可以自定义提示内容。

<demo vue="./tooltip-content.vue" codesandbox="true" />

## 手动控制

当 `trigger` 为 `manual` 时，可以通过组件实例的方法手动控制显示和隐藏。

<demo vue="./tooltip-manual.vue" codesandbox="true" />

## 禁用状态

通过 `disabled` 属性禁用 Tooltip。

<demo vue="./tooltip-disabled.vue" codesandbox="true" />

## 移动端关闭按钮

在移动端或需要手动关闭的场景下，可以通过 `show-close-button` 属性显示关闭按钮。

<demo vue="./tooltip-close-button.vue" codesandbox="true" />

## API

### Props

| 参数 | 说明 | 类型 | 默认值 | 与 Vant 差异 |
| --- | --- | --- | --- | --- |
| content | 提示文字 | _string_ | `''` | ✅ 兼容 |
| placement | 出现位置 | _TooltipPlacement_ | `'top'` | ✅ 兼容 |
| visible | 是否显示 | _boolean_ | - | ✅ 兼容 |
| theme | 主题风格 | _'dark' \\| 'light'_ | `'dark'` | ✅ 兼容 |
| trigger | 触发方式 | _'hover' \\| 'click' \\| 'focus' \\| 'manual'_ | `'hover'` | ✅ 兼容 |
| show-arrow | 是否显示箭头 | _boolean_ | `true` | ✅ 兼容 |
| disabled | 是否禁用 | _boolean_ | `false` | ✅ 兼容 |
| show-delay | 延迟显示，单位毫秒 | _number_ | `0` | ✅ 兼容 |
| hide-delay | 延迟隐藏，单位毫秒 | _number_ | `0` | ✅ 兼容 |
| offset | 偏移量 | _number_ | `8` | ✅ 兼容 |
| popper-class | 自定义弹出层类名 | _string_ | `''` | ⚠️ 属性名差异：Vant 为 `overlay-class` |
| popper-style | 自定义弹出层样式 | _object_ | `{}` | ⚠️ 属性名差异：Vant 为 `overlay-style` |
| append-to-body | 是否插入到 body 元素 | _boolean_ | `true` | ✨ HTTooltip 独有 |
| destroy-on-hide | 隐藏时是否销毁 | _boolean_ | `false` | ✨ HTTooltip 独有 |
| max-width | 最大宽度 | _string \\| number_ | `300` | ✨ HTTooltip 独有 |
| show-close-button | 是否显示关闭按钮（移动端推荐） | _boolean_ | `false` | ✨ HTTooltip 独有 |

### TooltipPlacement

```ts
type TooltipPlacement = 
  | 'top' 
  | 'top-start' 
  | 'top-end'
  | 'bottom' 
  | 'bottom-start' 
  | 'bottom-end'
  | 'left' 
  | 'left-start' 
  | 'left-end'
  | 'right' 
  | 'right-start' 
  | 'right-end';
```

### Events

| 事件名 | 说明 | 回调参数 | 与 Vant 差异 |
| --- | --- | --- | --- |
| show | 显示时触发 | - | ✅ 兼容 |
| hide | 隐藏时触发 | - | ✅ 兼容 |
| update:visible | 显示状态改变时触发 | _visible: boolean_ | ✅ 兼容 |
| close | 点击关闭按钮时触发 | - | ✨ HTTooltip 独有 |

### Slots

| 名称 | 说明 | 与 Vant 差异 |
| --- | --- | --- |
| default | 触发 Tooltip 的元素 | ✅ 兼容 |
| content | 自定义提示内容 | ✅ 兼容 |

### Methods

通过 ref 可以获取到 Tooltip 实例并调用实例方法。

| 方法名 | 说明 | 参数 | 返回值 | 与 Vant 差异 |
| --- | --- | --- | --- | --- |
| show | 显示 Tooltip | - | - | ✅ 兼容 |
| hide | 隐藏 Tooltip | - | - | ✅ 兼容 |
| toggle | 切换显示状态 | - | - | ✅ 兼容 |

## 主题定制

### CSS 变量

组件提供了下列 CSS 变量，可用于自定义样式。

| 名称 | 默认值 | 描述 |
| --- | --- | --- |
| --ht-tooltip-z-index | _2000_ | 层级 |
| --ht-tooltip-max-width | _300px_ | 最大宽度 |
| --ht-tooltip-padding-x | _12px_ | 水平内边距 |
| --ht-tooltip-padding-y | _6px_ | 垂直内边距 |
| --ht-tooltip-font-size | _12px_ | 字体大小 |
| --ht-tooltip-line-height | _1.4_ | 行高 |
| --ht-tooltip-border-radius | _6px_ | 圆角大小 |
| --ht-tooltip-arrow-size | _6px_ | 箭头大小 |
| --ht-tooltip-dark-bg | _#303133_ | 暗色主题背景色 |
| --ht-tooltip-dark-color | _#ffffff_ | 暗色主题文字颜色 |
| --ht-tooltip-light-bg | _#ffffff_ | 亮色主题背景色 |
| --ht-tooltip-light-color | _#606266_ | 亮色主题文字颜色 |
| --ht-tooltip-light-border | _#e4e7ed_ | 亮色主题边框颜色 |
| --ht-tooltip-light-shadow | _0 2px 12px 0 rgba(0, 0, 0, 0.1)_ | 亮色主题阴影 |
| --ht-tooltip-animation-duration | _0.15s_ | 动画持续时间 |
| --ht-tooltip-animation-timing | _cubic-bezier(0.4, 0, 0.2, 1)_ | 动画时间函数 |

## Vant API 兼容性

| API 类型 | 兼容性 | 说明 |
| --- | --- | --- |
| Props | 🟡 部分兼容 | 大部分属性兼容，部分属性名有差异 |
| Events | 🟢 完全兼容 | 支持所有 Vant 事件，并新增了 `close` 事件 |
| Slots | 🟢 完全兼容 | 支持所有 Vant 插槽 |
| Methods | 🟢 完全兼容 | 支持所有 Vant 方法 |

### 主要差异

1. **属性名差异**：
   - `overlay-class` → `popper-class`
   - `overlay-style` → `popper-style`

2. **新增功能**：
   - 支持 `show-close-button` 属性，适用于移动端场景
   - 支持 `append-to-body`、`destroy-on-hide`、`max-width` 等配置
   - 新增 `close` 事件

## 注意事项

1. 在移动端使用时，建议开启 `show-close-button` 属性以提供更好的用户体验
2. 当使用 `manual` 触发方式时，需要通过组件实例的方法手动控制显示和隐藏
3. `placement` 属性支持 12 个方向，可以根据实际需求选择合适的位置
4. 组件会自动处理边界检测，当空间不足时会自动调整位置