<script setup lang="ts">
import { HTIcon } from '@hytech/ht-ui';
</script>

<template>
  <HTIcon name="https://fastly.jsdelivr.net/npm/@vant/assets/icon-demo.png" />
</template>
