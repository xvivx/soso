<script setup lang="ts">
import { HTIcon } from '@hytech/ht-ui';
</script>

<template>
  <div class="flex items-end gap-4">
    <HTIcon name="search-line" size="16px" />
    <HTIcon name="search-line" size="24px" />
    <HTIcon name="search-line" size="32px" />
  </div>
</template>
