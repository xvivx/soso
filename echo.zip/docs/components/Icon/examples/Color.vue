<script setup lang="ts">
import { HTIcon } from '@hytech/ht-ui';
</script>

<template>
  <div class="flex items-center gap-4">
    <HTIcon name="search" color="#f43f5e" />
    <HTIcon name="user" color="#3b82f6" />
  </div>
</template>
