<script setup lang="ts">
import { HTIcon } from '@hytech/ht-ui';

// Icon names are derived from the CSS classes in `src/components/icon/style/icon.css`.
// Keep this list in sync with the .ht-icon-... rules defined there.
const icons = [
  'minus-line-sm',
  'plus-line-sm',
  'check-line-sm',
  'close-line-sm',
  'arrow-down-s-line',
  'info-circle-line',
  'tips-fill',
  'placeholder',
  'checkout-line',
  'eye-line',
  'search-line',
  'eye-close-line',
];
</script>

<template>
  <div class="grid grid-cols-4 gap-6">
    <div v-for="name in icons" :key="name" class="flex flex-col items-center justify-center gap-2 rounded p-3">
      <HTIcon :name="name" class="text-2xl" />
      <div class="muted-foreground text-center text-xs break-words">{{ name }}</div>
    </div>
  </div>
</template>
