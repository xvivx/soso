# HTIcon 图标

基于字体的图标集

## 基础用法

通过 name 属性来指定需要使用的图标。 <demo vue="./examples/Basic.vue" codesandbox="true" />

## 使用图片 URL

你也可以直接在 name 属性中传入一个图片 URL 来作为图标。 <demo vue="./examples/ImageUrl.vue" codesandbox="true" />

## 图标颜色

使用 color 属性来改变图标颜色，也可以通过 classPrefix 自定义类名前缀。
<demo vue="./examples/Color.vue" codesandbox="true" />

## 图标大小

通过 size 属性来设置图标的尺寸大小，可以指定任意 CSS 单位。 <demo vue="./examples/Size.vue" codesandbox="true" />

## 自定义图标

如果需要在现有 Icon 的基础上使用更多图标，可以引入第三方 iconfont 对应的字体文件和 CSS 文件，之后就可以在 Icon 组件中直接使用。

```ts
/* 引入第三方或自定义的字体图标样式 */
@font-face {
  font-family: 'my-icon';
  src: url('./my-icon.ttf') format('truetype');
}

.my-icon {
  font-family: 'my-icon';
}

.my-icon-extra::before {
  content: '\e626';
}
```

### Props

| 参数         | 说明                                 | 类型               | 默认值    |
| ------------ | ------------------------------------ | ------------------ | --------- |
| name         | 图标名称或图片链接。                 | `string`           | -         |
| color        | 图标颜色                             | `string`           | -         |
| size         | 图标大小，如 20px 2em，默认单位为 px | `number \| string` | -         |
| class-prefix | 类名前缀，用于使用自定义图标         | `string`           | `ht-icon` |
| tag          | 根节点对应的 HTML 标签名             | string             | `i`       |

### Events

| 事件名 | 说明           | 参数                |
| ------ | -------------- | ------------------- |
| click  | 点击图标时触发 | `event: MouseEvent` |

### Slots

| 名称    | 说明                                               |
| ------- | -------------------------------------------------- |
| default | 插槽内容会替代 `name` 的渲染，通常用于传入内联 SVG |

### 类型定义

组件导出以下类型定义：

```ts
import type { IconProps } from '@hytech/ht-ui';
```
