<script setup lang="ts">
import { ref } from 'vue';
import { HTList } from '@hytech/ht-ui';

const list = ref<number[]>([]);
const error = ref(false);
const loading = ref(false);
const onLoad = () => {
  setTimeout(() => {
    for (let i = 0; i < 10; i++) {
      list.value.push(list.value.length + 1);
    }

    // 加载状态结束
    loading.value = false;

    // 数据加载出错
    if (list.value.length >= 10) {
      error.value = true;
    }
  }, 1000);
};
</script>

<template>
  <div class="h-[200px] overflow-auto">
    <HTList v-model:loading="loading" v-model:error="error" error-text="请求失败，点击重新加载" @load="onLoad">
      <div v-for="item in list" :key="item" class="border-b border-[#ebedf0] p-2">
        {{ item }}
      </div>
    </HTList>
  </div>
</template>
