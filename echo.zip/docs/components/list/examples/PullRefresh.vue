<script setup lang="ts">
import { ref } from 'vue';
import { HTCell, HTList, HTPullRefresh } from '@hytech/ht-ui';

const list = ref<number[]>([]);
const loading = ref(false);
const finished = ref(false);
const refreshing = ref(false);

const onLoad = () => {
  setTimeout(() => {
    if (refreshing.value) {
      list.value = [];
      refreshing.value = false;
    }

    for (let i = 0; i < 10; i++) {
      list.value.push(list.value.length + 1);
    }
    loading.value = false;

    if (list.value.length >= 40) {
      finished.value = true;
    }
  }, 1000);
};

const onRefresh = () => {
  // 清空列表数据
  finished.value = false;

  // 重新加载数据
  // 将 loading 设置为 true，表示处于加载状态
  loading.value = true;
  onLoad();
};
</script>

<template>
  <div class="h-[200px] overflow-auto">
    <HTPullRefresh v-model="refreshing" @refresh="onRefresh">
      <HTList v-model:loading="loading" :finished="finished" finished-text="没有更多了" @load="onLoad">
        <HTCell v-for="item in list" :key="item" :title="String(item)" />
      </HTList>
    </HTPullRefresh>
  </div>
</template>
