# HTList 列表

瀑布流滚动加载，用于展示长列表，当列表即将滚动到底部时，会触发事件并加载更多列表项。

## 基础用法

List 组件通过 loading 和 finished 两个变量控制加载状态，当组件滚动到底部时，会触发 load 事件并将 loading 设置成 true。此时可以发起异步操作并更新数据，数据更新完毕后，将 loading 设置成 false 即可。若数据已全部加载完毕，则直接将 finished 设置成 true 即可。
<demo vue="./examples/basic.vue" codesandbox="true" />

## 错误提示

若列表数据加载失败，将 error 设置成 true 即可显示错误提示，用户点击错误提示后会重新触发 load 事件。
<demo vue="./examples/Error.vue" codesandbox="true" />

## 下拉刷新

List 组件可以与 [PullRefresh 组件](/components/pull-refresh/) 组件结合使用，实现下拉刷新的效果。
<demo vue="./examples/PullRefresh.vue" codesandbox="true" />

### Props

| 参数            | 说明                                                         | 类型               | 默认值               |
| --------------- | ------------------------------------------------------------ | ------------------ | -------------------- |
| v-model:loading | 是否处于加载状态，加载过程中不触发 `load` 事件               | `boolean`          | `false`              |
| v-model:error   | 是否加载失败，加载失败后点击错误提示可以重新触发 `load` 事件 | `boolean`          | `false`              |
| finished        | 是否已加载完成，加载完成后不再触发 `load` 事件               | `boolean`          | `false`              |
| offset          | 滚动条与底部距离小于 offset 时触发 load 事件                 | `number \| string` | `300`                |
| loading-text    | 加载过程中的提示文案                                         | `string`           | `加载中...`          |
| finished-text   | 加载完成后的提示文案                                         | `string`           | `没有更多了`         |
| error-text      | 加载失败后的提示文案                                         | `string`           | `加载失败，点击重试` |
| immediate-check | 是否在初始化时立即执行滚动位置检查                           | `boolean`          | `true`               |

### Events

| 事件名 | 说明                               | 参数 |
| ------ | ---------------------------------- | ---- |
| load   | 滚动条与底部距离小于 offset 时触发 | -    |

### Slots

| 名称     | 说明                       |
| -------- | -------------------------- |
| default  | 列表内容                   |
| loading  | 自定义底部加载中提示       |
| error    | 自定义加载完成后的提示文案 |
| finished | 自定义加载失败后的提示文案 |

### 类型定义

组件导出以下类型定义：

```ts
import type { ListInstance, ListProps } from '@hytech/ht-ui';
```
