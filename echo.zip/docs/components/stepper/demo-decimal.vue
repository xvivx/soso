<template>
  <HTStepper v-model="value" :min="0" :max="10" :step="0.1" :decimal-length="1" />
</template>
<script setup lang="ts">
import { ref } from 'vue';
import { HTStepper } from '@hytech/ht-ui';

const value = ref(2.5);
</script>
