<template>
  <HTStepper v-model="value" :min="0" :max="20" :step="5" />
</template>
<script setup lang="ts">
import { ref } from 'vue';
import { HTStepper } from '@hytech/ht-ui';

const value = ref(10);
</script>
