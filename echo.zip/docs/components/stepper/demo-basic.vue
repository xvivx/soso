<template>
  <HTStepper v-model="value" :min="1" :max="10" :step="1" placeholder="请输入内容" />
</template>

<script setup lang="ts">
import { ref } from 'vue';
import { HTStepper } from '@hytech/ht-ui';

const value = ref(1);
</script>
