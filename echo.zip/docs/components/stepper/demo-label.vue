<template>
  <HTStepper v-model="value" :min="0" :max="10" label="数量" />
</template>
<script setup lang="ts">
import { ref } from 'vue';
import { HTStepper } from '@hytech/ht-ui';

const value = ref(2);
</script>
