# Stepper 步进器

用于在数值输入场景中，进行加减操作。

## 基本用法

<demo vue="./demo-basic.vue" codesandbox="true" />

## 输入框标签

<demo vue="./demo-label.vue" codesandbox="true" />

## 禁用状态

<demo vue="./demo-disabled.vue" codesandbox="true"  />

## 小数步长

<demo vue="./demo-decimal.vue" codesandbox="true"  />

### 最大/最小值限制

<demo vue="./demo-min-max.vue" codesandbox="true" />

## 步长设置

<demo vue="./demo-step.vue" codesandbox="true" />

## 属性

| 属性名        | 说明         | 类型          | 默认值   |
| ------------- | ------------ | ------------- | -------- |
| modelValue    | 当前值       | number        | 0        |
| min           | 最小值       | number        | 0        |
| max           | 最大值       | number        | Infinity |
| step          | 步长         | number        | 1        |
| disabled      | 是否禁用     | boolean       | false    |
| inputWidth    | 输入框宽度   | string/number | 100%     |
| decimalLength | 保留小数位数 | number        | -        |
| name          | 标识符       | string        | -        |
| size          | 尺寸         | string        | -        |
| disableInput  | 禁用输入框   | boolean       | false    |
| beforeChange  | 修改前回调   | Function      | -        |
| defaultValue  | 默认值       | number        | 0        |
| allowEmpty    | 允许空值     | boolean       | false    |
| placeholder   | 输入框占位符 | string        | -        |
| label         | 输入框标签   | string        | -        |

## 事件

| 事件名            | 说明         | 回调参数           |
| ----------------- | ------------ | ------------------ |
| update:modelValue | 值变化时触发 | value              |
| change            | 值变化时触发 | value              |
| blur              | 输入框失焦时 | event              |
| focus             | 输入框聚焦时 | event              |
| overlimit         | 超出限制时   | type（plus/minus） |
| plus              | 点击加号时   | -                  |
| minus             | 点击减号时   | -                  |
