<template>
  <div class="demo-config-provider-basic">
    <HTConfigProvider theme="light" locale="zh-CN">
      <div class="space-y-4">
        <div class="rounded-lg border bg-white p-4">
          <h3 class="mb-2 text-lg font-medium">基础配置</h3>
          <p class="mb-4 text-gray-600">使用默认的 light 主题和中文语言环境</p>
          <div class="flex gap-2">
            <button class="rounded bg-blue-500 px-4 py-2 text-white hover:bg-blue-600">主要按钮</button>
            <button class="rounded bg-gray-200 px-4 py-2 text-gray-700 hover:bg-gray-300">次要按钮</button>
          </div>
        </div>

        <div class="rounded-lg border bg-gray-50 p-4">
          <h3 class="mb-2 text-lg font-medium">配置信息</h3>
          <div class="space-y-2 text-sm">
            <p><strong>主题:</strong> {{ currentTheme }}</p>
            <p><strong>语言:</strong> {{ currentLocale }}</p>
            <p><strong>图标前缀:</strong> {{ iconPrefix }}</p>
          </div>
        </div>
      </div>
    </HTConfigProvider>
  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue';
import { HTConfigProvider } from '@/components/config-provider';
import { useConfigProvider } from '@/components/config-provider/useConfigProvider';

// 使用配置获取当前配置信息
const config = useConfigProvider();

const currentTheme = computed(() => config.theme.value);
const currentLocale = computed(() => config.locale.value);
const iconPrefix = computed(() => config.iconPrefix.value);
</script>

<style scoped>
.demo-config-provider-basic {
  width: 100%;
  max-width: 800px;
  margin: 0 auto;
  padding: 20px;
}
</style>
