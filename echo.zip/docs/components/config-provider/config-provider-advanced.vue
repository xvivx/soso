<template>
  <div class="demo-config-provider-advanced">
    <HTConfigProvider
      :theme="config.theme"
      :theme-vars="config.themeVars"
      :theme-vars-scope="config.themeVarsScope"
      :z-index="config.zIndex"
      :icon-prefix="config.iconPrefix"
      :locale="config.locale"
      :tag="config.tag"
    >
      <div class="space-y-6">
        <!-- 配置控制面板 -->
        <div class="rounded-lg border bg-white p-4">
          <h3 class="mb-4 text-lg font-medium">高级配置控制</h3>

          <!-- 主题配置 -->
          <div class="mb-4 grid grid-cols-1 gap-4 md:grid-cols-2">
            <div>
              <label class="mb-2 block text-sm font-medium">主题模式</label>
              <select
                v-model="config.theme"
                class="w-full rounded-md border border-gray-300 px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:outline-none"
              >
                <option value="light">浅色主题</option>
                <option value="dark">深色主题</option>
                <option value="auto">跟随系统</option>
              </select>
            </div>

            <div>
              <label class="mb-2 block text-sm font-medium">CSS 变量作用域</label>
              <select
                v-model="config.themeVarsScope"
                class="w-full rounded-md border border-gray-300 px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:outline-none"
              >
                <option value="local">局部作用域</option>
                <option value="global">全局作用域</option>
              </select>
            </div>

            <div>
              <label class="mb-2 block text-sm font-medium">Z-index 基础值</label>
              <input
                v-model.number="config.zIndex"
                type="number"
                min="0"
                max="9999"
                class="w-full rounded-md border border-gray-300 px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:outline-none"
              />
            </div>

            <div>
              <label class="mb-2 block text-sm font-medium">图标前缀</label>
              <input
                v-model="config.iconPrefix"
                type="text"
                class="w-full rounded-md border border-gray-300 px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:outline-none"
              />
            </div>

            <div>
              <label class="mb-2 block text-sm font-medium">语言代码</label>
              <select
                v-model="config.locale"
                class="w-full rounded-md border border-gray-300 px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:outline-none"
              >
                <option value="zh-CN">简体中文</option>
                <option value="zh-TW">繁體中文</option>
                <option value="en-US">English</option>
                <option value="ja-JP">日本語</option>
              </select>
            </div>

            <div>
              <label class="mb-2 block text-sm font-medium">根标签</label>
              <select
                v-model="config.tag"
                class="w-full rounded-md border border-gray-300 px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:outline-none"
              >
                <option value="div">div</option>
                <option value="section">section</option>
                <option value="main">main</option>
                <option value="article">article</option>
              </select>
            </div>
          </div>

          <div class="flex gap-2">
            <button @click="resetConfig" class="rounded bg-gray-500 px-4 py-2 text-white hover:bg-gray-600">
              重置配置
            </button>
            <button @click="exportConfig" class="rounded bg-blue-500 px-4 py-2 text-white hover:bg-blue-600">
              导出配置
            </button>
            <button
              @click="showConfigJson = !showConfigJson"
              class="rounded bg-green-500 px-4 py-2 text-white hover:bg-green-600"
            >
              {{ showConfigJson ? '隐藏' : '显示' }}配置JSON
            </button>
          </div>
        </div>

        <!-- 配置JSON显示 -->
        <div v-if="showConfigJson" class="rounded-lg border bg-gray-50 p-4">
          <h3 class="mb-4 text-lg font-medium">当前配置 JSON</h3>
          <div class="overflow-x-auto rounded-lg bg-gray-900 p-4 text-gray-100">
            <pre class="text-sm"><code>{{ JSON.stringify(config, null, 2) }}</code></pre>
          </div>
        </div>

        <!-- 层级演示 -->
        <div class="rounded-lg border bg-white p-4">
          <h3 class="mb-4 text-lg font-medium">Z-index 层级演示</h3>
          <div class="relative h-64 rounded bg-gray-100">
            <div
              class="absolute rounded bg-blue-500 p-3 text-white"
              :style="{
                zIndex: config.zIndex + 1,
                top: '20px',
                left: '20px',
              }"
            >
              层级 {{ config.zIndex + 1 }}
            </div>
            <div
              class="absolute rounded bg-green-500 p-3 text-white"
              :style="{
                zIndex: config.zIndex + 2,
                top: '40px',
                left: '40px',
              }"
            >
              层级 {{ config.zIndex + 2 }}
            </div>
            <div
              class="absolute rounded bg-red-500 p-3 text-white"
              :style="{
                zIndex: config.zIndex + 3,
                top: '60px',
                left: '60px',
              }"
            >
              层级 {{ config.zIndex + 3 }}
            </div>
          </div>
          <p class="mt-2 text-sm text-gray-600">基础 Z-index: {{ config.zIndex }}，所有弹窗层级将在基础上递增</p>
        </div>

        <!-- 图标前缀演示 -->
        <div class="rounded-lg border bg-white p-4">
          <h3 class="mb-4 text-lg font-medium">图标前缀演示</h3>
          <div class="space-y-4">
            <div class="flex items-center gap-4">
              <div class="flex h-8 w-8 items-center justify-center rounded bg-blue-500 text-white">
                <i :class="`${config.iconPrefix}-user`"></i>
              </div>
              <span>用户图标 ({{ config.iconPrefix }}-user)</span>
            </div>
            <div class="flex items-center gap-4">
              <div class="flex h-8 w-8 items-center justify-center rounded bg-green-500 text-white">
                <i :class="`${config.iconPrefix}-settings`"></i>
              </div>
              <span>设置图标 ({{ config.iconPrefix }}-settings)</span>
            </div>
            <div class="flex items-center gap-4">
              <div class="flex h-8 w-8 items-center justify-center rounded bg-red-500 text-white">
                <i :class="`${config.iconPrefix}-bell`"></i>
              </div>
              <span>通知图标 ({{ config.iconPrefix }}-bell)</span>
            </div>
          </div>
        </div>

        <!-- 组件集成演示 -->
        <div class="rounded-lg border bg-white p-4">
          <h3 class="mb-4 text-lg font-medium">组件集成演示</h3>
          <div class="grid grid-cols-1 gap-4 md:grid-cols-2">
            <!-- 模拟弹窗 -->
            <div>
              <h4 class="mb-2 text-sm font-medium">模拟弹窗 (Z-index: {{ config.zIndex + 100 }})</h4>
              <div
                class="rounded-lg border p-4 shadow-lg"
                :style="{ zIndex: config.zIndex + 100, position: 'relative' }"
              >
                <h5 class="mb-2 font-medium">弹窗标题</h5>
                <p class="mb-3 text-sm text-gray-600">这是一个模拟弹窗，展示 Z-index 配置的效果。</p>
                <div class="flex gap-2">
                  <button class="rounded bg-blue-500 px-3 py-1 text-sm text-white hover:bg-blue-600">确认</button>
                  <button class="rounded bg-gray-300 px-3 py-1 text-sm text-gray-700 hover:bg-gray-400">取消</button>
                </div>
              </div>
            </div>

            <!-- 模拟抽屉 -->
            <div>
              <h4 class="mb-2 text-sm font-medium">模拟抽屉 (Z-index: {{ config.zIndex + 200 }})</h4>
              <div
                class="rounded-lg border bg-gray-50 p-4 shadow-lg"
                :style="{ zIndex: config.zIndex + 200, position: 'relative' }"
              >
                <h5 class="mb-2 font-medium">抽屉内容</h5>
                <p class="mb-3 text-sm text-gray-600">抽屉通常具有比弹窗更高的层级。</p>
                <div class="space-y-2">
                  <div class="rounded bg-white p-2 text-sm">菜单项 1</div>
                  <div class="rounded bg-white p-2 text-sm">菜单项 2</div>
                  <div class="rounded bg-white p-2 text-sm">菜单项 3</div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- 主题变量作用域演示 -->
        <div class="rounded-lg border bg-white p-4">
          <h3 class="mb-4 text-lg font-medium">主题变量作用域: {{ config.themeVarsScope }}</h3>
          <div class="grid grid-cols-1 gap-4 md:grid-cols-2">
            <div class="rounded-lg border p-4">
              <h4 class="mb-2 text-sm font-medium">ConfigProvider 内部</h4>
              <p class="mb-3 text-sm text-gray-600">这些组件会受到 ConfigProvider 的主题变量影响。</p>
              <div class="space-y-2">
                <div
                  class="rounded p-3 text-center font-medium text-white"
                  :style="{ backgroundColor: 'var(--config-provider-primary-color, #1677ff)' }"
                >
                  主要按钮
                </div>
                <div
                  class="rounded p-3 text-center font-medium text-white"
                  :style="{ backgroundColor: 'var(--config-provider-success-color, #52c41a)' }"
                >
                  成功按钮
                </div>
              </div>
            </div>

            <div class="rounded-lg border p-4">
              <h4 class="mb-2 text-sm font-medium">ConfigProvider 外部 (模拟)</h4>
              <p class="mb-3 text-sm text-gray-600">这些组件不受 ConfigProvider 影响（当作用域为 local 时）。</p>
              <div class="space-y-2">
                <div class="rounded bg-blue-500 p-3 text-center font-medium text-white">默认按钮</div>
                <div class="rounded bg-green-500 p-3 text-center font-medium text-white">默认成功</div>
              </div>
            </div>
          </div>
        </div>

        <!-- 根标签演示 -->
        <div class="rounded-lg border bg-white p-4">
          <h3 class="mb-4 text-lg font-medium">根标签: &lt;{{ config.tag }}&gt;</h3>
          <p class="mb-3 text-sm text-gray-600">ConfigProvider 使用 {{ config.tag }} 标签作为根元素包裹内容。</p>
          <div class="rounded bg-gray-100 p-3 font-mono text-sm">
            &lt;{{ config.tag }} class="ht-config-provider"&gt;<br />
            &nbsp;&nbsp;<!-- 你的内容 --><br />
            &lt;/{{ config.tag }}&gt;
          </div>
        </div>
      </div>
    </HTConfigProvider>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import { HTConfigProvider } from '@/components/config-provider';

const showConfigJson = ref(false);

const config = ref({
  theme: 'light' as const,
  themeVars: {
    primaryColor: '#1677ff',
    successColor: '#52c41a',
    warningColor: '#faad14',
    dangerColor: '#ff4d4f',
  },
  themeVarsScope: 'local' as const,
  zIndex: 1000,
  iconPrefix: 'ht-icon',
  locale: 'zh-CN',
  tag: 'div' as const,
});

const defaultConfig = {
  theme: 'light',
  themeVars: {
    primaryColor: '#1677ff',
    successColor: '#52c41a',
    warningColor: '#faad14',
    dangerColor: '#ff4d4f',
  },
  themeVarsScope: 'local',
  zIndex: 1000,
  iconPrefix: 'ht-icon',
  locale: 'zh-CN',
  tag: 'div',
};

const resetConfig = () => {
  config.value = { ...defaultConfig };
};

const exportConfig = () => {
  const configStr = JSON.stringify(config.value, null, 2);
  const blob = new Blob([configStr], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'config-provider-config.json';
  a.click();
  URL.revokeObjectURL(url);
};
</script>

<style scoped>
.demo-config-provider-advanced {
  width: 100%;
  max-width: 1200px;
  margin: 0 auto;
  padding: 20px;
}

/* 图标样式模拟 */
[class^='ht-icon-']::before {
  content: '◉';
  font-size: 16px;
}

.ht-icon-user::before {
  content: '👤';
}

.ht-icon-settings::before {
  content: '⚙️';
}

.ht-icon-bell::before {
  content: '🔔';
}
</style>
