<template>
  <div class="demo-config-provider-theme">
    <HTConfigProvider :theme="selectedTheme" :theme-vars="currentThemeVars">
      <div class="space-y-6">
        <!-- 主题切换控制 -->
        <div class="rounded-lg border bg-white p-4">
          <h3 class="mb-4 text-lg font-medium">主题切换</h3>
          <div class="mb-4 flex flex-wrap gap-2">
            <button
              v-for="theme in themes"
              :key="theme.value"
              @click="selectedTheme = theme.value"
              :class="[
                'rounded px-4 py-2 transition-colors',
                selectedTheme === theme.value
                  ? 'bg-blue-500 text-white'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200',
              ]"
            >
              {{ theme.label }}
            </button>
          </div>
          <p class="text-sm text-gray-600">
            当前主题: <span class="font-medium">{{ getThemeLabel(selectedTheme) }}</span>
          </p>
        </div>

        <!-- 组件展示区域 -->
        <div class="rounded-lg border bg-white p-4">
          <h3 class="mb-4 text-lg font-medium">组件展示</h3>
          <div class="grid grid-cols-1 gap-4 md:grid-cols-2">
            <!-- 按钮示例 -->
            <div class="space-y-2">
              <h4 class="text-sm font-medium text-gray-700">按钮组件</h4>
              <div class="flex flex-wrap gap-2">
                <button class="rounded bg-blue-500 px-4 py-2 text-white hover:bg-blue-600">主要按钮</button>
                <button class="rounded bg-green-500 px-4 py-2 text-white hover:bg-green-600">成功按钮</button>
                <button class="rounded bg-yellow-500 px-4 py-2 text-white hover:bg-yellow-600">警告按钮</button>
                <button class="rounded bg-red-500 px-4 py-2 text-white hover:bg-red-600">危险按钮</button>
              </div>
            </div>

            <!-- 输入框示例 -->
            <div class="space-y-2">
              <h4 class="text-sm font-medium text-gray-700">输入框组件</h4>
              <input
                type="text"
                placeholder="请输入内容"
                class="w-full rounded border border-gray-300 px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:outline-none"
              />
            </div>

            <!-- 卡片示例 -->
            <div class="space-y-2">
              <h4 class="text-sm font-medium text-gray-700">卡片组件</h4>
              <div class="rounded-lg border p-4">
                <h5 class="mb-2 font-medium">卡片标题</h5>
                <p class="text-sm text-gray-600">这是一个卡片示例，展示主题对组件样式的影响。</p>
              </div>
            </div>

            <!-- 标签示例 -->
            <div class="space-y-2">
              <h4 class="text-sm font-medium text-gray-700">标签组件</h4>
              <div class="flex flex-wrap gap-2">
                <span class="rounded-full bg-blue-100 px-3 py-1 text-sm text-blue-800">默认</span>
                <span class="rounded-full bg-green-100 px-3 py-1 text-sm text-green-800">成功</span>
                <span class="rounded-full bg-yellow-100 px-3 py-1 text-sm text-yellow-800">警告</span>
                <span class="rounded-full bg-red-100 px-3 py-1 text-sm text-red-800">错误</span>
              </div>
            </div>
          </div>
        </div>

        <!-- 主题变量信息 -->
        <div class="rounded-lg border bg-gray-50 p-4">
          <h3 class="mb-4 text-lg font-medium">主题变量</h3>
          <div class="grid grid-cols-1 gap-4 text-sm md:grid-cols-2">
            <div>
              <h4 class="mb-2 font-medium">颜色变量</h4>
              <ul class="space-y-1">
                <li>
                  主色: <span class="font-mono">{{ currentThemeVars.primaryColor }}</span>
                </li>
                <li>
                  成功色: <span class="font-mono">{{ currentThemeVars.successColor }}</span>
                </li>
                <li>
                  警告色: <span class="font-mono">{{ currentThemeVars.warningColor }}</span>
                </li>
                <li>
                  错误色: <span class="font-mono">{{ currentThemeVars.dangerColor }}</span>
                </li>
              </ul>
            </div>
            <div>
              <h4 class="mb-2 font-medium">尺寸变量</h4>
              <ul class="space-y-1">
                <li>
                  字体大小: <span class="font-mono">{{ currentThemeVars.fontSizeMd }}</span>
                </li>
                <li>
                  内边距: <span class="font-mono">{{ currentThemeVars.paddingMd }}</span>
                </li>
                <li>
                  圆角: <span class="font-mono">{{ currentThemeVars.radiusMd }}</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </HTConfigProvider>
  </div>
</template>

<script setup lang="ts">
import { computed, ref } from 'vue';
import { HTConfigProvider } from '@/components/config-provider';

const selectedTheme = ref<'light' | 'dark' | 'auto'>('light');

const themes: { value: 'light' | 'dark' | 'auto'; label: string }[] = [
  { value: 'light', label: '浅色主题' },
  { value: 'dark', label: '深色主题' },
  { value: 'auto', label: '跟随系统' },
];

const getThemeLabel = (theme: 'light' | 'dark' | 'auto') => {
  const found = themes.find((t) => t.value === theme);
  return found ? found.label : theme;
};

// 根据主题返回对应的 CSS 变量
const currentThemeVars = computed(() => {
  const baseVars = {
    fontSizeMd: '14px',
    paddingMd: '12px',
    radiusMd: '4px',
    borderWidth: '1px',
    durationBase: '0.3s',
    durationFast: '0.2s',
  };

  switch (selectedTheme.value) {
    case 'light':
      return {
        ...baseVars,
        // 基础颜色
        black: '#000000',
        white: '#ffffff',
        gray1: '#f7f8fa',
        gray2: '#f2f3f5',
        gray3: '#e5e6eb',
        gray4: '#c9cdd4',
        gray5: '#8c8c8c',
        gray6: '#595959',
        gray7: '#434343',
        gray8: '#262626',

        // 品牌色
        red: '#ff4d4f',
        blue: '#1677ff',
        orange: '#faad14',
        orangeDark: '#d48806',
        orangeLight: '#fff7e6',
        green: '#52c41a',

        // 组件颜色
        primaryColor: '#1677ff',
        successColor: '#52c41a',
        warningColor: '#faad14',
        dangerColor: '#ff4d4f',
        textColor: '#333333',
        textColor2: '#666666',
        textColor3: '#999999',
        activeColor: '#1677ff',
        background: '#ffffff',
        background2: '#fafafa',

        // 按钮变量
        buttonContainerHeightDefault: '44px',
        buttonContainerHeightLarge: '52px',
        buttonContainerHeightSmall: '36px',
        buttonContainerHeightMini: '28px',
        buttonTextFontSizeDefault: '16px',
        buttonTextFontSizeLarge: '18px',
        buttonTextFontSizeSmall: '14px',
        buttonTextFontSizeMini: '12px',

        // 弹窗变量
        popupContainerZIndexDefault: 2000,
        popupContainerBorderRadiusDefault: '16px',
        popupContainerBoxShadowDefault: '0 4px 16px rgba(0, 0, 0, 0.1)',
      };
    case 'dark':
      return {
        ...baseVars,
        // 基础颜色
        black: '#000000',
        white: '#ffffff',
        gray1: '#1f1f1f',
        gray2: '#2f2f2f',
        gray3: '#3f3f3f',
        gray4: '#4f4f4f',
        gray5: '#6f6f6f',
        gray6: '#8f8f8f',
        gray7: '#afafaf',
        gray8: '#cfcfcf',

        // 品牌色
        red: '#ff7875',
        blue: '#1890ff',
        orange: '#faad14',
        orangeDark: '#d48806',
        orangeLight: '#fff7e6',
        green: '#52c41a',

        // 组件颜色
        primaryColor: '#1890ff',
        successColor: '#52c41a',
        warningColor: '#faad14',
        dangerColor: '#ff4d4f',
        textColor: '#ffffff',
        textColor2: '#a0a0a0',
        textColor3: '#7a7a7a',
        activeColor: '#1890ff',
        background: '#1f1f1f',
        background2: '#2f2f2f',

        // 按钮变量
        buttonContainerHeightDefault: '44px',
        buttonContainerHeightLarge: '52px',
        buttonContainerHeightSmall: '36px',
        buttonContainerHeightMini: '28px',
        buttonTextFontSizeDefault: '16px',
        buttonTextFontSizeLarge: '18px',
        buttonTextFontSizeSmall: '14px',
        buttonTextFontSizeMini: '12px',

        // 弹窗变量
        popupContainerZIndexDefault: 2000,
        popupContainerBorderRadiusDefault: '16px',
        popupContainerBoxShadowDefault: '0 4px 16px rgba(0, 0, 0, 0.3)',
      };
    default:
      return {
        ...baseVars,
        primaryColor: '#1677ff',
        successColor: '#52c41a',
        warningColor: '#faad14',
        dangerColor: '#ff4d4f',
        textColor: '#333333',
        background: '#ffffff',
      };
  }
});
</script>

<style scoped>
.demo-config-provider-theme {
  width: 100%;
  max-width: 1000px;
  margin: 0 auto;
  padding: 20px;
}

/* 深色主题样式 */
:global(.dark) .demo-config-provider-theme {
  background-color: #1f1f1f;
  color: #ffffff;
}

:global(.dark) .demo-config-provider-theme .bg-white {
  background-color: #2f2f2f;
}

:global(.dark) .demo-config-provider-theme .text-gray-600 {
  color: #a0a0a0;
}

:global(.dark) .demo-config-provider-theme .text-gray-700 {
  color: #b0b0b0;
}

:global(.dark) .demo-config-provider-theme .border {
  border-color: #404040;
}

:global(.dark) .demo-config-provider-theme .bg-gray-50 {
  background-color: #2f2f2f;
}

:global(.dark) .demo-config-provider-theme .bg-gray-100 {
  background-color: #3f3f3f;
}
</style>
