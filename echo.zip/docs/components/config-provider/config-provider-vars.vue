<template>
  <div class="demo-config-provider-vars">
    <HTConfigProvider :theme-vars="customThemeVars">
      <div class="space-y-6">
        <!-- 自定义变量配置 -->
        <div class="rounded-lg border bg-white p-4">
          <h3 class="mb-4 text-lg font-medium">CSS 变量定制</h3>
          <div class="mb-4 grid grid-cols-1 gap-4 md:grid-cols-2">
            <div>
              <label class="mb-2 block text-sm font-medium">主色调</label>
              <input v-model="customThemeVars.primaryColor" type="color" class="h-10 w-full cursor-pointer rounded" />
            </div>
            <div>
              <label class="mb-2 block text-sm font-medium">成功色</label>
              <input v-model="customThemeVars.successColor" type="color" class="h-10 w-full cursor-pointer rounded" />
            </div>
            <div>
              <label class="mb-2 block text-sm font-medium">警告色</label>
              <input v-model="customThemeVars.warningColor" type="color" class="h-10 w-full cursor-pointer rounded" />
            </div>
            <div>
              <label class="mb-2 block text-sm font-medium">危险色</label>
              <input v-model="customThemeVars.dangerColor" type="color" class="h-10 w-full cursor-pointer rounded" />
            </div>
          </div>
          <div class="flex gap-2">
            <button @click="resetToDefault" class="rounded bg-gray-500 px-4 py-2 text-white hover:bg-gray-600">
              重置默认
            </button>
            <button @click="applyBrandTheme" class="rounded bg-blue-500 px-4 py-2 text-white hover:bg-blue-600">
              应用品牌主题
            </button>
            <button @click="applyDarkTheme" class="rounded bg-gray-800 px-4 py-2 text-white hover:bg-gray-900">
              应用深色主题
            </button>
          </div>
        </div>

        <!-- 组件预览 -->
        <div class="rounded-lg border bg-white p-4">
          <h3 class="mb-4 text-lg font-medium">组件预览</h3>
          <div class="space-y-4">
            <!-- 按钮组 -->
            <div>
              <h4 class="mb-2 text-sm font-medium">按钮组件</h4>
              <div class="flex flex-wrap gap-2">
                <button
                  class="rounded px-4 py-2 text-white transition-opacity hover:opacity-90"
                  :style="{ backgroundColor: customThemeVars.primaryColor }"
                >
                  主要按钮
                </button>
                <button
                  class="rounded px-4 py-2 text-white transition-opacity hover:opacity-90"
                  :style="{ backgroundColor: customThemeVars.successColor }"
                >
                  成功按钮
                </button>
                <button
                  class="rounded px-4 py-2 text-white transition-opacity hover:opacity-90"
                  :style="{ backgroundColor: customThemeVars.warningColor }"
                >
                  警告按钮
                </button>
                <button
                  class="rounded px-4 py-2 text-white transition-opacity hover:opacity-90"
                  :style="{ backgroundColor: customThemeVars.dangerColor }"
                >
                  危险按钮
                </button>
              </div>
            </div>

            <!-- 标签组 -->
            <div>
              <h4 class="mb-2 text-sm font-medium">标签组件</h4>
              <div class="flex flex-wrap gap-2">
                <span
                  class="rounded-full px-3 py-1 text-sm font-medium"
                  :style="{
                    backgroundColor: `${customThemeVars.primaryColor}20`,
                    color: customThemeVars.primaryColor,
                  }"
                >
                  主要标签
                </span>
                <span
                  class="rounded-full px-3 py-1 text-sm font-medium"
                  :style="{
                    backgroundColor: `${customThemeVars.successColor}20`,
                    color: customThemeVars.successColor,
                  }"
                >
                  成功标签
                </span>
                <span
                  class="rounded-full px-3 py-1 text-sm font-medium"
                  :style="{
                    backgroundColor: `${customThemeVars.warningColor}20`,
                    color: customThemeVars.warningColor,
                  }"
                >
                  警告标签
                </span>
                <span
                  class="rounded-full px-3 py-1 text-sm font-medium"
                  :style="{
                    backgroundColor: `${customThemeVars.dangerColor}20`,
                    color: customThemeVars.dangerColor,
                  }"
                >
                  危险标签
                </span>
              </div>
            </div>

            <!-- 进度条 -->
            <div>
              <h4 class="mb-2 text-sm font-medium">进度条组件</h4>
              <div class="space-y-2">
                <div class="h-2 w-full rounded-full bg-gray-200">
                  <div
                    class="h-2 rounded-full transition-all duration-300"
                    :style="{
                      width: '75%',
                      backgroundColor: customThemeVars.primaryColor,
                    }"
                  ></div>
                </div>
                <div class="h-2 w-full rounded-full bg-gray-200">
                  <div
                    class="h-2 rounded-full transition-all duration-300"
                    :style="{
                      width: '60%',
                      backgroundColor: customThemeVars.successColor,
                    }"
                  ></div>
                </div>
                <div class="h-2 w-full rounded-full bg-gray-200">
                  <div
                    class="h-2 rounded-full transition-all duration-300"
                    :style="{
                      width: '40%',
                      backgroundColor: customThemeVars.warningColor,
                    }"
                  ></div>
                </div>
              </div>
            </div>

            <!-- 状态指示器 -->
            <div>
              <h4 class="mb-2 text-sm font-medium">状态指示器</h4>
              <div class="flex items-center gap-4">
                <div class="flex items-center gap-2">
                  <div class="h-3 w-3 rounded-full" :style="{ backgroundColor: customThemeVars.successColor }"></div>
                  <span class="text-sm">成功状态</span>
                </div>
                <div class="flex items-center gap-2">
                  <div class="h-3 w-3 rounded-full" :style="{ backgroundColor: customThemeVars.warningColor }"></div>
                  <span class="text-sm">警告状态</span>
                </div>
                <div class="flex items-center gap-2">
                  <div class="h-3 w-3 rounded-full" :style="{ backgroundColor: customThemeVars.dangerColor }"></div>
                  <span class="text-sm">错误状态</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- CSS 变量值显示 -->
        <div class="rounded-lg border bg-gray-50 p-4">
          <h3 class="mb-4 text-lg font-medium">当前 CSS 变量值</h3>
          <div class="overflow-x-auto rounded-lg bg-gray-900 p-4 text-gray-100">
            <pre class="text-sm"><code>{{ cssVariablesCode }}</code></pre>
          </div>
        </div>
      </div>
    </HTConfigProvider>
  </div>
</template>

<script setup lang="ts">
import { computed, ref } from 'vue';
import { HTConfigProvider } from '@/components/config-provider';

const customThemeVars = ref({
  primaryColor: '#1677ff',
  successColor: '#52c41a',
  warningColor: '#faad14',
  dangerColor: '#ff4d4f',
});

const defaultThemeVars = {
  primaryColor: '#1677ff',
  successColor: '#52c41a',
  warningColor: '#faad14',
  dangerColor: '#ff4d4f',
};

const brandThemeVars = {
  primaryColor: '#1890ff',
  successColor: '#52c41a',
  warningColor: '#faad14',
  dangerColor: '#f5222d',
};

const darkThemeVars = {
  primaryColor: '#177ddc',
  successColor: '#49aa19',
  warningColor: '#d89614',
  dangerColor: '#d32029',
};

const resetToDefault = () => {
  customThemeVars.value = { ...defaultThemeVars };
};

const applyBrandTheme = () => {
  customThemeVars.value = { ...brandThemeVars };
};

const applyDarkTheme = () => {
  customThemeVars.value = { ...darkThemeVars };
};

const cssVariablesCode = computed(() => {
  return `.ht-config-provider {
  /* 颜色变量 */
  --config-provider-primary-color: ${customThemeVars.value.primaryColor};
  --config-provider-success-color: ${customThemeVars.value.successColor};
  --config-provider-warning-color: ${customThemeVars.value.warningColor};
  --config-provider-danger-color: ${customThemeVars.value.dangerColor};

  /* 按钮变量 */
  --config-provider-button-bg-color-primary: ${customThemeVars.value.primaryColor};
  --config-provider-button-bg-color-success: ${customThemeVars.value.successColor};
  --config-provider-button-bg-color-warning: ${customThemeVars.value.warningColor};
  --config-provider-button-bg-color-danger: ${customThemeVars.value.dangerColor};
}`;
});
</script>

<style scoped>
.demo-config-provider-vars {
  width: 100%;
  max-width: 1000px;
  margin: 0 auto;
  padding: 20px;
}

input[type='color'] {
  border: 1px solid #d1d5db;
  border-radius: 6px;
}

input[type='color']::-webkit-color-swatch-wrapper {
  padding: 0;
}

input[type='color']::-webkit-color-swatch {
  border: none;
  border-radius: 4px;
}
</style>
