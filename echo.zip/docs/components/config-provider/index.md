# HTConfigProvider 全局配置

全局配置组件，用于提供应用级别的主题、国际化、CSS变量等配置。参照 Element 与 Vant 的结合式用法。
todo: 还在实现中的功能
- 支持主题切换（light、dark、auto）
- 支持 CSS 变量定制


## 基础用法

<demo vue="./config-provider-basic.vue" codesandbox="true" />

## 主题配置

支持 light、dark、auto 三种主题模式，可以全局切换应用主题。

<demo vue="./config-provider-theme.vue" codesandbox="true" />

## CSS变量定制

通过 themeVars 属性可以自定义组件的 CSS 变量，实现个性化的主题定制。

<demo vue="./config-provider-vars.vue" codesandbox="true" />

## 国际化配置

内置多语言支持，可以轻松切换应用语言。

<demo vue="./config-provider-locale.vue" codesandbox="true" />

## 高级配置

展示完整的配置选项，包括 Z-index 管理、图标前缀等。

<demo vue="./config-provider-advanced.vue" codesandbox="true" />

## Attributes

| Attribute | Description | Type | Default | Vant 兼容 |
| --- | --- | --- | --- | --- |
| `tag` | 配置提供商的标签名 | `string` | `'div'` | ✅ |
| `theme` | 主题模式 | `'light' \| 'dark' \| 'auto'` | `'light'` | ✅ |
| `theme-vars` | 浅色主题 CSS 变量 | `Partial<ThemeVars>` | `{}` | ✅ |
| `theme-vars-dark` | 深色主题 CSS 变量 | `Partial<ThemeVars>` | `{}` | ✅ |
| `theme-vars-light` | 浅色主题 CSS 变量 | `Partial<ThemeVars>` | `{}` | ✅ |
| `theme-vars-scope` | CSS 变量作用域 | `'local' \| 'global'` | `'local'` | ✅ |
| `z-index` | 全局 Z-index 基础值 | `number` | `undefined` | ✅ |
| `icon-prefix` | 图标类名前缀 | `string` | `'ht-icon'` | ✅ |
| `locale` | 语言代码 | `string` | `'zh-CN'` | ✅ |

## Slots

| Slot | Description | Parameters | Vant 兼容 |
| --- | --- | --- | --- |
| `default` | 默认插槽，包裹需要配置的子组件 | - | ✅ |

## Methods

ConfigProvider 通过依赖注入系统向子组件提供配置，子组件可以通过 `useConfigProvider` hook 获取配置。

```typescript
import { useConfigProvider } from 'ht-ui'

const config = useConfigProvider()
console.log(config.theme.value) // 当前主题
console.log(config.locale.value) // 当前语言
```

## 主题定制

基于项目的 H5组件三级token.md 规范，支持以下 CSS 变量定制。

**注意**: TypeScript 接口中的 camelCase 属性名会自动转换为 kebab-case CSS 变量名。例如：
- `buttonContainerHeightDefault` → `--config-provider-button-container-height-default`
- `popupContainerZIndexDefault` → `--config-provider-popup-container-z-index-default`

### 基础颜色变量

```css
.ht-config-provider {
  /* 基础颜色 */
  --config-provider-black: #000000;
  --config-provider-white: #ffffff;
  --config-provider-gray1: #f7f8fa;
  --config-provider-gray2: #f2f3f5;
  --config-provider-gray3: #e5e6eb;
  --config-provider-gray4: #c9cdd4;
  --config-provider-gray5: #8c8c8c;
  --config-provider-gray6: #595959;
  --config-provider-gray7: #434343;
  --config-provider-gray8: #262626;

  /* 品牌色 */
  --config-provider-red: #ff4d4f;
  --config-provider-blue: #1677ff;
  --config-provider-orange: #faad14;
  --config-provider-orange-dark: #d48806;
  --config-provider-orange-light: #fff7e6;
  --config-provider-green: #52c41a;

  /* 渐变色 */
  --config-provider-gradient-red: linear-gradient(135deg, #ff6b6b 0%, #ee5a24 100%);
  --config-provider-gradient-orange: linear-gradient(135deg, #feca57 0%, #ff9ff3 100%);

  /* 组件颜色 */
  --config-provider-primary-color: #1677ff;
  --config-provider-success-color: #52c41a;
  --config-provider-danger-color: #ff4d4f;
  --config-provider-warning-color: #faad14;
  --config-provider-text-color: #333333;
  --config-provider-text-color2: #666666;
  --config-provider-text-color3: #999999;
  --config-provider-active-color: #1677ff;
  --config-provider-active-opacity: 0.7;
  --config-provider-disabled-opacity: 0.5;
  --config-provider-background: #ffffff;
  --config-provider-background2: #fafafa;
}
```

### 间距变量

```css
.ht-config-provider {
  --config-provider-padding-base: 8px;
  --config-provider-padding-xs: 4px;
  --config-provider-padding-sm: 6px;
  --config-provider-padding-md: 12px;
  --config-provider-padding-lg: 16px;
  --config-provider-padding-xl: 24px;
}
```

### 字体变量

```css
.ht-config-provider {
  --config-provider-font-size-xs: 10px;
  --config-provider-font-size-sm: 12px;
  --config-provider-font-size-md: 14px;
  --config-provider-font-size-lg: 16px;
  --config-provider-font-bold: 500;
  --config-provider-line-height-xs: 18px;
  --config-provider-line-height-sm: 20px;
  --config-provider-line-height-md: 22px;
  --config-provider-line-height-lg: 24px;
  --config-provider-base-font: -apple-system, BlinkMacSystemFont, 'Helvetica Neue', Helvetica, Segoe UI, Arial, Roboto, 'PingFang SC', 'miui', 'Hiragino Sans GB', 'Microsoft Yahei', sans-serif;
  --config-provider-price-font: DIN-Medium, 'PingFang SC', sans-serif;
}
```

### 动画变量

```css
.ht-config-provider {
  --config-provider-duration-base: 0.3s;
  --config-provider-duration-fast: 0.2s;
  --config-provider-ease-out: cubic-bezier(0.215, 0.61, 0.355, 1);
  --config-provider-ease-in: cubic-bezier(0.55, 0.055, 0.675, 0.19);
}
```

### 边框变量

```css
.ht-config-provider {
  --config-provider-border-color: #eeeeee;
  --config-provider-border-width: 1px;
  --config-provider-radius-sm: 2px;
  --config-provider-radius-md: 4px;
  --config-provider-radius-lg: 8px;
  --config-provider-radius-max: 999px;
}
```

### 按钮变量

```css
.ht-config-provider {
  /* 按钮容器尺寸 */
  --config-provider-button-container-height-default: 44px;
  --config-provider-button-container-height-large: 52px;
  --config-provider-button-container-height-small: 36px;
  --config-provider-button-container-height-mini: 28px;

  /* 按钮容器内边距 */
  --config-provider-button-container-padding-default: 0 24px;
  --config-provider-button-container-padding-large: 0 32px;
  --config-provider-button-container-padding-small: 0 16px;
  --config-provider-button-container-padding-mini: 0 8px;

  /* 按钮容器圆角 */
  --config-provider-button-container-border-radius-default: 8px;
  --config-provider-button-container-border-radius-round: 999px;
  --config-provider-button-container-border-radius-square: 4px;

  /* 按钮背景色 */
  --config-provider-button-bg-color-primary: #1677ff;
  --config-provider-button-bg-color-primary-hover: #0f62d9;
  --config-provider-button-bg-color-primary-active: #0a58c9;
  --config-provider-button-bg-color-success: #52c41a;
  --config-provider-button-bg-color-warning: #faad14;
  --config-provider-button-bg-color-danger: #ff4d4f;
  --config-provider-button-bg-color-info: #8c8c8c;
  --config-provider-button-bg-color-light: #f5f5f5;
  --config-provider-button-bg-color-plain: transparent;
  --config-provider-button-bg-color-text: transparent;

  /* 按钮边框色 */
  --config-provider-button-border-color-primary: #1677ff;
  --config-provider-button-border-color-success: #52c41a;
  --config-provider-button-border-color-plain: #1677ff;

  /* 按钮字体大小 */
  --config-provider-button-text-font-size-default: 16px;
  --config-provider-button-text-font-size-large: 18px;
  --config-provider-button-text-font-size-small: 14px;
  --config-provider-button-text-font-size-mini: 12px;
  --config-provider-button-text-font-weight-default: 500;

  /* 按钮图标 */
  --config-provider-button-icon-size-default: 18px;
  --config-provider-button-icon-gap-default: 8px;

  /* 按钮状态 */
  --config-provider-button-bg-color-disabled: #f5f5f5;
  --config-provider-button-text-color-disabled: #8c8c8c;
  --config-provider-button-border-color-disabled: #c9cdd4;
  --config-provider-button-opacity-disabled: 0.5;
  --config-provider-button-transform-active: scale(0.96);
  --config-provider-button-loading-size-default: 18px;
  --config-provider-button-loading-color-default: #ffffff;
  --config-provider-button-loading-color-dark: #333333;
}
```

### 弹窗变量

```css
.ht-config-provider {
  /* 弹窗容器 */
  --config-provider-popup-container-position-default: fixed;
  --config-provider-popup-container-z-index-default: 2000;
  --config-provider-popup-container-width-default: 280px;
  --config-provider-popup-container-max-width-default: 90vw;
  --config-provider-popup-container-height-default: auto;
  --config-provider-popup-container-max-height-default: 80vh;
  --config-provider-popup-container-padding-default: 16px;
  --config-provider-popup-container-bg-color-default: #ffffff;
  --config-provider-popup-container-border-radius-default: 16px;
  --config-provider-popup-container-box-shadow-default: 0 4px 16px rgba(0, 0, 0, 0.1);
  --config-provider-popup-container-transition-duration: 0.3s;

  /* 弹窗遮罩 */
  --config-provider-popup-mask-bg-color-default: rgba(0, 0, 0, 0.5);
  --config-provider-popup-mask-opacity-default: 1;
  --config-provider-popup-mask-transition-duration: 0.3s;

  /* 弹窗状态 */
  --config-provider-popup-container-opacity-hidden: 0;
  --config-provider-popup-container-transform-hidden: translateY(20px);
}
```

### 对话框变量

```css
.ht-config-provider {
  /* 对话框容器 */
  --config-provider-dialog-container-z-index-default: 2000;
  --config-provider-dialog-container-width-default: 280px;
  --config-provider-dialog-container-max-width-default: 90vw;
  --config-provider-dialog-container-padding-default: 24px;
  --config-provider-dialog-container-bg-color-default: #ffffff;
  --config-provider-dialog-container-border-radius-default: 16px;
  --config-provider-dialog-container-box-shadow-default: 0 4px 16px rgba(0, 0, 0, 0.1);

  /* 对话框头部 */
  --config-provider-dialog-header-title-font-size-default: 18px;
  --config-provider-dialog-header-title-color-default: #333333;
  --config-provider-dialog-header-title-font-weight-default: 500;
  --config-provider-dialog-header-close-icon-size-default: 16px;
  --config-provider-dialog-header-close-icon-color-default: #8c8c8c;

  /* 对话框内容 */
  --config-provider-dialog-content-font-size-default: 14px;
  --config-provider-dialog-content-color-default: #666666;
  --config-provider-dialog-content-line-height-default: 1.5;
  --config-provider-dialog-content-margin-default: 8px 0 24px;

  /* 对话框按钮 */
  --config-provider-dialog-button-group-gap-default: 8px;
  --config-provider-dialog-button-height-default: 44px;
  --config-provider-dialog-button-font-size-default: 16px;
  --config-provider-dialog-button-color-default: #333333;
  --config-provider-dialog-button-color-primary: #1677ff;
  --config-provider-dialog-button-border-radius-default: 8px;

  /* 对话框状态 */
  --config-provider-dialog-container-opacity-hidden: 0;
  --config-provider-dialog-container-transform-hidden: scale(0.95);
  --config-provider-dialog-container-transition-duration: 0.3s;
}
```

### 遮罩层变量

```css
.ht-config-provider {
  /* 遮罩容器 */
  --config-provider-overlay-container-position-default: fixed;
  --config-provider-overlay-container-z-index-default: 1000;
  --config-provider-overlay-container-width-default: 100%;
  --config-provider-overlay-container-height-default: 100%;
  --config-provider-overlay-container-bg-color-default: rgba(0, 0, 0, 0.5);
  --config-provider-overlay-container-opacity-default: 1;
  --config-provider-overlay-container-opacity-hidden: 0;

  /* 遮罩动画 */
  --config-provider-overlay-transition-duration: 0.3s;
  --config-provider-overlay-transition-timing-function: ease-in-out;
}
```

## Vant API 兼容性

| Vant API | HT 实现 | 说明 |
| --- | --- | --- |
| theme | ✅ 完全兼容 | 支持 light、dark、auto 主题 |
| theme-vars | ✅ 完全兼容 | CSS 变量定制功能一致 |
| theme-vars-scope | ✅ 完全兼容 | 支持局部和全局作用域 |
| locale | ✅ 完全兼容 | 国际化配置完全兼容 |
| z-index | ✅ 完全兼容 | 全局 Z-index 管理 |
| icon-prefix | ✅ 完全兼容 | 图标前缀配置 |
| tag | ✅ 完全兼容 | 根标签配置 |

## 最佳实践

### 1. 全局配置

在应用根部使用 ConfigProvider 进行全局配置：

```vue
<template>
  <HTConfigProvider
    :theme="theme"
    :theme-vars="themeVars"
    :locale="currentLocale"
    :z-index="2000"
  >
    <App />
  </HTConfigProvider>
</template>
```

### 2. 主题切换

结合系统偏好实现自动主题切换：

```vue
<script setup>
import { computed } from 'vue'

const theme = computed(() => {
  if (prefersDark.value) return 'dark'
  if (prefersLight.value) return 'light'
  return 'auto'
})
</script>
```

### 3. CSS变量定制

根据品牌规范定制主题变量：

```typescript
const themeVars = {
  primaryColor: '#1890ff',
  successColor: '#52c41a',
  warningColor: '#faad14',
  dangerColor: '#f5222d',
}
```

### 4. 国际化配置

```typescript
import { Locale } from 'ht-ui'

// 切换语言
Locale.use('en-US')

// 在 ConfigProvider 中使用
<HTConfigProvider locale="en-US">
  <App />
</HTConfigProvider>
```
