<template>
  <div class="demo-config-provider-locale">
    <HTConfigProvider :locale="currentLocale">
      <div class="space-y-6">
        <!-- 语言切换 -->
        <div class="rounded-lg border bg-white p-4">
          <h3 class="mb-4 text-lg font-medium">语言切换</h3>
          <div class="mb-4 grid grid-cols-2 gap-2 md:grid-cols-4">
            <button
              v-for="locale in locales"
              :key="locale.code"
              @click="switchLanguage(locale.code)"
              :class="[
                'rounded px-3 py-2 text-sm font-medium transition-colors',
                currentLocale === locale.code
                  ? 'bg-blue-500 text-white'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200',
              ]"
            >
              {{ locale.name }}
            </button>
          </div>
          <p class="text-sm text-gray-600">
            当前语言: <span class="font-medium">{{ getCurrentLocaleName() }}</span>
          </p>
        </div>

        <!-- 格式化示例 -->
        <div class="rounded-lg border bg-white p-4">
          <h3 class="mb-4 text-lg font-medium">日期时间格式化</h3>
          <div class="grid grid-cols-1 gap-4 md:grid-cols-2">
            <div>
              <h4 class="mb-2 text-sm font-medium">短日期格式</h4>
              <div class="rounded bg-gray-50 p-3 font-mono text-sm">
                {{ formatDate('short') }}
              </div>
            </div>
            <div>
              <h4 class="mb-2 text-sm font-medium">长日期格式</h4>
              <div class="rounded bg-gray-50 p-3 font-mono text-sm">
                {{ formatDate('long') }}
              </div>
            </div>
            <div>
              <h4 class="mb-2 text-sm font-medium">时间格式</h4>
              <div class="rounded bg-gray-50 p-3 font-mono text-sm">
                {{ formatDate('time') }}
              </div>
            </div>
            <div>
              <h4 class="mb-2 text-sm font-medium">完整格式</h4>
              <div class="rounded bg-gray-50 p-3 font-mono text-sm">
                {{ formatDate('full') }}
              </div>
            </div>
          </div>
        </div>

        <!-- 数字格式化 -->
        <div class="rounded-lg border bg-white p-4">
          <h3 class="mb-4 text-lg font-medium">数字格式化</h3>
          <div class="grid grid-cols-1 gap-4 md:grid-cols-3">
            <div>
              <h4 class="mb-2 text-sm font-medium">整数</h4>
              <div class="rounded bg-gray-50 p-3 font-mono text-sm">
                {{ formatNumber(1234567) }}
              </div>
            </div>
            <div>
              <h4 class="mb-2 text-sm font-medium">小数</h4>
              <div class="rounded bg-gray-50 p-3 font-mono text-sm">
                {{ formatNumber(1234.5678, 2) }}
              </div>
            </div>
            <div>
              <h4 class="mb-2 text-sm font-medium">货币</h4>
              <div class="rounded bg-gray-50 p-3 font-mono text-sm">
                {{ formatCurrency(1234.56) }}
              </div>
            </div>
          </div>
        </div>

        <!-- 常用文本 -->
        <div class="rounded-lg border bg-white p-4">
          <h3 class="mb-4 text-lg font-medium">常用文本</h3>
          <div class="grid grid-cols-1 gap-4 md:grid-cols-2">
            <div>
              <h4 class="mb-2 text-sm font-medium">操作按钮</h4>
              <div class="space-y-2">
                <div class="flex items-center justify-between rounded bg-gray-50 p-2">
                  <span class="text-sm">确认</span>
                  <span class="font-mono text-sm">{{ getText('confirm') }}</span>
                </div>
                <div class="flex items-center justify-between rounded bg-gray-50 p-2">
                  <span class="text-sm">取消</span>
                  <span class="font-mono text-sm">{{ getText('cancel') }}</span>
                </div>
                <div class="flex items-center justify-between rounded bg-gray-50 p-2">
                  <span class="text-sm">删除</span>
                  <span class="font-mono text-sm">{{ getText('delete') }}</span>
                </div>
                <div class="flex items-center justify-between rounded bg-gray-50 p-2">
                  <span class="text-sm">编辑</span>
                  <span class="font-mono text-sm">{{ getText('edit') }}</span>
                </div>
              </div>
            </div>
            <div>
              <h4 class="mb-2 text-sm font-medium">状态文本</h4>
              <div class="space-y-2">
                <div class="flex items-center justify-between rounded bg-gray-50 p-2">
                  <span class="text-sm">加载中</span>
                  <span class="font-mono text-sm">{{ getText('loading') }}</span>
                </div>
                <div class="flex items-center justify-between rounded bg-gray-50 p-2">
                  <span class="text-sm">成功</span>
                  <span class="font-mono text-sm">{{ getText('success') }}</span>
                </div>
                <div class="flex items-center justify-between rounded bg-gray-50 p-2">
                  <span class="text-sm">失败</span>
                  <span class="font-mono text-sm">{{ getText('fail') }}</span>
                </div>
                <div class="flex items-center justify-between rounded bg-gray-50 p-2">
                  <span class="text-sm">无数据</span>
                  <span class="font-mono text-sm">{{ getText('empty') }}</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- 表单验证信息 -->
        <div class="rounded-lg border bg-white p-4">
          <h3 class="mb-4 text-lg font-medium">表单验证信息</h3>
          <div class="space-y-3">
            <div class="rounded border border-red-200 bg-red-50 p-3">
              <div class="flex items-center gap-2">
                <div class="h-4 w-4 rounded-full bg-red-500"></div>
                <span class="text-sm font-medium">{{ getText('required') }}</span>
              </div>
            </div>
            <div class="rounded border border-yellow-200 bg-yellow-50 p-3">
              <div class="flex items-center gap-2">
                <div class="h-4 w-4 rounded-full bg-yellow-500"></div>
                <span class="text-sm font-medium">{{ getText('invalid') }}</span>
              </div>
            </div>
            <div class="rounded border border-blue-200 bg-blue-50 p-3">
              <div class="flex items-center gap-2">
                <div class="h-4 w-4 rounded-full bg-blue-500"></div>
                <span class="text-sm font-medium">{{ getText('minLength', { min: 6 }) }}</span>
              </div>
            </div>
          </div>
        </div>

        <!-- 实际应用示例 -->
        <div class="rounded-lg border bg-white p-4">
          <h3 class="mb-4 text-lg font-medium">实际应用示例</h3>
          <div class="rounded-lg bg-gray-50 p-4">
            <h4 class="mb-3 text-sm font-medium">用户列表</h4>
            <div class="overflow-x-auto">
              <table class="w-full text-sm">
                <thead>
                  <tr class="border-b">
                    <th class="py-2 text-left">{{ getText('name') }}</th>
                    <th class="py-2 text-left">{{ getText('email') }}</th>
                    <th class="py-2 text-left">{{ getText('status') }}</th>
                    <th class="py-2 text-left">{{ getText('actions') }}</th>
                  </tr>
                </thead>
                <tbody>
                  <tr class="border-b">
                    <td class="py-2">张三</td>
                    <td class="py-2">zhangsan@example.com</td>
                    <td class="py-2">
                      <span class="rounded bg-green-100 px-2 py-1 text-xs text-green-800">
                        {{ getText('active') }}
                      </span>
                    </td>
                    <td class="py-2">
                      <button class="mr-2 text-blue-500 hover:text-blue-700">
                        {{ getText('edit') }}
                      </button>
                      <button class="text-red-500 hover:text-red-700">
                        {{ getText('delete') }}
                      </button>
                    </td>
                  </tr>
                  <tr class="border-b">
                    <td class="py-2">李四</td>
                    <td class="py-2">lisi@example.com</td>
                    <td class="py-2">
                      <span class="rounded bg-gray-100 px-2 py-1 text-xs text-gray-800">
                        {{ getText('inactive') }}
                      </span>
                    </td>
                    <td class="py-2">
                      <button class="mr-2 text-blue-500 hover:text-blue-700">
                        {{ getText('edit') }}
                      </button>
                      <button class="text-red-500 hover:text-red-700">
                        {{ getText('delete') }}
                      </button>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </HTConfigProvider>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import { HTConfigProvider } from '@/components/config-provider';

const currentLocale = ref('zh-CN');

const locales = [
  { code: 'zh-CN', name: '简体中文' },
  { code: 'zh-TW', name: '繁體中文' },
  { code: 'en-US', name: 'English' },
  { code: 'ja-JP', name: '日本語' },
];

const localeTexts = {
  'zh-CN': {
    confirm: '确认',
    cancel: '取消',
    delete: '删除',
    edit: '编辑',
    loading: '加载中...',
    success: '成功',
    fail: '失败',
    empty: '暂无数据',
    required: '此字段为必填项',
    invalid: '格式不正确',
    minLength: '最少需要 {min} 个字符',
    name: '姓名',
    email: '邮箱',
    status: '状态',
    actions: '操作',
    active: '活跃',
    inactive: '非活跃',
  },
  'zh-TW': {
    confirm: '確認',
    cancel: '取消',
    delete: '刪除',
    edit: '編輯',
    loading: '載入中...',
    success: '成功',
    fail: '失敗',
    empty: '暫無數據',
    required: '此欄位為必填項',
    invalid: '格式不正確',
    minLength: '最少需要 {min} 個字元',
    name: '姓名',
    email: '郵箱',
    status: '狀態',
    actions: '操作',
    active: '活躍',
    inactive: '非活躍',
  },
  'en-US': {
    confirm: 'Confirm',
    cancel: 'Cancel',
    delete: 'Delete',
    edit: 'Edit',
    loading: 'Loading...',
    success: 'Success',
    fail: 'Failed',
    empty: 'No data',
    required: 'This field is required',
    invalid: 'Invalid format',
    minLength: 'Minimum {min} characters required',
    name: 'Name',
    email: 'Email',
    status: 'Status',
    actions: 'Actions',
    active: 'Active',
    inactive: 'Inactive',
  },
  'ja-JP': {
    confirm: '確認',
    cancel: 'キャンセル',
    delete: '削除',
    edit: '編集',
    loading: '読み込み中...',
    success: '成功',
    fail: '失敗',
    empty: 'データがありません',
    required: 'この項目は必須です',
    invalid: '形式が正しくありません',
    minLength: '最低 {min} 文字必要です',
    name: '名前',
    email: 'メール',
    status: 'ステータス',
    actions: 'アクション',
    active: 'アクティブ',
    inactive: '非アクティブ',
  },
};

const switchLanguage = (locale: string) => {
  currentLocale.value = locale;
};

const getCurrentLocaleName = () => {
  const locale = locales.find((l) => l.code === currentLocale.value);
  return locale ? locale.name : currentLocale.value;
};

const getText = (key: string, params?: Record<string, any>) => {
  const texts = localeTexts[currentLocale.value as keyof typeof localeTexts];
  let text = texts[key as keyof typeof texts] || key;

  if (params) {
    Object.keys(params).forEach((param) => {
      text = text.replace(`{${param}}`, params[param]);
    });
  }

  return text;
};

const formatDate = (type: string) => {
  const now = new Date();
  const options = {
    short: { year: 'numeric', month: '2-digit', day: '2-digit' },
    long: { year: 'numeric', month: 'long', day: 'numeric', weekday: 'long' },
    time: { hour: '2-digit', minute: '2-digit', second: '2-digit' },
    full: {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      weekday: 'long',
    },
  }[type] as Intl.DateTimeFormatOptions;

  return now.toLocaleString(currentLocale.value, options);
};

const formatNumber = (num: number, decimals = 0) => {
  return num.toLocaleString(currentLocale.value, {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  });
};

const formatCurrency = (amount: number) => {
  const currencySymbols = {
    'zh-CN': '¥',
    'zh-TW': 'NT$',
    'en-US': '$',
    'ja-JP': '¥',
  };

  const symbol = currencySymbols[currentLocale.value as keyof typeof currencySymbols] || '¥';
  return `${symbol}${amount.toFixed(2)}`;
};
</script>

<style scoped>
.demo-config-provider-locale {
  width: 100%;
  max-width: 1000px;
  margin: 0 auto;
  padding: 20px;
}
</style>
