<template>
  <div class="demo-swipe">
    <HTSwipe vertical :autoplay="3000" height="400">
      <HTSwipeItem>
        <div class="swipe-item-content-vertical bg-blue">
          <div class="content-wrapper">
            <h3>垂直项目 1</h3>
            <p>这是垂直滚动的第一个项目</p>
          </div>
        </div>
      </HTSwipeItem>
      <HTSwipeItem>
        <div class="swipe-item-content-vertical bg-green">
          <div class="content-wrapper">
            <h3>垂直项目 2</h3>
            <p>这是垂直滚动的第二个项目</p>
          </div>
        </div>
      </HTSwipeItem>
      <HTSwipeItem>
        <div class="swipe-item-content-vertical bg-red">
          <div class="content-wrapper">
            <h3>垂直项目 3</h3>
            <p>这是垂直滚动的第三个项目</p>
          </div>
        </div>
      </HTSwipeItem>
    </HTSwipe>
  </div>
</template>

<script setup lang="ts">
import { HTSwipe, HTSwipeItem } from '@hytech/ht-ui';
</script>

<style scoped>
.demo-swipe {
  width: 100%;
  max-width: 600px;
  margin: 0 auto;
}

.swipe-item-content-vertical {
  width: 100%;
  height: 400px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: white;
  border-radius: 8px;
}

.content-wrapper {
  text-align: center;
}

.content-wrapper h3 {
  font-size: 32px;
  margin-bottom: 16px;
  font-weight: bold;
}

.content-wrapper p {
  font-size: 18px;
  opacity: 0.9;
  margin: 0;
}

.bg-blue {
  background-color: #409eff;
}

.bg-green {
  background-color: #67c23a;
}

.bg-red {
  background-color: #f56c6c;
}
</style>
