<template>
  <div class="demo-swipe">
    <HTSwipe :autoplay="3000" height="200" arrow="always" trigger="hover">
      <HTSwipeItem>
        <div class="swipe-item-content bg-blue">hover 触发</div>
      </HTSwipeItem>
      <HTSwipeItem>
        <div class="swipe-item-content bg-green">hover 触发</div>
      </HTSwipeItem>
      <HTSwipeItem>
        <div class="swipe-item-content bg-red">hover 触发</div>
      </HTSwipeItem>
    </HTSwipe>

    <HTSwipe :autoplay="3000" height="200" arrow="hover" trigger="click" :style="{ marginTop: '12px' }">
      <HTSwipeItem>
        <div class="swipe-item-content bg-blue">click 触发</div>
      </HTSwipeItem>
      <HTSwipeItem>
        <div class="swipe-item-content bg-green">click 触发</div>
      </HTSwipeItem>
      <HTSwipeItem>
        <div class="swipe-item-content bg-red">click 触发</div>
      </HTSwipeItem>
    </HTSwipe>
  </div>
</template>

<script setup lang="ts">
import { HTSwipe, HTSwipeItem } from '@hytech/ht-ui';
</script>

<style scoped>
.demo-swipe {
  width: 100%;
  max-width: 600px;
  margin: 0 auto;
}
.swipe-item-content {
  width: 100%;
  height: 200px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: white;
  font-size: 24px;
  border-radius: 8px;
}
.bg-blue {
  background-color: #409eff;
}
.bg-green {
  background-color: #67c23a;
}
.bg-red {
  background-color: #f56c6c;
}
</style>
