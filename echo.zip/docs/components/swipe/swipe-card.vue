<template>
  <div class="demo-swipe">
    <HTSwipe type="card" :autoplay="3000" height="300">
      <HTSwipeItem>
        <div class="swipe-card-content bg-gradient-1">
          <h3>卡片 1</h3>
          <p>这是卡片模式的第一张卡片</p>
        </div>
      </HTSwipeItem>
      <HTSwipeItem>
        <div class="swipe-card-content bg-gradient-2">
          <h3>卡片 2</h3>
          <p>这是卡片模式的第二张卡片</p>
        </div>
      </HTSwipeItem>
      <HTSwipeItem>
        <div class="swipe-card-content bg-gradient-3">
          <h3>卡片 3</h3>
          <p>这是卡片模式的第三张卡片</p>
        </div>
      </HTSwipeItem>
    </HTSwipe>
  </div>
</template>

<script setup lang="ts">
import { HTSwipe, HTSwipeItem } from '@hytech/ht-ui';
</script>

<style scoped>
.demo-swipe {
  width: 100%;
  max-width: 800px;
  margin: 0 auto;
}

.swipe-card-content {
  width: 100%;
  height: 300px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  color: white;
  border-radius: 12px;
  text-align: center;
  padding: 20px;
}

.swipe-card-content h3 {
  font-size: 32px;
  margin-bottom: 16px;
  font-weight: bold;
}

.swipe-card-content p {
  font-size: 18px;
  opacity: 0.9;
}

.bg-gradient-1 {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
}

.bg-gradient-2 {
  background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
}

.bg-gradient-3 {
  background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
}
</style>
