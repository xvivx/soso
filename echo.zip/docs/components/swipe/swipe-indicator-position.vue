<template>
  <div class="demo-swipe">
    <h4>内部指示器</h4>
    <HTSwipe indicator-position="inside" :autoplay="3000" height="200">
      <HTSwipeItem>
        <div class="swipe-item-content bg-blue">1</div>
      </HTSwipeItem>
      <HTSwipeItem>
        <div class="swipe-item-content bg-green">2</div>
      </HTSwipeItem>
      <HTSwipeItem>
        <div class="swipe-item-content bg-red">3</div>
      </HTSwipeItem>
    </HTSwipe>

    <h4>外部指示器</h4>
    <HTSwipe indicator-position="outside" :autoplay="3000" height="200">
      <HTSwipeItem>
        <div class="swipe-item-content bg-purple">4</div>
      </HTSwipeItem>
      <HTSwipeItem>
        <div class="swipe-item-content bg-orange">5</div>
      </HTSwipeItem>
      <HTSwipeItem>
        <div class="swipe-item-content bg-teal">6</div>
      </HTSwipeItem>
    </HTSwipe>
  </div>
</template>

<script setup lang="ts">
import { HTSwipe, HTSwipeItem } from '@hytech/ht-ui';
</script>

<style scoped>
.demo-swipe {
  width: 100%;
  max-width: 600px;
  margin: 0 auto;
}

.demo-swipe h4 {
  margin: 20px 0 10px;
  color: #333;
}

.swipe-item-content {
  width: 100%;
  height: 200px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: white;
  font-size: 48px;
  font-weight: bold;
  border-radius: 8px;
}

.bg-blue {
  background-color: #409eff;
}

.bg-green {
  background-color: #67c23a;
}

.bg-red {
  background-color: #f56c6c;
}

.bg-purple {
  background-color: #909399;
}

.bg-orange {
  background-color: #e6a23c;
}

.bg-teal {
  background-color: #00c0ef;
}
</style>
