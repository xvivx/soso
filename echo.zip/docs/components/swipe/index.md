# HTSwipe

轮播组件，支持自动播放、循环滚动、垂直滚动等多种模式。

## 基础用法

<demo vue="./swipe-basic.vue" codesandbox="true" />

## 指示器位置

<demo vue="./swipe-indicator-position.vue" codesandbox="true" />

## 箭头按钮

<demo vue="./swipe-arrow.vue" codesandbox="true" />

## 触发方式

<demo vue="./swipe-trigger.vue" codesandbox="true" />

## 卡片模式

<demo vue="./swipe-card.vue" codesandbox="true" />

## 垂直滚动

<demo vue="./swipe-vertical.vue" codesandbox="true" />

## 自定义滑块宽度

通过 `width` 属性可以自定义滑块的宽度。

<demo vue="./swipe-width.vue" codesandbox="true" />

## Attributes

| Attribute | Description | Type | Default | 与 Vant 差异 |
| --- | --- | --- | --- | --- |
| `height` | 轮播容器高度 | `number \| string` | - | HTSwipe 新增，Vant 无此属性 |
| `autoplay` | 自动播放间隔时间 (ms) | `number \| string` | `3000` | HTSwipe 默认值为 3000，Vant 默认为 0 |
| `duration` | 动画持续时间 (ms) | `number \| string` | `500` | HTSwipe 默认值为 500，Vant 兼容 |
| `initial-swipe` | 初始位置索引 | `number \| string` | `0` | 兼容 |
| `loop` | 是否循环播放 | `boolean` | `true` | 兼容 |
| `show-indicators` | 是否显示指示器 | `boolean` | `true` | 兼容 |
| `vertical` | 是否垂直滚动 | `boolean` | `false` | 兼容 |
| `touchable` | 是否可以通过手势滑动 | `boolean` | `true` | 兼容 |
| `stop-propagation` | 是否阻止事件冒泡 | `boolean` | `true` | 兼容 |
| `indicator-color` | 指示器颜色 | `string` | - | 兼容 |
| `swipe-threshold` | 滑动阈值 | `number \| string` | `0.15` | HTSwipe 默认值为 0.15，Vant 无此属性 |
| `lazy-render` | 是否懒加载 | `boolean` | `true` | HTSwipe 默认值为 true，Vant 默认为 false |
| `indicator-position` | 指示器位置 | `'inside' \| 'outside' \| 'none'` | `'inside'` | HTSwipe 新增，Vant 无此属性 |
| `arrow` | 箭头显示时机 | `'always' \| 'hover' \| 'never'` | `'hover'` | HTSwipe 新增，Vant 无此属性 |
| `trigger` | 触发方式 | `'click' \| 'hover'` | `'hover'` | HTSwipe 新增，Vant 无此属性 |
| `type` | 轮播类型 | `'' \| 'card'` | `''` | HTSwipe 新增，Vant 无此属性 |
| `card-scale` | 卡片缩放比例 | `number \| string` | `0.83` | HTSwipe 新增，Vant 无此属性 |
| `pause-on-hover` | 鼠标悬停时是否暂停自动播放 | `boolean` | `true` | HTSwipe 新增，Vant 无此属性 |
| `width` | 滑块宽度 | `number \| string` | `auto` | 兼容 |

## Events

| Event | Description | Arguments | 与 Vant 差异 |
| --- | --- | --- | --- |
| `change` | 切换时触发 | `index: number` | 兼容 |

## Methods

| Method | Description | Arguments | 与 Vant 差异 |
| --- | --- | --- | --- |
| `prev` | 切换到上一页 | - | 兼容 |
| `next` | 切换到下一页 | - | 兼容 |
| `swipeTo` | 切换到指定位置 | `index: number, options?: { immediate?: boolean }` | 兼容 |
| `resize` | 外层元素大小变化后，可以调用此方法来触发重绘 | - | 兼容 |

## HTSwipeItem Props

| Attribute | Description | Type | Default | 与 Vant 差异 |
| --- | --- | --- | --- | --- |
| `lazy` | 是否懒加载 | `boolean` | `false` | 兼容 |

## Slots

| Name | Description | 与 Vant 差异 |
| --- | --- | --- |
| `default` | 轮播内容 | 兼容 |
| `arrow-left` | 左箭头内容 | HTSwipe 新增，Vant 无此插槽 |
| `arrow-right` | 右箭头内容 | HTSwipe 新增，Vant 无此插槽 |
| - | 自定义指示器 | HTSwipe 缺少 Vant 的 `indicator` 插槽 |