<template>
  <div class="demo-swipe">
    <HTSwipe :autoplay="3000" height="200">
      <HTSwipeItem>
        <div class="swipe-item-content bg-blue">1</div>
      </HTSwipeItem>
      <HTSwipeItem>
        <div class="swipe-item-content bg-green">2</div>
      </HTSwipeItem>
      <HTSwipeItem>
        <div class="swipe-item-content bg-red">3</div>
      </HTSwipeItem>
    </HTSwipe>
  </div>
</template>

<script setup lang="ts">
import { HTSwipe, HTSwipeItem } from '@hytech/ht-ui';
</script>

<style scoped>
.demo-swipe {
  width: 100%;
  max-width: 600px;
  margin: 0 auto;
}

.swipe-item-content {
  width: 100%;
  height: 200px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: white;
  font-size: 48px;
  font-weight: bold;
  border-radius: 8px;
}

.bg-blue {
  background-color: #409eff;
}

.bg-green {
  background-color: #67c23a;
}

.bg-red {
  background-color: #f56c6c;
}
</style>
