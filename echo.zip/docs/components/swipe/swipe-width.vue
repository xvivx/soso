<template>
  <HTSwipe :width="200" :height="150" :autoplay="3000" indicator-position="outside">
    <HTSwipeItem>1</HTSwipeItem>
    <HTSwipeItem>2</HTSwipeItem>
    <HTSwipeItem>3</HTSwipeItem>
    <HTSwipeItem>4</HTSwipeItem>
  </HTSwipe>
</template>

<script setup lang="ts">
import { HTSwipe, HTSwipeItem } from '@hytech/ht-ui';
</script>

<style scoped>
.ht-swipe-item {
  color: #fff;
  font-size: 20px;
  line-height: 150px;
  text-align: center;
}

.ht-swipe-item:nth-child(odd) {
  background-color: #39a9ed;
}

.ht-swipe-item:nth-child(even) {
  background-color: #66c6f2;
}
</style>
