<script setup lang="ts">
import { HTButton, HTEmpty } from '@hytech/ht-ui';

const handleRefresh = () => {
  alert('刷新数据');
};
</script>

<template>
  <section>
    <HTEmpty>
      <template #title>
        <div class="text-base font-semibold text-gray-800">自定义标题</div>
      </template>
      <template #description>
        <div class="text-sm text-gray-600">这是一段自定义的描述内容</div>
      </template>
      <template #button>
        <HTButton @click="handleRefresh">自定义按钮</HTButton>
      </template>
    </HTEmpty>
  </section>
</template>
