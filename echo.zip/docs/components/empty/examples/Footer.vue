<script setup lang="ts">
import { HTButton, HTEmpty } from '@hytech/ht-ui';
</script>

<template>
  <HTEmpty>
    <template #description>
      <div class="text-sm text-gray-600">自定义描述内容</div>
    </template>
    <template #default>
      <HTButton>按钮</HTButton>
    </template>
  </HTEmpty>
</template>
