<script setup lang="ts">
import { HTEmpty } from '@hytech/ht-ui';
</script>

<template>
  <HTEmpty :imageSize="[80, 80]" description="image-size 数组格式，分别设置宽高[80, 80]" />
  <HTEmpty imageSize="6rem" description="image-size 字符串格式 6rem" />
</template>
