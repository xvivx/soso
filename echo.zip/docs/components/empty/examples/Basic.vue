<script setup lang="ts">
import { HTEmpty } from '@hytech/ht-ui';
</script>

<template>
  <section>
    <HTEmpty description="描述文字" />
  </section>
</template>
