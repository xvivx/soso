<script setup lang="ts">
import { HTEmpty } from '@hytech/ht-ui';
</script>

<template>
  <section>
    <HTEmpty title="暂无数据" description="当前没有任何内容" />
  </section>
</template>
