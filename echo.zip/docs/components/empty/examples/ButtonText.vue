<script setup lang="ts">
import { HTEmpty } from '@hytech/ht-ui';

const handleClickButton = () => {
  alert('刷新页面');
};
</script>

<template>
  <section>
    <HTEmpty title="暂无数据" description="当前没有任何内容" buttonText="刷新页面" @clickButton="handleClickButton" />
  </section>
</template>
