# HTEmpty 空状态

空状态时的占位提示。

## 基础用法

<demo vue="./examples/Basic.vue" codesandbox="true" />

## 自定义大小

通过 image-size 属性图片的大小。 <demo vue="./examples/ImageSize.vue" codesandbox="true" />

## 自定义图片

需要自定义图片时，可以在 image 属性中传入任意图片 URL。 <demo vue="./examples/Image.vue" codesandbox="true" />

## 底部内容

通过默认插槽可以在 Empty 组件的下方插入内容。 <demo vue="./examples/Footer.vue" codesandbox="true" />

### Props

| 参数        | 说明                    | 类型                                       | 默认值 |
| ----------- | ----------------------- | ------------------------------------------ | ------ |
| image       | 自定义图片 URL          | `string`                                   | -      |
| imageSize   | 图片大小，默认单位为 px | `number \| string \| (number \| string)[]` | -      |
| description | 图片下方的描述文字      | `string`                                   |        |

### Slots

| 名称        | 说明           |
| ----------- | -------------- |
| default     | 自定义底部内容 |
| image       | 自定义图标     |
| description | 自定义描述文字 |

### 类型定义

组件导出以下类型定义：

```ts
import type { EmptyProps } from '@hytech/ht-ui';
```
