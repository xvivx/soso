<template>
  <div class="space-y-6">
    <!-- Primary Variant -->
    <div class="space-y-3">
      <div class="flex items-center gap-2">
        <h3 class="text-base font-semibold text-gray-900">Primary（黑色）</h3>
        <span class="rounded bg-gray-100 px-2 py-0.5 text-xs text-gray-600">默认</span>
      </div>

      <div class="grid grid-cols-1 gap-3 rounded-lg border border-gray-200 bg-gray-50 p-4 md:grid-cols-2">
        <!-- 正常状态 -->
        <div class="space-y-2">
          <p class="text-xs font-medium text-gray-600">正常状态</p>
          <div class="space-y-2 rounded bg-white p-3">
            <HTCheckbox v-model="primary.normal1" variant="primary">未选中</HTCheckbox>
            <HTCheckbox v-model="primary.normal2" variant="primary">已选中</HTCheckbox>
            <HTCheckbox v-model="primary.normal3" variant="primary" :indeterminate="true">半选</HTCheckbox>
          </div>
        </div>

        <!-- 禁用状态 -->
        <div class="space-y-2">
          <p class="text-xs font-medium text-gray-600">禁用状态</p>
          <div class="space-y-2 rounded bg-white p-3">
            <HTCheckbox v-model="primary.disabled1" variant="primary" disabled>未选中禁用</HTCheckbox>
            <HTCheckbox v-model="primary.disabled2" variant="primary" disabled>已选中禁用</HTCheckbox>
            <HTCheckbox v-model="primary.disabled3" variant="primary" :indeterminate="true" disabled>
              半选禁用
            </HTCheckbox>
          </div>
        </div>
      </div>

      <p class="text-xs text-gray-500">💡 鼠标悬停查看 hover 效果：未选中时边框变为 #717680，选中时背景变为 #717680</p>
    </div>

    <!-- Secondary Variant -->
    <div class="space-y-3">
      <div class="flex items-center gap-2">
        <h3 class="text-base font-semibold text-gray-900">Secondary（绿色）</h3>
        <span class="rounded bg-green-100 px-2 py-0.5 text-xs text-green-700">成功/确认场景</span>
      </div>

      <div class="grid grid-cols-1 gap-3 rounded-lg border border-green-200 bg-green-50 p-4 md:grid-cols-2">
        <!-- 正常状态 -->
        <div class="space-y-2">
          <p class="text-xs font-medium text-gray-600">正常状态</p>
          <div class="space-y-2 rounded bg-white p-3">
            <HTCheckbox v-model="secondary.normal1" variant="secondary">未选中</HTCheckbox>
            <HTCheckbox v-model="secondary.normal2" variant="secondary">已选中</HTCheckbox>
            <HTCheckbox v-model="secondary.normal3" variant="secondary" :indeterminate="true">半选</HTCheckbox>
          </div>
        </div>

        <!-- 禁用状态 -->
        <div class="space-y-2">
          <p class="text-xs font-medium text-gray-600">禁用状态</p>
          <div class="space-y-2 rounded bg-white p-3">
            <HTCheckbox v-model="secondary.disabled1" variant="secondary" disabled>未选中禁用</HTCheckbox>
            <HTCheckbox v-model="secondary.disabled2" variant="secondary" disabled>已选中禁用</HTCheckbox>
            <HTCheckbox v-model="secondary.disabled3" variant="secondary" :indeterminate="true" disabled>
              半选禁用
            </HTCheckbox>
          </div>
        </div>
      </div>

      <p class="text-xs text-gray-500">💡 鼠标悬停查看 hover 效果：未选中时边框变为 #099250，选中时背景变为 #099250</p>
    </div>

    <!-- 实际使用示例 -->
    <div class="space-y-3">
      <h3 class="text-base font-semibold text-gray-900">实际使用示例</h3>

      <div class="space-y-4 rounded-lg border border-gray-200 p-4">
        <div>
          <p class="mb-2 text-sm font-medium text-gray-700">任务列表（使用 Primary）</p>
          <div class="space-y-1.5">
            <HTCheckbox v-model="tasks.task1" variant="primary">完成项目文档</HTCheckbox>
            <HTCheckbox v-model="tasks.task2" variant="primary">代码审查</HTCheckbox>
            <HTCheckbox v-model="tasks.task3" variant="primary">部署到生产环境</HTCheckbox>
          </div>
        </div>

        <div class="border-t pt-4">
          <p class="mb-2 text-sm font-medium text-gray-700">用户协议确认（使用 Secondary）</p>
          <div class="space-y-1.5">
            <HTCheckbox v-model="agreements.terms" variant="secondary"> 我已阅读并同意《用户协议》 </HTCheckbox>
            <HTCheckbox v-model="agreements.privacy" variant="secondary"> 我已阅读并同意《隐私政策》 </HTCheckbox>
          </div>
        </div>
      </div>
    </div>

    <!-- 颜色对照表 -->
    <div class="space-y-3">
      <h3 class="text-base font-semibold text-gray-900">颜色规范</h3>

      <div class="overflow-hidden rounded-lg border border-gray-200">
        <table class="w-full text-left text-sm">
          <thead class="bg-gray-50">
            <tr>
              <th class="px-4 py-2 font-medium text-gray-700">变体</th>
              <th class="px-4 py-2 font-medium text-gray-700">选中状态</th>
              <th class="px-4 py-2 font-medium text-gray-700">Hover 选中</th>
              <th class="px-4 py-2 font-medium text-gray-700">Hover 未选中</th>
            </tr>
          </thead>
          <tbody class="divide-y divide-gray-200 bg-white">
            <tr>
              <td class="px-4 py-2 font-medium">Primary</td>
              <td class="px-4 py-2">
                <div class="flex items-center gap-2">
                  <div class="h-4 w-4 rounded border border-gray-200" style="background: #000"></div>
                  <span class="font-mono text-xs">#000000</span>
                </div>
              </td>
              <td class="px-4 py-2">
                <div class="flex items-center gap-2">
                  <div class="h-4 w-4 rounded border border-gray-200" style="background: #717680"></div>
                  <span class="font-mono text-xs">#717680</span>
                </div>
              </td>
              <td class="px-4 py-2">
                <div class="flex items-center gap-2">
                  <div class="h-4 w-4 rounded border" style="border-color: #717680"></div>
                  <span class="font-mono text-xs">#717680</span>
                </div>
              </td>
            </tr>
            <tr>
              <td class="px-4 py-2 font-medium">Secondary</td>
              <td class="px-4 py-2">
                <div class="flex items-center gap-2">
                  <div class="h-4 w-4 rounded border border-gray-200" style="background: #16b364"></div>
                  <span class="font-mono text-xs">#16B364</span>
                </div>
              </td>
              <td class="px-4 py-2">
                <div class="flex items-center gap-2">
                  <div class="h-4 w-4 rounded border border-gray-200" style="background: #099250"></div>
                  <span class="font-mono text-xs">#099250</span>
                </div>
              </td>
              <td class="px-4 py-2">
                <div class="flex items-center gap-2">
                  <div class="h-4 w-4 rounded border" style="border-color: #099250"></div>
                  <span class="font-mono text-xs">#099250</span>
                </div>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { reactive } from 'vue';
import { HTCheckbox } from '@hytech/ht-ui';

const primary = reactive({
  normal1: false,
  normal2: true,
  normal3: true,
  disabled1: false,
  disabled2: true,
  disabled3: true,
});

const secondary = reactive({
  normal1: false,
  normal2: true,
  normal3: true,
  disabled1: false,
  disabled2: true,
  disabled3: true,
});

const tasks = reactive({
  task1: true,
  task2: false,
  task3: false,
});

const agreements = reactive({
  terms: false,
  privacy: false,
});
</script>
