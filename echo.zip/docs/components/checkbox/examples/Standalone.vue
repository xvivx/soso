<script setup lang="ts">
import { ref } from 'vue';
import { HTCheckbox } from '@hytech/ht-ui';

const checked = ref(true);
</script>

<template>
  <HTCheckbox v-model="checked" :bind-group="false">复选框</HTCheckbox>
</template>
