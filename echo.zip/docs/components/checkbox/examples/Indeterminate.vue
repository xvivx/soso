<script setup lang="ts">
import { computed, ref, watch } from 'vue';
import { HTCheckbox, HTCheckboxGroup } from '@hytech/ht-ui';

const checkAll = ref(false);
const checked = ref<string[]>([]);
const checkboxes = ['1', '2', '3'];

const indeterminate = computed(() => {
  return checked.value.length > 0 && checked.value.length < checkboxes.length;
});

// 监听子选项变化，同步全选状态
watch(
  () => checked.value.length,
  (newLength) => {
    checkAll.value = newLength === checkboxes.length;
  }
);

// 全选切换
const toggleAll = (value: boolean) => {
  if (value) {
    checked.value = [...checkboxes];
  } else {
    checked.value = [];
  }
};
</script>

<template>
  <div class="flex flex-col gap-4">
    <HTCheckbox v-model="checkAll" :bind-group="false" :indeterminate="indeterminate" @change="toggleAll">
      全选
    </HTCheckbox>
    <HTCheckboxGroup v-model="checked">
      <HTCheckbox name="1">复选框 1</HTCheckbox>
      <HTCheckbox name="2">复选框 2</HTCheckbox>
      <HTCheckbox name="3">复选框 3</HTCheckbox>
    </HTCheckboxGroup>
  </div>
</template>
