<script setup lang="ts">
import { ref } from 'vue';
import { HTCheckbox, HTCheckboxGroup } from '@hytech/ht-ui';

const checked = ref(['1']);
</script>

<template>
  <HTCheckboxGroup v-model="checked" direction="horizontal">
    <HTCheckbox name="1">复选框 1</HTCheckbox>
    <HTCheckbox name="2">复选框 2</HTCheckbox>
    <HTCheckbox name="3">复选框 3</HTCheckbox>
  </HTCheckboxGroup>
</template>
