# Checkbox 复选框

在一组备选项中进行多选。

## 基础用法

通过 v-model 绑定复选框的勾选状态。 <demo vue="./examples/Basic.vue" codesandbox="true" />

## 排列方向

通过 direction 属性设置排列方向。 <demo vue="./examples/Direction.vue" codesandbox="true" />

## 禁用状态

通过设置 disabled 属性可以禁用单个复选框。 <demo vue="./examples/Disabled.vue" codesandbox="true" />

## 禁用整组

通过在 CheckboxGroup 上设置 disabled 属性可以禁用所有复选框。
<demo vue="./examples/DisabledGroup.vue" codesandbox="true" />

## 最大可选数

通过 max 属性可以限制最多可选的数量。 <demo vue="./examples/MaxCount.vue" codesandbox="true" />

## 自定义颜色

通过 checked-color 属性设置选中状态的颜色。 <demo vue="./examples/CheckedColor.vue" codesandbox="true" />

## 自定义大小

通过 icon-size 属性可以自定义图标的大小。 <demo vue="./examples/IconSize.vue" codesandbox="true" />

## 自定义形状

通过 shape 属性可以设置复选框形状，支持 square 和 round 两种形状。
<demo vue="./examples/Shape.vue" codesandbox="true" />

## 颜色变体

通过 variant 属性可以设置复选框的颜色变体，支持 primary（黑色）和 secondary（绿色）两种。
<demo vue="./examples/Variant.vue" codesandbox="true" />

## 半选状态

通过设置 indeterminate 属性可以让复选框显示为半选状态。 <demo vue="./examples/Indeterminate.vue" codesandbox="true" />

## 单独使用

Checkbox 可以单独使用，通过设置 bind-group 为 false 即可。 <demo vue="./examples/Standalone.vue" codesandbox="true" />

## CheckboxGroup

### Props

| 参数           | 说明                                | 类型                         | 默认值       |
| -------------- | ----------------------------------- | ---------------------------- | ------------ |
| v-model        | 当前选中项的标识符数组              | `(string \| number)[]`       | -            |
| disabled       | 是否禁用所有复选框                  | `boolean`                    | `false`      |
| max            | 最大可选数，0 表示无限制            | `number`                     | `0`          |
| direction      | 排列方向，可选值为 horizontal       | `'vertical' \| 'horizontal'` | `'vertical'` |
| label-position | 文本位置，可选值为 left             | `'left' \| 'right'`          | `'right'`    |
| icon-size      | 所有复选框的图标大小，默认单位为 px | `number \| string`           | `16px`       |
| checked-color  | 所有复选框的选中状态颜色            | `string`                     | `#1677FF`    |
| shape          | 所有复选框的形状，可选值为 round    | `'square' \| 'round'`        | `'square'`   |

### Events

| 事件名 | 说明                     | 参数                          |
| ------ | ------------------------ | ----------------------------- |
| change | 当绑定值变化时触发的事件 | `value: (string \| number)[]` |

### Slots

| 名称    | 说明                   |
| ------- | ---------------------- |
| default | 放置 `HTCheckbox` 子项 |

---

## Checkbox

### Props

| 参数           | 说明                                 | 类型                          | 默认值      |
| -------------- | ------------------------------------ | ----------------------------- | ----------- |
| name           | 标识符，通常为一个唯一的字符串或数字 | `string \| number`            | -           |
| v-model        | 是否为选中状态（单独使用时）         | `boolean`                     | `false`     |
| disabled       | 是否为禁用状态                       | `boolean`                     | `false`     |
| shape          | 形状，可选值为 round                 | `'square' \| 'round'`         | `'square'`  |
| variant        | 颜色变体，可选值为 secondary         | `'primary' \| 'secondary'`    | `'primary'` |
| label-position | 文本位置，可选值为 left              | `'left' \| 'right'`           | `'right'`   |
| icon-size      | 图标大小，默认单位为 px              | `number \| string`            | `12px`      |
| checked-color  | 选中状态颜色（会覆盖 variant）       | `string`                      | -           |
| label-disabled | 是否禁用文本点击                     | `boolean`                     | `false`     |
| indeterminate  | 是否为半选状态                       | `boolean`                     | `false`     |
| bind-group     | 是否与 CheckboxGroup 绑定            | `boolean`                     | `true`      |

### Events

| 事件名 | 说明             | 参数                |
| ------ | ---------------- | ------------------- |
| click  | 点击复选框时触发 | `event: MouseEvent` |
| change | 状态变化时触发   | `value: boolean`    |

### Slots

| 名称    | 说明       | 参数                                                              |
| ------- | ---------- | ----------------------------------------------------------------- |
| default | 自定义文本 | `{ checked: boolean, disabled: boolean, indeterminate: boolean }` |
| icon    | 自定义图标 | `{ checked: boolean, disabled: boolean, indeterminate: boolean }` |

### 类型定义

组件导出以下类型定义：

```ts
import type {
  CheckboxGroupDirection,
  CheckboxGroupProps,
  CheckboxLabelPosition,
  CheckboxProps,
  CheckboxShape,
  CheckboxVariant,
} from '@hytech/ht-ui';
```
