<script setup lang="ts">
import { ref } from 'vue';
import { HTActionSheet } from '@hytech/ht-ui';

const show = ref(false);
const actions = [{ name: '选项一' }, { name: '选项二' }, { name: '选项三' }];
</script>

<template>
  <div>
    <button
      @click="show = true"
      class="rounded border border-gray-300 bg-white px-4 py-2 text-gray-900 hover:bg-gray-50"
    >
      无圆角
    </button>
    <HTActionSheet v-model="show" :actions="actions" cancel-text="取消" :round="false" />
  </div>
</template>
