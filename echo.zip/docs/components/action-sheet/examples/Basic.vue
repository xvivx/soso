<script setup lang="ts">
import { getCurrentInstance, onMounted, ref, watch } from 'vue';
import { HTActionSheet } from '@hytech/ht-ui';

const show = ref(false);
const actions = [{ name: '选项一' }, { name: '选项二' }, { name: '选项三' }];

const onSelect = (action: any, index: number) => {
  console.log('Selected:', action, index);
};

function handleClick() {
  console.log('[Basic.vue] Button clicked, before show =', show.value);
  show.value = true;
  console.log('[Basic.vue] Button clicked, after show =', show.value);
}

// Debug: watch show变化
watch(show, (newValue) => {
  console.log('[Basic.vue] show changed to:', newValue);
});

onMounted(() => {
  const instance = getCurrentInstance();
  console.log('[Basic.vue] HTActionSheet from import:', HTActionSheet);
  console.log('[Basic.vue] HTActionSheet registered:', instance?.appContext.components.HTActionSheet);
  console.log('[Basic.vue] All registered components:', Object.keys(instance?.appContext.components || {}));
});
</script>

<template>
  <div>
    <button
      @click="handleClick"
      class="rounded border border-gray-300 bg-white px-4 py-2 text-gray-900 hover:bg-gray-50"
    >
      显示动作面板
    </button>
    <div class="mt-2 text-sm text-gray-500">Debug: show = {{ show }}</div>
    <HTActionSheet v-model="show" :actions="actions" cancel-text="取消" @select="onSelect" />
  </div>
</template>
