# ActionSheet 动作面板

底部弹起的模态面板，包含与当前情境相关的多个选项。

## 基础用法

通过 v-model 绑定动作面板的显示状态。 <demo vue="./examples/Basic.vue" codesandbox="true" />

## 显示标题和描述

通过 title 和 description 属性可以显示标题和描述信息。 <demo vue="./examples/WithDescription.vue" codesandbox="true" />

## 选项状态

选项可以设置为禁用或加载状态。 <demo vue="./examples/Status.vue" codesandbox="true" />

## 自定义颜色

可以通过 color 属性自定义选项的颜色，通常用于高亮危险操作。 <demo vue="./examples/Color.vue" codesandbox="true" />

## 显示副标题

通过 subname 属性可以为选项添加描述信息。 <demo vue="./examples/Subname.vue" codesandbox="true" />

## 无取消按钮

不设置 cancel-text 属性时，不会显示取消按钮。 <demo vue="./examples/NoCancel.vue" codesandbox="true" />

## 无圆角

通过设置 round 为 false 可以取消面板的圆角效果。 <demo vue="./examples/NoRound.vue" codesandbox="true" />

## API

### Props

| 参数                   | 说明                   | 类型                  | 默认值  |
| ---------------------- | ---------------------- | --------------------- | ------- |
| v-model                | 是否显示动作面板       | `boolean`             | `false` |
| actions                | 面板选项列表           | `ActionSheetAction[]` | `[]`    |
| title                  | 面板标题               | `string`              | -       |
| description            | 面板描述               | `string`              | -       |
| cancel-text            | 取消按钮文字           | `string`              | -       |
| close-on-click-action  | 是否在点击选项后关闭   | `boolean`             | `true`  |
| close-on-click-overlay | 是否在点击遮罩层后关闭 | `boolean`             | `true`  |
| round                  | 是否显示圆角           | `boolean`             | `true`  |
| safe-area-inset-bottom | 是否开启底部安全区适配 | `boolean`             | `true`  |

### ActionSheetAction

| 参数      | 说明                   | 类型         |
| --------- | ---------------------- | ------------ |
| name      | 选项文字               | `string`     |
| subname   | 选项副标题             | `string`     |
| color     | 选项文字颜色           | `string`     |
| disabled  | 是否为禁用状态         | `boolean`    |
| loading   | 是否为加载状态         | `boolean`    |
| className | 为选项添加额外的 class | `string`     |
| callback  | 点击选项时的回调函数   | `() => void` |

### Events

| 事件名        | 说明               | 参数                                       |
| ------------- | ------------------ | ------------------------------------------ |
| select        | 点击选项时触发     | `action: ActionSheetAction, index: number` |
| cancel        | 点击取消按钮时触发 | -                                          |
| open          | 打开面板时触发     | -                                          |
| close         | 关闭面板时触发     | -                                          |
| click-overlay | 点击遮罩层时触发   | -                                          |

### 类型定义

组件导出以下类型定义：

```ts
import type { ActionSheetAction, ActionSheetEmits, ActionSheetProps } from '@hytech/ht-ui';
```
