<template>
  <HTSelect class="w-full md:w-60" v-model:value="value" placeholder="基础用法" :options="options" />
</template>

<script setup lang="ts">
import { ref } from 'vue';
import { HTSelect } from '@hytech/ht-ui';
import { mock } from 'mockjs';

const { options } = mock({
  'options|5-10': [
    {
      label: '@word(5,10)',
      value: '@uuid',
    },
  ],
});
const value = ref<string>();
</script>
