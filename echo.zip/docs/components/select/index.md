# Select 选择器

用于在下拉菜单中选择选项。

## 基础用法

通过 v-model:value 绑定选中的值，options 属性设置选项列表。 <demo vue="./base.vue" codesandbox="true" />

## 自定义选项内容（使用 HTOption）

可以通过 HTOption 组件自定义选项的显示内容。 <demo vue="./custom-render.vue" codesandbox="true" />

## 使用说明

Select 组件提供了两种自定义选项的方式：

1. **使用 HTOption 组件**（完全自定义）- 适合每个选项都不同的场景
2. **使用 option 插槽**（批量自定义）- 适合所有选项使用相同模板的场景

## API

### Select Props

| 参数        | 说明         | 类型           | 默认值 |
| ----------- | ------------ | -------------- | ------ |
| value       | 当前选中的值 | `ValueType`    | -      |
| options     | 选项列表     | `OptionType[]` | `[]`   |
| placeholder | 占位提示文字 | `string`       | -      |

### Select Events

| 事件名       | 说明             | 参数               |
| ------------ | ---------------- | ------------------ |
| update:value | 选中值变化时触发 | `value: ValueType` |

### Select Slots

| 名称      | 说明                     | 参数                                        |
| --------- | ------------------------ | ------------------------------------------- |
| default   | 自定义选项列表           | -                                           |
| reference | 自定义触发器             | `{ open: boolean, option: OptionType }`     |
| option    | 自定义所有选项的显示内容 | `{ option: OptionType, selected: boolean }` |

---

## Option

### Props

| 参数   | 说明     | 类型         | 默认值 |
| ------ | -------- | ------------ | ------ |
| option | 选项数据 | `OptionType` | -      |

### Slots

| 名称    | 说明           | 参数                    |
| ------- | -------------- | ----------------------- |
| default | 自定义选项内容 | `{ selected: boolean }` |

---

## 类型定义

### BaseOption

```ts
type BaseOption<ValueType> = {
  value: ValueType;
  label: string | number;
  children?: BaseOption<ValueType>[]; // 用于分组
  class?: string;
};
```

### 组件导出

```ts
import { HTOption, HTSelect, type BaseOption, type SelectProps } from '@hytech/ht-ui';
```
