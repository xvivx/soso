<template>
  <div class="flex flex-wrap gap-4">
    <HTSelect class="w-full md:w-60" v-model:value="value" placeholder="自定义Option渲染" :options="options">
      <HTOption v-for="option in options" :option="option" :key="option.value">
        <div class="flex h-10 items-center gap-4 rounded px-2" :style="{ backgroundColor: option.color }">
          <div>{{ option.label }}</div>
          <img :src="mock('@image(40)')" />
        </div>
      </HTOption>
    </HTSelect>

    <HTSelect class="w-full md:w-60" v-model:value="value" :options="options">
      <template #reference="{ selected }">
        <div :style="{ color: selected && selected.color }">
          {{ selected ? `${selected.label} ${selected.title}` : '未选择' }}
        </div>
      </template>
    </HTSelect>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import { HTOption, HTSelect } from '@hytech/ht-ui';
import { mock } from 'mockjs';

const { options } = mock({
  'options|5-10': [
    {
      label: '@word(5,10)',
      value: '@uuid',
      title: '@cname',
      color: '@color',
    },
  ],
}) as { options: Option[] };
const value = ref<string>();

type Option = {
  label: string;
  value: string;
  title: string;
  color: string;
};
</script>
