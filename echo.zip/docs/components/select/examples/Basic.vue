<script setup lang="ts">
import { ref } from 'vue';
import { HTSelect } from '@hytech/ht-ui';

const value = ref('1');
const options = [
  { value: '1', label: '选项一' },
  { value: '2', label: '选项二' },
  { value: '3', label: '选项三' },
];
</script>

<template>
  <HTSelect v-model:value="value" :options="options" placeholder="请选择" />
</template>
