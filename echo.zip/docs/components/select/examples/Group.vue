<script setup lang="ts">
import { ref } from 'vue';
import { HTSelect } from '@hytech/ht-ui';

const value = ref('1');
const options = [
  {
    value: 'group1',
    label: '分组一',
    children: [
      { value: '1', label: '选项一' },
      { value: '2', label: '选项二' },
    ],
  },
  {
    value: 'group2',
    label: '分组二',
    children: [
      { value: '3', label: '选项三' },
      { value: '4', label: '选项四' },
    ],
  },
];
</script>

<template>
  <HTSelect v-model:value="value" :options="options" placeholder="请选择" />
</template>
