<script setup lang="ts">
import { ref } from 'vue';
import { HTOption, HTSelect } from '@hytech/ht-ui';

const value = ref('1');
</script>

<template>
  <HTSelect v-model:value="value" placeholder="请选择">
    <HTOption :option="{ value: '1', label: '选项一' }">
      <div class="flex items-center gap-2">
        <span>✨</span>
        <span>选项一</span>
      </div>
    </HTOption>
    <HTOption :option="{ value: '2', label: '选项二' }">
      <div class="flex items-center gap-2">
        <span>🎯</span>
        <span>选项二</span>
      </div>
    </HTOption>
    <HTOption :option="{ value: '3', label: '选项三' }">
      <div class="flex items-center gap-2">
        <span>🚀</span>
        <span>选项三</span>
      </div>
    </HTOption>
  </HTSelect>
</template>
