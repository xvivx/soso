<script setup lang="ts">
import { ref } from 'vue';
import { HTOption, HTSelect } from '@hytech/ht-ui';

const value = ref('1');
</script>

<template>
  <HTSelect v-model:value="value" placeholder="请选择" class="cursor-not-allowed opacity-50">
    <HTOption :option="{ value: '1', label: '选项一' }" />
    <HTOption :option="{ value: '2', label: '选项二' }" />
    <HTOption :option="{ value: '3', label: '选项三' }" />
  </HTSelect>
</template>
