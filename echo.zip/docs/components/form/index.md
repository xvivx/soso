# Form 表单

用于数据录入、校验，支持输入框、单选框、复选框、文件上传等类型，需要与 [Field 输入框](/components/field/) 组件搭配使用。

## 基础用法

在表单中，每个 [Field 组件](/components/field/) 代表一个表单项，使用 Field 的 `rules` 属性定义校验规则。
<demo vue="./examples/Basic.vue" codesandbox="true" />

## 校验规则

通过 `rules` 定义表单校验规则，所有可用字段见[下方表格](#/components/form/#rule-shu-ju-jie-gou)。
<demo vue="./examples/ValidateRules.vue" codesandbox="true" />

## 表单项类型 - 复选框组

在表单中使用 [Checkbox 组件](/components/checkbox/)。
<demo vue="./examples/FieldTypeCheckboxGroup.vue" codesandbox="true" />

## 表单项类型 - 单选框

在表单中使用 [Radio 组件](/components/radio/)。 <demo vue="./examples/FieldTypeRadio.vue" codesandbox="true" />

## 表单项类型 - 选择器

在表单中使用 [Select 组件](/components/select/)。 <demo vue="./examples/FieldTypeSelect.vue" codesandbox="true" />

## 表单项类型 - 进步器

在表单中使用 [Stepper 组件](/components/stepper/)。 <demo vue="./examples/FieldTypeStepper.vue" codesandbox="true" />

## 表单项类型 - 选择器

在表单中使用 [Select 组件](/components/select/)。 <demo vue="./examples/FieldTypeSelect.vue" codesandbox="true" />

## 表单项类型 - 进步器

在表单中使用 [Stepper 组件](/components/stepper/)。 <demo vue="./examples/FieldTypeStepper.vue" codesandbox="true" />

## 表单项类型 - 日期选择器

在表单中使用 [DatePicker 组件]。

<demo vue="./examples/FieldTypeDatePicker.vue" codesandbox="true" />

### Props

| 参数                     | 说明                                                                                              | 类型                 | 默认值   |
| ------------------------ | ------------------------------------------------------------------------------------------------- | -------------------- | -------- |
| label-width              | 表单项 label 宽度，默认单位为`px`                                                                 | _number \| string_   | -        |
| label-align              | 表单项 label 对齐方式，可选值为 `center` `right` `top`                                            | _string_             | `left`   |
| input-align              | 输入框对齐方式，可选值为 `center` `right`                                                         | _string_             | `left`   |
| error-message-align      | 错误提示文案对齐方式，可选值为 `center` `right`                                                   | _string_             | `left`   |
| validate-trigger         | 表单校验触发时机，可选值为 `onChange`、`onSubmit`，支持通过数组同时设置多个值，具体用法见下方表格 | _string \| string[]_ | `onBlur` |
| colon                    | 是否在 label 后面添加冒号                                                                         | _boolean_            | `false`  |
| disabled                 | 是否禁用表单中的所有输入框                                                                        | _boolean_            | `false`  |
| readonly                 | 是否将表单中的所有输入框设置为只读状态                                                            | _boolean_            | `false`  |
| required                 | 是否显示表单必填星号                                                                              | _boolean \| 'auto'_  | `null`   |
| validate-first           | 是否在某一项校验不通过时停止校验                                                                  | _boolean_            | `false`  |
| scroll-to-error          | 是否在提交表单且校验不通过时滚动至错误的表单项                                                    | _boolean_            | `false`  |
| scroll-to-error-position | 滚动至错误的表单项时的位置，可选值为 `center` \| `end` \| `nearest` \| `start`                    | _string_             | -        |
| show-error               | 是否在校验不通过时标红输入框                                                                      | _boolean_            | `false`  |
| show-error-message       | 是否在校验不通过时在输入框下方展示错误提示                                                        | _boolean_            | `true`   |
| submit-on-enter          | 是否在按下回车键时提交表单                                                                        | _boolean_            | `true`   |

> 表单项的 API 参见：[Field 组件](/components/field/)

### Rule 数据结构

使用 Field 的 `rules` 属性可以定义校验规则，可选属性如下:

| 键名          | 说明                                                                                                                  | 类型                                            |
| ------------- | --------------------------------------------------------------------------------------------------------------------- | ----------------------------------------------- |
| required      | 是否为必选字段，当值为空值时（空字符串、空数组、`false`、`undefined`、`null` ），校验不通过                           | `boolean`                                       |
| message       | 错误提示文案，可以设置为一个函数来返回动态的文案内容                                                                  | `string \| (value, rule) => string`             |
| validator     | 通过函数进行校验，可以返回一个 Promise 来进行异步校验                                                                 | `(value, rule) => boolean \| string \| Promise` |
| pattern       | 通过正则表达式进行校验，正则无法匹配表示校验不通过                                                                    | `RegExp`                                        |
| trigger       | 设置本项规则的触发时机，优先级高于 Form 组件设置的 `validate-trigger` 属性，可选值为 `onChange`、`onBlur`、`onSubmit` | `string \| string[]`                            |
| formatter     | 格式化函数，将表单项的值转换后进行校验                                                                                | `(value, rule) => any`                          |
| validateEmpty | 设置 `validator` 和 `pattern` 是否要对空值进行校验，默认值为 `true`，可以设置为 `false` 来禁用该行为                  | `boolean`                                       |

### validate-trigger 可选值

通过 `validate-trigger` 属性可以自定义表单校验的触发时机。

| 值       | 描述                                 |
| -------- | ------------------------------------ |
| onSubmit | 仅在提交表单时触发校验               |
| onBlur   | 在提交表单和输入框失焦时触发校验     |
| onChange | 在提交表单和输入框内容变化时触发校验 |

### Events

| 事件名 | 说明                       | 回调参数                                          |
| ------ | -------------------------- | ------------------------------------------------- |
| submit | 提交表单且验证通过后触发   | `values: object`                                  |
| failed | 提交表单且验证不通过后触发 | `errorInfo: { values: object, errors: object[] }` |

### 方法

通过 ref 可以获取到 Form 实例并调用实例方法。

| 方法名              | 说明                                                                                                       | 参数                                | 返回值                                    |
| ------------------- | ---------------------------------------------------------------------------------------------------------- | ----------------------------------- | ----------------------------------------- |
| submit              | 提交表单，与点击提交按钮的效果等价                                                                         | -                                   | -                                         |
| getValues           | 获取所有表单项当前的值                                                                                     | -                                   | `Record<string, unknown>`                 |
| validate            | 验证表单，支持传入一个或多个 `name` 来验证单个或部分表单项，不传入 `name` 时，会验证所有表单项             | `name?: string \| string[]`         | `Promise\<void\>`                         |
| resetValidation     | 重置表单项的验证提示，支持传入一个或多个 `name` 来重置单个或部分表单项，不传入 `name` 时，会重置所有表单项 | `name?: string \| string[]`         | -                                         |
| getValidationStatus | 获取所有表单项的校验状态，状态包括 `passed`、`failed`、`unvalidated`                                       | -                                   | `Record\<string, FieldValidationStatus\>` |
| scrollToField       | 滚动到对应表单项的位置，默认滚动到顶部，第二个参数传 false 可滚动至底部                                    | `name: string, alignToTop: boolean` | -                                         |

### 类型定义

组件导出以下类型定义：

```ts
import type { FormInstance, FormProps } from '@hytech/ht-ui';
```

`FormInstance` 是组件实例的类型，用法如下：

```ts
import { ref } from 'vue';
import type { FormInstance } from '@hytech/ht-ui';

const formRef = ref<FormInstance>();

formRef.value?.submit();
```

### Slots

| 名称    | 说明     |
| ------- | -------- |
| default | 表单内容 |
