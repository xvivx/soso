<!-- <script setup lang="ts">
import { ref } from 'vue';
import { HTButton, HTSwitch, HTField, HTForm } from '@hytech/ht-ui';

const switchChecked = ref(false);

const onSubmit = (values: Record<string, string>) => {
  console.log(values);
};
</script>

<template>
  <HTForm @submit="onSubmit">
    <HTField name="switch" label="开关">
      <template #input>
        <HTSwitch v-model="switchChecked" />
      </template>
    </HTField>
    <div style="margin: 16px 0">
      <HTButton round type="primary" native-type="submit"> 提交 </HTButton>
    </div>
  </HTForm>
</template> -->
