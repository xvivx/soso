<script setup lang="ts">
import { ref } from 'vue';
import { HTButton, HTDatePicker, HTField, HTForm, HTPopover } from '@hytech/ht-ui';

const result = ref('');
const showPicker = ref(false);
const pickerValue = ref(new Date());
const onConfirm = (value: Date) => {
  result.value = value.toISOString().split('T')[0]!;
  pickerValue.value = value;
  showPicker.value = false;
};

const onSubmit = (value: Date) => {
  console.log(value);
};
</script>

<template>
  <HTForm @submit="onSubmit">
    <HTField
      v-model="result"
      is-link
      readonly
      name="datePicker"
      label="时间选择"
      placeholder="点击选择时间"
      @click="showPicker = true"
    />
    <HTPopover v-model:open="showPicker" title="选择日期">
      <HTDatePicker :v-model="pickerValue" @confirm="onConfirm" />
    </HTPopover>
    <div style="margin: 16px 0">
      <HTButton round type="primary" native-type="submit"> 提交 </HTButton>
    </div>
  </HTForm>
</template>
