<script setup lang="ts">
import { ref } from 'vue';
import { HTField, HTForm } from '@hytech/ht-ui';

const username = ref('');
const password = ref('');
const onSubmit = (values: object) => {
  console.log('submit', values);
};
</script>

<template>
  <HTForm @submit="onSubmit">
    <HTField
      v-model="username"
      name="username"
      label="用户名"
      placeholder="用户名"
      :rules="[{ required: true, message: '请填写用户名' }]"
    />
    <HTField
      v-model="password"
      type="password"
      name="password"
      label="密码"
      placeholder="密码"
      :rules="[{ required: true, message: '请填写密码' }]"
    />
    <div style="margin: 16px 0">
      <HTButton round type="primary" native-type="submit"> 提交 </HTButton>
    </div>
  </HTForm>
</template>
