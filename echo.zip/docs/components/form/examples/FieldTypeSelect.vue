<script setup lang="ts">
import { ref } from 'vue';
import { HTButton, HTField, HTForm, HTSelect } from '@hytech/ht-ui';
import { mock } from 'mockjs';

const { options } = mock({
  'options|5-10': [
    {
      label: '@word(5,10)',
      value: '@uuid',
    },
  ],
});
const value = ref<string>();

const onSubmit = (values: Record<string, string>) => {
  console.log(values);
};
</script>

<template>
  <HTForm @submit="onSubmit">
    <HTField name="selector" label="选择器">
      <template #input>
        <HTSelect class="w-full md:w-60" v-model:value="value" placeholder="请选择" :options="options" />
      </template>
    </HTField>

    <div style="margin: 16px 0">
      <HTButton round type="primary" native-type="submit"> 提交 </HTButton>
    </div>
  </HTForm>
</template>
