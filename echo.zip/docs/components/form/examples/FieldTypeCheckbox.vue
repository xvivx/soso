<script setup lang="ts">
import { ref } from 'vue';
import { HTButton, HTCheckbox, HTField, HTForm } from '@hytech/ht-ui';

const value = ref();

const onSubmit = (values: Record<string, string>) => {
  console.log(values);
};
</script>

<template>
  <HTForm @submit="onSubmit">
    <HTField name="checkboxGroup" label="复选框">
      <template #input>
        <HTCheckbox v-model="value" name="1" shape="square"> 复选框 1 </HTCheckbox>
      </template>
    </HTField>
    <div style="margin: 16px 0">
      <HTButton round type="primary" native-type="submit"> 提交 </HTButton>
    </div>
  </HTForm>
</template>
