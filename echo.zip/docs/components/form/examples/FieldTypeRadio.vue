<script setup lang="ts">
import { ref } from 'vue';
import { HTButton, HTField, HTForm, HTRadio, HTRadioGroup } from '@hytech/ht-ui';

const value = ref('1');

const onSubmit = (values: Record<string, string>) => {
  console.log(values);
};
</script>

<template>
  <HTForm @submit="onSubmit">
    <HTField name="radio" label="单选框">
      <template #input>
        <HTRadioGroup v-model="value" direction="horizontal">
          <HTRadio name="1">单选框 1</HTRadio>
          <HTRadio name="2">单选框 2</HTRadio>
        </HTRadioGroup>
      </template>
    </HTField>

    <div style="margin: 16px 0">
      <HTButton round type="primary" native-type="submit"> 提交 </HTButton>
    </div>
  </HTForm>
</template>
