<script setup lang="ts">
import { ref } from 'vue';
import { HTButton, HTField, HTForm, HTStepper } from '@hytech/ht-ui';

const value = ref(1);

const onSubmit = (values: Record<string, string>) => {
  console.log(values);
};
</script>

<template>
  <HTForm @submit="onSubmit">
    <HTField name="stepper" label="步进器">
      <template #input>
        <HTStepper v-model="value" :min="1" :max="10" :step="1" />
      </template>
    </HTField>

    <div style="margin: 16px 0">
      <HTButton round type="primary" native-type="submit"> 提交 </HTButton>
    </div>
  </HTForm>
</template>
