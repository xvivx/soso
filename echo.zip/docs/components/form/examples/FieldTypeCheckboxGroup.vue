<script setup lang="ts">
import { ref } from 'vue';
import { HTButton, HTCheckbox, HTCheckboxGroup, HTField, HTForm } from '@hytech/ht-ui';

const value = ref(['1']);

const onSubmit = (values: Record<string, string>) => {
  console.log(values);
};
</script>

<template>
  <HTForm @submit="onSubmit">
    <HTField name="checkboxGroup" label="复选框组">
      <template #input>
        <HTCheckboxGroup v-model="value" direction="horizontal">
          <HTCheckbox name="1" shape="square"> 复选框 1 </HTCheckbox>
          <HTCheckbox name="2" shape="square"> 复选框 2 </HTCheckbox>
        </HTCheckboxGroup>
      </template>
    </HTField>
    <div style="margin: 16px 0">
      <HTButton round type="primary" native-type="submit"> 提交 </HTButton>
    </div>
  </HTForm>
</template>
