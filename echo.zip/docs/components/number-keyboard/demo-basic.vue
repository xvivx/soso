<template>
  <div>
    <input v-model="value" readonly @focus="show = true" placeholder="请输入数字" />
    <HTNumberKeyboard
      v-model="value"
      :show="show"
      title="数字键盘示例"
      :extra-key="[]"
      hide-on-click-outside
      @close="show = false"
    />
  </div>
</template>
<script setup lang="ts">
import { ref } from 'vue';
import { HTNumberKeyboard } from '@hytech/ht-ui';

const value = ref('');
const show = ref(false);
</script>
