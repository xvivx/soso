---
title: NumberKeyboard 数字键盘
---

# NumberKeyboard 数字键盘

用于移动端数字输入场景，支持自定义键盘内容和交互。

## 基本用法

<demo vue="./demo-basic.vue" codesandbox="true" />

## 属性

| 属性名                | 说明                       | 类型           | 默认值      |
| --------------------- | -------------------------- | -------------- | ----------- |
| modelValue            | 当前输入值                 | string         | -           |
| show                  | 是否显示键盘               | boolean        | false       |
| title                 | 顶部标题                   | string         | -           |
| theme                 | 主题风格（default/custom） | string         | default     |
| extraKey              | 自定义额外按键（不支持小数点） | string[]   | []          |
| closeButtonText       | 关闭按钮文字               | string         | 收起        |
| deleteButtonText      | 删除按钮文字               | string         | 删除        |
| hideDelete            | 隐藏删除按钮               | boolean        | false       |
| hideClose             | 隐藏关闭按钮               | boolean        | false       |
| maxlength             | 最大输入长度               | number         | -           |
| randomKeyOrder        | 随机排列数字键             | boolean        | false       |
| transition            | 是否显示弹出动画（始终开启） | boolean        | true        |
| hideOnClickOutside    | 点击外部自动关闭键盘       | boolean        | false       |

## 事件

| 事件名            | 说明                   | 回调参数       |
| ----------------- | ---------------------- | -------------- |
| update:modelValue | 输入值变化时触发       | value          |
| input             | 点击数字键时触发       | key            |
| delete            | 点击删除键时触发       | -              |
| close             | 点击关闭键时触发       | -              |
| blur              | 失焦时触发             | -              |
| show              | 显示时触发             | -              |

## 插槽

暂无

## 样式

支持移动端友好样式，支持自定义主题。

---

## 相关链接
- [Vant NumberKeyboard 文档](https://vant-ui.github.io/vant/#/zh-CN/number-keyboard)
