# DatePicker 日期选择器

用于选择日期，支持年月日的选择。

## 基础用法

通过 v-model 绑定选中的日期。 <demo vue="./examples/Basic.vue" codesandbox="true" />

## 限制日期范围

通过 min-date 和 max-date 属性可以限制可选的日期范围。 <demo vue="./examples/MinMax.vue" codesandbox="true" />

## 隐藏工具栏

通过设置 show-toolbar 为 false 可以隐藏工具栏。 <demo vue="./examples/NoToolbar.vue" codesandbox="true" />

## 自定义文本

通过 title、confirm-text 和 cancel-text 属性可以自定义文本。 <demo vue="./examples/CustomText.vue" codesandbox="true" />

## 监听事件

DatePicker 提供了 confirm、cancel 和 change 事件。 <demo vue="./examples/WithEvents.vue" codesandbox="true" />

## API

### Props

| 参数         | 说明           | 类型                                             | 默认值   |
| ------------ | -------------- | ------------------------------------------------ | -------- |
| v-model      | 当前选中的日期 | `Date`                                           | -        |
| type         | 选择器类型     | `'date' \| 'time' \| 'datetime' \| 'year-month'` | `'date'` |
| min-date     | 可选的最小日期 | `Date`                                           | 十年前   |
| max-date     | 可选的最大日期 | `Date`                                           | 十年后   |
| title        | 顶部栏标题     | `string`                                         | -        |
| confirm-text | 确认按钮文字   | `string`                                         | `'确认'` |
| cancel-text  | 取消按钮文字   | `string`                                         | `'取消'` |
| show-toolbar | 是否显示顶部栏 | `boolean`                                        | `true`   |
| formatter    | 选项格式化函数 | `(type: string, value: string) => string`        | -        |
| filter       | 选项过滤函数   | `(type: string, values: string[]) => string[]`   | -        |

### Events

| 事件名  | 说明               | 参数          |
| ------- | ------------------ | ------------- |
| confirm | 点击确认按钮时触发 | `value: Date` |
| cancel  | 点击取消按钮时触发 | -             |
| change  | 选项变化时触发     | `value: Date` |

### 类型定义

组件导出以下类型定义：

```ts
import type { DatePickerEmits, DatePickerProps, DatePickerType, PickerColumn } from '@hytech/ht-ui';
```

## 注意事项

- 当前版本仅支持 date 类型（年月日选择）
- time 和 datetime 类型将在后续版本中支持
- 建议配合 ActionSheet 或 Popup 组件使用，实现底部弹出效果
