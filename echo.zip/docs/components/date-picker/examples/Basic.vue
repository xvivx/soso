<script setup lang="ts">
import { ref } from 'vue';
import { HTDatePicker } from '@hytech/ht-ui';

const date = ref(new Date());
</script>

<template>
  <HTDatePicker v-model="date" title="选择日期" />
</template>
