<script setup lang="ts">
import { ref } from 'vue';
import { HTDatePicker } from '@hytech/ht-ui';

const date = ref(new Date());
const minDate = new Date(2020, 0, 1);
const maxDate = new Date(2025, 11, 31);
</script>

<template>
  <HTDatePicker v-model="date" title="选择日期" :min-date="minDate" :max-date="maxDate" />
</template>
