<script setup lang="ts">
import { ref } from 'vue';
import { HTDatePicker } from '@hytech/ht-ui';

const date = ref(new Date());
const result = ref('');

const onConfirm = (value: Date) => {
  result.value = `确认: ${value.toLocaleDateString()}`;
};

const onCancel = () => {
  result.value = '取消选择';
};

const onChange = (value: Date) => {
  result.value = `变化: ${value.toLocaleDateString()}`;
};
</script>

<template>
  <div>
    <HTDatePicker v-model="date" title="选择日期" @confirm="onConfirm" @cancel="onCancel" @change="onChange" />
    <div v-if="result" class="mt-4 text-gray-600">{{ result }}</div>
  </div>
</template>
