<script setup lang="ts">
import { ref } from 'vue';
import { HTButton, HTCollapse, HTCollapseItem, type CollapseInstance, type CollapseProps } from '@hytech/ht-ui';

const activeNames = ref([]);
const collapseRef = ref<CollapseInstance>();

function onChange(val: CollapseProps['modelValue']) {
  console.log('multiple change', val);
}

function expandAll() {
  collapseRef.value?.toggleAll(true);
}

function collapseAll() {
  collapseRef.value?.toggleAll(false);
}
</script>

<template>
  <HTCollapse ref="collapseRef" v-model="activeNames" @change="onChange">
    <HTCollapseItem name="item-a" title="标题 1">内容 1</HTCollapseItem>
    <HTCollapseItem name="item-b" title="标题 2">内容 2</HTCollapseItem>
    <HTCollapseItem name="item-c" title="标题 3">内容 3</HTCollapseItem>
  </HTCollapse>
  <div class="mt-6 flex gap-4">
    <HTButton class="btn border" @click="expandAll">全部展开</HTButton>
    <HTButton class="btn border" @click="collapseAll">全部折叠</HTButton>
  </div>
</template>
