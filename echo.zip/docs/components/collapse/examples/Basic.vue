<script setup lang="ts">
import { ref } from 'vue';
import { HTCollapse, HTCollapseItem } from '@hytech/ht-ui';

const activeNames = ref([]);
</script>

<template>
  <HTCollapse v-model="activeNames">
    <HTCollapseItem name="item-1" title="标题 1">内容 1</HTCollapseItem>
    <HTCollapseItem name="item-2" title="标题 2">内容 2</HTCollapseItem>
    <HTCollapseItem name="item-3" title="标题 3">内容 3</HTCollapseItem>
  </HTCollapse>
</template>
