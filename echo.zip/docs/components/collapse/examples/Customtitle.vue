<script setup lang="ts">
import { ref } from 'vue';
import { HTCollapse, HTCollapseItem } from '@hytech/ht-ui';

const activeNames = ref([]);
</script>

<template>
  <HTCollapse v-model="activeNames">
    <HTCollapseItem name="item-1">
      <template #title>
        <div>标题1</div>
      </template>
      内容1
    </HTCollapseItem>
    <HTCollapseItem name="item-2">
      <template #title>
        <div>标题 2</div>
      </template>
      内容2
    </HTCollapseItem>
    <HTCollapseItem name="item-3">
      <template #title>
        <div>标题 3</div>
      </template>
      内容3
    </HTCollapseItem>
  </HTCollapse>
</template>
