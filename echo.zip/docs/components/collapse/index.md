# HTCollapse 折叠面板

将一组内容放置在多个折叠面板中，点击面板的标题可以展开或收缩其内容。

## 基础用法

通过 v-model 控制展开的面板列表，activeNames 为数组格式。 <demo vue="./examples/Basic.vue" codesandbox="true" />

## 手风琴

通过 accordion 可以设置为手风琴模式，最多展开一个面板，此时 activeName 为字符串格式。
<demo vue="./examples/Accordion.vue" codesandbox="true" />

## 禁用状态

通过 disabled 属性来禁用单个面板。 <demo vue="./examples/Disabled.vue" codesandbox="true" />

## 自定义标题内容

通过 title 插槽可以自定义标题栏的内容。 <demo vue="./examples/CustomTitle.vue" codesandbox="true" />

## 全部展开与全部切换

通过 Collapse 实例上的 toggleAll 方法可以实现全部展开与全部切换。
<demo vue="./examples/ToggleAll.vue" codesandbox="true" />

## Collapse（容器）

### Props

| 参数        | 说明                                                                  | 类型      | 默认值  |
| ----------- | --------------------------------------------------------------------- | --------- | ------- |
| v-model     | 当前展开面板的 name，手风琴模式： `string`，非手风琴模式： `string[]` | -         |
| accordion   | 是否开启手风琴模式                                                    | `boolean` | `false` |
| collapsible | 是否允许全部折叠（仅手风琴模式下生效）                                | `boolean` | `true`  |

### Events

| 事件名 | 说明           | 回调参数                                 |
| ------ | -------------- | ---------------------------------------- |
| change | 切换面板时触发 | activeNames: 类型与 v-model 绑定的值一致 |

### 方法

| 方法名    | 说明                                                                             | 参数                                     | 返回值 |
| --------- | -------------------------------------------------------------------------------- | ---------------------------------------- | ------ |
| toggleAll | 切换所有面板展开状态，传 `true` 为全部展开，`false` 为全部收起，不传参为全部切换 | activeNames: 类型与 v-model 绑定的值一致 | -      |

### Slots

| 名称    | 说明                         |
| ------- | ---------------------------- |
| default | 放置 `<HTCollapseItem>` 子项 |

---

## CollapseItem（子项）

### Props

| 参数       | 说明                                                       | 类型      | 默认值 |
| ---------- | ---------------------------------------------------------- | --------- | ------ |
| name       | 唯一标识符                                                 | `string`  | -      |
| title      | 标题                                                       | `string`  | -      |
| icon       | 标题栏左侧图标名称或图片链接，等同于 Icon 组件的 name 属性 | `string`  | -      |
| size       | 标题栏大小，可选值为 large                                 | `string`  | -      |
| disabled   | 是否禁用面板                                               | `boolean` | false  |
| titleClass | 标题额外类名                                               | `string`  | -      |

### 方法

| 方法名 | 说明                                                         | 参数             | 返回值 |
| ------ | ------------------------------------------------------------ | ---------------- | ------ |
| toggle | 切换面板展开状态，传 true 为展开，false 为收起，不传参为切换 | expand?: boolean | -      |

### Slots

| 名称       | 说明                 |
| ---------- | -------------------- |
| default    | 面板内容             |
| title      | 自定义标题内容       |
| icon-right | 自定义标题栏右侧图标 |

### 类型定义

组件导出以下类型定义：

```ts
import type {
  CollapseInstance,
  CollapseItemInstance,
  CollapseItemProps,
  CollapseProps,
  CollapseToggleAllOptions,
} from '@hytech/ht-ui';
```
