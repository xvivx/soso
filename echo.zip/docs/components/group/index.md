# HTCellGroup 单元格组

用于将多个 HTCell 进行分组展示，支持标题、卡片容器（inset）与首尾边框。对齐 Element 与 Vant 的常见分组样式。

## 基础用法

<demo vue="./group-basic.vue" codesandbox="true" />

## 卡片容器（Inset）

<demo vue="./group-inset.vue" codesandbox="true" />

## Attributes

| Attribute | Description | Type | Default | 与 Vant 差异 |
| --- | --- | --- | --- | --- |
| `class` | 自定义类名 | `string \| object \| array` | - | ✨ HTCellGroup 独有 |
| `title` | 组标题 | `string` | - | ✅ 兼容 |
| `border` | 是否展示组首尾边框 | `boolean` | `true` | ✅ 兼容 |
| `inset` | 是否使用卡片容器样式 | `boolean` | `false` | ✅ 兼容 |

## Slots

| Slot | Description | 与 Vant 差异 |
| --- | --- | --- |
| `default` | 默认插槽，用于放置 HTCell 组件 | ✅ 兼容 |

## 主题定制

```css
.ht-cell-group {
  --ht-cell-group-background: var(--ht-background-2);
  --ht-cell-group-title-color: var(--ht-text-color-2);
  --ht-cell-group-title-padding: 16px 16px 8px;
  --ht-cell-group-title-font-size: 14px;
  --ht-cell-group-title-line-height: 16px;
  --ht-cell-group-inset-padding: 0 16px;
  --ht-cell-group-inset-radius: 8px;
  --ht-cell-group-inset-title-padding: 16px 0 8px;
}
```

## Vant API 兼容性

| Vant API | HT 实现 | 说明 |
| --- | --- | --- |
| `title` | ✅ 完全兼容 | 无差异 |
| `border` | ✅ 完全兼容 | 无差异 |
| `inset` | ✅ 完全兼容 | 无差异 |