# HTCellGroup 单元格组

用于将多个 HTCell 进行分组展示，支持标题、卡片容器（inset）与首尾边框。对齐 Element 与 Vant 的常见分组样式。

## 基础用法

<demo vue="./group-basic.vue" codesandbox="true" />

## 卡片容器（Inset）

<demo vue="./group-inset.vue" codesandbox="true" />

## Attributes

| Attribute | Description | Type | Default | 与 Vant 差异 |
| --- | --- | --- | --- | --- |
| `title` | 组标题 | `string` | - | 兼容 |
| `border` | 是否展示组首尾边框 | `boolean` | `true` | 兼容 |
| `inset` | 是否使用卡片容器样式 | `boolean` | `false` | 兼容 |

## Slots

| 名称    | 说明     | 与 Vant 差异 |
| ------- | -------- | ------------ |
| default | 默认插槽 | 兼容         |