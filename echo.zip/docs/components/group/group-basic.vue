<template>
  <div class="demo-group">
    <HTCellGroup title="分组标题">
      <div class="content" :style="{ position: 'relative' }">
        <HTCell title="账号" value="hello@company.com" />
        <HTCell title="通知" label="接收系统推送" />
        <HTCell title="语言" value="中文" />
      </div>
    </HTCellGroup>

    <HTCellGroup title="带边框">
      <div class="content" :style="{ position: 'relative' }">
        <HTCell title="城市" value="成都" />
        <HTCell title="地区" value="高新区" />
      </div>
    </HTCellGroup>
  </div>
</template>

<script setup lang="ts">
import { HTCell, HTCellGroup } from '@/components';
</script>

<style scoped>
.demo-group {
  width: 100%;
  max-width: 600px;
  margin: 0 auto;
}
</style>
