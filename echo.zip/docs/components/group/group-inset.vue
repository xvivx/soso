<template>
  <div class="demo-group">
    <HTCellGroup title="卡片容器" inset>
      <div class="content" :style="{ position: 'relative' }">
        <HTCell title="昵称" value="海神" />
        <HTCell title="简介" label="以 Element 与 Vant 的使用习惯为参考" />
        <HTCell title="网站" value="poseidon.design" />
      </div>
    </HTCellGroup>

    <HTCellGroup title="卡片容器（带边框）" inset border>
      <div class="content" :style="{ position: 'relative' }">
        <HTCell title="国家" value="中国" />
        <HTCell title="城市" value="上海" />
      </div>
    </HTCellGroup>
  </div>
</template>

<script setup lang="ts">
import { HTCell, HTCellGroup } from '@hytech/ht-ui';
</script>

<style scoped>
.demo-group {
  width: 100%;
  max-width: 600px;
  margin: 0 auto;
}
</style>
