# HTRow 栅格行

用于栅格布局的行容器，配合 HTCol 使用。支持 `gutter` 间距、`justify` 主轴对齐以及 `align` 交叉轴对齐。

## 基础栅格

<demo vue="./row-basic.vue" codesandbox="true" />

## 对齐与间距

<demo vue="./row-justify-align.vue" codesandbox="true" />

## Attributes

| Attribute | Description | Type | Default | 与 Vant 差异 |
| --- | --- | --- | --- | --- |
| `class` | 自定义类名 | `string \| object \| array` | - | ✨ HTRow 独有 |
| `tag` | 根节点标签 | `string` | `'div'` | ✨ HTRow 独有 |
| `gutter` | 栅格间距（px） | `number \| string` | `0` | ✅ 兼容 |
| `justify` | 主轴对齐 | `'start' \| 'end' \| 'center' \| 'space-around' \| 'space-between'` | `'start'` | ✅ 兼容 |
| `align` | 交叉轴对齐 | `'top' \| 'middle' \| 'bottom'` | `'top'` | ✅ 兼容 |
| `wrap` | 是否自动换行 | `boolean` | `true` | ✅ 兼容 |

## Events

| Event | Description | Parameters | 与 Vant 差异 |
| --- | --- | --- | --- |
| `click` | 点击 Row 时触发 | `(event: MouseEvent)` | ✅ 兼容 |

## Slots

| Slot | Description | 与 Vant 差异 |
| --- | --- | --- |
| `default` | 放置 HTCol 组件 | ✅ 兼容 |

## 主题定制

```css
.ht-row {
  --ht-row-gutter: 0px;
}
```

## Vant API 兼容性

| Vant API | HT 实现 | 说明 |
| --- | --- | --- |
| `gutter` | ✅ 完全兼容 | 无差异 |
| `justify` | ✅ 完全兼容 | 无差异 |
| `align` | ✅ 完全兼容 | 无差异 |
| `wrap` | ✅ 完全兼容 | 无差异 |
| `type` | ❌ 不支持 | HTRow 默认使用 flex 布局 |

## 注意事项

- HTRow 组件通过 `provide` 向子组件 HTCol 传递 `gutter` 间距配置
- 栅格系统基于 24 列布局
- 默认使用 flex 布局，无需额外配置 `type` 属性

## 示例

### 不换行

当 `wrap` 属性为 `false` 时，子元素将不会自动换行。

```vue
<template>
  <HTRow :wrap="false">
    <HTCol :span="8">span: 8</HTCol>
    <HTCol :span="8">span: 8</HTCol>
    <HTCol :span="10">span: 10</HTCol>
  </HTRow>
</template>
```