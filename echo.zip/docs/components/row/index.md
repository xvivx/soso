# HTRow 栅格行

用于栅格布局的行容器，配合 HTCol 使用。支持 `gutter` 间距、`justify` 主轴对齐以及 `align` 交叉轴对齐。

## 基础栅格

<demo vue="./row-basic.vue" codesandbox="true" />

## 对齐与间距

<demo vue="./row-justify-align.vue" codesandbox="true" />

## Attributes

| Attribute | Description | Type | Default | 与 Vant 差异 |
| --- | --- | --- | --- | --- |
| `tag` | 根节点标签 | `string` | `'div'` | ✅ 兼容 |
| `gutter` | 栅格间距（px） | `number \| string` | `0` | ✅ 兼容 |
| `justify` | 主轴对齐 | `'start' \| 'end' \| 'center' \| 'space-around' \| 'space-between'` | `'start'` | ✅ 兼容 |
| `align` | 交叉轴对齐 | `'top' \| 'middle' \| 'bottom'` | `'top'` | ✅ 兼容 |
| `wrap` | 是否自动换行 | `boolean` | `true` | ✅ 兼容（Vant 默认为 true） |
| - | 布局方式 | - | - | ❌ 缺少 `type` 属性（flex 布局） |

## Events

| Event | Description | Parameters | 与 Vant 差异 |
| --- | --- | --- | --- |
| `click` | 点击 Row 时触发 | `event: MouseEvent` | ✅ 兼容 |

## Slots

| Slot | Description | 与 Vant 差异 |
| --- | --- | --- |
| `default` | 放置 HTCol | ✅ 兼容 |

## 示例

### 不换行

当 `wrap` 属性为 `false` 时，子元素将不会自动换行。

```vue
<template>
  <HTRow :wrap="false">
    <HTCol :span="8">span: 8</HTCol>
    <HTCol :span="8">span: 8</HTCol>
    <HTCol :span="10">span: 10</HTCol>
  </HTRow>
</template>
```