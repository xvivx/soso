<template>
  <div class="demo-row">
    <HTRow :gutter="16" justify="space-between" align="middle">
      <HTCol :span="6"><div class="box tall">A</div></HTCol>
      <HTCol :span="6"><div class="box">B</div></HTCol>
      <HTCol :span="6"><div class="box tall">C</div></HTCol>
    </HTRow>

    <HTRow :gutter="16" justify="center" :style="{ marginTop: '12px' }">
      <HTCol :span="4"><div class="box">1</div></HTCol>
      <HTCol :span="4"><div class="box">2</div></HTCol>
      <HTCol :span="4"><div class="box">3</div></HTCol>
    </HTRow>
  </div>
</template>

<script setup lang="ts">
import { HTCol, HTRow } from '@hytech/ht-ui';
</script>

<style scoped>
.demo-row {
  width: 100%;
  max-width: 800px;
  margin: 0 auto;
}
.box {
  background: #f5f5f5;
  border: 1px solid #e0e0e0;
  border-radius: 4px;
  text-align: center;
  padding: 12px 0;
  color: #333;
}
.tall {
  height: 80px;
  display: flex;
  align-items: center;
  justify-content: center;
}
</style>
