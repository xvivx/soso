import { type EnhanceAppContext } from 'vitepress/client';
import DefaultTheme from 'vitepress/theme';
import Layout, { HT } from '../../App.vue';

export default {
  ...DefaultTheme,
  Layout,
  enhanceApp(ctx: EnhanceAppContext) {
    DefaultTheme.enhanceApp(ctx);

    Object.keys(HT).forEach((name) => {
      ctx.app.component(name, HT[name as keyof typeof HT]);
    });
  },
};
