import { type EnhanceAppContext } from 'vitepress/client';
import DefaultTheme from 'vitepress/theme';
import Layout from '../../App.vue';

export default {
  ...DefaultTheme,
  Layout,
  enhanceApp(ctx: EnhanceAppContext) {
    DefaultTheme.enhanceApp(ctx);
  },
};
