import { resolve } from 'path';
import vueJsx from '@vitejs/plugin-vue-jsx';
import checker from 'vite-plugin-checker';
import { defineConfig } from 'vitepress';
import { vitepressDemoPlugin } from 'vitepress-demo-plugin';

const docsRoot = resolve(__dirname, '../../docs');
const compRoot = resolve(__dirname, '../../src');

// https://vitepress.dev/reference/site-config
export default defineConfig({
  title: 'Hytech UI',
  description: 'Hytech UI Components',
  cacheDir: resolve(process.cwd(), 'node_modules/.vite/vitepress'),
  outDir: '../docs-dist',
  themeConfig: {
    // https://vitepress.dev/reference/default-theme-config
    nav: [
      { text: 'Home', link: '/components' },
      { text: '组件', link: '/components' },
    ],
    sidebar: [
      {
        text: '基础组件',
        items: [
          { text: 'Button 按钮', link: '/components/button/' },
          { text: 'Icon 图标', link: '/components/icon/' },
          { text: 'Cell 单元格', link: '/components/cell/' },
          { text: 'Group 分组容器', link: '/components/group/' },
          { text: 'Image 图片', link: '/components/image/' },
          { text: 'Row 栅格行', link: '/components/row/' },
          { text: 'Col 栅格列', link: '/components/col/' },
          { text: 'Divider 分割线', link: '/components/divider/' },
          { text: 'Collapse 折叠面板', link: '/components/collapse/' },
          { text: 'Empty 空状态', link: '/components/empty/' },
          { text: 'Skeleton 骨架屏', link: '/components/skeleton/' },
          { text: 'Loading 加载', link: '/components/loading/' },
          { text: 'Radio 单选框', link: '/components/radio/' },
          { text: 'Checkbox 复选框', link: '/components/checkbox/' },
          { text: 'Switch 开关', link: '/components/switch/' },
          { text: 'List 列表', link: '/components/list/' },
          { text: 'Form 表单', link: '/components/form/' },
          { text: 'Field 输入框', link: '/components/field/' },
          { text: 'Search 搜索框', link: '/components/search/' },
          { text: 'Stepper 步进器', link: '/components/stepper/' },
          { text: 'DatePicker 日期选择器', link: '/components/date-picker/' },
          { text: 'Sticky 吸附', link: '/components/sticky/' },
          { text: 'Swipe 轮播', link: '/components/swipe/' },
          { text: 'Tabs 标签页', link: '/components/tabs/' },
          { text: 'Pull-refresh 下拉刷新', link: '/components/pull-refresh/' },
          { text: 'Modal 弹窗', link: '/components/modal/' },
          { text: 'ActionSheet 动作面板', link: '/components/action-sheet/' },
          { text: 'Popover 气泡弹出', link: '/components/popover/' },
          { text: 'Select 选择器', link: '/components/select/' },
          { text: 'Tag 标签', link: '/components/tag/' },
          { text: 'Toast 轻提示', link: '/components/toast/' },
          { text: 'Tooltip 提示', link: '/components/tooltip/' },
          { text: 'PinInput 验证码输入框', link: '/components/pin-input/' },
        ],
      },
    ],
  },
  markdown: {
    theme: { light: 'github-light', dark: 'github-dark' },
    config: (md) => {
      md.use(vitepressDemoPlugin);
    },
  },
  vite: {
    plugins: [
      vueJsx(),
      checker({
        typescript: { buildMode: true },
        eslint: {
          watchPath: [docsRoot, compRoot],
          useFlatConfig: true,
          lintCommand: `eslint --ext .ts,tsx,.vue ${[docsRoot, compRoot].join(' ')} --max-warnings=0`,
        },
      }),
    ] as any[],
    resolve: {
      alias: {
        '@': resolve(__dirname, '../../src'),
        '@hytech/ht-ui': resolve(__dirname, '../../src/components'),
      },
    },
  },
});
