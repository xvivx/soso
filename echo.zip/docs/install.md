## 安装

这是一个私有库, 安装前请配置相关权限, 确保你有这个库的访问权限。

::: code-group

```bash [pnpm]
pnpm install @hytech/ht-ui
```

```bash [npm]
npm install @hytech/ht-ui
```

```bash [yarn]
yarn add @hytech/ht-ui
```

:::

## 自动导入

配置你的 `vite.config.ts`

```ts
import htAutoImport from '@hytech/ht-ui/plugins/auto-import';
import vue from '@vitejs/plugin-vue';
import { defineConfig } from 'vite';

export default defineConfig({
  plugins: [vue(), htAutoImport()],
});
```

这样可以在项目中无需 `import` 就可以直接写 `ht-button` 或者 `HtButton` 这样的标签。推荐使用 `vue` 风格的写法。

## 组件类型提示

拥有所有组件的类型提示

### 方式一（推荐）

在项目中能被ts解析到的类型文件(env.d.ts)中添加

```ts
/// <reference types="@hytech/ht-ui/component-list" />
```

### 方式二

或者在入口文件中引入类型

```ts
import '@hytech/ht-ui/component-list';
```
