---
layout: home
title: Hytech UI Components
hero:
  name: Hytech UI Components
  text: Headless + Tailwind + Vue 3 组件库
  actions:
    - theme: brand
      text: 浏览组件
      link: /components
    - theme: alt
      text: 快速上手
      link: /components
    - theme: alt
      text: 国际化指南
      link: /locale
---

Hytech UI 是一套面向企业级产品的 Headless + Tailwind + Vue 3 组件库，提供一致的 API、完善的可访问性支持与高度可定制的样式体系。你可以按需引入、组合使用，快速构建现代 Web 应用。

## 特性

- 🌍 **多语言支持**：提供完善的国际化能力与智能回退机制
- 🎯 **类型安全**：全量 TypeScript 类型提示与严格的 Props 校验
- 🎨 **主题可定制**：基于设计 Token 与 CSS 变量，支持深浅色与品牌色扩展
- ♿ **可访问性优先**：完整 ARIA 属性、键盘导航与无障碍规范落实
- 📦 **按需/树摇优化**：组件与样式可按需引入，产物更轻量
- 🧩 **可组合设计**：Headless 组件 + Tailwind 原子类，灵活搭建业务界面

## 组件覆盖范围

以下为常用组件的功能分布，点击顶部“浏览组件”查看完整目录与示例：

- 基础：`HTButton`、`HTIcon`、`HTDivider`、`HTTag`、`HTTooltip`
- 表单：`HTField`、`HTCheckbox`、`HTCheckboxGroup`、`HTRadio`、`HTSelect`、`HTDatePicker`、`HTStepper`、`HTSwitch`、`HTForm`
- 数据与展示：`HTList`、`HTCell`、`HTImage`、`HTEmpty`、`HTSkeleton`
- 反馈与交互：`HTModal`、`HTToast`、`HTPopover`、`HTLoading`、`HTActionSheet`
- 导航与容器：`HTTabs`、`HTSticky`、`HTSwipe`、`HTPullRefresh`、`HTGroup`、`HTRow`、`HTCol`

## 快速上手

安装依赖：

```bash
pnpm add @hytech/ht-ui
```

引入基础样式（建议在应用入口）：

```ts
// main.ts
import '@hytech/ht-ui/index.css'
```

按需使用组件：

```vue
<script setup lang="ts">
import { HTButton, HTModal } from '@hytech/ht-ui'
</script>

<template>
  <HTButton type="primary">确认</HTButton>
  <HTModal v-model="visible" title="示例">
    这里是弹窗内容
  </HTModal>
</template>
```

更多示例请进入“浏览组件”，其中包含基础用法与高级用法（如样式定制、可访问性、表单集成、虚拟滚动等）。

## 设计理念

- **Headless-first**：不强制样式，方便与设计系统融合
- **Token-based Theming**：通过设计 Token 与 CSS 变量构建品牌一致性
- **Composable API**：统一、直观的 API，组件间配合紧密
- **Accessibility-first**：从交互到语义全面落实可访问性规范
