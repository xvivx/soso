<template>
  <DefaultLayout />
  <ClientOnly>
    <PortalProvider />
    <ToastProvider />
  </ClientOnly>
</template>

<script setup lang="ts">
import { PortalProvider, ToastProvider } from '@hytech/ht-ui';
import '@/styles/index.css';
import DefaultTheme from 'vitepress/theme';

const DefaultLayout = DefaultTheme.Layout;
</script>
