# @hytech/ht-ui 组件库

## 技术栈

- 基于[shadcn-vue](https://www.shadcn-vue.com/)
- vue 3
- typescript
- vite
- tailwind 4

## 安装

```sh
pnpm install
```

## 开发与调试

- 参考 figma： <https://www.figma.com/design/2RHRs10db9CpIu8gU8Zvs9/SA-Draft?node-id=4717-521794&m=dev>

```sh
pnpm run dev
```

举例：在 /docs 目录下添加对应的 button 组件，然后访问 <http://localhost:5173/button> 即可查看组件效果

### 引入 shadcn 组件

```sh
pnpm dlx shadcn-vue@latest add button
```

## 发布

## 代码规范

- 组件命名：PascalCase（例如：HTPopover）
- 组件文件：每个组件对应一个单独的文件，文件名与组件名相同（例如：Popover.vue）, 需要导出 index.ts 文件，用于导出组件及类型
- 组件目录：组件文件存放在 /src/components 目录下
- className 规范：每个组件除了 tailwind 类名，均需要定义一个 BEM 类名（例如：`ht-popover`），用于后续代码调试及定位
- 组件三级 token 规范：每个组件的 token 放在自己的目录下，在代码复杂的时候需要拆分为多个文件（例如新增：/src/components/popover/tokens.scss）

## 组件 token 规范

- 每个组件的 token 放在自己的目录下，在代码复杂的时候需要拆分为多个文件（例如新增：/src/components/popover/tokens.scss）
- token 文件名：与组件名相同（例如：popover.scss）
- token 变量：对齐 [H5组件三级token](H5组件三级token.md) 组件的 token 变量
- 涉及尺寸的，需要根据 size 设置不同的 token 变量（例如：--button-container-height-default）

## 组件 API 规范

- 基于 [shadcn-vue](https://www.shadcn-vue.com/) 组件的 API 规范
- 同时，需要兼容 [vant](https://github.com/youzan/vant) 组件的 API 规范，举例 button 里面的转化

```
withDefaults(defineProps<Props>(), {
  tag: 'button',
});
```
