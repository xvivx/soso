import type { ComponentPublicInstance } from 'vue';

export function isObject(val: unknown): val is Record<string, unknown> {
  return val !== null && typeof val === 'object';
}

export function isFunction(val: unknown): val is (...args: unknown[]) => unknown {
  return typeof val === 'function';
}

export function isPromise<T = unknown>(val: unknown): val is Promise<T> {
  return isObject(val) && isFunction(val.then) && isFunction(val.catch);
}

export function isArray(val: unknown): val is unknown[] {
  return Array.isArray(val);
}

export function getScrollTop(el: Window | HTMLElement): number {
  const top = 'scrollTop' in el ? el.scrollTop : el.pageYOffset;
  return Math.max(top, 0);
}

export function getElementTop(el: HTMLElement, scrollContainer: Window | HTMLElement) {
  if (scrollContainer === window) {
    const rect = el.getBoundingClientRect();
    const { top } = rect;
    const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
    return top + scrollTop;
  }

  const containerRect = (scrollContainer as HTMLElement).getBoundingClientRect();
  const elementRect = el.getBoundingClientRect();
  return elementRect.top - containerRect.top + getScrollTop(scrollContainer as HTMLElement);
}

export function unitToPx(value: string | number): string {
  if (typeof value === 'number') {
    return `${value}px`;
  }
  if (value.includes('px')) {
    return value;
  }
  return `${parseFloat(value)}px`;
}

export function noop() {}

export const extend = Object.assign;

export const inBrowser = typeof window !== 'undefined';

export type Numeric = number | string;

// eslint-disable-next-line
export type ComponentInstance = ComponentPublicInstance<{}, any>;

export const isDef = <T>(val: T): val is NonNullable<T> => val !== undefined && val !== null;

export const isDate = (val: unknown): val is Date =>
  Object.prototype.toString.call(val) === '[object Date]' && !Number.isNaN((val as Date).getTime());

export function isMobile(value: string): boolean {
  value = value.replace(/[^-|\d]/g, '');
  return /^((\+86)|(86))?(1)\d{10}$/.test(value) || /^0[0-9-]{10,13}$/.test(value);
}

export const isNumeric = (val: Numeric): val is string => typeof val === 'number' || /^\d+(\.\d+)?$/.test(val);

export const isIOS = (): boolean =>
  inBrowser ? /ios|iphone|ipad|ipod/.test(navigator.userAgent.toLowerCase()) : false;

export type Writeable<T> = { -readonly [P in keyof T]: T[P] };

export type RequiredParams<T> = T extends (...args: infer P) => infer R
  ? (...args: { [K in keyof P]-?: NonNullable<P[K]> }) => R
  : never;

export function pick<T, U extends keyof T>(obj: T, keys: ReadonlyArray<U>, ignoreUndefined?: boolean) {
  return keys.reduce(
    (ret, key) => {
      if (!ignoreUndefined || obj[key] !== undefined) {
        ret[key] = obj[key];
      }
      return ret;
    },
    {} as Writeable<Pick<T, U>>
  );
}

export const isSameValue = (newValue: unknown, oldValue: unknown) =>
  JSON.stringify(newValue) === JSON.stringify(oldValue);

export const toArray = <T>(item: T | T[]): T[] => (Array.isArray(item) ? item : [item]);

export const flat = <T>(arr: Array<T | T[]>) => arr.reduce<T[]>((acc, val) => acc.concat(val), []);
