/**
 * Check if a value is a number
 * @param value - the value to check
 * @returns true if the value is a number
 */
export function isNumber(value: unknown): value is number {
  return typeof value === 'number' && !isNaN(value);
}

/**
 * Convert a value to number
 * @param value - the value to convert
 * @returns the converted number
 */
export function toNumber(value: unknown): number {
  if (isNumber(value)) {
    return value;
  }

  if (typeof value === 'string') {
    const num = parseFloat(value);
    return isNaN(num) ? 0 : num;
  }

  return 0;
}
