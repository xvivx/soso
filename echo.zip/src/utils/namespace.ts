/**
 * 创建 BEM 命名空间
 * @param name - 组件名称
 * @returns [name, bem] 元组
 */
export function createNamespace(name: string) {
  const prefixedName = `ht-${name}`;

  const bem = (blockSuffix?: string, element?: string, modifier?: string): string[] => {
    let block = prefixedName;
    if (blockSuffix) {
      block += `-${blockSuffix}`;
    }

    if (element) {
      block += `__${element}`;
    }

    if (modifier) {
      block += `--${modifier}`;
    }

    return [block];
  };

  return [prefixedName, bem] as const;
}
