import { unref, type Ref } from 'vue';
import { isIOS as checkIsIOS } from './basic';

export type ScrollElement = Element | Window;

export function setScrollTop(el: ScrollElement, value: number) {
  if ('scrollTop' in el) {
    el.scrollTop = value;
  } else {
    el.scrollTo(el.scrollX, value);
  }
}

export function getRootScrollTop(): number {
  return window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop || 0;
}

export function setRootScrollTop(value: number) {
  setScrollTop(window, value);
  setScrollTop(document.body, value);
}

const isIOS = checkIsIOS();

// hack for iOS12 page scroll
// see: https://developers.weixin.qq.com/community/develop/doc/00044ae90742f8c82fb78fcae56800
export function resetScroll() {
  if (isIOS) {
    setRootScrollTop(getRootScrollTop());
  }
}

export const stopPropagation = (event: Event) => event.stopPropagation();

export function preventDefault(event: Event, isStopPropagation?: boolean) {
  /* istanbul ignore else */
  if (typeof event.cancelable !== 'boolean' || event.cancelable) {
    event.preventDefault();
  }

  if (isStopPropagation) {
    stopPropagation(event);
  }
}

export function isHidden(elementRef: HTMLElement | Ref<HTMLElement | undefined>) {
  const el = unref(elementRef);
  if (!el) {
    return false;
  }

  const style = window.getComputedStyle(el);
  const hidden = style.display === 'none';

  // offsetParent returns null in the following situations:
  // 1. The element or its parent element has the display property set to none.
  // 2. The element has the position property set to fixed
  const parentHidden = el.offsetParent === null && style.position !== 'fixed';

  return hidden || parentHidden;
}

function isContainingBlock(el: Element) {
  const css = window.getComputedStyle(el);

  return (
    css.transform !== 'none' ||
    css.perspective !== 'none' ||
    ['transform', 'perspective', 'filter'].some((value) => (css.willChange || '').includes(value))
  );
}

export function getContainingBlock(el: Element) {
  let node = el.parentElement;

  while (node) {
    if (node && node.tagName !== 'HTML' && node.tagName !== 'BODY' && isContainingBlock(node)) {
      return node;
    }

    node = node.parentElement;
  }

  return null;
}
/**
 * 获取元素的 DOMRect 信息
 */
export function useRect(element: Element | Window | undefined | null): DOMRect {
  if (!element) {
    // 返回空的 DOMRect
    return new DOMRect(0, 0, 0, 0);
  }
  if (element === window) {
    return new DOMRect(0, 0, window.innerWidth, window.innerHeight);
  }
  return (element as Element).getBoundingClientRect();
}
