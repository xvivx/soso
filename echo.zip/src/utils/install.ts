import type { App, Plugin } from 'vue';

/**
 * 为组件添加 install 方法
 */
export function withInstall<T extends { name?: string; displayName?: string }>(
  component: T,
  extra?: Record<string, T>
) {
  const comp = component as T & { install?: (app: App) => void };

  comp.install = (app: App) => {
    app.component(comp.name || comp.displayName || 'Component', component);

    if (extra) {
      Object.keys(extra).forEach((key) => {
        const extraComponent = extra[key];
        if (extraComponent) {
          app.component(key, extraComponent);
        }
      });
    }
  };

  return component as T & Plugin;
}
