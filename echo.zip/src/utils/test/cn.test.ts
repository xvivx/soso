import { describe, expect, it } from 'vitest';
import { cn } from '../cn';

describe('cn 函数', () => {
  describe('基础功能', () => {
    it('应该合并字符串类名', () => {
      expect(cn('class1', 'class2')).toBe('class1 class2');
    });

    it('应该处理空字符串', () => {
      expect(cn('class1', '', 'class2')).toBe('class1 class2');
    });

    it('应该处理空参数', () => {
      expect(cn()).toBe('');
    });

    it('应该处理单个类名', () => {
      expect(cn('single-class')).toBe('single-class');
    });
  });

  describe('条件类名', () => {
    it('应该处理条件对象', () => {
      expect(
        cn({
          'active': true,
          'disabled': false,
          'loading': true,
        })
      ).toBe('active loading');
    });

    it('应该处理混合的字符串和对象', () => {
      expect(
        cn(
          'base-class',
          {
            'active': true,
            'disabled': false,
          },
          'additional-class'
        )
      ).toBe('base-class active additional-class');
    });

    it('应该处理嵌套的条件对象', () => {
      expect(
        cn({
          'btn': true,
          'btn-primary': true,
          'btn-secondary': false,
          'btn-large': false,
        })
      ).toBe('btn btn-primary');
    });
  });

  describe('数组类名', () => {
    it('应该处理数组类名', () => {
      expect(cn(['class1', 'class2', 'class3'])).toBe('class1 class2 class3');
    });

    it('应该处理包含条件的数组', () => {
      expect(cn(['base', true && 'active', false && 'disabled', null, undefined, 'additional'])).toBe(
        'base active additional'
      );
    });

    it('应该处理嵌套数组', () => {
      expect(cn(['outer1', ['inner1', 'inner2'], 'outer2'])).toBe('outer1 inner1 inner2 outer2');
    });

    it('应该处理空数组', () => {
      expect(cn([])).toBe('');
    });
  });

  describe('Tailwind 类名合并', () => {
    it('应该合并冲突的 Tailwind 类名', () => {
      expect(cn('p-4 p-8')).toBe('p-8');
    });

    it('应该保留不同的 Tailwind 属性', () => {
      expect(cn('p-4 m-2')).toBe('p-4 m-2');
    });

    it('应该处理复杂的 Tailwind 类名冲突', () => {
      expect(cn('bg-red-500 bg-blue-500 text-white text-black')).toBe('bg-blue-500 text-black');
    });

    it('应该处理响应式 Tailwind 类名', () => {
      expect(cn('p-4 md:p-8 lg:p-4')).toBe('p-4 md:p-8 lg:p-4');
    });

    it('应该合并响应式类名冲突', () => {
      expect(cn('p-4 md:p-8 md:p-4')).toBe('p-4 md:p-4');
    });

    it('应该处理 Tailwind 变体类名', () => {
      expect(cn('hover:bg-red-500 hover:bg-blue-500 focus:ring-2 focus:ring-4')).toBe('hover:bg-blue-500 focus:ring-4');
    });

    it('应该处理暗模式类名', () => {
      expect(cn('bg-white dark:bg-gray-800 dark:bg-black')).toBe('bg-white dark:bg-black');
    });

    it('应该处理任意值类名', () => {
      expect(cn('grid-cols-[200px,1fr] grid-cols-[300px,1fr]')).toBe('grid-cols-[300px,1fr]');
    });
  });

  describe('边界情况', () => {
    it('应该处理 null 值', () => {
      expect(cn('class1', null, 'class2')).toBe('class1 class2');
    });

    it('应该处理 undefined 值', () => {
      expect(cn('class1', undefined, 'class2')).toBe('class1 class2');
    });

    it('应该处理数字', () => {
      expect(cn('class1', 123, 'class2')).toBe('class1 123 class2');
    });

    it('应该处理布尔值', () => {
      expect(cn('class1', true, 'class2', false)).toBe('class1 class2');
    });

    it('应该处理零值', () => {
      expect(cn('class1', 0, 'class2')).toBe('class1 class2');
    });

    it('应该处理空字符串数组', () => {
      expect(cn(['', 'class1', '', 'class2', ''])).toBe('class1 class2');
    });
  });

  describe('复杂组合', () => {
    it('应该处理多种类型的组合', () => {
      const isActive = true;
      const isDisabled = false;
      const size = 'large';

      expect(
        cn(
          'btn',
          `btn-${size}`,
          {
            'btn-active': isActive,
            'btn-disabled': isDisabled,
          },
          ['hover:shadow', 'transition-colors'],
          isActive && 'bg-blue-500',
          null,
          undefined
        )
      ).toBe('btn btn-large btn-active hover:shadow transition-colors bg-blue-500');
    });

    it('应该处理动态类名生成', () => {
      const colors = ['red', 'blue', 'green'];
      const selectedColor = 'blue';

      const classes = cn(
        'color-picker',
        colors.map((color) => `color-${color}`),
        selectedColor && `selected-${selectedColor}`
      );

      expect(classes).toBe('color-picker color-red color-blue color-green selected-blue');
    });

    it('应该处理条件样式的复杂逻辑', () => {
      const props = {
        variant: 'primary',
        size: 'lg',
        disabled: false,
        loading: true,
        outline: true,
      };

      expect(
        cn(
          'btn',
          `btn-${props.variant}`,
          `btn-${props.size}`,
          {
            'btn-disabled': props.disabled,
            'btn-loading': props.loading,
            'btn-outline': props.outline,
          },
          props.outline && `outline-${props.variant}`
        )
      ).toBe('btn btn-primary btn-lg btn-loading btn-outline outline-primary');
    });
  });

  describe('性能考虑', () => {
    it('应该快速处理大量类名', () => {
      const startTime = performance.now();

      // 生成大量类名
      const largeClassList = Array.from({ length: 1000 }, (_, i) => `class-${i}`);
      const result = cn(...largeClassList);

      const endTime = performance.now();
      const executionTime = endTime - startTime;

      expect(result).toContain('class-0');
      expect(result).toContain('class-999');
      expect(executionTime).toBeLessThan(100); // 应该在100ms内完成
    });

    it('应该快速处理复杂的嵌套结构', () => {
      const startTime = performance.now();

      const complexInput = [
        'base',
        {
          'active': true,
          'disabled': false,
        },
        Array.from({ length: 100 }, (_, i) => `item-${i}`),
        'final-class',
      ];

      const result = cn(complexInput);

      const endTime = performance.now();
      const executionTime = endTime - startTime;

      expect(result).toContain('base');
      expect(result).toContain('active');
      expect(result).toContain('item-0');
      expect(result).toContain('item-99');
      expect(result).toContain('final-class');
      expect(executionTime).toBeLessThan(50); // 应该在50ms内完成
    });
  });

  describe('实际使用场景', () => {
    it('应该处理组件类名合并', () => {
      const baseClasses = 'flex items-center justify-center';
      const variantClasses = 'bg-blue-500 text-white';
      const sizeClasses = 'px-4 py-2 rounded-lg';
      const conditionalClasses = {
        'opacity-50 cursor-not-allowed': false,
        'hover:bg-blue-600': true,
        'focus:ring-2 focus:ring-blue-300': true,
      };

      const result = cn(baseClasses, variantClasses, sizeClasses, conditionalClasses);

      expect(result).toBe(
        'flex items-center justify-center bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600 focus:ring-2 focus:ring-blue-300'
      );
    });

    it('应该处理表单状态类名', () => {
      const hasError = true;
      const isTouched = false;
      const isDisabled = false;

      const inputClasses = cn('input', 'base-input-styles', {
        'input-error': hasError,
        'input-touched': isTouched,
        'input-disabled': isDisabled,
        'ring-2 ring-red-500': hasError,
        'ring-2 ring-green-500': !hasError && isTouched,
      });

      expect(inputClasses).toBe('input base-input-styles input-error ring-2 ring-red-500');
    });

    it('应该处理动画和过渡类名', () => {
      const isAnimating = true;
      const animationType: 'fade' | 'slide' | 'scale' = 'fade';

      const animationClasses = cn(
        'transition-all duration-300',
        {
          'animate-fade-in': isAnimating && animationType === 'fade',
        },
        !isAnimating && 'opacity-0'
      );

      expect(animationClasses).toBe('transition-all duration-300 animate-fade-in');
    });
  });
});
