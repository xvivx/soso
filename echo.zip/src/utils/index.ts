import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

export * from './cn';
export * from './injectionKey';
export * from './install';
export * from './namespace';
export * from './props';
export * from './dom';
export * from './format';
export * from './common';
export * from './deep-assign';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function isObject(val: unknown): val is Record<string, unknown> {
  return val !== null && typeof val === 'object';
}

export function isFunction(val: unknown): val is (...args: unknown[]) => unknown {
  return typeof val === 'function';
}

export function isPromise<T = unknown>(val: unknown): val is Promise<T> {
  return isObject(val) && isFunction(val.then) && isFunction(val.catch);
}

export function isArray(val: unknown): val is unknown[] {
  return Array.isArray(val);
}

export function getScrollTop(el: Window | HTMLElement): number {
  const top = 'scrollTop' in el ? el.scrollTop : el.pageYOffset;
  return Math.max(top, 0);
}

export function getElementTop(el: HTMLElement, scrollContainer: Window | HTMLElement) {
  if (scrollContainer === window) {
    const rect = el.getBoundingClientRect();
    const { top } = rect;
    const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
    return top + scrollTop;
  }

  const containerRect = (scrollContainer as HTMLElement).getBoundingClientRect();
  const elementRect = el.getBoundingClientRect();
  return elementRect.top - containerRect.top + getScrollTop(scrollContainer as HTMLElement);
}

export function unitToPx(value: string | number): string {
  if (typeof value === 'number') {
    return `${value}px`;
  }
  if (value.includes('px')) {
    return value;
  }
  return `${parseFloat(value)}px`;
}
