import type { InjectionKey } from 'vue';
import type { CheckboxGroupProvide } from '@/components/checkbox-group/types';
import type { FormProvide } from '@/components/form/types';
import type { RadioGroupProvide } from '@/components/radioGroup/types';

export const COLLAPSE_KEY: InjectionKey<null> = Symbol('ht-collapse');
export const FORM_KEY: InjectionKey<FormProvide> = Symbol('van-form');
export const RADIO_GROUP_KEY: InjectionKey<RadioGroupProvide> = Symbol('ht-radio-group');
export const CHECKBOX_GROUP_KEY: InjectionKey<CheckboxGroupProvide> = Symbol('ht-checkbox-group');
