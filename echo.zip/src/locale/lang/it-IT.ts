import type { Message } from '../index';

// Italian language pack
export default {
  // Common UI elements
  name: 'Nome',
  tel: 'Telefono',
  save: 'Salva',
  clear: 'Cancella',
  cancel: 'Annulla',
  confirm: 'Conferma',
  delete: 'Elimina',
  loading: 'Caricamento...',
  more: 'Carica altro',
  noMore: 'Niente altro',
  refresh: 'Aggiorna',
  done: 'Fatto',
  close: 'Chiudi',
  search: 'Cerca',
  select: 'Seleziona',
  upload: 'Carica',
  download: 'Scarica',
  edit: 'Modifica',
  copy: 'Copia',
  share: 'Condividi',
  back: 'Indietro',
  next: 'Successivo',
  previous: 'Precedente',
  submit: 'Invia',
  reset: 'Reimposta',
  tryAgain: 'Riprova',
  error: 'Errore',
  success: 'Successo',
  warning: 'Avviso',
  info: 'Informazioni',

  // Component-specific translations
  htLoading: {
    loading: 'Caricamento...',
    text: 'Caricamento...',
  },

  htList: {
    loadingText: 'Caricamento...',
    errorText: 'Caricamento fallito. Clicca per riprovare',
    finishedText: 'Niente altro',
    error: 'Caricamento fallito',
    tryAgain: 'Clicca per riprovare',
    noMore: 'Niente altro',
  },

  htPullRefresh: {
    pullingText: 'Tira per aggiornare...',
    loosingText: 'Rilascia per aggiornare...',
    loadingText: 'Caricamento...',
    successText: 'Aggiornamento riuscito',
    completeText: 'Aggiornamento completato',
  },

  htEmpty: {
    description: 'Nessun dato',
    image: {
      alt: 'Immagine stato vuoto',
    },
  },

  htModal: {
    close: 'Chiudi',
    confirm: 'Conferma',
    cancel: 'Annulla',
  },

  htForm: {
    required: 'Questo campo è obbligatorio',
    invalid: 'Formato input non valido',
    minLength: "L'input deve avere almeno {min} caratteri",
    maxLength: "L'input non può superare {max} caratteri",
    email: 'Inserisci un indirizzo email valido',
    phone: 'Inserisci un numero di telefono valido',
    url: 'Inserisci un URL valido',
    number: 'Inserisci un numero valido',
    date: 'Seleziona una data valida',
    time: 'Seleziona un orario valido',
    pattern: "Il formato dell'input non è valido",
    match: 'Gli input non corrispondono',
  },

  htField: {
    clear: 'Cancella',
    required: 'Obbligatorio',
    optional: 'Opzionale',
    placeholder: 'Inserisci',
    search: 'Cerca',
    wordLimit: '{count} caratteri rimanenti',
    wordLimitExceeded: 'Limite caratteri superato',
  },

  htButton: {
    loading: 'Caricamento...',
    disabled: 'Disabilitato',
  },

  htToast: {
    success: 'Successo',
    error: 'Errore',
    loading: 'Caricamento...',
    warning: 'Avviso',
    info: 'Informazioni',
  },

  htDialog: {
    title: 'Conferma',
    message: 'Sei sicuro di voler eseguire questa operazione?',
    confirm: 'Conferma',
    cancel: 'Annulla',
  },

  htPicker: {
    confirm: 'Conferma',
    cancel: 'Annulla',
    title: 'Seleziona',
  },

  htDatePicker: {
    title: 'Seleziona data',
    year: 'Anno',
    month: 'Mese',
    day: 'Giorno',
    today: 'Oggi',
    confirm: 'Conferma',
    cancel: 'Annulla',
    weekdays: ['Dom', 'Lun', 'Mar', 'Mer', 'Gio', 'Ven', 'Sab'],
    months: ['Gen', 'Feb', 'Mar', 'Apr', 'Mag', 'Giu', 'Lug', 'Ago', 'Set', 'Ott', 'Nov', 'Dic'],
  },

  htTimePicker: {
    title: 'Seleziona orario',
    hour: 'Ora',
    minute: 'Minuto',
    second: 'Secondo',
    confirm: 'Conferma',
    cancel: 'Annulla',
  },

  htStepper: {
    increase: 'Aumenta',
    decrease: 'Diminuisci',
    min: 'Non può essere inferiore al valore minimo',
    max: 'Non può essere superiore al valore massimo',
    integer: 'Inserisci un numero intero',
  },

  htRate: {
    score: 'Valutazione',
  },

  htSteps: {
    step: 'Passo',
    done: 'Completato',
    process: 'In corso',
    wait: 'In attesa',
  },

  htTabBar: {
    home: 'Home',
    category: 'Categoria',
    cart: 'Carrello',
    user: 'Utente',
    search: 'Cerca',
  },

  htImage: {
    loading: 'Caricamento immagine...',
    error: 'Caricamento immagine fallito',
    preview: 'Anteprima',
    zoom: 'Ingrandisci',
    zoomOut: 'Rimpicciolisci',
    rotate: 'Ruota',
    original: 'Vedi originale',
  },

  htSwitch: {
    on: 'Sì',
    off: 'No',
  },

  htCheckbox: {
    checked: 'Selezionato',
    unchecked: 'Non selezionato',
    all: 'Seleziona tutto',
    none: 'Deseleziona tutto',
  },

  htRadio: {
    checked: 'Selezionato',
    unchecked: 'Non selezionato',
  },

  htSelect: {
    placeholder: 'Seleziona',
    noData: 'Nessun dato',
    search: 'Cerca',
    clear: 'Cancella',
  },

  htUpload: {
    uploading: 'Caricamento...',
    uploadingText: 'Caricamento {percent}%',
    success: 'Caricamento riuscito',
    error: 'Caricamento fallito',
    preview: 'Anteprima',
    delete: 'Elimina',
    retry: 'Riprova',
    maxCount: 'Massimo {count} file possono essere caricati',
    maxSize: 'La dimensione del file non può superare {size}',
    fileType: 'Tipo di file non supportato',
  },

  htPagination: {
    prev: 'Precedente',
    next: 'Successivo',
    total: 'Totale {total} elementi',
    page: 'Pagina {current} di {pages}',
    jumper: 'Vai a',
    pageSize: 'elementi/pagina',
    totalPage: 'pagine',
  },

  htTable: {
    empty: 'Nessun dato',
    selectAll: 'Seleziona tutto',
    deselectAll: 'Deseleziona tutto',
    expand: 'Espandi',
    collapse: 'Comprimi',
    sort: 'Ordina',
    filter: 'Filtra',
    reset: 'Reimposta',
    confirm: 'Conferma',
  },

  htCalendar: {
    title: 'Calendario',
    year: 'Anno',
    month: 'Mese',
    today: 'Oggi',
    confirm: 'Conferma',
    cancel: 'Annulla',
    weekdays: ['Dom', 'Lun', 'Mar', 'Mer', 'Gio', 'Ven', 'Sab'],
    months: ['Gen', 'Feb', 'Mar', 'Apr', 'Mag', 'Giu', 'Lug', 'Ago', 'Set', 'Ott', 'Nov', 'Dic'],
    rangePrompt: "L'intervallo di date non può superare {maxRange} giorni",
    minRange: 'Seleziona almeno {minRange} giorni',
    maxRange: 'Seleziona al massimo {maxRange} giorni',
  },

  htSwipe: {
    previous: 'Precedente',
    next: 'Successivo',
    indicator: '{current} / {total}',
  },

  htCollapse: {
    expand: 'Espandi',
    collapse: 'Comprimi',
  },

  htBadge: {
    dot: 'Indicatore punto',
    count: 'Contatore',
  },

  htTag: {
    close: 'Chiudi tag',
  },

  htProgress: {
    percent: '{percent}%',
  },

  htSkeleton: {
    loading: 'Caricamento...',
  },

  htAffix: {
    fixed: 'Posizionamento fisso',
  },

  htBackTop: {
    tooltip: 'Torna su',
  },

  htAnchor: {
    copy: 'Copia link',
    copied: 'Copiato',
  },

  htBreadcrumb: {
    home: 'Home',
  },

  htDivider: {
    text: 'Testo divisore',
  },

  htResult: {
    success: 'Operazione riuscita',
    error: 'Operazione fallita',
    info: 'Informazioni',
    warning: 'Avviso',
    notFound: 'Pagina non trovata',
    unauthorized: 'Non autorizzato',
    forbidden: 'Accesso vietato',
    serverError: 'Errore server',
  },

  htTypography: {
    copy: 'Copia',
    copied: 'Copiato',
    edit: 'Modifica',
    expand: 'Espandi',
    collapse: 'Comprimi',
  },

  htAlert: {
    close: 'Chiudi',
  },

  htMessage: {
    close: 'Chiudi',
  },

  htNotification: {
    close: 'Chiudi',
  },

  htPopconfirm: {
    title: 'Conferma',
    confirm: 'OK',
    cancel: 'Annulla',
  },

  htTooltip: {
    empty: 'Nessun tooltip',
  },

  htPopover: {
    close: 'Chiudi',
  },

  htDropdown: {
    title: 'Menu a tendina',
  },
} as unknown as Message;
