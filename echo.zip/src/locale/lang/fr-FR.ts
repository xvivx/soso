import type { Message } from '../index';

// French language pack
export default {
  // Common UI elements
  name: 'Nom',
  tel: 'Téléphone',
  save: 'Enregistrer',
  clear: 'Effacer',
  cancel: 'Annuler',
  confirm: 'Confirmer',
  delete: 'Supprimer',
  loading: 'Chargement...',
  more: 'Charger plus',
  noMore: 'Plus de données',
  refresh: 'Actualiser',
  done: 'Terminé',
  close: 'Fermer',
  search: 'Rechercher',
  select: 'Sélectionner',
  upload: 'Télécharger',
  download: 'Télécharger',
  edit: 'Modifier',
  copy: 'Copier',
  share: 'Partager',
  back: 'Retour',
  next: 'Suivant',
  previous: 'Précédent',
  submit: 'Soumettre',
  reset: 'Réinitialiser',
  tryAgain: 'Réessayer',
  error: 'Erreur',
  success: 'Succès',
  warning: 'Avertissement',
  info: 'Informations',

  // Component-specific translations
  htLoading: {
    loading: 'Chargement...',
    text: 'Chargement...',
  },

  htList: {
    loadingText: 'Chargement...',
    errorText: 'Échec du chargement. Cliquez pour réessayer',
    finishedText: 'Pas plus de données',
    error: 'Échec du chargement',
    tryAgain: 'Cliquez pour réessayer',
    noMore: 'Pas plus de données',
  },

  htPullRefresh: {
    pullingText: 'Tirez pour rafraîchir...',
    loosingText: 'Relâchez pour rafraîchir...',
    loadingText: 'Chargement...',
    successText: 'Actualisation réussie',
    completeText: 'Actualisation terminée',
  },

  htEmpty: {
    description: 'Aucune donnée',
    image: {
      alt: "Image d'état vide",
    },
  },

  htModal: {
    close: 'Fermer',
    confirm: 'Confirmer',
    cancel: 'Annuler',
  },

  htForm: {
    required: 'Ce champ est obligatoire',
    invalid: 'Format de saisie invalide',
    minLength: 'La saisie doit contenir au moins {min} caractères',
    maxLength: 'La saisie ne peut pas dépasser {max} caractères',
    email: 'Veuillez saisir une adresse e-mail valide',
    phone: 'Veuillez saisir un numéro de téléphone valide',
    url: 'Veuillez saisir une URL valide',
    number: 'Veuillez saisir un nombre valide',
    date: 'Veuillez sélectionner une date valide',
    time: 'Veuillez sélectionner une heure valide',
    pattern: 'Le format de saisie est invalide',
    match: 'Les saisies ne correspondent pas',
  },

  htField: {
    clear: 'Effacer',
    required: 'Obligatoire',
    optional: 'Optionnel',
    placeholder: 'Veuillez saisir',
    search: 'Rechercher',
    wordLimit: '{count} caractères restants',
    wordLimitExceeded: 'Limite de caractères dépassée',
  },

  htButton: {
    loading: 'Chargement...',
    disabled: 'Désactivé',
  },

  htToast: {
    success: 'Succès',
    error: 'Erreur',
    loading: 'Chargement...',
    warning: 'Avertissement',
    info: 'Informations',
  },

  htDialog: {
    title: 'Confirmer',
    message: 'Êtes-vous sûr de vouloir effectuer cette opération ?',
    confirm: 'Confirmer',
    cancel: 'Annuler',
  },

  htPicker: {
    confirm: 'Confirmer',
    cancel: 'Annuler',
    title: 'Veuillez sélectionner',
  },

  htDatePicker: {
    title: 'Sélectionner une date',
    year: 'Année',
    month: 'Mois',
    day: 'Jour',
    today: "Aujourd'hui",
    confirm: 'Confirmer',
    cancel: 'Annuler',
    weekdays: ['Dim', 'Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam'],
    months: ['Jan', 'Fév', 'Mar', 'Avr', 'Mai', 'Juin', 'Juil', 'Août', 'Sep', 'Oct', 'Nov', 'Déc'],
  },

  htTimePicker: {
    title: 'Sélectionner une heure',
    hour: 'Heure',
    minute: 'Minute',
    second: 'Seconde',
    confirm: 'Confirmer',
    cancel: 'Annuler',
  },

  htStepper: {
    increase: 'Augmenter',
    decrease: 'Diminuer',
    min: 'Ne peut pas être inférieur à la valeur minimale',
    max: 'Ne peut pas être supérieur à la valeur maximale',
    integer: 'Veuillez saisir un nombre entier',
  },

  htRate: {
    score: 'Note',
  },

  htSteps: {
    step: 'Étape',
    done: 'Terminé',
    process: 'En cours',
    wait: 'En attente',
  },

  htTabBar: {
    home: 'Accueil',
    category: 'Catégorie',
    cart: 'Panier',
    user: 'Utilisateur',
    search: 'Rechercher',
  },

  htImage: {
    loading: "Chargement de l'image...",
    error: "Échec du chargement de l'image",
    preview: 'Aperçu',
    zoom: 'Zoomer',
    zoomOut: 'Dézoomer',
    rotate: 'Tourner',
    original: "Voir l'original",
  },

  htSwitch: {
    on: 'Oui',
    off: 'Non',
  },

  htCheckbox: {
    checked: 'Sélectionné',
    unchecked: 'Non sélectionné',
    all: 'Tout sélectionner',
    none: 'Tout désélectionner',
  },

  htRadio: {
    checked: 'Sélectionné',
    unchecked: 'Non sélectionné',
  },

  htSelect: {
    placeholder: 'Veuillez sélectionner',
    noData: 'Aucune donnée',
    search: 'Rechercher',
    clear: 'Effacer',
  },

  htUpload: {
    uploading: 'Téléchargement...',
    uploadingText: 'Téléchargement {percent}%',
    success: 'Téléchargement réussi',
    error: 'Échec du téléchargement',
    preview: 'Aperçu',
    delete: 'Supprimer',
    retry: 'Réessayer',
    maxCount: 'Maximum {count} fichiers peuvent être téléchargés',
    maxSize: 'La taille du fichier ne peut pas dépasser {size}',
    fileType: 'Type de fichier non supporté',
  },

  htPagination: {
    prev: 'Précédent',
    next: 'Suivant',
    total: 'Total {total} éléments',
    page: 'Page {current} sur {pages}',
    jumper: 'Aller à',
    pageSize: 'éléments/page',
    totalPage: 'pages',
  },

  htTable: {
    empty: 'Aucune donnée',
    selectAll: 'Tout sélectionner',
    deselectAll: 'Tout désélectionner',
    expand: 'Développer',
    collapse: 'Réduire',
    sort: 'Trier',
    filter: 'Filtrer',
    reset: 'Réinitialiser',
    confirm: 'Confirmer',
  },

  htCalendar: {
    title: 'Calendrier',
    year: 'Année',
    month: 'Mois',
    today: "Aujourd'hui",
    confirm: 'Confirmer',
    cancel: 'Annuler',
    weekdays: ['Dim', 'Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam'],
    months: ['Jan', 'Fév', 'Mar', 'Avr', 'Mai', 'Juin', 'Juil', 'Août', 'Sep', 'Oct', 'Nov', 'Déc'],
    rangePrompt: 'La plage de dates ne peut pas dépasser {maxRange} jours',
    minRange: 'Sélectionnez au moins {minRange} jours',
    maxRange: 'Sélectionnez au maximum {maxRange} jours',
  },

  htSwipe: {
    previous: 'Précédent',
    next: 'Suivant',
    indicator: '{current} / {total}',
  },

  htCollapse: {
    expand: 'Développer',
    collapse: 'Réduire',
  },

  htBadge: {
    dot: 'Indicateur de point',
    count: 'Compteur',
  },

  htTag: {
    close: "Fermer l'étiquette",
  },

  htProgress: {
    percent: '{percent}%',
  },

  htSkeleton: {
    loading: 'Chargement...',
  },

  htAffix: {
    fixed: 'Position fixe',
  },

  htBackTop: {
    tooltip: 'Retour en haut',
  },

  htAnchor: {
    copy: 'Copier le lien',
    copied: 'Copié',
  },

  htBreadcrumb: {
    home: 'Accueil',
  },

  htDivider: {
    text: 'Texte du séparateur',
  },

  htResult: {
    success: 'Opération réussie',
    error: 'Opération échouée',
    info: 'Informations',
    warning: 'Avertissement',
    notFound: 'Page non trouvée',
    unauthorized: 'Non autorisé',
    forbidden: 'Accès interdit',
    serverError: 'Erreur serveur',
  },

  htTypography: {
    copy: 'Copier',
    copied: 'Copié',
    edit: 'Modifier',
    expand: 'Développer',
    collapse: 'Réduire',
  },

  htAlert: {
    close: 'Fermer',
  },

  htMessage: {
    close: 'Fermer',
  },

  htNotification: {
    close: 'Fermer',
  },

  htPopconfirm: {
    title: 'Confirmer',
    confirm: 'OK',
    cancel: 'Annuler',
  },

  htTooltip: {
    empty: "Pas d'info-bulle",
  },

  htPopover: {
    close: 'Fermer',
  },

  htDropdown: {
    title: 'Menu déroulant',
  },
} as unknown as Message;
