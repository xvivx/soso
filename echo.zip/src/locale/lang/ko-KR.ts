import type { Message } from '../index';

// Korean language pack
export default {
  // Common UI elements
  name: '이름',
  tel: '전화번호',
  save: '저장',
  clear: '지우기',
  cancel: '취소',
  confirm: '확인',
  delete: '삭제',
  loading: '로딩 중...',
  more: '더보기',
  noMore: '더 이상 데이터가 없습니다',
  refresh: '새로고침',
  done: '완료',
  close: '닫기',
  search: '검색',
  select: '선택',
  upload: '업로드',
  download: '다운로드',
  edit: '편집',
  copy: '복사',
  share: '공유',
  back: '뒤로',
  next: '다음',
  previous: '이전',
  submit: '제출',
  reset: '재설정',
  tryAgain: '다시 시도',
  error: '오류',
  success: '성공',
  warning: '경고',
  info: '정보',

  // Component-specific translations
  htLoading: {
    loading: '로딩 중...',
    text: '로딩 중...',
  },

  htList: {
    loadingText: '로딩 중...',
    errorText: '로딩에 실패했습니다. 클릭하여 다시 시도하세요',
    finishedText: '더 이상 데이터가 없습니다',
    error: '로딩에 실패했습니다',
    tryAgain: '클릭하여 다시 시도하세요',
    noMore: '더 이상 데이터가 없습니다',
  },

  htPullRefresh: {
    pullingText: '당겨서 새로고침...',
    loosingText: '놓아서 새로고침...',
    loadingText: '새로고침 중...',
    successText: '새로고침 성공',
    completeText: '새로고침 완료',
  },

  htEmpty: {
    description: '데이터가 없습니다',
    image: {
      alt: '빈 상태 이미지',
    },
  },

  htModal: {
    close: '닫기',
    confirm: '확인',
    cancel: '취소',
  },

  htForm: {
    required: '이 필드는 필수입니다',
    invalid: '잘못된 입력 형식입니다',
    minLength: '입력은 최소 {min}자 이상이어야 합니다',
    maxLength: '입력은 {max}자를 초과할 수 없습니다',
    email: '유효한 이메일 주소를 입력하세요',
    phone: '유효한 전화번호를 입력하세요',
    url: '유효한 URL을 입력하세요',
    number: '유효한 숫자를 입력하세요',
    date: '유효한 날짜를 선택하세요',
    time: '유효한 시간을 선택하세요',
    pattern: '입력 형식이 유효하지 않습니다',
    match: '입력이 일치하지 않습니다',
  },

  htField: {
    clear: '지우기',
    required: '필수',
    optional: '선택',
    placeholder: '입력하세요',
    search: '검색',
    wordLimit: '{count}자 남음',
    wordLimitExceeded: '문자 수 제한 초과',
  },

  htButton: {
    loading: '로딩 중...',
    disabled: '비활성화됨',
  },

  htToast: {
    success: '성공',
    error: '오류',
    loading: '로딩 중...',
    warning: '경고',
    info: '정보',
  },

  htDialog: {
    title: '확인',
    message: '이 작업을 수행하시겠습니까?',
    confirm: '확인',
    cancel: '취소',
  },

  htPicker: {
    confirm: '확인',
    cancel: '취소',
    title: '선택하세요',
  },

  htDatePicker: {
    title: '날짜 선택',
    year: '년',
    month: '월',
    day: '일',
    today: '오늘',
    confirm: '확인',
    cancel: '취소',
    weekdays: ['일', '월', '화', '수', '목', '금', '토'],
    months: ['1월', '2월', '3월', '4월', '5월', '6월', '7월', '8월', '9월', '10월', '11월', '12월'],
  },

  htTimePicker: {
    title: '시간 선택',
    hour: '시',
    minute: '분',
    second: '초',
    confirm: '확인',
    cancel: '취소',
  },

  htStepper: {
    increase: '증가',
    decrease: '감소',
    min: '최소값보다 작을 수 없습니다',
    max: '최대값보다 클 수 없습니다',
    integer: '정수를 입력하세요',
  },

  htRate: {
    score: '평점',
  },

  htSteps: {
    step: '단계',
    done: '완료',
    process: '진행 중',
    wait: '대기 중',
  },

  htTabBar: {
    home: '홈',
    category: '카테고리',
    cart: '장바구니',
    user: '사용자',
    search: '검색',
  },

  htImage: {
    loading: '이미지 로딩 중...',
    error: '이미지 로딩 실패',
    preview: '미리보기',
    zoom: '확대',
    zoomOut: '축소',
    rotate: '회전',
    original: '원본 보기',
  },

  htSwitch: {
    on: '켬',
    off: '끔',
  },

  htCheckbox: {
    checked: '선택됨',
    unchecked: '선택안됨',
    all: '모두 선택',
    none: '모두 선택 해제',
  },

  htRadio: {
    checked: '선택됨',
    unchecked: '선택안됨',
  },

  htSelect: {
    placeholder: '선택하세요',
    noData: '데이터가 없습니다',
    search: '검색',
    clear: '지우기',
  },

  htUpload: {
    uploading: '업로드 중...',
    uploadingText: '업로드 중 {percent}%',
    success: '업로드 성공',
    error: '업로드 실패',
    preview: '미리보기',
    delete: '삭제',
    retry: '다시 시도',
    maxCount: '최대 {count}개 파일을 업로드할 수 있습니다',
    maxSize: '파일 크기는 {size}를 초과할 수 없습니다',
    fileType: '지원되지 않는 파일 형식입니다',
  },

  htPagination: {
    prev: '이전',
    next: '다음',
    total: '총 {total}개 항목',
    page: '{current} / {pages} 페이지',
    jumper: '이동',
    pageSize: '항목/페이지',
    totalPage: '페이지',
  },

  htTable: {
    empty: '데이터가 없습니다',
    selectAll: '모두 선택',
    deselectAll: '모두 선택 해제',
    expand: '확장',
    collapse: '축소',
    sort: '정렬',
    filter: '필터',
    reset: '재설정',
    confirm: '확인',
  },

  htCalendar: {
    title: '달력',
    year: '년',
    month: '월',
    today: '오늘',
    confirm: '확인',
    cancel: '취소',
    weekdays: ['일', '월', '화', '수', '목', '금', '토'],
    months: ['1월', '2월', '3월', '4월', '5월', '6월', '7월', '8월', '9월', '10월', '11월', '12월'],
    rangePrompt: '날짜 범위는 {maxRange}일을 초과할 수 없습니다',
    minRange: '최소 {minRange}일을 선택하세요',
    maxRange: '최대 {maxRange}일을 선택하세요',
  },

  htSwipe: {
    previous: '이전',
    next: '다음',
    indicator: '{current} / {total}',
  },

  htCollapse: {
    expand: '확장',
    collapse: '축소',
  },

  htBadge: {
    dot: '점 표시기',
    count: '카운트',
  },

  htTag: {
    close: '태그 닫기',
  },

  htProgress: {
    percent: '{percent}%',
  },

  htSkeleton: {
    loading: '로딩 중...',
  },

  htAffix: {
    fixed: '고정 위치',
  },

  htBackTop: {
    tooltip: '맨 위로',
  },

  htAnchor: {
    copy: '링크 복사',
    copied: '복사됨',
  },

  htBreadcrumb: {
    home: '홈',
  },

  htDivider: {
    text: '구분선 텍스트',
  },

  htResult: {
    success: '작업 성공',
    error: '작업 실패',
    info: '정보',
    warning: '경고',
    notFound: '페이지를 찾을 수 없습니다',
    unauthorized: '권한 없음',
    forbidden: '접근 금지',
    serverError: '서버 오류',
  },

  htTypography: {
    copy: '복사',
    copied: '복사됨',
    edit: '편집',
    expand: '확장',
    collapse: '축소',
  },

  htAlert: {
    close: '닫기',
  },

  htMessage: {
    close: '닫기',
  },

  htNotification: {
    close: '닫기',
  },

  htPopconfirm: {
    title: '확인',
    confirm: '확인',
    cancel: '취소',
  },

  htTooltip: {
    empty: '툴팁이 없습니다',
  },

  htPopover: {
    close: '닫기',
  },

  htDropdown: {
    title: '드롭다운 메뉴',
  },
} as unknown as Message;
