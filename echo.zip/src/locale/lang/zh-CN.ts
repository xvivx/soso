import type { Message } from '../index';

// Chinese (Simplified) language pack
export default {
  // Common UI elements
  name: '名称',
  tel: '电话',
  save: '保存',
  clear: '清空',
  cancel: '取消',
  confirm: '确认',
  delete: '删除',
  loading: '加载中...',
  more: '加载更多',
  noMore: '没有更多了',
  refresh: '刷新',
  done: '完成',
  close: '关闭',
  search: '搜索',
  select: '选择',
  upload: '上传',
  download: '下载',
  edit: '编辑',
  copy: '复制',
  share: '分享',
  back: '返回',
  next: '下一步',
  previous: '上一步',
  submit: '提交',
  reset: '重置',
  tryAgain: '重试',
  error: '错误',
  success: '成功',
  warning: '警告',
  info: '信息',

  // Component-specific translations
  htLoading: {
    loading: '加载中...',
    text: '加载中...',
  },

  htList: {
    loadingText: '加载中...',
    errorText: '加载失败，点击重试',
    finishedText: '没有更多了',
    error: '加载失败',
    tryAgain: '点击重试',
    noMore: '没有更多了',
  },

  htPullRefresh: {
    pullingText: '下拉即可刷新...',
    loosingText: '释放即可刷新...',
    loadingText: '正在刷新...',
    successText: '刷新成功',
    completeText: '刷新完成',
  },

  htEmpty: {
    description: '暂无数据',
    image: {
      alt: '空状态图片',
    },
  },

  htModal: {
    close: '关闭',
    confirm: '确认',
    cancel: '取消',
  },

  htForm: {
    required: '此项为必填项',
    invalid: '输入格式不正确',
    minLength: '输入内容长度不能少于 {min} 个字符',
    maxLength: '输入内容长度不能超过 {max} 个字符',
    email: '请输入有效的邮箱地址',
    phone: '请输入有效的手机号码',
    url: '请输入有效的网址',
    number: '请输入有效的数字',
    date: '请选择有效的日期',
    time: '请选择有效的时间',
    pattern: '输入内容格式不正确',
    match: '两次输入内容不一致',
  },

  htField: {
    clear: '清空',
    required: '必填',
    optional: '选填',
    placeholder: '请输入',
    search: '搜索',
    wordLimit: '还可输入 {count} 个字符',
    wordLimitExceeded: '输入内容超过限制',
  },

  htButton: {
    loading: '加载中...',
    disabled: '已禁用',
  },

  htToast: {
    success: '成功',
    error: '错误',
    loading: '加载中...',
    warning: '警告',
    info: '信息',
  },

  htDialog: {
    title: '提示',
    message: '确定要执行此操作吗？',
    confirm: '确认',
    cancel: '取消',
  },

  htPicker: {
    confirm: '确认',
    cancel: '取消',
    title: '请选择',
  },

  htDatePicker: {
    title: '选择日期',
    year: '年',
    month: '月',
    day: '日',
    today: '今天',
    confirm: '确认',
    cancel: '取消',
    weekdays: ['日', '一', '二', '三', '四', '五', '六'],
    months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  },

  htTimePicker: {
    title: '选择时间',
    hour: '时',
    minute: '分',
    second: '秒',
    confirm: '确认',
    cancel: '取消',
  },

  htStepper: {
    increase: '增加',
    decrease: '减少',
    min: '不能小于最小值',
    max: '不能大于最大值',
    integer: '请输入整数',
  },

  htRate: {
    score: '评分',
  },

  htSteps: {
    step: '步骤',
    done: '已完成',
    process: '进行中',
    wait: '待进行',
  },

  htTabBar: {
    home: '首页',
    category: '分类',
    cart: '购物车',
    user: '我的',
    search: '搜索',
  },

  htImage: {
    loading: '图片加载中...',
    error: '图片加载失败',
    preview: '预览图片',
    zoom: '放大',
    zoomOut: '缩小',
    rotate: '旋转',
    original: '查看原图',
  },

  htSwitch: {
    on: '开',
    off: '关',
  },

  htCheckbox: {
    checked: '已选中',
    unchecked: '未选中',
    all: '全选',
    none: '全不选',
  },

  htRadio: {
    checked: '已选中',
    unchecked: '未选中',
  },

  htSelect: {
    placeholder: '请选择',
    noData: '暂无数据',
    search: '搜索',
    clear: '清空',
  },

  htUpload: {
    uploading: '上传中...',
    uploadingText: '上传中 {percent}%',
    success: '上传成功',
    error: '上传失败',
    preview: '预览',
    delete: '删除',
    retry: '重试',
    maxCount: '最多上传 {count} 个文件',
    maxSize: '文件大小不能超过 {size}',
    fileType: '文件类型不支持',
  },

  htPagination: {
    prev: '上一页',
    next: '下一页',
    total: '共 {total} 条',
    page: '第 {current} 页，共 {pages} 页',
    jumper: '前往',
    pageSize: '条/页',
    totalPage: '页',
  },

  htTable: {
    empty: '暂无数据',
    selectAll: '全选',
    deselectAll: '取消全选',
    expand: '展开',
    collapse: '收起',
    sort: '排序',
    filter: '筛选',
    reset: '重置',
    confirm: '确认',
  },

  htCalendar: {
    title: '日历',
    year: '年',
    month: '月',
    today: '今天',
    confirm: '确认',
    cancel: '取消',
    weekdays: ['日', '一', '二', '三', '四', '五', '六'],
    months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
    rangePrompt: '选择日期范围不能超过 {maxRange} 天',
    minRange: '最少选择 {minRange} 天',
    maxRange: '最多选择 {maxRange} 天',
  },

  htSwipe: {
    previous: '上一张',
    next: '下一张',
    indicator: '{current} / {total}',
  },

  htCollapse: {
    expand: '展开',
    collapse: '收起',
  },

  htBadge: {
    dot: '红点提示',
    count: '计数',
  },

  htTag: {
    close: '关闭标签',
  },

  htProgress: {
    percent: '{percent}%',
  },

  htSkeleton: {
    loading: '加载中...',
  },

  htAffix: {
    fixed: '固定定位',
  },

  htBackTop: {
    tooltip: '回到顶部',
  },

  htAnchor: {
    copy: '复制链接',
    copied: '已复制',
  },

  htBreadcrumb: {
    home: '首页',
  },

  htDivider: {
    text: '分割线文本',
  },

  htResult: {
    success: '操作成功',
    error: '操作失败',
    info: '信息提示',
    warning: '警告信息',
    notFound: '页面不存在',
    unauthorized: '未授权',
    forbidden: '禁止访问',
    serverError: '服务器错误',
  },

  htTypography: {
    copy: '复制',
    copied: '已复制',
    edit: '编辑',
    expand: '展开',
    collapse: '收起',
  },

  htAlert: {
    close: '关闭',
  },

  htMessage: {
    close: '关闭',
  },

  htNotification: {
    close: '关闭',
  },

  htPopconfirm: {
    title: '确认',
    confirm: '确定',
    cancel: '取消',
  },

  htTooltip: {
    empty: '暂无提示',
  },

  htPopover: {
    close: '关闭',
  },

  htDropdown: {
    title: '下拉菜单',
  },
} as unknown as Message;
