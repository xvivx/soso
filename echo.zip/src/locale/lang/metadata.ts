import type { LanguageFamily, LanguageMetadata } from '../types';

// Language metadata for all supported locales
export const LANGUAGE_METADATA: Record<string, LanguageMetadata> = {
  'zh-CN': {
    code: 'zh-CN',
    name: 'Chinese (Simplified)',
    nativeName: '简体中文',
    region: 'China',
    rtl: false,
    completeness: 'complete',
  },
  'zh-TW': {
    code: 'zh-TW',
    name: 'Chinese (Traditional)',
    nativeName: '繁體中文',
    region: 'Taiwan',
    rtl: false,
    completeness: 'complete',
  },
  'zh-HK': {
    code: 'zh-HK',
    name: 'Chinese (Hong Kong)',
    nativeName: '繁體中文',
    region: 'Hong Kong',
    rtl: false,
    completeness: 'complete',
  },
  'en-US': {
    code: 'en-US',
    name: 'English (US)',
    nativeName: 'English',
    region: 'United States',
    rtl: false,
    completeness: 'complete',
  },
  'en-GB': {
    code: 'en-GB',
    name: 'English (UK)',
    nativeName: 'English',
    region: 'United Kingdom',
    rtl: false,
    completeness: 'complete',
  },
  'ja-JP': {
    code: 'ja-JP',
    name: 'Japanese',
    nativeName: '日本語',
    region: 'Japan',
    rtl: false,
    completeness: 'complete',
  },
  'ko-KR': {
    code: 'ko-KR',
    name: 'Korean',
    nativeName: '한국어',
    region: 'South Korea',
    rtl: false,
    completeness: 'complete',
  },

  // European languages
  'es-ES': {
    code: 'es-ES',
    name: 'Spanish (Spain)',
    nativeName: 'Español',
    region: 'Spain',
    rtl: false,
    completeness: 'complete',
  },
  'fr-FR': {
    code: 'fr-FR',
    name: 'French',
    nativeName: 'Français',
    region: 'France',
    rtl: false,
    completeness: 'complete',
  },
  'de-DE': {
    code: 'de-DE',
    name: 'German',
    nativeName: 'Deutsch',
    region: 'Germany',
    rtl: false,
    completeness: 'complete',
  },
  'it-IT': {
    code: 'it-IT',
    name: 'Italian',
    nativeName: 'Italiano',
    region: 'Italy',
    rtl: false,
    completeness: 'complete',
  },
  'pt-PT': {
    code: 'pt-PT',
    name: 'Portuguese (Portugal)',
    nativeName: 'Português',
    region: 'Portugal',
    rtl: false,
    completeness: 'complete',
  },
  'pt-BR': {
    code: 'pt-BR',
    name: 'Portuguese (Brazil)',
    nativeName: 'Português',
    region: 'Brazil',
    rtl: false,
    completeness: 'complete',
  },
  'nl-NL': {
    code: 'nl-NL',
    name: 'Dutch',
    nativeName: 'Nederlands',
    region: 'Netherlands',
    rtl: false,
    completeness: 'complete',
  },
  'ru-RU': {
    code: 'ru-RU',
    name: 'Russian',
    nativeName: 'Русский',
    region: 'Russia',
    rtl: false,
    completeness: 'complete',
  },
  'pl-PL': {
    code: 'pl-PL',
    name: 'Polish',
    nativeName: 'Polski',
    region: 'Poland',
    rtl: false,
    completeness: 'complete',
  },
  'ro-RO': {
    code: 'ro-RO',
    name: 'Romanian',
    nativeName: 'Română',
    region: 'Romania',
    rtl: false,
    completeness: 'complete',
  },
  'sv-SE': {
    code: 'sv-SE',
    name: 'Swedish',
    nativeName: 'Svenska',
    region: 'Sweden',
    rtl: false,
    completeness: 'complete',
  },
  'nb-NO': {
    code: 'nb-NO',
    name: 'Norwegian (Bokmål)',
    nativeName: 'Norsk bokmål',
    region: 'Norway',
    rtl: false,
    completeness: 'complete',
  },
  'da-DK': {
    code: 'da-DK',
    name: 'Danish',
    nativeName: 'Dansk',
    region: 'Denmark',
    rtl: false,
    completeness: 'complete',
  },
  'uk-UA': {
    code: 'uk-UA',
    name: 'Ukrainian',
    nativeName: 'Українська',
    region: 'Ukraine',
    rtl: false,
    completeness: 'complete',
  },
  'el-GR': {
    code: 'el-GR',
    name: 'Greek',
    nativeName: 'Ελληνικά',
    region: 'Greece',
    rtl: false,
    completeness: 'complete',
  },
  'bg-BG': {
    code: 'bg-BG',
    name: 'Bulgarian',
    nativeName: 'Български',
    region: 'Bulgaria',
    rtl: false,
    completeness: 'complete',
  },
  'hu-HU': {
    code: 'hu-HU',
    name: 'Hungarian',
    nativeName: 'Magyar',
    region: 'Hungary',
    rtl: false,
    completeness: 'complete',
  },
  'cs-CZ': {
    code: 'cs-CZ',
    name: 'Czech',
    nativeName: 'Čeština',
    region: 'Czech Republic',
    rtl: false,
    completeness: 'complete',
  },
  'sk-SK': {
    code: 'sk-SK',
    name: 'Slovak',
    nativeName: 'Slovenčina',
    region: 'Slovakia',
    rtl: false,
    completeness: 'complete',
  },
  'fi-FI': {
    code: 'fi-FI',
    name: 'Finnish',
    nativeName: 'Suomi',
    region: 'Finland',
    rtl: false,
    completeness: 'complete',
  },
  'et-EE': {
    code: 'et-EE',
    name: 'Estonian',
    nativeName: 'Eesti',
    region: 'Estonia',
    rtl: false,
    completeness: 'complete',
  },
  'lv-LV': {
    code: 'lv-LV',
    name: 'Latvian',
    nativeName: 'Latviešu',
    region: 'Latvia',
    rtl: false,
    completeness: 'complete',
  },
  'lt-LT': {
    code: 'lt-LT',
    name: 'Lithuanian',
    nativeName: 'Lietuvių',
    region: 'Lithuania',
    rtl: false,
    completeness: 'complete',
  },

  // Asian and Middle Eastern languages
  'th-TH': { code: 'th-TH', name: 'Thai', nativeName: 'ไทย', region: 'Thailand', rtl: false, completeness: 'complete' },
  'vi-VN': {
    code: 'vi-VN',
    name: 'Vietnamese',
    nativeName: 'Tiếng Việt',
    region: 'Vietnam',
    rtl: false,
    completeness: 'complete',
  },
  'id-ID': {
    code: 'id-ID',
    name: 'Indonesian',
    nativeName: 'Bahasa Indonesia',
    region: 'Indonesia',
    rtl: false,
    completeness: 'complete',
  },
  'hi-IN': {
    code: 'hi-IN',
    name: 'Hindi',
    nativeName: 'हिन्दी',
    region: 'India',
    rtl: false,
    completeness: 'complete',
  },
  'ar-SA': {
    code: 'ar-SA',
    name: 'Arabic (Saudi Arabia)',
    nativeName: 'العربية',
    region: 'Saudi Arabia',
    rtl: true,
    completeness: 'complete',
  },
  'he-IL': {
    code: 'he-IL',
    name: 'Hebrew',
    nativeName: 'עברית',
    region: 'Israel',
    rtl: true,
    completeness: 'complete',
  },
  'tr-TR': {
    code: 'tr-TR',
    name: 'Turkish',
    nativeName: 'Türkçe',
    region: 'Turkey',
    rtl: false,
    completeness: 'complete',
  },
  'kk-KZ': {
    code: 'kk-KZ',
    name: 'Kazakh',
    nativeName: 'Қазақша',
    region: 'Kazakhstan',
    rtl: false,
    completeness: 'complete',
  },
  'mn-MN': {
    code: 'mn-MN',
    name: 'Mongolian',
    nativeName: 'Монгол',
    region: 'Mongolia',
    rtl: false,
    completeness: 'complete',
  },
  'kh-KH': {
    code: 'kh-KH',
    name: 'Khmer',
    nativeName: 'ភាសាខ្មែរ',
    region: 'Cambodia',
    rtl: false,
    completeness: 'complete',
  },
  'lo-LA': { code: 'lo-LA', name: 'Lao', nativeName: 'ລາວ', region: 'Laos', rtl: false, completeness: 'complete' },

  // Additional languages
  'bn-BD': {
    code: 'bn-BD',
    name: 'Bengali (Bangladesh)',
    nativeName: 'বাংলা',
    region: 'Bangladesh',
    rtl: false,
    completeness: 'complete',
  },
  'eo': {
    code: 'eo',
    name: 'Esperanto',
    nativeName: 'Esperanto',
    region: 'International',
    rtl: false,
    completeness: 'complete',
  },
  'is-IS': {
    code: 'is-IS',
    name: 'Icelandic',
    nativeName: 'Íslenska',
    region: 'Iceland',
    rtl: false,
    completeness: 'complete',
  },
  'sr-RS': {
    code: 'sr-RS',
    name: 'Serbian',
    nativeName: 'Српски',
    region: 'Serbia',
    rtl: false,
    completeness: 'complete',
  },
  'sl-SI': {
    code: 'sl-SI',
    name: 'Slovenian',
    nativeName: 'Slovenščina',
    region: 'Slovenia',
    rtl: false,
    completeness: 'complete',
  },
};

// Language family mapping
export const LANGUAGE_FAMILY_MAP: Record<string, LanguageFamily> = {
  'zh-CN': 'chinese',
  'zh-TW': 'chinese',
  'zh-HK': 'chinese',
  'en-US': 'english',
  'en-GB': 'english',
  'ja-JP': 'japanese',
  'ko-KR': 'korean',
  'es-ES': 'romance',
  'fr-FR': 'romance',
  'de-DE': 'germanic',
  'it-IT': 'romance',
  'pt-PT': 'romance',
  'pt-BR': 'romance',
  'nl-NL': 'germanic',
  'ru-RU': 'slavic',
  'pl-PL': 'slavic',
  'ro-RO': 'romance',
  'sv-SE': 'nordic',
  'nb-NO': 'nordic',
  'da-DK': 'nordic',
  'uk-UA': 'slavic',
  'el-GR': 'other',
  'bg-BG': 'slavic',
  'hu-HU': 'other',
  'cs-CZ': 'slavic',
  'sk-SK': 'slavic',
  'fi-FI': 'nordic',
  'et-EE': 'other',
  'lv-LV': 'other',
  'lt-LT': 'other',
  'th-TH': 'southeast-asian',
  'vi-VN': 'southeast-asian',
  'id-ID': 'southeast-asian',
  'hi-IN': 'indian',
  'ar-SA': 'arabic',
  'he-IL': 'other',
  'tr-TR': 'other',
  'kk-KZ': 'other',
  'mn-MN': 'other',
  'kh-KH': 'southeast-asian',
  'lo-LA': 'southeast-asian',
  'bn-BD': 'indian',
  'eo': 'other',
  'is-IS': 'nordic',
  'sr-RS': 'slavic',
  'sl-SI': 'slavic',
};

// Fallback language chains for better user experience
export const FALLBACK_CHAINS: Record<string, string[]> = {
  // Primary languages
  'zh-CN': ['zh-CN'],
  'en-US': ['en-US'],

  // Chinese variants fall back to Simplified Chinese
  'zh-TW': ['zh-TW', 'zh-CN'],
  'zh-HK': ['zh-HK', 'zh-CN', 'zh-TW'],

  // English variants fall back to US English
  'en-GB': ['en-GB', 'en-US'],

  // Portuguese variants
  'pt-BR': ['pt-BR', 'pt-PT'],

  // European languages can fall back to major languages
  'es-ES': ['es-ES', 'en-US'],
  'fr-FR': ['fr-FR', 'en-US'],
  'de-DE': ['de-DE', 'en-US'],
  'it-IT': ['it-IT', 'en-US'],
  'nl-NL': ['nl-NL', 'en-US'],

  // Slavic languages can fall back to Russian or English
  'pl-PL': ['pl-PL', 'ru-RU', 'en-US'],
  'uk-UA': ['uk-UA', 'ru-RU', 'en-US'],
  'bg-BG': ['bg-BG', 'ru-RU', 'en-US'],
  'cs-CZ': ['cs-CZ', 'en-US'],
  'sk-SK': ['sk-SK', 'cs-CZ', 'en-US'],
  'sr-RS': ['sr-RS', 'ru-RU', 'en-US'],

  // Nordic languages
  'sv-SE': ['sv-SE', 'en-US'],
  'nb-NO': ['nb-NO', 'sv-SE', 'en-US'],
  'da-DK': ['da-DK', 'sv-SE', 'en-US'],
  'fi-FI': ['fi-FI', 'sv-SE', 'en-US'],
  'is-IS': ['is-IS', 'sv-SE', 'en-US'],

  // Other European languages
  'el-GR': ['el-GR', 'en-US'],
  'hu-HU': ['hu-HU', 'en-US'],
  'ro-RO': ['ro-RO', 'it-IT', 'en-US'],
  'et-EE': ['et-EE', 'fi-FI', 'en-US'],
  'lv-LV': ['lv-LV', 'lt-LT', 'en-US'],
  'lt-LT': ['lt-LT', 'lv-LV', 'en-US'],

  // Asian languages
  'ja-JP': ['ja-JP', 'en-US'],
  'ko-KR': ['ko-KR', 'en-US'],
  'th-TH': ['th-TH', 'en-US'],
  'vi-VN': ['vi-VN', 'en-US'],
  'id-ID': ['id-ID', 'en-US'],
  'hi-IN': ['hi-IN', 'en-US'],
  'tr-TR': ['tr-TR', 'en-US'],

  // RTL languages fall back to English for LTR content
  'ar-SA': ['ar-SA', 'en-US'],
  'he-IL': ['he-IL', 'en-US'],

  // Other languages
  'kk-KZ': ['kk-KZ', 'ru-RU', 'en-US'],
  'mn-MN': ['mn-MN', 'ru-RU', 'en-US'],
  'kh-KH': ['kh-KH', 'en-US'],
  'lo-LA': ['lo-LA', 'th-TH', 'en-US'],
  'bn-BD': ['bn-BD', 'en-US'],

  // Esperanto has no natural fallback
  'eo': ['eo', 'en-US'],

  // Default fallback for all languages
  'default': ['zh-CN', 'en-US'],
};

// Helper function to get fallback chain for a locale
export function getFallbackChain(locale: string): string[] {
  return FALLBACK_CHAINS[locale] || FALLBACK_CHAINS.default || [];
}

// Helper function to check if a language is RTL
export function isRTLLanguage(locale: string): boolean {
  return LANGUAGE_METADATA[locale]?.rtl || false;
}

// Helper function to get language family
export function getLanguageFamily(locale: string): LanguageFamily {
  return LANGUAGE_FAMILY_MAP[locale] || 'other';
}
