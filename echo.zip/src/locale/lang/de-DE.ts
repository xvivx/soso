import type { Message } from '../index';

// German language pack
export default {
  // Common UI elements
  name: 'Name',
  tel: 'Telefon',
  save: 'Speichern',
  clear: 'Löschen',
  cancel: 'Abbrechen',
  confirm: 'Bestätigen',
  delete: 'Löschen',
  loading: 'Wird geladen...',
  more: 'Mehr laden',
  noMore: 'Keine weiteren Daten',
  refresh: 'Aktualisieren',
  done: 'Fertig',
  close: 'Schließen',
  search: 'Suchen',
  select: 'Auswählen',
  upload: 'Hochladen',
  download: 'Herunterladen',
  edit: 'Bearbeiten',
  copy: 'Kopieren',
  share: 'Teilen',
  back: 'Zurück',
  next: 'Weiter',
  previous: 'Vorherige',
  submit: 'Absenden',
  reset: 'Zurücksetzen',
  tryAgain: 'Erneut versuchen',
  error: 'Fehler',
  success: 'Erfolg',
  warning: 'Warnung',
  info: 'Information',

  // Component-specific translations
  htLoading: {
    loading: 'Wird geladen...',
    text: 'Wird geladen...',
  },

  htList: {
    loadingText: 'Wird geladen...',
    errorText: 'Laden fehlgeschlagen. Klicken Sie zum Wiederholen',
    finishedText: 'Keine weiteren Daten',
    error: 'Laden fehlgeschlagen',
    tryAgain: 'Klicken Sie zum Wiederholen',
    noMore: 'Keine weiteren Daten',
  },

  htPullRefresh: {
    pullingText: 'Zum Aktualisieren ziehen...',
    loosingText: 'Loslassen zum Aktualisieren...',
    loadingText: 'Wird aktualisiert...',
    successText: 'Aktualisierung erfolgreich',
    completeText: 'Aktualisierung abgeschlossen',
  },

  htEmpty: {
    description: 'Keine Daten',
    image: {
      alt: 'Leerzustandsbild',
    },
  },

  htModal: {
    close: 'Schließen',
    confirm: 'Bestätigen',
    cancel: 'Abbrechen',
  },

  htForm: {
    required: 'Dieses Feld ist erforderlich',
    invalid: 'Ungültiges Eingabeformat',
    minLength: 'Eingabe muss mindestens {min} Zeichen haben',
    maxLength: 'Eingabe darf nicht mehr als {max} Zeichen haben',
    email: 'Bitte geben Sie eine gültige E-Mail-Adresse ein',
    phone: 'Bitte geben Sie eine gültige Telefonnummer ein',
    url: 'Bitte geben Sie eine gültige URL ein',
    number: 'Bitte geben Sie eine gültige Zahl ein',
    date: 'Bitte wählen Sie ein gültiges Datum',
    time: 'Bitte wählen Sie eine gültige Uhrzeit',
    pattern: 'Eingabeformat ist ungültig',
    match: 'Eingaben stimmen nicht überein',
  },

  htField: {
    clear: 'Löschen',
    required: 'Erforderlich',
    optional: 'Optional',
    placeholder: 'Bitte eingeben',
    search: 'Suchen',
    wordLimit: '{count} Zeichen verbleibend',
    wordLimitExceeded: 'Zeichenlimit überschritten',
  },

  htButton: {
    loading: 'Wird geladen...',
    disabled: 'Deaktiviert',
  },

  htToast: {
    success: 'Erfolg',
    error: 'Fehler',
    loading: 'Wird geladen...',
    warning: 'Warnung',
    info: 'Information',
  },

  htDialog: {
    title: 'Bestätigen',
    message: 'Sind Sie sicher, dass Sie diese Operation durchführen möchten?',
    confirm: 'Bestätigen',
    cancel: 'Abbrechen',
  },

  htPicker: {
    confirm: 'Bestätigen',
    cancel: 'Abbrechen',
    title: 'Bitte auswählen',
  },

  htDatePicker: {
    title: 'Datum auswählen',
    year: 'Jahr',
    month: 'Monat',
    day: 'Tag',
    today: 'Heute',
    confirm: 'Bestätigen',
    cancel: 'Abbrechen',
    weekdays: ['So', 'Mo', 'Di', 'Mi', 'Do', 'Fr', 'Sa'],
    months: ['Jan', 'Feb', 'Mär', 'Apr', 'Mai', 'Jun', 'Jul', 'Aug', 'Sep', 'Okt', 'Nov', 'Dez'],
  },

  htTimePicker: {
    title: 'Uhrzeit auswählen',
    hour: 'Stunde',
    minute: 'Minute',
    second: 'Sekunde',
    confirm: 'Bestätigen',
    cancel: 'Abbrechen',
  },

  htStepper: {
    increase: 'Erhöhen',
    decrease: 'Verringern',
    min: 'Kann nicht kleiner als der Mindestwert sein',
    max: 'Kann nicht größer als der Höchstwert sein',
    integer: 'Bitte geben Sie eine ganze Zahl ein',
  },

  htRate: {
    score: 'Bewertung',
  },

  htSteps: {
    step: 'Schritt',
    done: 'Abgeschlossen',
    process: 'In Bearbeitung',
    wait: 'Wartend',
  },

  htTabBar: {
    home: 'Startseite',
    category: 'Kategorie',
    cart: 'Warenkorb',
    user: 'Benutzer',
    search: 'Suchen',
  },

  htImage: {
    loading: 'Bild wird geladen...',
    error: 'Fehler beim Laden des Bildes',
    preview: 'Vorschau',
    zoom: 'Vergrößern',
    zoomOut: 'Verkleinern',
    rotate: 'Drehen',
    original: 'Original anzeigen',
  },

  htSwitch: {
    on: 'Ein',
    off: 'Aus',
  },

  htCheckbox: {
    checked: 'Ausgewählt',
    unchecked: 'Nicht ausgewählt',
    all: 'Alle auswählen',
    none: 'Alle abwählen',
  },

  htRadio: {
    checked: 'Ausgewählt',
    unchecked: 'Nicht ausgewählt',
  },

  htSelect: {
    placeholder: 'Bitte auswählen',
    noData: 'Keine Daten',
    search: 'Suchen',
    clear: 'Löschen',
  },

  htUpload: {
    uploading: 'Wird hochgeladen...',
    uploadingText: 'Hochladen {percent}%',
    success: 'Hochladen erfolgreich',
    error: 'Hochladen fehlgeschlagen',
    preview: 'Vorschau',
    delete: 'Löschen',
    retry: 'Erneut versuchen',
    maxCount: 'Maximal {count} Dateien können hochgeladen werden',
    maxSize: 'Dateigröße darf nicht {size} überschreiten',
    fileType: 'Dateityp nicht unterstützt',
  },

  htPagination: {
    prev: 'Vorherige',
    next: 'Nächste',
    total: 'Insgesamt {total} Elemente',
    page: 'Seite {current} von {pages}',
    jumper: 'Gehe zu',
    pageSize: 'Elemente/Seite',
    totalPage: 'Seiten',
  },

  htTable: {
    empty: 'Keine Daten',
    selectAll: 'Alle auswählen',
    deselectAll: 'Alle abwählen',
    expand: 'Erweitern',
    collapse: 'Zusammenklappen',
    sort: 'Sortieren',
    filter: 'Filtern',
    reset: 'Zurücksetzen',
    confirm: 'Bestätigen',
  },

  htCalendar: {
    title: 'Kalender',
    year: 'Jahr',
    month: 'Monat',
    today: 'Heute',
    confirm: 'Bestätigen',
    cancel: 'Abbrechen',
    weekdays: ['So', 'Mo', 'Di', 'Mi', 'Do', 'Fr', 'Sa'],
    months: ['Jan', 'Feb', 'Mär', 'Apr', 'Mai', 'Jun', 'Jul', 'Aug', 'Sep', 'Okt', 'Nov', 'Dez'],
    rangePrompt: 'Datumsbereich kann nicht mehr als {maxRange} Tage betragen',
    minRange: 'Wählen Sie mindestens {minRange} Tage',
    maxRange: 'Wählen Sie höchstens {maxRange} Tage',
  },

  htSwipe: {
    previous: 'Vorherige',
    next: 'Nächste',
    indicator: '{current} / {total}',
  },

  htCollapse: {
    expand: 'Erweitern',
    collapse: 'Zusammenklappen',
  },

  htBadge: {
    dot: 'Punkt-Indikator',
    count: 'Zähler',
  },

  htTag: {
    close: 'Tag schließen',
  },

  htProgress: {
    percent: '{percent}%',
  },

  htSkeleton: {
    loading: 'Wird geladen...',
  },

  htAffix: {
    fixed: 'Feste Positionierung',
  },

  htBackTop: {
    tooltip: 'Nach oben',
  },

  htAnchor: {
    copy: 'Link kopieren',
    copied: 'Kopiert',
  },

  htBreadcrumb: {
    home: 'Startseite',
  },

  htDivider: {
    text: 'Trennlinientext',
  },

  htResult: {
    success: 'Operation erfolgreich',
    error: 'Operation fehlgeschlagen',
    info: 'Information',
    warning: 'Warnung',
    notFound: 'Seite nicht gefunden',
    unauthorized: 'Nicht autorisiert',
    forbidden: 'Zugriff verboten',
    serverError: 'Serverfehler',
  },

  htTypography: {
    copy: 'Kopieren',
    copied: 'Kopiert',
    edit: 'Bearbeiten',
    expand: 'Erweitern',
    collapse: 'Zusammenklappen',
  },

  htAlert: {
    close: 'Schließen',
  },

  htMessage: {
    close: 'Schließen',
  },

  htNotification: {
    close: 'Schließen',
  },

  htPopconfirm: {
    title: 'Bestätigen',
    confirm: 'OK',
    cancel: 'Abbrechen',
  },

  htTooltip: {
    empty: 'Kein Tooltip',
  },

  htPopover: {
    close: 'Schließen',
  },

  htDropdown: {
    title: 'Dropdown-Menü',
  },
} as unknown as Message;
