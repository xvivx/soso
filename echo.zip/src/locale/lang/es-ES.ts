import type { Message } from '../index';

// Spanish (Spain) language pack
export default {
  // Common UI elements
  name: 'Nombre',
  tel: 'Teléfono',
  save: 'Guardar',
  clear: 'Limpiar',
  cancel: 'Cancelar',
  confirm: 'Confirmar',
  delete: 'Eliminar',
  loading: 'Cargando...',
  more: 'Cargar más',
  noMore: 'No hay más',
  refresh: 'Actualizar',
  done: 'Hecho',
  close: 'Cerrar',
  search: 'Buscar',
  select: 'Seleccionar',
  upload: 'Subir',
  download: 'Descargar',
  edit: 'Editar',
  copy: 'Copiar',
  share: 'Compartir',
  back: 'Atrás',
  next: 'Siguiente',
  previous: 'Anterior',
  submit: 'Enviar',
  reset: 'Restablecer',
  tryAgain: 'Intentar de nuevo',
  error: 'Error',
  success: 'Éxito',
  warning: 'Advertencia',
  info: 'Información',

  // Component-specific translations
  htLoading: {
    loading: 'Cargando...',
    text: 'Cargando...',
  },

  htList: {
    loadingText: 'Cargando...',
    errorText: 'Error al cargar. Haz clic para reintentar',
    finishedText: 'No hay más datos',
    error: 'Error al cargar',
    tryAgain: 'Haz clic para reintentar',
    noMore: 'No hay más datos',
  },

  htPullRefresh: {
    pullingText: 'Tira para actualizar...',
    loosingText: 'Suelta para actualizar...',
    loadingText: 'Actualizando...',
    successText: 'Actualización exitosa',
    completeText: 'Actualización completa',
  },

  htEmpty: {
    description: 'Sin datos',
    image: {
      alt: 'Imagen de estado vacío',
    },
  },

  htModal: {
    close: 'Cerrar',
    confirm: 'Confirmar',
    cancel: 'Cancelar',
  },

  htForm: {
    required: 'Este campo es obligatorio',
    invalid: 'Formato de entrada inválido',
    minLength: 'La entrada debe tener al menos {min} caracteres',
    maxLength: 'La entrada no puede exceder {max} caracteres',
    email: 'Por favor introduce una dirección de correo válida',
    phone: 'Por favor introduce un número de teléfono válido',
    url: 'Por favor introduce una URL válida',
    number: 'Por favor introduce un número válido',
    date: 'Por favor selecciona una fecha válida',
    time: 'Por favor selecciona una hora válida',
    pattern: 'El formato de entrada es inválido',
    match: 'Las entradas no coinciden',
  },

  htField: {
    clear: 'Limpiar',
    required: 'Obligatorio',
    optional: 'Opcional',
    placeholder: 'Por favor introduce',
    search: 'Buscar',
    wordLimit: '{count} caracteres restantes',
    wordLimitExceeded: 'Límite de caracteres excedido',
  },

  htButton: {
    loading: 'Cargando...',
    disabled: 'Desactivado',
  },

  htToast: {
    success: 'Éxito',
    error: 'Error',
    loading: 'Cargando...',
    warning: 'Advertencia',
    info: 'Información',
  },

  htDialog: {
    title: 'Confirmar',
    message: '¿Estás seguro de que quieres realizar esta operación?',
    confirm: 'Confirmar',
    cancel: 'Cancelar',
  },

  htPicker: {
    confirm: 'Confirmar',
    cancel: 'Cancelar',
    title: 'Por favor selecciona',
  },

  htDatePicker: {
    title: 'Seleccionar fecha',
    year: 'Año',
    month: 'Mes',
    day: 'Día',
    today: 'Hoy',
    confirm: 'Confirmar',
    cancel: 'Cancelar',
    weekdays: ['Dom', 'Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb'],
    months: ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic'],
  },

  htTimePicker: {
    title: 'Seleccionar hora',
    hour: 'Hora',
    minute: 'Minuto',
    second: 'Segundo',
    confirm: 'Confirmar',
    cancel: 'Cancelar',
  },

  htStepper: {
    increase: 'Aumentar',
    decrease: 'Disminuir',
    min: 'No puede ser menor que el valor mínimo',
    max: 'No puede ser mayor que el valor máximo',
    integer: 'Por favor introduce un número entero',
  },

  htRate: {
    score: 'Puntuación',
  },

  htSteps: {
    step: 'Paso',
    done: 'Completado',
    process: 'En proceso',
    wait: 'En espera',
  },

  htTabBar: {
    home: 'Inicio',
    category: 'Categoría',
    cart: 'Carrito',
    user: 'Usuario',
    search: 'Buscar',
  },

  htImage: {
    loading: 'Cargando imagen...',
    error: 'Error al cargar imagen',
    preview: 'Vista previa',
    zoom: 'Acercar',
    zoomOut: 'Alejar',
    rotate: 'Rotar',
    original: 'Ver original',
  },

  htSwitch: {
    on: 'Sí',
    off: 'No',
  },

  htCheckbox: {
    checked: 'Seleccionado',
    unchecked: 'No seleccionado',
    all: 'Seleccionar todo',
    none: 'Deseleccionar todo',
  },

  htRadio: {
    checked: 'Seleccionado',
    unchecked: 'No seleccionado',
  },

  htSelect: {
    placeholder: 'Por favor selecciona',
    noData: 'Sin datos',
    search: 'Buscar',
    clear: 'Limpiar',
  },

  htUpload: {
    uploading: 'Subiendo...',
    uploadingText: 'Subiendo {percent}%',
    success: 'Subida exitosa',
    error: 'Error en la subida',
    preview: 'Vista previa',
    delete: 'Eliminar',
    retry: 'Reintentar',
    maxCount: 'Máximo {count} archivos pueden ser subidos',
    maxSize: 'El tamaño del archivo no puede exceder {size}',
    fileType: 'Tipo de archivo no soportado',
  },

  htPagination: {
    prev: 'Anterior',
    next: 'Siguiente',
    total: 'Total {total} elementos',
    page: 'Página {current} de {pages}',
    jumper: 'Ir a',
    pageSize: 'elementos/página',
    totalPage: 'páginas',
  },

  htTable: {
    empty: 'Sin datos',
    selectAll: 'Seleccionar todo',
    deselectAll: 'Deseleccionar todo',
    expand: 'Expandir',
    collapse: 'Contraer',
    sort: 'Ordenar',
    filter: 'Filtrar',
    reset: 'Restablecer',
    confirm: 'Confirmar',
  },

  htCalendar: {
    title: 'Calendario',
    year: 'Año',
    month: 'Mes',
    today: 'Hoy',
    confirm: 'Confirmar',
    cancel: 'Cancelar',
    weekdays: ['Dom', 'Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb'],
    months: ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic'],
    rangePrompt: 'El rango de fechas no puede exceder {maxRange} días',
    minRange: 'Selecciona al menos {minRange} días',
    maxRange: 'Selecciona como máximo {maxRange} días',
  },

  htSwipe: {
    previous: 'Anterior',
    next: 'Siguiente',
    indicator: '{current} / {total}',
  },

  htCollapse: {
    expand: 'Expandir',
    collapse: 'Contraer',
  },

  htBadge: {
    dot: 'Indicador de punto',
    count: 'Contador',
  },

  htTag: {
    close: 'Cerrar etiqueta',
  },

  htProgress: {
    percent: '{percent}%',
  },

  htSkeleton: {
    loading: 'Cargando...',
  },

  htAffix: {
    fixed: 'Posición fija',
  },

  htBackTop: {
    tooltip: 'Volver arriba',
  },

  htAnchor: {
    copy: 'Copiar enlace',
    copied: 'Copiado',
  },

  htBreadcrumb: {
    home: 'Inicio',
  },

  htDivider: {
    text: 'Texto del divisor',
  },

  htResult: {
    success: 'Operación exitosa',
    error: 'Operación fallida',
    info: 'Información',
    warning: 'Advertencia',
    notFound: 'Página no encontrada',
    unauthorized: 'No autorizado',
    forbidden: 'Acceso prohibido',
    serverError: 'Error del servidor',
  },

  htTypography: {
    copy: 'Copiar',
    copied: 'Copiado',
    edit: 'Editar',
    expand: 'Expandir',
    collapse: 'Contraer',
  },

  htAlert: {
    close: 'Cerrar',
  },

  htMessage: {
    close: 'Cerrar',
  },

  htNotification: {
    close: 'Cerrar',
  },

  htPopconfirm: {
    title: 'Confirmar',
    confirm: 'OK',
    cancel: 'Cancelar',
  },

  htTooltip: {
    empty: 'Sin información sobre herramientas',
  },

  htPopover: {
    close: 'Cerrar',
  },

  htDropdown: {
    title: 'Menú desplegable',
  },
} as unknown as Message;
