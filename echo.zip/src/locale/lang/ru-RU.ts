import type { Message } from '../index';

// Russian language pack
export default {
  // Common UI elements
  name: 'Имя',
  tel: 'Телефон',
  save: 'Сохранить',
  clear: 'Очистить',
  cancel: 'Отмена',
  confirm: 'Подтвердить',
  delete: 'Удалить',
  loading: 'Загрузка...',
  more: 'Загрузить еще',
  noMore: 'Больше нет данных',
  refresh: 'Обновить',
  done: 'Готово',
  close: 'Закрыть',
  search: 'Поиск',
  select: 'Выбрать',
  upload: 'Загрузить',
  download: 'Скачать',
  edit: 'Редактировать',
  copy: 'Копировать',
  share: 'Поделиться',
  back: 'Назад',
  next: 'Далее',
  previous: 'Предыдущий',
  submit: 'Отправить',
  reset: 'Сбросить',
  tryAgain: 'Попробовать снова',
  error: 'Ошибка',
  success: 'Успех',
  warning: 'Предупреждение',
  info: 'Информация',

  // Component-specific translations
  htLoading: {
    loading: 'Загрузка...',
    text: 'Загрузка...',
  },

  htList: {
    loadingText: 'Загрузка...',
    errorText: 'Ошибка загрузки. Нажмите для повтора',
    finishedText: 'Больше нет данных',
    error: 'Ошибка загрузки',
    tryAgain: 'Нажмите для повтора',
    noMore: 'Больше нет данных',
  },

  htPullRefresh: {
    pullingText: 'Потяните для обновления...',
    loosingText: 'Отпустите для обновления...',
    loadingText: 'Обновление...',
    successText: 'Обновление успешно',
    completeText: 'Обновление завершено',
  },

  htEmpty: {
    description: 'Нет данных',
    image: {
      alt: 'Изображение пустого состояния',
    },
  },

  htModal: {
    close: 'Закрыть',
    confirm: 'Подтвердить',
    cancel: 'Отмена',
  },

  htForm: {
    required: 'Это поле обязательно для заполнения',
    invalid: 'Неверный формат ввода',
    minLength: 'Ввод должен содержать минимум {min} символов',
    maxLength: 'Ввод не может превышать {max} символов',
    email: 'Пожалуйста, введите действительный адрес электронной почты',
    phone: 'Пожалуйста, введите действительный номер телефона',
    url: 'Пожалуйста, введите действительный URL',
    number: 'Пожалуйста, введите действительное число',
    date: 'Пожалуйста, выберите действительную дату',
    time: 'Пожалуйста, выберите действительное время',
    pattern: 'Формат ввода недействителен',
    match: 'Введенные данные не совпадают',
  },

  htField: {
    clear: 'Очистить',
    required: 'Обязательно',
    optional: 'Необязательно',
    placeholder: 'Пожалуйста, введите',
    search: 'Поиск',
    wordLimit: 'Осталось {count} символов',
    wordLimitExceeded: 'Превышен лимит символов',
  },

  htButton: {
    loading: 'Загрузка...',
    disabled: 'Отключено',
  },

  htToast: {
    success: 'Успех',
    error: 'Ошибка',
    loading: 'Загрузка...',
    warning: 'Предупреждение',
    info: 'Информация',
  },

  htDialog: {
    title: 'Подтверждение',
    message: 'Вы уверены, что хотите выполнить эту операцию?',
    confirm: 'Подтвердить',
    cancel: 'Отмена',
  },

  htPicker: {
    confirm: 'Подтвердить',
    cancel: 'Отмена',
    title: 'Пожалуйста, выберите',
  },

  htDatePicker: {
    title: 'Выбрать дату',
    year: 'Год',
    month: 'Месяц',
    day: 'День',
    today: 'Сегодня',
    confirm: 'Подтвердить',
    cancel: 'Отмена',
    weekdays: ['Вс', 'Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб'],
    months: ['Янв', 'Фев', 'Мар', 'Апр', 'Май', 'Июн', 'Июл', 'Авг', 'Сен', 'Окт', 'Ноя', 'Дек'],
  },

  htTimePicker: {
    title: 'Выбрать время',
    hour: 'Час',
    minute: 'Минута',
    second: 'Секунда',
    confirm: 'Подтвердить',
    cancel: 'Отмена',
  },

  htStepper: {
    increase: 'Увеличить',
    decrease: 'Уменьшить',
    min: 'Не может быть меньше минимального значения',
    max: 'Не может быть больше максимального значения',
    integer: 'Пожалуйста, введите целое число',
  },

  htRate: {
    score: 'Оценка',
  },

  htSteps: {
    step: 'Шаг',
    done: 'Завершено',
    process: 'В процессе',
    wait: 'Ожидание',
  },

  htTabBar: {
    home: 'Главная',
    category: 'Категория',
    cart: 'Корзина',
    user: 'Пользователь',
    search: 'Поиск',
  },

  htImage: {
    loading: 'Загрузка изображения...',
    error: 'Ошибка загрузки изображения',
    preview: 'Предпросмотр',
    zoom: 'Увеличить',
    zoomOut: 'Уменьшить',
    rotate: 'Повернуть',
    original: 'Посмотреть оригинал',
  },

  htSwitch: {
    on: 'Вкл',
    off: 'Выкл',
  },

  htCheckbox: {
    checked: 'Выбрано',
    unchecked: 'Не выбрано',
    all: 'Выбрать все',
    none: 'Снять все',
  },

  htRadio: {
    checked: 'Выбрано',
    unchecked: 'Не выбрано',
  },

  htSelect: {
    placeholder: 'Пожалуйста, выберите',
    noData: 'Нет данных',
    search: 'Поиск',
    clear: 'Очистить',
  },

  htUpload: {
    uploading: 'Загрузка...',
    uploadingText: 'Загрузка {percent}%',
    success: 'Загрузка успешна',
    error: 'Ошибка загрузки',
    preview: 'Предпросмотр',
    delete: 'Удалить',
    retry: 'Повторить',
    maxCount: 'Максимум {count} файлов могут быть загружены',
    maxSize: 'Размер файла не может превышать {size}',
    fileType: 'Тип файла не поддерживается',
  },

  htPagination: {
    prev: 'Предыдущий',
    next: 'Следующий',
    total: 'Всего {total} элементов',
    page: 'Страница {current} из {pages}',
    jumper: 'Перейти к',
    pageSize: 'элементов/страница',
    totalPage: 'страниц',
  },

  htTable: {
    empty: 'Нет данных',
    selectAll: 'Выбрать все',
    deselectAll: 'Снять все',
    expand: 'Развернуть',
    collapse: 'Свернуть',
    sort: 'Сортировка',
    filter: 'Фильтр',
    reset: 'Сбросить',
    confirm: 'Подтвердить',
  },

  htCalendar: {
    title: 'Календарь',
    year: 'Год',
    month: 'Месяц',
    today: 'Сегодня',
    confirm: 'Подтвердить',
    cancel: 'Отмена',
    weekdays: ['Вс', 'Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб'],
    months: ['Янв', 'Фев', 'Мар', 'Апр', 'Май', 'Июн', 'Июл', 'Авг', 'Сен', 'Окт', 'Ноя', 'Дек'],
    rangePrompt: 'Диапазон дат не может превышать {maxRange} дней',
    minRange: 'Выберите минимум {minRange} дней',
    maxRange: 'Выберите максимум {maxRange} дней',
  },

  htSwipe: {
    previous: 'Предыдущий',
    next: 'Следующий',
    indicator: '{current} / {total}',
  },

  htCollapse: {
    expand: 'Развернуть',
    collapse: 'Свернуть',
  },

  htBadge: {
    dot: 'Индикатор точки',
    count: 'Счетчик',
  },

  htTag: {
    close: 'Закрыть тег',
  },

  htProgress: {
    percent: '{percent}%',
  },

  htSkeleton: {
    loading: 'Загрузка...',
  },

  htAffix: {
    fixed: 'Фиксированное позиционирование',
  },

  htBackTop: {
    tooltip: 'Наверх',
  },

  htAnchor: {
    copy: 'Копировать ссылку',
    copied: 'Скопировано',
  },

  htBreadcrumb: {
    home: 'Главная',
  },

  htDivider: {
    text: 'Текст разделителя',
  },

  htResult: {
    success: 'Операция успешна',
    error: 'Операция не удалась',
    info: 'Информация',
    warning: 'Предупреждение',
    notFound: 'Страница не найдена',
    unauthorized: 'Не авторизован',
    forbidden: 'Доступ запрещен',
    serverError: 'Ошибка сервера',
  },

  htTypography: {
    copy: 'Копировать',
    copied: 'Скопировано',
    edit: 'Редактировать',
    expand: 'Развернуть',
    collapse: 'Свернуть',
  },

  htAlert: {
    close: 'Закрыть',
  },

  htMessage: {
    close: 'Закрыть',
  },

  htNotification: {
    close: 'Закрыть',
  },

  htPopconfirm: {
    title: 'Подтверждение',
    confirm: 'ОК',
    cancel: 'Отмена',
  },

  htTooltip: {
    empty: 'Нет подсказки',
  },

  htPopover: {
    close: 'Закрыть',
  },

  htDropdown: {
    title: 'Выпадающее меню',
  },
} as unknown as Message;
