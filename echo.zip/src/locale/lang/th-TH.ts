import type { Message } from '../index';

// Thai language pack
export default {
  // Common UI elements
  name: 'ชื่อ',
  tel: 'โทรศัพท์',
  save: 'บันทึก',
  clear: 'ล้าง',
  cancel: 'ยกเลิก',
  confirm: 'ยืนยัน',
  delete: 'ลบ',
  loading: 'กำลังโหลด...',
  more: 'โหลดเพิ่ม',
  noMore: 'ไม่มีข้อมูลเพิ่มเติม',
  refresh: 'รีเฟรช',
  done: 'เสร็จสิ้น',
  close: 'ปิด',
  search: 'ค้นหา',
  select: 'เลือก',
  upload: 'อัปโหลด',
  download: 'ดาวน์โหลด',
  edit: 'แก้ไข',
  copy: 'คัดลอก',
  share: 'แชร์',
  back: 'ย้อนกลับ',
  next: 'ถัดไป',
  previous: 'ก่อนหน้า',
  submit: 'ส่ง',
  reset: 'รีเซ็ต',
  tryAgain: 'ลองใหม่',
  error: 'ข้อผิดพลาด',
  success: 'สำเร็จ',
  warning: 'คำเตือน',
  info: 'ข้อมูล',

  // Component-specific translations
  htLoading: {
    loading: 'กำลังโหลด...',
    text: 'กำลังโหลด...',
  },

  htList: {
    loadingText: 'กำลังโหลด...',
    errorText: 'โหลดไม่สำเร็จ คลิกเพื่อลองใหม่',
    finishedText: 'ไม่มีข้อมูลเพิ่มเติม',
    error: 'โหลดไม่สำเร็จ',
    tryAgain: 'คลิกเพื่อลองใหม่',
    noMore: 'ไม่มีข้อมูลเพิ่มเติม',
  },

  htPullRefresh: {
    pullingText: 'ดึงเพื่อรีเฟรช...',
    loosingText: 'ปล่อยเพื่อรีเฟรช...',
    loadingText: 'กำลังรีเฟรช...',
    successText: 'รีเฟรชสำเร็จ',
    completeText: 'รีเฟรชเสร็จสิ้น',
  },

  htEmpty: {
    description: 'ไม่มีข้อมูล',
    image: {
      alt: 'รูปภาพสถานะว่าง',
    },
  },

  htModal: {
    close: 'ปิด',
    confirm: 'ยืนยัน',
    cancel: 'ยกเลิก',
  },

  htForm: {
    required: 'ฟิลด์นี้จำเป็น',
    invalid: 'รูปแบบการป้อนไม่ถูกต้อง',
    minLength: 'ต้องป้อนอย่างน้อย {min} ตัวอักษร',
    maxLength: 'ไม่สามารถป้อนเกิน {max} ตัวอักษร',
    email: 'กรุณาป้อนอีเมลที่ถูกต้อง',
    phone: 'กรุณาป้อนหมายเลขโทรศัพท์ที่ถูกต้อง',
    url: 'กรุณาป้อน URL ที่ถูกต้อง',
    number: 'กรุณาป้อนตัวเลขที่ถูกต้อง',
    date: 'กรุณาเลือกวันที่ที่ถูกต้อง',
    time: 'กรุณาเลือกเวลาที่ถูกต้อง',
    pattern: 'รูปแบบการป้อนไม่ถูกต้อง',
    match: 'ข้อมูลไม่ตรงกัน',
  },

  htField: {
    clear: 'ล้าง',
    required: 'จำเป็น',
    optional: 'ไม่จำเป็น',
    placeholder: 'กรุณาป้อน',
    search: 'ค้นหา',
    wordLimit: 'เหลืออีก {count} ตัวอักษร',
    wordLimitExceeded: 'เกินจำนวนตัวอักษรที่กำหนด',
  },

  htButton: {
    loading: 'กำลังโหลด...',
    disabled: 'ปิดใช้งาน',
  },

  htToast: {
    success: 'สำเร็จ',
    error: 'ข้อผิดพลาด',
    loading: 'กำลังโหลด...',
    warning: 'คำเตือน',
    info: 'ข้อมูล',
  },

  htDialog: {
    title: 'ยืนยัน',
    message: 'คุณแน่ใจหรือไม่ว่าต้องการดำเนินการนี้?',
    confirm: 'ยืนยัน',
    cancel: 'ยกเลิก',
  },

  htPicker: {
    confirm: 'ยืนยัน',
    cancel: 'ยกเลิก',
    title: 'กรุณาเลือก',
  },

  htDatePicker: {
    title: 'เลือกวันที่',
    year: 'ปี',
    month: 'เดือน',
    day: 'วัน',
    today: 'วันนี้',
    confirm: 'ยืนยัน',
    cancel: 'ยกเลิก',
    weekdays: ['อา.', 'จ.', 'อ.', 'พ.', 'พฤ.', 'ศ.', 'ส.'],
    months: ['ม.ค.', 'ก.พ.', 'มี.ค.', 'เม.ย.', 'พ.ค.', 'มิ.ย.', 'ก.ค.', 'ส.ค.', 'ก.ย.', 'ต.ค.', 'พ.ย.', 'ธ.ค.'],
  },

  htTimePicker: {
    title: 'เลือกเวลา',
    hour: 'ชั่วโมง',
    minute: 'นาที',
    second: 'วินาที',
    confirm: 'ยืนยัน',
    cancel: 'ยกเลิก',
  },

  htStepper: {
    increase: 'เพิ่ม',
    decrease: 'ลด',
    min: 'ไม่สามารถน้อยกว่าค่าต่ำสุดได้',
    max: 'ไม่สามารถมากกว่าค่าสูงสุดได้',
    integer: 'กรุณาป้อนจำนวนเต็ม',
  },

  htRate: {
    score: 'คะแนน',
  },

  htSteps: {
    step: 'ขั้นตอน',
    done: 'เสร็จสิ้น',
    process: 'กำลังดำเนินการ',
    wait: 'รอ',
  },

  htTabBar: {
    home: 'หน้าแรก',
    category: 'หมวดหมู่',
    cart: 'ตะกร้า',
    user: 'ผู้ใช้',
    search: 'ค้นหา',
  },

  htImage: {
    loading: 'กำลังโหลดรูปภาพ...',
    error: 'โหลดรูปภาพไม่สำเร็จ',
    preview: 'ดูตัวอย่าง',
    zoom: 'ขยาย',
    zoomOut: 'ย่อ',
    rotate: 'หมุน',
    original: 'ดูต้นฉบับ',
  },

  htSwitch: {
    on: 'เปิด',
    off: 'ปิด',
  },

  htCheckbox: {
    checked: 'เลือกแล้ว',
    unchecked: 'ยังไม่เลือก',
    all: 'เลือกทั้งหมด',
    none: 'ยกเลิกการเลือกทั้งหมด',
  },

  htRadio: {
    checked: 'เลือกแล้ว',
    unchecked: 'ยังไม่เลือก',
  },

  htSelect: {
    placeholder: 'กรุณาเลือก',
    noData: 'ไม่มีข้อมูล',
    search: 'ค้นหา',
    clear: 'ล้าง',
  },

  htUpload: {
    uploading: 'กำลังอัปโหลด...',
    uploadingText: 'กำลังอัปโหลด {percent}%',
    success: 'อัปโหลดสำเร็จ',
    error: 'อัปโหลดไม่สำเร็จ',
    preview: 'ดูตัวอย่าง',
    delete: 'ลบ',
    retry: 'ลองใหม่',
    maxCount: 'สามารถอัปโหลดได้สูงสุด {count} ไฟล์',
    maxSize: 'ขนาดไฟล์ไม่สามารถเกิน {size}',
    fileType: 'ไม่รองรับประเภทไฟล์นี้',
  },

  htPagination: {
    prev: 'ก่อนหน้า',
    next: 'ถัดไป',
    total: 'รวม {total} รายการ',
    page: 'หน้า {current} จาก {pages}',
    jumper: 'ไปที่',
    pageSize: 'รายการ/หน้า',
    totalPage: 'หน้า',
  },

  htTable: {
    empty: 'ไม่มีข้อมูล',
    selectAll: 'เลือกทั้งหมด',
    deselectAll: 'ยกเลิกการเลือกทั้งหมด',
    expand: 'ขยาย',
    collapse: 'ยุบ',
    sort: 'เรียงลำดับ',
    filter: 'กรอง',
    reset: 'รีเซ็ต',
    confirm: 'ยืนยัน',
  },

  htCalendar: {
    title: 'ปฏิทิน',
    year: 'ปี',
    month: 'เดือน',
    today: 'วันนี้',
    confirm: 'ยืนยัน',
    cancel: 'ยกเลิก',
    weekdays: ['อา.', 'จ.', 'อ.', 'พ.', 'พฤ.', 'ศ.', 'ส.'],
    months: ['ม.ค.', 'ก.พ.', 'มี.ค.', 'เม.ย.', 'พ.ค.', 'มิ.ย.', 'ก.ค.', 'ส.ค.', 'ก.ย.', 'ต.ค.', 'พ.ย.', 'ธ.ค.'],
    rangePrompt: 'ช่วงวันที่ไม่สามารถเกิน {maxRange} วันได้',
    minRange: 'เลือกอย่างน้อย {minRange} วัน',
    maxRange: 'เลือกได้มากสุด {maxRange} วัน',
  },

  htSwipe: {
    previous: 'ก่อนหน้า',
    next: 'ถัดไป',
    indicator: '{current} / {total}',
  },

  htCollapse: {
    expand: 'ขยาย',
    collapse: 'ยุบ',
  },

  htBadge: {
    dot: 'ตัวบ่งชี้จุด',
    count: 'จำนวน',
  },

  htTag: {
    close: 'ปิดแท็ก',
  },

  htProgress: {
    percent: '{percent}%',
  },

  htSkeleton: {
    loading: 'กำลังโหลด...',
  },

  htAffix: {
    fixed: 'ตำแหน่งคงที่',
  },

  htBackTop: {
    tooltip: 'กลับด้านบน',
  },

  htAnchor: {
    copy: 'คัดลอกลิงก์',
    copied: 'คัดลอกแล้ว',
  },

  htBreadcrumb: {
    home: 'หน้าแรก',
  },

  htDivider: {
    text: 'ข้อความตัวแบ่ง',
  },

  htResult: {
    success: 'ดำเนินการสำเร็จ',
    error: 'ดำเนินการล้มเหลว',
    info: 'ข้อมูล',
    warning: 'คำเตือน',
    notFound: 'ไม่พบหน้า',
    unauthorized: 'ไม่ได้รับอนุญาต',
    forbidden: 'ปฏิเสธการเข้าถึง',
    serverError: 'ข้อผิดพลาดเซิร์ฟเวอร์',
  },

  htTypography: {
    copy: 'คัดลอก',
    copied: 'คัดลอกแล้ว',
    edit: 'แก้ไข',
    expand: 'ขยาย',
    collapse: 'ยุบ',
  },

  htAlert: {
    close: 'ปิด',
  },

  htMessage: {
    close: 'ปิด',
  },

  htNotification: {
    close: 'ปิด',
  },

  htPopconfirm: {
    title: 'ยืนยัน',
    confirm: 'ตกลง',
    cancel: 'ยกเลิก',
  },

  htTooltip: {
    empty: 'ไม่มีคำแนะนำเครื่องมือ',
  },

  htPopover: {
    close: 'ปิด',
  },

  htDropdown: {
    title: 'เมนูแบบหล่นลง',
  },
} as unknown as Message;
