import type { Message } from '../index';

// English (US) language pack
export default {
  // Common UI elements
  name: 'Name',
  tel: 'Phone',
  save: 'Save',
  clear: 'Clear',
  cancel: 'Cancel',
  confirm: 'Confirm',
  delete: 'Delete',
  loading: 'Loading...',
  more: 'Load More',
  noMore: 'No More',
  refresh: 'Refresh',
  done: 'Done',
  close: 'Close',
  search: 'Search',
  select: 'Select',
  upload: 'Upload',
  download: 'Download',
  edit: 'Edit',
  copy: 'Copy',
  share: 'Share',
  back: 'Back',
  next: 'Next',
  previous: 'Previous',
  submit: 'Submit',
  reset: 'Reset',
  tryAgain: 'Try Again',
  error: 'Error',
  success: 'Success',
  warning: 'Warning',
  info: 'Info',

  // Component-specific translations
  htLoading: {
    loading: 'Loading...',
    text: 'Loading...',
  },

  htList: {
    loadingText: 'Loading...',
    errorText: 'Request failed. Click to retry',
    finishedText: 'No more data',
    error: 'Request failed',
    tryAgain: 'Click to retry',
    noMore: 'No more data',
  },

  htPullRefresh: {
    pullingText: 'Pull to refresh...',
    loosingText: 'Release to refresh...',
    loadingText: 'Loading...',
    successText: 'Refresh successful',
    completeText: 'Refresh complete',
  },

  htEmpty: {
    description: 'No data',
    image: {
      alt: 'Empty state image',
    },
  },

  htModal: {
    close: 'Close',
    confirm: 'Confirm',
    cancel: 'Cancel',
  },

  htForm: {
    required: 'This field is required',
    invalid: 'Invalid input format',
    minLength: 'Input must be at least {min} characters',
    maxLength: 'Input cannot exceed {max} characters',
    email: 'Please enter a valid email address',
    phone: 'Please enter a valid phone number',
    url: 'Please enter a valid URL',
    number: 'Please enter a valid number',
    date: 'Please select a valid date',
    time: 'Please select a valid time',
    pattern: 'Input format is invalid',
    match: 'Inputs do not match',
  },

  htField: {
    clear: 'Clear',
    required: 'Required',
    optional: 'Optional',
    placeholder: 'Please enter',
    search: 'Search',
    wordLimit: '{count} characters remaining',
    wordLimitExceeded: 'Character limit exceeded',
  },

  htButton: {
    loading: 'Loading...',
    disabled: 'Disabled',
  },

  htToast: {
    success: 'Success',
    error: 'Error',
    loading: 'Loading...',
    warning: 'Warning',
    info: 'Info',
  },

  htDialog: {
    title: 'Confirm',
    message: 'Are you sure you want to perform this operation?',
    confirm: 'Confirm',
    cancel: 'Cancel',
  },

  htPicker: {
    confirm: 'Confirm',
    cancel: 'Cancel',
    title: 'Please select',
  },

  htDatePicker: {
    title: 'Select Date',
    year: 'Year',
    month: 'Month',
    day: 'Day',
    today: 'Today',
    confirm: 'Confirm',
    cancel: 'Cancel',
    weekdays: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
    months: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
  },

  htTimePicker: {
    title: 'Select Time',
    hour: 'Hour',
    minute: 'Minute',
    second: 'Second',
    confirm: 'Confirm',
    cancel: 'Cancel',
  },

  htStepper: {
    increase: 'Increase',
    decrease: 'Decrease',
    min: 'Cannot be less than minimum value',
    max: 'Cannot be greater than maximum value',
    integer: 'Please enter an integer',
  },

  htRate: {
    score: 'Rating',
  },

  htSteps: {
    step: 'Step',
    done: 'Completed',
    process: 'In Progress',
    wait: 'Waiting',
  },

  htTabBar: {
    home: 'Home',
    category: 'Category',
    cart: 'Cart',
    user: 'User',
    search: 'Search',
  },

  htImage: {
    loading: 'Loading image...',
    error: 'Failed to load image',
    preview: 'Preview image',
    zoom: 'Zoom in',
    zoomOut: 'Zoom out',
    rotate: 'Rotate',
    original: 'View original',
  },

  htSwitch: {
    on: 'On',
    off: 'Off',
  },

  htCheckbox: {
    checked: 'Checked',
    unchecked: 'Unchecked',
    all: 'Select All',
    none: 'Deselect All',
  },

  htRadio: {
    checked: 'Checked',
    unchecked: 'Unchecked',
  },

  htSelect: {
    placeholder: 'Please select',
    noData: 'No data',
    search: 'Search',
    clear: 'Clear',
  },

  htUpload: {
    uploading: 'Uploading...',
    uploadingText: 'Uploading {percent}%',
    success: 'Upload successful',
    error: 'Upload failed',
    preview: 'Preview',
    delete: 'Delete',
    retry: 'Retry',
    maxCount: 'Maximum {count} files can be uploaded',
    maxSize: 'File size cannot exceed {size}',
    fileType: 'File type not supported',
  },

  htPagination: {
    prev: 'Previous',
    next: 'Next',
    total: 'Total {total} items',
    page: 'Page {current} of {pages}',
    jumper: 'Go to',
    pageSize: 'items/page',
    totalPage: 'pages',
  },

  htTable: {
    empty: 'No data',
    selectAll: 'Select All',
    deselectAll: 'Deselect All',
    expand: 'Expand',
    collapse: 'Collapse',
    sort: 'Sort',
    filter: 'Filter',
    reset: 'Reset',
    confirm: 'Confirm',
  },

  htCalendar: {
    title: 'Calendar',
    year: 'Year',
    month: 'Month',
    today: 'Today',
    confirm: 'Confirm',
    cancel: 'Cancel',
    weekdays: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
    months: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
    rangePrompt: 'Date range cannot exceed {maxRange} days',
    minRange: 'Select at least {minRange} days',
    maxRange: 'Select at most {maxRange} days',
  },

  htSwipe: {
    previous: 'Previous',
    next: 'Next',
    indicator: '{current} / {total}',
  },

  htCollapse: {
    expand: 'Expand',
    collapse: 'Collapse',
  },

  htBadge: {
    dot: 'Dot indicator',
    count: 'Count',
  },

  htTag: {
    close: 'Close tag',
  },

  htProgress: {
    percent: '{percent}%',
  },

  htSkeleton: {
    loading: 'Loading...',
  },

  htAffix: {
    fixed: 'Fixed positioning',
  },

  htBackTop: {
    tooltip: 'Back to top',
  },

  htAnchor: {
    copy: 'Copy link',
    copied: 'Copied',
  },

  htBreadcrumb: {
    home: 'Home',
  },

  htDivider: {
    text: 'Divider text',
  },

  htResult: {
    success: 'Operation successful',
    error: 'Operation failed',
    info: 'Information',
    warning: 'Warning',
    notFound: 'Page not found',
    unauthorized: 'Unauthorized',
    forbidden: 'Access forbidden',
    serverError: 'Server error',
  },

  htTypography: {
    copy: 'Copy',
    copied: 'Copied',
    edit: 'Edit',
    expand: 'Expand',
    collapse: 'Collapse',
  },

  htAlert: {
    close: 'Close',
  },

  htMessage: {
    close: 'Close',
  },

  htNotification: {
    close: 'Close',
  },

  htPopconfirm: {
    title: 'Confirm',
    confirm: 'OK',
    cancel: 'Cancel',
  },

  htTooltip: {
    empty: 'No tooltip',
  },

  htPopover: {
    close: 'Close',
  },

  htDropdown: {
    title: 'Dropdown menu',
  },
} as unknown as Message;
