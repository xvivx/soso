import type { Message } from '../index';

// Japanese language pack
export default {
  // Common UI elements
  name: '名前',
  tel: '電話番号',
  save: '保存',
  clear: 'クリア',
  cancel: 'キャンセル',
  confirm: '確認',
  delete: '削除',
  loading: '読み込み中...',
  more: 'もっと読み込む',
  noMore: 'これ以上データがありません',
  refresh: '更新',
  done: '完了',
  close: '閉じる',
  search: '検索',
  select: '選択',
  upload: 'アップロード',
  download: 'ダウンロード',
  edit: '編集',
  copy: 'コピー',
  share: '共有',
  back: '戻る',
  next: '次へ',
  previous: '前へ',
  submit: '送信',
  reset: 'リセット',
  tryAgain: '再試行',
  error: 'エラー',
  success: '成功',
  warning: '警告',
  info: '情報',

  // Component-specific translations
  htLoading: {
    loading: '読み込み中...',
    text: '読み込み中...',
  },

  htList: {
    loadingText: '読み込み中...',
    errorText: '読み込みに失敗しました。クリックして再試行',
    finishedText: 'これ以上データがありません',
    error: '読み込みに失敗しました',
    tryAgain: 'クリックして再試行',
    noMore: 'これ以上データがありません',
  },

  htPullRefresh: {
    pullingText: '引っ張って更新...',
    loosingText: '離して更新...',
    loadingText: '更新中...',
    successText: '更新に成功しました',
    completeText: '更新が完了しました',
  },

  htEmpty: {
    description: 'データがありません',
    image: {
      alt: '空状態イメージ',
    },
  },

  htModal: {
    close: '閉じる',
    confirm: '確認',
    cancel: 'キャンセル',
  },

  htForm: {
    required: 'この項目は必須です',
    invalid: '無効な入力形式です',
    minLength: '入力は最低{min}文字必要です',
    maxLength: '入力は{max}文字を超えることはできません',
    email: '有効なメールアドレスを入力してください',
    phone: '有効な電話番号を入力してください',
    url: '有効なURLを入力してください',
    number: '有効な数値を入力してください',
    date: '有効な日付を選択してください',
    time: '有効な時刻を選択してください',
    pattern: '入力形式が無効です',
    match: '入力が一致しません',
  },

  htField: {
    clear: 'クリア',
    required: '必須',
    optional: '任意',
    placeholder: '入力してください',
    search: '検索',
    wordLimit: 'あと{count}文字',
    wordLimitExceeded: '文字数制限を超えました',
  },

  htButton: {
    loading: '読み込み中...',
    disabled: '無効',
  },

  htToast: {
    success: '成功',
    error: 'エラー',
    loading: '読み込み中...',
    warning: '警告',
    info: '情報',
  },

  htDialog: {
    title: '確認',
    message: 'この操作を実行してもよろしいですか？',
    confirm: '確認',
    cancel: 'キャンセル',
  },

  htPicker: {
    confirm: '確認',
    cancel: 'キャンセル',
    title: '選択してください',
  },

  htDatePicker: {
    title: '日付を選択',
    year: '年',
    month: '月',
    day: '日',
    today: '今日',
    confirm: '確認',
    cancel: 'キャンセル',
    weekdays: ['日', '月', '火', '水', '木', '金', '土'],
    months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  },

  htTimePicker: {
    title: '時刻を選択',
    hour: '時',
    minute: '分',
    second: '秒',
    confirm: '確認',
    cancel: 'キャンセル',
  },

  htStepper: {
    increase: '増加',
    decrease: '減少',
    min: '最小値より小さくすることはできません',
    max: '最大値より大きくすることはできません',
    integer: '整数を入力してください',
  },

  htRate: {
    score: '評価',
  },

  htSteps: {
    step: 'ステップ',
    done: '完了',
    process: '処理中',
    wait: '待機中',
  },

  htTabBar: {
    home: 'ホーム',
    category: 'カテゴリ',
    cart: 'カート',
    user: 'ユーザー',
    search: '検索',
  },

  htImage: {
    loading: '画像を読み込み中...',
    error: '画像の読み込みに失敗しました',
    preview: 'プレビュー',
    zoom: '拡大',
    zoomOut: '縮小',
    rotate: '回転',
    original: '元画像を表示',
  },

  htSwitch: {
    on: 'オン',
    off: 'オフ',
  },

  htCheckbox: {
    checked: '選択済み',
    unchecked: '未選択',
    all: 'すべて選択',
    none: 'すべて選択解除',
  },

  htRadio: {
    checked: '選択済み',
    unchecked: '未選択',
  },

  htSelect: {
    placeholder: '選択してください',
    noData: 'データがありません',
    search: '検索',
    clear: 'クリア',
  },

  htUpload: {
    uploading: 'アップロード中...',
    uploadingText: 'アップロード中 {percent}%',
    success: 'アップロード成功',
    error: 'アップロード失敗',
    preview: 'プレビュー',
    delete: '削除',
    retry: '再試行',
    maxCount: '最大{count}個のファイルをアップロードできます',
    maxSize: 'ファイルサイズは{size}を超えることはできません',
    fileType: 'サポートされていないファイル形式です',
  },

  htPagination: {
    prev: '前へ',
    next: '次へ',
    total: '合計{total}件',
    page: '{current} / {pages}ページ',
    jumper: '移動',
    pageSize: '件/ページ',
    totalPage: 'ページ',
  },

  htTable: {
    empty: 'データがありません',
    selectAll: 'すべて選択',
    deselectAll: 'すべて選択解除',
    expand: '展開',
    collapse: '折りたたみ',
    sort: 'ソート',
    filter: 'フィルタ',
    reset: 'リセット',
    confirm: '確認',
  },

  htCalendar: {
    title: 'カレンダー',
    year: '年',
    month: '月',
    today: '今日',
    confirm: '確認',
    cancel: 'キャンセル',
    weekdays: ['日', '月', '火', '水', '木', '金', '土'],
    months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
    rangePrompt: '日付範囲は{maxRange}日を超えることはできません',
    minRange: '最低{minRange}日選択してください',
    maxRange: '最大{maxRange}日選択してください',
  },

  htSwipe: {
    previous: '前へ',
    next: '次へ',
    indicator: '{current} / {total}',
  },

  htCollapse: {
    expand: '展開',
    collapse: '折りたたみ',
  },

  htBadge: {
    dot: 'ドットインジケーター',
    count: 'カウント',
  },

  htTag: {
    close: 'タグを閉じる',
  },

  htProgress: {
    percent: '{percent}%',
  },

  htSkeleton: {
    loading: '読み込み中...',
  },

  htAffix: {
    fixed: '固定位置',
  },

  htBackTop: {
    tooltip: 'トップに戻る',
  },

  htAnchor: {
    copy: 'リンクをコピー',
    copied: 'コピーしました',
  },

  htBreadcrumb: {
    home: 'ホーム',
  },

  htDivider: {
    text: '区切りテキスト',
  },

  htResult: {
    success: '操作が成功しました',
    error: '操作が失敗しました',
    info: '情報',
    warning: '警告',
    notFound: 'ページが見つかりません',
    unauthorized: '認証されていません',
    forbidden: 'アクセスが禁止されています',
    serverError: 'サーバーエラー',
  },

  htTypography: {
    copy: 'コピー',
    copied: 'コピーしました',
    edit: '編集',
    expand: '展開',
    collapse: '折りたたみ',
  },

  htAlert: {
    close: '閉じる',
  },

  htMessage: {
    close: '閉じる',
  },

  htNotification: {
    close: '閉じる',
  },

  htPopconfirm: {
    title: '確認',
    confirm: 'OK',
    cancel: 'キャンセル',
  },

  htTooltip: {
    empty: 'ツールチップがありません',
  },

  htPopover: {
    close: '閉じる',
  },

  htDropdown: {
    title: 'ドロップダウンメニュー',
  },
} as unknown as Message;
