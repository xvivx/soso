import type { Message } from '../index';

// Arabic (Saudi Arabia) language pack
export default {
  // Common UI elements
  name: 'الاسم',
  tel: 'الهاتف',
  save: 'حفظ',
  clear: 'مسح',
  cancel: 'إلغاء',
  confirm: 'تأكيد',
  delete: 'حذف',
  loading: 'جارٍ التحميل...',
  more: 'تحميل المزيد',
  noMore: 'لا توجد بيانات أخرى',
  refresh: 'تحديث',
  done: 'تم',
  close: 'إغلاق',
  search: 'بحث',
  select: 'اختيار',
  upload: 'رفع',
  download: 'تنزيل',
  edit: 'تحرير',
  copy: 'نسخ',
  share: 'مشاركة',
  back: 'رجوع',
  next: 'التالي',
  previous: 'السابق',
  submit: 'إرسال',
  reset: 'إعادة تعيين',
  tryAgain: 'محاولة مرة أخرى',
  error: 'خطأ',
  success: 'نجح',
  warning: 'تحذير',
  info: 'معلومات',

  // Component-specific translations
  htLoading: {
    loading: 'جارٍ التحميل...',
    text: 'جارٍ التحميل...',
  },

  htList: {
    loadingText: 'جارٍ التحميل...',
    errorText: 'فشل التحميل. انقر لإعادة المحاولة',
    finishedText: 'لا توجد بيانات أخرى',
    error: 'فشل التحميل',
    tryAgain: 'انقر لإعادة المحاولة',
    noMore: 'لا توجد بيانات أخرى',
  },

  htPullRefresh: {
    pullingText: 'اسحب للتحديث...',
    loosingText: 'اترك للتحديث...',
    loadingText: 'جارٍ التحديث...',
    successText: 'تم التحديث بنجاح',
    completeText: 'اكتمل التحديث',
  },

  htEmpty: {
    description: 'لا توجد بيانات',
    image: {
      alt: 'صورة الحالة الفارغة',
    },
  },

  htModal: {
    close: 'إغلاق',
    confirm: 'تأكيد',
    cancel: 'إلغاء',
  },

  htForm: {
    required: 'هذا الحقل مطلوب',
    invalid: 'تنسيق الإدخال غير صالح',
    minLength: 'يجب أن يحتوي الإدخال على {min} أحرف على الأقل',
    maxLength: 'لا يمكن أن يتجاوز الإدخال {max} حرفًا',
    email: 'يرجى إدخال عنوان بريد إلكتروني صالح',
    phone: 'يرجى إدخال رقم هاتف صالح',
    url: 'يرجى إدخال رابط صالح',
    number: 'يرجى إدخال رقم صالح',
    date: 'يرجى تحديد تاريخ صالح',
    time: 'يرجى تحديد وقت صالح',
    pattern: 'تنسيق الإدخال غير صالح',
    match: 'المدخلات لا تتطابق',
  },

  htField: {
    clear: 'مسح',
    required: 'مطلوب',
    optional: 'اختياري',
    placeholder: 'يرجى الإدخال',
    search: 'بحث',
    wordLimit: '{count} أحرف متبقية',
    wordLimitExceeded: 'تم تجاوز حد الأحرف',
  },

  htButton: {
    loading: 'جارٍ التحميل...',
    disabled: 'معطل',
  },

  htToast: {
    success: 'نجح',
    error: 'خطأ',
    loading: 'جارٍ التحميل...',
    warning: 'تحذير',
    info: 'معلومات',
  },

  htDialog: {
    title: 'تأكيد',
    message: 'هل أنت متأكد أنك تريد تنفيذ هذه العملية؟',
    confirm: 'تأكيد',
    cancel: 'إلغاء',
  },

  htPicker: {
    confirm: 'تأكيد',
    cancel: 'إلغاء',
    title: 'يرجى الاختيار',
  },

  htDatePicker: {
    title: 'اختيار التاريخ',
    year: 'سنة',
    month: 'شهر',
    day: 'يوم',
    today: 'اليوم',
    confirm: 'تأكيد',
    cancel: 'إلغاء',
    weekdays: ['الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'],
    months: [
      'يناير',
      'فبراير',
      'مارس',
      'أبريل',
      'مايو',
      'يونيو',
      'يوليو',
      'أغسطس',
      'سبتمبر',
      'أكتوبر',
      'نوفمبر',
      'ديسمبر',
    ],
  },

  htTimePicker: {
    title: 'اختيار الوقت',
    hour: 'ساعة',
    minute: 'دقيقة',
    second: 'ثانية',
    confirm: 'تأكيد',
    cancel: 'إلغاء',
  },

  htStepper: {
    increase: 'زيادة',
    decrease: 'نقصان',
    min: 'لا يمكن أن يكون أقل من القيمة الدنيا',
    max: 'لا يمكن أن يكون أكبر من القيمة القصوى',
    integer: 'يرجى إدخال عدد صحيح',
  },

  htRate: {
    score: 'تقييم',
  },

  htSteps: {
    step: 'خطوة',
    done: 'مكتمل',
    process: 'قيد التنفيذ',
    wait: 'في الانتظار',
  },

  htTabBar: {
    home: 'الرئيسية',
    category: 'الفئة',
    cart: 'عربة التسوق',
    user: 'المستخدم',
    search: 'بحث',
  },

  htImage: {
    loading: 'جارٍ تحميل الصورة...',
    error: 'فشل تحميل الصورة',
    preview: 'معاينة',
    zoom: 'تكبير',
    zoomOut: 'تصغير',
    rotate: 'دوران',
    original: 'عرض الأصلي',
  },

  htSwitch: {
    on: 'نعم',
    off: 'لا',
  },

  htCheckbox: {
    checked: 'محدد',
    unchecked: 'غير محدد',
    all: 'تحديد الكل',
    none: 'إلغاء تحديد الكل',
  },

  htRadio: {
    checked: 'محدد',
    unchecked: 'غير محدد',
  },

  htSelect: {
    placeholder: 'يرجى الاختيار',
    noData: 'لا توجد بيانات',
    search: 'بحث',
    clear: 'مسح',
  },

  htUpload: {
    uploading: 'جارٍ الرفع...',
    uploadingText: 'جارٍ الرفع {percent}%',
    success: 'تم الرفع بنجاح',
    error: 'فشل الرفع',
    preview: 'معاينة',
    delete: 'حذف',
    retry: 'إعادة المحاولة',
    maxCount: 'يمكن رفع أقصى {count} ملفات',
    maxSize: 'لا يمكن أن يتجاوز حجم الملف {size}',
    fileType: 'نوع الملف غير مدعوم',
  },

  htPagination: {
    prev: 'السابق',
    next: 'التالي',
    total: 'مجموع {total} عنصر',
    page: 'صفحة {current} من {pages}',
    jumper: 'الذهاب إلى',
    pageSize: 'عناصر/صفحة',
    totalPage: 'صفحات',
  },

  htTable: {
    empty: 'لا توجد بيانات',
    selectAll: 'تحديد الكل',
    deselectAll: 'إلغاء تحديد الكل',
    expand: 'توسيع',
    collapse: 'طي',
    sort: 'ترتيب',
    filter: 'تصفية',
    reset: 'إعادة تعيين',
    confirm: 'تأكيد',
  },

  htCalendar: {
    title: 'التقويم',
    year: 'سنة',
    month: 'شهر',
    today: 'اليوم',
    confirm: 'تأكيد',
    cancel: 'إلغاء',
    weekdays: ['الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'],
    months: [
      'يناير',
      'فبراير',
      'مارس',
      'أبريل',
      'مايو',
      'يونيو',
      'يوليو',
      'أغسطس',
      'سبتمبر',
      'أكتوبر',
      'نوفمبر',
      'ديسمبر',
    ],
    rangePrompt: 'لا يمكن أن يتجاوز نطاق التاريخ {maxRange} يومًا',
    minRange: 'اختر على الأقل {minRange} يومًا',
    maxRange: 'اختر على الأكثر {maxRange} يومًا',
  },

  htSwipe: {
    previous: 'السابق',
    next: 'التالي',
    indicator: '{current} / {total}',
  },

  htCollapse: {
    expand: 'توسيع',
    collapse: 'طي',
  },

  htBadge: {
    dot: 'مؤشر النقطة',
    count: 'العداد',
  },

  htTag: {
    close: 'إغلاق العلامة',
  },

  htProgress: {
    percent: '{percent}%',
  },

  htSkeleton: {
    loading: 'جارٍ التحميل...',
  },

  htAffix: {
    fixed: 'موضع ثابت',
  },

  htBackTop: {
    tooltip: 'العودة إلى الأعلى',
  },

  htAnchor: {
    copy: 'نسخ الرابط',
    copied: 'تم النسخ',
  },

  htBreadcrumb: {
    home: 'الرئيسية',
  },

  htDivider: {
    text: 'نص الفاصل',
  },

  htResult: {
    success: 'نجحت العملية',
    error: 'فشلت العملية',
    info: 'معلومات',
    warning: 'تحذير',
    notFound: 'الصفحة غير موجودة',
    unauthorized: 'غير مصرح',
    forbidden: 'ممنوع الوصول',
    serverError: 'خطأ في الخادم',
  },

  htTypography: {
    copy: 'نسخ',
    copied: 'تم النسخ',
    edit: 'تحرير',
    expand: 'توسيع',
    collapse: 'طي',
  },

  htAlert: {
    close: 'إغلاق',
  },

  htMessage: {
    close: 'إغلاق',
  },

  htNotification: {
    close: 'إغلاق',
  },

  htPopconfirm: {
    title: 'تأكيد',
    confirm: 'موافق',
    cancel: 'إلغاء',
  },

  htTooltip: {
    empty: 'لا توجد تلميح',
  },

  htPopover: {
    close: 'إغلاق',
  },

  htDropdown: {
    title: 'القائمة المنسدلة',
  },
} as unknown as Message;
