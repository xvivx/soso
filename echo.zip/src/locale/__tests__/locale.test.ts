import { beforeEach, describe, expect, it } from 'vitest';
import { Locale, useLocale } from '../index';
import { getFallbackChain, isRTLLanguage } from '../lang/metadata';

describe('Locale System', () => {
  beforeEach(() => {
    // Reset to default language before each test
    Locale.use('zh-CN');
  });

  describe('Basic Functionality', () => {
    it('should have default language zh-CN', () => {
      expect(Locale.lang).toBe('zh-CN');
    });

    it('should get messages for current language', () => {
      const messages = Locale.messages();
      expect(messages).toHaveProperty('htList');
      expect(messages).toHaveProperty('htLoading');
    });

    it('should switch languages', () => {
      Locale.use('en-US');
      expect(Locale.lang).toBe('en-US');

      const messages = Locale.messages();
      expect(messages).toHaveProperty('htList');
    });

    it('should get specific messages by key', () => {
      Locale.use('zh-CN');
      expect(Locale.message('htList.loadingText')).toBe('加载中...');
      expect(Locale.message('htLoading.loading')).toBe('加载中...');

      Locale.use('en-US');
      expect(Locale.message('htList.loadingText')).toBe('Loading...');
      expect(Locale.message('htLoading.loading')).toBe('Loading...');
    });

    it('should return fallback for missing keys', () => {
      expect(Locale.message('nonexistent.key', 'fallback')).toBe('fallback');
      expect(Locale.message('nonexistent.key')).toBe('nonexistent.key');
    });

    it('should handle custom message addition', () => {
      // Test that the add method doesn't throw errors
      expect(() => {
        Locale.add({
          'zh-CN': {
            custom: {
              test: '自定义测试',
            },
          },
        });
      }).not.toThrow();

      // Test that the add method is callable
      expect(typeof Locale.add).toBe('function');
    });
  });

  describe('Enhanced Features', () => {
    it('should provide language metadata', () => {
      const metadata = Locale.getMetadata('ar-SA');
      expect(metadata?.code).toBe('ar-SA');
      expect(metadata?.name).toBe('Arabic (Saudi Arabia)');
      expect(metadata?.rtl).toBe(true);
    });

    it('should check language availability', () => {
      expect(Locale.isAvailable('zh-CN')).toBe(true);
      expect(Locale.isAvailable('en-US')).toBe(true);
      expect(Locale.isAvailable('es-ES')).toBe(true);
      expect(Locale.isAvailable('nonexistent-lang')).toBe(false);
    });

    it('should get language family', () => {
      const family = Locale.getLanguageFamily('es-ES');
      expect(family).toBe('romance');

      const arabicFamily = Locale.getLanguageFamily('ar-SA');
      expect(arabicFamily).toBe('arabic');
    });

    it('should check RTL status', () => {
      expect(Locale.isRTL('ar-SA')).toBe(true);
      expect(Locale.isRTL('en-US')).toBe(false);
      expect(Locale.isRTL('zh-CN')).toBe(false);
    });

    it('should get available languages list', () => {
      const languages = Locale.getAvailableLanguages();
      expect(Array.isArray(languages)).toBe(true);
      expect(languages.length).toBeGreaterThan(0);

      const chineseLang = languages.find((lang) => lang.code === 'zh-CN');
      expect(chineseLang?.name).toBe('Chinese (Simplified)');
    });

    it('should get fallback chain', () => {
      const chain = Locale.getFallbackChain('es-ES');
      expect(Array.isArray(chain)).toBe(true);
      expect(chain).toContain('es-ES');
      expect(chain).toContain('en-US');
    });
  });

  describe('useLocale Composable', () => {
    it('should provide reactive language state', () => {
      const { lang, messages, t } = useLocale();

      expect(typeof lang.value).toBe('string');
      expect(typeof messages.value).toBe('object');
      expect(typeof t).toBe('function');

      expect(t('htList.loadingText')).toBe('加载中...');
    });

    it('should react to language changes', () => {
      const { lang, t } = useLocale();

      expect(lang.value).toBe('zh-CN');
      expect(t('htList.loadingText')).toBe('加载中...');

      Locale.use('en-US');
      expect(lang.value).toBe('en-US');
      expect(t('htList.loadingText')).toBe('Loading...');
    });

    it('should provide metadata reactively', () => {
      const { metadata, family, isRTL, availableLanguages, fallbackChain } = useLocale();

      expect(typeof metadata.value).toBe('object');
      expect(typeof family.value).toBe('string');
      expect(typeof isRTL.value).toBe('boolean');
      expect(Array.isArray(availableLanguages.value)).toBe(true);
      expect(Array.isArray(fallbackChain.value)).toBe(true);

      // Test RTL reactivity
      Locale.use('ar-SA');
      expect(isRTL.value).toBe(true);

      Locale.use('en-US');
      expect(isRTL.value).toBe(false);
    });

    it('should provide setLang function', () => {
      const { lang, setLang } = useLocale();

      expect(lang.value).toBe('zh-CN');

      setLang('es-ES');
      expect(lang.value).toBe('es-ES');
    });

    it('should provide addMessages function', () => {
      const { addMessages } = useLocale();

      expect(typeof addMessages).toBe('function');

      expect(() => {
        addMessages({
          'zh-CN': {
            customTest: '自定义测试',
          },
        });
      }).not.toThrow();
    });
  });

  describe('Fallback System', () => {
    it('should use fallback chain when message not found', () => {
      const fallbackChain = getFallbackChain('es-ES');
      expect(fallbackChain).toEqual(['es-ES', 'en-US']);
    });

    it('should handle empty fallback chain gracefully', () => {
      const emptyChain = getFallbackChain('nonexistent-lang');
      expect(emptyChain).toEqual(['zh-CN', 'en-US']);
    });
  });

  describe('Browser Detection', () => {
    it('should detect browser locale when available', () => {
      // Mock navigator.language
      const originalLanguage = global.navigator?.language;

      Object.defineProperty(global.navigator, 'language', {
        value: 'en-US',
        configurable: true,
      });

      const browserLocale = Locale.getBrowserLocale();
      expect(browserLocale).toBe('en-US');

      // Restore original
      if (originalLanguage) {
        Object.defineProperty(global.navigator, 'language', {
          value: originalLanguage,
          configurable: true,
        });
      }
    });

    it('should return null when navigator not available', () => {
      const originalNavigator = global.navigator;

      // @ts-expect-error - Intentionally deleting navigator property for testing
      delete global.navigator;

      const browserLocale = Locale.getBrowserLocale();
      expect(browserLocale).toBeNull();

      global.navigator = originalNavigator;
    });

    it('should auto-detect and set language', () => {
      const originalLanguage = global.navigator?.language;

      Object.defineProperty(global.navigator, 'language', {
        value: 'es-ES',
        configurable: true,
      });

      const detectedLanguage = Locale.autoDetect();
      expect(detectedLanguage).toBe('es-ES');
      expect(Locale.lang).toBe('es-ES');

      // Restore original
      if (originalLanguage) {
        Object.defineProperty(global.navigator, 'language', {
          value: originalLanguage,
          configurable: true,
        });
      }
    });
  });

  describe('Multiple Languages', () => {
    it('should support implemented European languages', () => {
      const europeanLanguages = ['es-ES', 'fr-FR', 'de-DE', 'it-IT', 'pt-PT', 'nl-NL', 'ru-RU'];

      europeanLanguages.forEach((langCode) => {
        expect(Locale.isAvailable(langCode)).toBe(true);

        Locale.use(langCode);
        expect(Locale.lang).toBe(langCode);

        // Test that basic keys exist
        expect(Locale.message('name')).toBeDefined();
        expect(Locale.message('save')).toBeDefined();
        expect(Locale.message('cancel')).toBeDefined();
        expect(Locale.message('htLoading.loading')).toBeDefined();
      });
    });

    it('should support implemented Asian languages', () => {
      const asianLanguages = ['ja-JP', 'ko-KR', 'th-TH', 'ar-SA'];

      asianLanguages.forEach((langCode) => {
        expect(Locale.isAvailable(langCode)).toBe(true);

        Locale.use(langCode);
        expect(Locale.lang).toBe(langCode);

        // Test that basic keys exist
        expect(Locale.message('name')).toBeDefined();
        expect(Locale.message('save')).toBeDefined();
        expect(Locale.message('htLoading.loading')).toBeDefined();
      });
    });

    it('should handle RTL languages correctly', () => {
      const rtlLanguages = ['ar-SA'];
      const ltrLanguages = ['zh-CN', 'en-US', 'es-ES', 'ja-JP'];

      rtlLanguages.forEach((langCode) => {
        expect(isRTLLanguage(langCode)).toBe(true);
        expect(Locale.isRTL(langCode)).toBe(true);
      });

      ltrLanguages.forEach((langCode) => {
        expect(isRTLLanguage(langCode)).toBe(false);
        expect(Locale.isRTL(langCode)).toBe(false);
      });
    });
  });

  describe('Component Integration', () => {
    it('should provide consistent structure across languages', () => {
      const languages = ['zh-CN', 'en-US', 'es-ES', 'ja-JP', 'ar-SA'];

      languages.forEach((langCode) => {
        Locale.use(langCode);

        // Check that all major component namespaces exist
        expect(Locale.message('htLoading')).toBeDefined();
        expect(Locale.message('htButton')).toBeDefined();
        expect(Locale.message('htForm')).toBeDefined();
        expect(Locale.message('htList')).toBeDefined();
        expect(Locale.message('htModal')).toBeDefined();
        expect(Locale.message('htToast')).toBeDefined();
      });
    });

    it('should handle nested keys correctly', () => {
      Locale.use('zh-CN');
      expect(Locale.message('htDatePicker.weekdays.0')).toBe('日');
      expect(Locale.message('htCalendar.weekdays.1')).toBe('一');

      Locale.use('en-US');
      expect(Locale.message('htDatePicker.weekdays.0')).toBe('Sun');
      expect(Locale.message('htCalendar.weekdays.1')).toBe('Mon');
    });

    it('should maintain component-specific terminology', () => {
      // Test loading terminology consistency in English
      Locale.use('en-US');
      const loadingTerms = [
        Locale.message('htLoading.loading'),
        Locale.message('htList.loadingText'),
        Locale.message('htPullRefresh.loadingText'),
      ];

      loadingTerms.forEach((term) => {
        expect(term).toBeDefined();
        expect(typeof term).toBe('string');
        expect(term.toLowerCase()).toContain('loading');
      });
    });
  });

  describe('Edge Cases', () => {
    it('should handle missing language files gracefully', () => {
      expect(() => {
        Locale.use('nonexistent-lang');
        const message = Locale.message('any.key', 'fallback');
        expect(message).toBe('fallback');
      }).not.toThrow();
    });

    it('should handle null and undefined values', () => {
      expect(() => {
        Locale.getMetadata(null as any);
        Locale.getMetadata(undefined as any);
        Locale.getLanguageFamily(null as any);
        Locale.getLanguageFamily(undefined as any);
      }).not.toThrow();
    });

    it('should handle empty string language codes', () => {
      expect(Locale.isAvailable('')).toBe(false);
      expect(() => Locale.use('')).not.toThrow();
    });

    it('should preserve default language on invalid language switch', () => {
      expect(() => Locale.use('invalid-lang-code')).not.toThrow();
      // Language should change to the invalid code but system should remain stable
      expect(typeof Locale.lang).toBe('string');
    });
  });

  describe('Message Content Quality', () => {
    it('should have non-empty translations for common keys', () => {
      const languages = ['zh-CN', 'en-US', 'es-ES'];
      const commonKeys = ['name', 'save', 'cancel', 'confirm', 'htLoading.loading'];

      languages.forEach((langCode) => {
        Locale.use(langCode);

        commonKeys.forEach((key) => {
          const message = Locale.message(key);
          expect(typeof message).toBe('string');
          expect(message.length).toBeGreaterThan(0);
        });
      });
    });

    it('should have consistent key structure across languages', () => {
      const languages = ['zh-CN', 'en-US', 'es-ES'];
      const componentKeys = ['htLoading', 'htButton', 'htForm', 'htList'];

      languages.forEach((langCode) => {
        Locale.use(langCode);

        componentKeys.forEach((componentKey) => {
          // Access the component messages directly from the messages object
          const messages = Locale.messages();
          const component = messages[componentKey as keyof typeof messages];
          expect(typeof component).toBe('object');
          expect(component).not.toBeNull();
        });
      });
    });
  });
});
