# HT-UI Internationalization (i18n) Documentation

## Overview

HT-UI provides comprehensive internationalization support for 40+ languages, with a robust fallback system, RTL language support, and extensive component coverage. The i18n system is designed to be developer-friendly while providing enterprise-grade localization capabilities.

## Supported Languages

### Primary Languages (100% Complete)
- 🇨🇳 **Chinese (Simplified)** - `zh-CN` (default)
- 🇹🇼 **Chinese (Traditional)** - `zh-TW`
- 🇭🇰 **Chinese (Hong Kong)** - `zh-HK`
- 🇺🇸 **English (US)** - `en-US`
- 🇬🇧 **English (UK)** - `en-GB`
- 🇯🇵 **Japanese** - `ja-JP`
- 🇰🇷 **Korean** - `ko-KR`

### European Languages (Currently Implemented)
- 🇪🇸 **Spanish** - `es-ES`
- 🇫🇷 **French** - `fr-FR`
- 🇩🇪 **German** - `de-DE`
- 🇮🇹 **Italian** - `it-IT`
- 🇵🇹 **Portuguese (Portugal)** - `pt-PT`
- 🇳🇱 **Dutch** - `nl-NL`
- 🇷🇺 **Russian** - `ru-RU`

### Asian & Middle Eastern Languages (Currently Implemented)
- 🇹🇭 **Thai** - `th-TH`
- 🇸🇦 **Arabic (Saudi Arabia)** - `ar-SA` (RTL)

### Additional Languages (Planned)
The following languages are fully defined in the metadata and will be implemented as needed:
- European: Portuguese (Brazil), Polish, Romanian, Swedish, Norwegian, Danish, Ukrainian, Greek, Bulgarian, Hungarian, Czech, Slovak, Finnish, Estonian, Latvian, Lithuanian
- Asian: Vietnamese, Indonesian, Hindi, Hebrew, Turkish, Kazakh, Mongolian, Khmer, Lao
- Additional: Bengali, Esperanto, Icelandic, Serbian, Slovenian

## Features

### 🔧 Smart Fallback System
- Intelligent fallback chains based on language families
- Regional variant support (e.g., `zh-TW` → `zh-CN`)
- Graceful degradation to English or Chinese as final fallback

### 🌐 RTL Language Support
- Full right-to-left language support
- Automatic RTL detection
- Proper text direction handling

### 📱 Component Coverage
- All HT-UI components have comprehensive translations
- Context-aware messaging
- Consistent terminology across components

### 🛠️ Developer Experience
- TypeScript-first implementation
- Autocomplete support for translation keys
- Hot module replacement support
- Browser language auto-detection

## Quick Start

### Basic Usage

```vue
<template>
  <div>
    <HTButton>{{ t('htButton.loading') }}</HTButton>
    <HTList :loading-text="t('htList.loadingText')" />
  </div>
</template>

<script setup>
import { useLocale } from 'ht-ui'

const { t, lang, setLang } = useLocale()

// Switch language
const switchToSpanish = () => {
  setLang('es-ES')
}

// Get current language
console.log(lang.value) // 'zh-CN' (default)
</script>
```

### Configuration

```typescript
import { Locale } from 'ht-ui'

// Manually set language
Locale.use('ja-JP')

// Add custom translations
Locale.add({
  'zh-CN': {
    customMessage: '自定义消息'
  }
})

// Get language metadata
const metadata = Locale.getMetadata('ar-SA')
console.log(metadata.rtl) // true
```

## API Reference

### useLocale Composable

```typescript
const {
  lang,              // Current language (ComputedRef<string>)
  messages,          // Current messages (ComputedRef<Message>)
  metadata,          // Current metadata (ComputedRef<LanguageMetadata>)
  family,            // Language family (ComputedRef<LanguageFamily>)
  isRTL,             // RTL status (ComputedRef<boolean>)
  availableLanguages, // All available languages (ComputedRef<LanguageMetadata[]>)
  fallbackChain,     // Fallback chain (ComputedRef<string[]>)
  t,                 // Translation function
  setLang,           // Set language
  addMessages        // Add custom messages
} = useLocale()
```

### Translation Function

```typescript
// Basic usage
t('htLoading.loading') // 'Loading...'

// With fallback
t('nonexistent.key', 'Default value')

// Interpolation (when supported)
t('htUpload.uploadingText', { percent: 50 }) // 'Uploading 50%'
```

### Locale System

```typescript
// Core methods
Locale.use('en-US')                    // Set language
Locale.add({ 'fr-FR': messages })      // Add messages
Locale.message('htButton.loading')     // Get message
Locale.messages()                       // Get all current messages
Locale.lang                             // Get current language

// Metadata methods
Locale.getMetadata('es-ES')            // Get language info
Locale.getLanguageFamily('es-ES')      // Get language family
Locale.isRTL('ar-SA')                   // Check RTL
Locale.getAvailableLanguages()          // Get all languages
Locale.getFallbackChain('es-ES')        // Get fallback chain

// Utility methods
Locale.isAvailable('pt-BR')             // Check if language exists
Locale.getBrowserLocale()               // Get browser language
Locale.autoDetect()                     // Auto-detect and set language
```

## Language Structure

### Message Object Structure

```typescript
interface Message {
  // Common UI elements
  name: string
  tel: string
  save: string
  clear: string
  cancel: string
  // ... more common elements

  // Component-specific translations
  htButton: HTButtonLocale
  htForm: HTFormLocale
  htList: HTListLocale
  // ... all component translations
}
```

### Language Metadata

```typescript
interface LanguageMetadata {
  code: string           // Language code (e.g., 'zh-CN')
  name: string           // English name (e.g., 'Chinese (Simplified)')
  nativeName: string     // Native name (e.g., '简体中文')
  region: string         // Region (e.g., 'China')
  rtl: boolean          // Right-to-left support
  completeness: 'complete' | 'partial' | 'minimal'
  contributors?: string[]
  lastUpdated?: string
}
```

### Language Families

- `chinese` - Chinese variants
- `english` - English variants
- `japanese` - Japanese
- `korean` - Korean
- `germanic` - German, Dutch, English
- `romance` - Spanish, French, Italian, Portuguese, Romanian
- `slavic` - Russian, Polish, Ukrainian, Czech, Slovak, Bulgarian, Serbian
- `nordic` - Swedish, Norwegian, Danish, Finnish, Icelandic
- `arabic` - Arabic
- `indian` - Hindi, Bengali
- `southeast-asian` - Thai, Vietnamese, Indonesian, Khmer, Lao
- `other` - Other languages

## Adding New Languages

### 1. Create Language File

Create a new file in `src/locale/lang/` following the pattern `{languageCode}-{countryCode}.ts`:

```typescript
// src/locale/lang/fr-FR.ts
import type { Message } from '../index'

export default {
  // Common UI elements
  name: 'Nom',
  save: 'Enregistrer',
  // ... all translations

  // Component translations
  htLoading: {
    loading: 'Chargement...',
    text: 'Chargement...',
  },
  // ... all component translations
} as unknown as Message
```

### 2. Add to Metadata

Update `src/locale/lang/metadata.ts`:

```typescript
export const LANGUAGE_METADATA: Record<string, LanguageMetadata> = {
  // ... existing languages
  'fr-FR': {
    code: 'fr-FR',
    name: 'French',
    nativeName: 'Français',
    region: 'France',
    rtl: false,
    completeness: 'complete',
  },
}

export const LANGUAGE_FAMILY_MAP: Record<string, LanguageFamily> = {
  // ... existing mappings
  'fr-FR': 'romance',
}

export const FALLBACK_CHAINS: Record<string, string[]> = {
  // ... existing chains
  'fr-FR': ['fr-FR', 'en-US'],
}
```

### 3. Update Main Index

Add imports and register the language in `src/locale/index.ts`:

```typescript
// Add import
import frFR from './lang/fr-FR'

// Add to messages object
const messages = reactive<Messages>({
  // ... existing languages
  'fr-FR': frFR,
})
```

## Component Integration

Components should use the `useLocale` composable for accessing translations:

```vue
<script setup>
import { useLocale } from 'ht-ui'

const { t } = useLocale()
</script>

<template>
  <div :class="{ 'rtl': isRTL }">
    {{ t('htComponent.message') }}
  </div>
</template>
```

## Testing

The locale system includes comprehensive test coverage:

```bash
# Run locale tests
pnpm test src/locale

# Run tests with coverage
pnpm test:coverage src/locale
```

## Best Practices

### 1. Translation Quality
- Use native speakers for translations
- Maintain consistent terminology
- Consider cultural context
- Test with real users when possible

### 2. Performance
- Load languages on-demand for large applications
- Use locale-specific code splitting
- Cache translations effectively

### 3. Maintenance
- Keep translations in sync with UI changes
- Regular review by native speakers
- Version control translation changes
- Document translation decisions

### 4. User Experience
- Respect user's browser language preference
- Provide language switcher in UI
- Store user's language preference
- Consider regional variants

## Troubleshooting

### Common Issues

**Missing Translations**
```typescript
// Check if key exists
const message = Locale.message('nonexistent.key', 'Default')
console.log(message) // 'Default'
```

**RTL Layout Issues**
```typescript
// Check RTL status
const { isRTL } = useLocale()
console.log(isRTL.value) // true for Arabic, Hebrew
```

**Language Not Loading**
```typescript
// Check if language is available
if (Locale.isAvailable('pt-BR')) {
  Locale.use('pt-BR')
}
```

### Debug Mode

Enable debug mode for detailed locale information:

```typescript
// Get detailed information
console.log('Current language:', Locale.lang)
console.log('Available languages:', Locale.getAvailableLanguages())
console.log('Fallback chain:', Locale.getFallbackChain(Locale.lang))
console.log('Metadata:', Locale.getMetadata())
```

## Contributing

When contributing translations:

1. **Quality**: Use native speakers or professional translators
2. **Consistency**: Follow existing terminology patterns
3. **Completeness**: Translate all keys, not just common ones
4. **Testing**: Test translations in actual components
5. **Documentation**: Document any cultural considerations

## Migration Guide

### From Vant

HT-UI's locale system is compatible with Vant's structure but with enhancements:

```typescript
// Vant style (still supported)
import { Locale } from 'vant'
Locale.use('en-US')

// HT-UI style (recommended)
import { Locale } from 'ht-ui'
Locale.use('en-US')

// Enhanced features available in HT-UI
const metadata = Locale.getMetadata('ar-SA')
const isRTL = Locale.isRTL()
const family = Locale.getLanguageFamily('es-ES')
```

## Legacy Integration Patterns

### Component Implementation

When implementing locale support in a component:

```vue
<script setup lang="ts">
import { useConfigProvider } from '../config-provider/useConfigProvider';

const { localeMessages } = useConfigProvider();

// Use locale text with fallback
const computedText = computed(() => {
  if (props.text) return props.text;
  return localeMessages.value?.htComponent?.messageKey || defaultText;
});
</script>
```

### TypeScript Support

The locale system provides comprehensive TypeScript support:

```typescript
import type { HTListLocale, LocaleInterface } from '@/components';

// Type-safe locale messages
const listMessages: HTListLocale = {
  loadingText: 'Loading...',
  errorText: 'Request failed',
  finishedText: 'No more data',
};

// Full locale interface
const fullLocale: LocaleInterface = {
  name: 'Name',
  htList: listMessages,
  // ... other component locales
};
```

## Message Key Format

Messages are organized hierarchically using dot notation:

```
htComponentName.messageKey
```

Example:
- `htList.loadingText` → Loading text for List component
- `htModal.confirm` → Confirm button text for Modal
- `htForm.required` → Required field validation message

## Supported Components

The following components have built-in locale support:

- **HTList**: `loadingText`, `errorText`, `finishedText`
- **HTLoading**: `loading`, `text`
- **HTPullRefresh**: `pullingText`, `loosingText`, `loadingText`, `successText`
- **HTEmpty**: `description`, `image.alt`
- **HTModal**: `close`, `confirm`, `cancel`
- **HTForm**: Form validation messages
- **HTField**: `clear`, `required`, `placeholder`, `wordLimit`
- **HTButton**: `loading`, `disabled`
- **HTToast**: `success`, `error`, `loading`, `warning`, `info`
- **HTDialog**: `title`, `message`, `confirm`, `cancel`
- **HTPicker**: `confirm`, `cancel`, `title`
- **HTDatePicker**: Calendar-specific translations
- **HTTimePicker**: Time picker translations
- **HTStepper**: `increase`, `decrease`, `min`, `max`, `integer`
- **HTRate**: `score`
- **HTSteps**: `step`, `done`, `process`, `wait`
- **HTTabBar**: Navigation item labels
- **HTImage**: `loading`, `error`, `preview`, `zoom`, `rotate`
- **HTSwitch**: `on`, `off`
- **HTCheckbox**: `checked`, `unchecked`, `all`, `none`
- **HTRadio**: `checked`, `unchecked`
- **HTSelect**: `placeholder`, `noData`, `search`, `clear`
- **HTUpload**: File upload messages
- **HTPagination**: Pagination controls
- **HTTable**: Table controls
- **HTCalendar**: Calendar interface
- **HTSwipe**: Swipe controls
- **HTCollapse**: Expand/collapse labels
- **HTBadge**: Badge descriptions
- **HTTag**: Tag controls
- **HTProgress**: Progress format
- **HTSkeleton**: Skeleton loading text
- **HTAffix**: Affix positioning text
- **HTBackTop**: Back to top tooltip
- **HTAnchor**: Link actions
- **HTBreadcrumb**: Navigation labels
- **HTDivider**: Divider text
- **HTResult**: Result page messages
- **HTTypography**: Text actions
- **HTAlert**: Alert controls
- **HTMessage**: Message controls
- **HTNotification**: Notification controls
- **HTPopconfirm**: Confirmation dialog
- **HTTooltip**: Tooltip text
- **HTPopover**: Popover controls
- **HTDropdown**: Dropdown menu

## Best Practices

1. **Always provide fallbacks**: When accessing locale messages, provide meaningful fallbacks
2. **Use computed properties**: Leverage Vue's reactivity for dynamic language switching
3. **Namespace components**: Use the `htComponentName` convention for component keys
4. **Consistent key naming**: Use camelCase for message keys
5. **Type safety**: Utilize the provided TypeScript interfaces for better development experience

## Migration from Hardcoded Text

If you have hardcoded text in your components:

1. Identify text that needs translation
2. Add keys to language files using the `htComponentName.messageKey` format
3. Update components to use `useConfigProvider` or `useLocale`
4. Provide appropriate fallbacks for backward compatibility

```typescript
// Before
const errorText = '加载失败，点击重试';

// After
const { localeMessages } = useConfigProvider();
const errorText = computed(() => {
  return props.errorText ||
         localeMessages.value?.htList?.errorText ||
         '加载失败，点击重试';
});
```

## Support

For locale-related issues:
- Check this documentation first
- Review existing language files for examples
- Test with the browser's developer tools
- Report issues with language code and specific key

---

## Changelog

### v1.0.0
- Initial release with 40+ language support
- Smart fallback system
- RTL language support
- Comprehensive component coverage
- TypeScript support
- Browser language auto-detection