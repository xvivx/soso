import type { ComputedRef } from 'vue';

// Base message type
export interface Message {
  [key: string]: string | number | boolean | Message | ((...args: any[]) => any) | any[] | Message[];
}

// Messages collection type
export type Messages = Record<string, Message>;

// Supported languages
export type SupportedLocale =
  // Primary languages
  | 'zh-CN'
  | 'zh-TW'
  | 'zh-HK'
  | 'en-US'
  | 'en-GB'
  | 'ja-JP'
  | 'ko-KR'

  // European languages
  | 'es-ES'
  | 'fr-FR'
  | 'de-DE'
  | 'it-IT'
  | 'pt-PT'
  | 'pt-BR'
  | 'nl-NL'
  | 'ru-RU'
  | 'pl-PL'
  | 'ro-RO'
  | 'sv-SE'
  | 'nb-NO'
  | 'da-DK'
  | 'uk-UA'
  | 'el-GR'
  | 'bg-BG'
  | 'hu-HU'
  | 'cs-CZ'
  | 'sk-SK'
  | 'fi-FI'
  | 'et-EE'
  | 'lv-LV'
  | 'lt-LT'

  // Asian and Middle Eastern languages
  | 'th-TH'
  | 'vi-VN'
  | 'id-ID'
  | 'hi-IN'
  | 'ar-SA'
  | 'he-IL'
  | 'tr-TR'
  | 'kk-KZ'
  | 'mn-MN'
  | 'kh-KH'
  | 'lo-LA'

  // Additional languages
  | 'bn-BD'
  | 'eo'
  | 'is-IS'
  | 'sr-RS'
  | 'sl-SI';

// Language metadata
export interface LanguageMetadata {
  code: string;
  name: string;
  nativeName: string;
  region: string;
  rtl: boolean;
  completeness: 'complete' | 'partial' | 'minimal';
  contributors?: string[];
  lastUpdated?: string;
}

// Language family groups
export type LanguageFamily =
  | 'chinese'
  | 'english'
  | 'japanese'
  | 'korean'
  | 'germanic'
  | 'romance'
  | 'slavic'
  | 'nordic'
  | 'arabic'
  | 'indian'
  | 'southeast-asian'
  | 'other';

// Enhanced locale interface with metadata
export interface LocaleInfo {
  messages: Message;
  metadata: LanguageMetadata;
  family: LanguageFamily;
}

// Component-specific locale interfaces
export interface HTLoadingLocale {
  loading: string;
  text: string;
}

export interface HTListLocale {
  loadingText: string;
  errorText: string;
  finishedText: string;
  error: string;
  tryAgain: string;
  noMore: string;
}

export interface HTPullRefreshLocale {
  pullingText: string;
  loosingText: string;
  loadingText: string;
  successText: string;
  completeText: string;
}

export interface HTEmptyLocale {
  description: string;
  image: {
    alt: string;
  };
}

export interface HTModalLocale {
  close: string;
  confirm: string;
  cancel: string;
}

export interface HTFormLocale {
  required: string;
  invalid: string;
  minLength: string;
  maxLength: string;
  email: string;
  phone: string;
  url: string;
  number: string;
  date: string;
  time: string;
  pattern: string;
  match: string;
}

export interface HTFieldLocale {
  clear: string;
  required: string;
  optional: string;
  placeholder: string;
  search: string;
  wordLimit: string;
  wordLimitExceeded: string;
}

export interface HTButtonLocale {
  loading: string;
  disabled: string;
}

export interface HTToastLocale {
  success: string;
  error: string;
  loading: string;
  warning: string;
  info: string;
}

export interface HTDialogLocale {
  title: string;
  message: string;
  confirm: string;
  cancel: string;
}

export interface HTPickerLocale {
  confirm: string;
  cancel: string;
  title: string;
}

export interface HTDatePickerLocale {
  title: string;
  year: string;
  month: string;
  day: string;
  today: string;
  confirm: string;
  cancel: string;
  weekdays: string[];
  months: string[];
}

export interface HTTimePickerLocale {
  title: string;
  hour: string;
  minute: string;
  second: string;
  confirm: string;
  cancel: string;
}

export interface HTStepperLocale {
  increase: string;
  decrease: string;
  min: string;
  max: string;
  integer: string;
}

export interface HTRateLocale {
  score: string;
}

export interface HTStepsLocale {
  step: string;
  done: string;
  process: string;
  wait: string;
}

export interface HTTabBarLocale {
  home: string;
  category: string;
  cart: string;
  user: string;
  search: string;
}

export interface HTImageLocale {
  loading: string;
  error: string;
  preview: string;
  zoom: string;
  zoomOut: string;
  rotate: string;
  original: string;
}

export interface HTSwitchLocale {
  on: string;
  off: string;
}

export interface HTCheckboxLocale {
  checked: string;
  unchecked: string;
  all: string;
  none: string;
}

export interface HTRadioLocale {
  checked: string;
  unchecked: string;
}

export interface HTSelectLocale {
  placeholder: string;
  noData: string;
  search: string;
  clear: string;
}

export interface HTUploadLocale {
  uploading: string;
  uploadingText: string;
  success: string;
  error: string;
  preview: string;
  delete: string;
  retry: string;
  maxCount: string;
  maxSize: string;
  fileType: string;
}

export interface HTPaginationLocale {
  prev: string;
  next: string;
  total: string;
  page: string;
  jumper: string;
  pageSize: string;
  totalPage: string;
}

export interface HTTableLocale {
  empty: string;
  selectAll: string;
  deselectAll: string;
  expand: string;
  collapse: string;
  sort: string;
  filter: string;
  reset: string;
  confirm: string;
}

export interface HTCalendarLocale {
  title: string;
  year: string;
  month: string;
  today: string;
  confirm: string;
  cancel: string;
  weekdays: string[];
  months: string[];
  rangePrompt: string;
  minRange: string;
  maxRange: string;
}

export interface HTSwipeLocale {
  previous: string;
  next: string;
  indicator: string;
}

export interface HTCollapseLocale {
  expand: string;
  collapse: string;
}

export interface HTBadgeLocale {
  dot: string;
  count: string;
}

export interface HTTagLocale {
  close: string;
}

export interface HTProgressLocale {
  percent: string;
}

export interface HTSkeletonLocale {
  loading: string;
}

export interface HTAffixLocale {
  fixed: string;
}

export interface HTBackTopLocale {
  tooltip: string;
}

export interface HTAnchorLocale {
  copy: string;
  copied: string;
}

export interface HTBreadcrumbLocale {
  home: string;
}

export interface HTDividerLocale {
  text: string;
}

export interface HTResultLocale {
  success: string;
  error: string;
  info: string;
  warning: string;
  notFound: string;
  unauthorized: string;
  forbidden: string;
  serverError: string;
}

export interface HTTypographyLocale {
  copy: string;
  copied: string;
  edit: string;
  expand: string;
  collapse: string;
}

export interface HTAlertLocale {
  close: string;
}

export interface HTMessageLocale {
  close: string;
}

export interface HTNotificationLocale {
  close: string;
}

export interface HTPopconfirmLocale {
  title: string;
  confirm: string;
  cancel: string;
}

export interface HTTooltipLocale {
  empty: string;
}

export interface HTPopoverLocale {
  close: string;
}

export interface HTDropdownLocale {
  title: string;
}

// Combined locale interface
export interface LocaleInterface {
  // Common UI elements
  name: string;
  tel: string;
  save: string;
  clear: string;
  cancel: string;
  confirm: string;
  delete: string;
  loading: string;
  more: string;
  noMore: string;
  refresh: string;
  done: string;
  close: string;
  search: string;
  select: string;
  upload: string;
  download: string;
  edit: string;
  copy: string;
  share: string;
  back: string;
  next: string;
  previous: string;
  submit: string;
  reset: string;
  tryAgain: string;
  error: string;
  success: string;
  warning: string;
  info: string;

  // Component-specific locales
  htLoading: HTLoadingLocale;
  htList: HTListLocale;
  htPullRefresh: HTPullRefreshLocale;
  htEmpty: HTEmptyLocale;
  htModal: HTModalLocale;
  htForm: HTFormLocale;
  htField: HTFieldLocale;
  htButton: HTButtonLocale;
  htToast: HTToastLocale;
  htDialog: HTDialogLocale;
  htPicker: HTPickerLocale;
  htDatePicker: HTDatePickerLocale;
  htTimePicker: HTTimePickerLocale;
  htStepper: HTStepperLocale;
  htRate: HTRateLocale;
  htSteps: HTStepsLocale;
  htTabBar: HTTabBarLocale;
  htImage: HTImageLocale;
  htSwitch: HTSwitchLocale;
  htCheckbox: HTCheckboxLocale;
  htRadio: HTRadioLocale;
  htSelect: HTSelectLocale;
  htUpload: HTUploadLocale;
  htPagination: HTPaginationLocale;
  htTable: HTTableLocale;
  htCalendar: HTCalendarLocale;
  htSwipe: HTSwipeLocale;
  htCollapse: HTCollapseLocale;
  htBadge: HTBadgeLocale;
  htTag: HTTagLocale;
  htProgress: HTProgressLocale;
  htSkeleton: HTSkeletonLocale;
  htAffix: HTAffixLocale;
  htBackTop: HTBackTopLocale;
  htAnchor: HTAnchorLocale;
  htBreadcrumb: HTBreadcrumbLocale;
  htDivider: HTDividerLocale;
  htResult: HTResultLocale;
  htTypography: HTTypographyLocale;
  htAlert: HTAlertLocale;
  htMessage: HTMessageLocale;
  htNotification: HTNotificationLocale;
  htPopconfirm: HTPopconfirmLocale;
  htTooltip: HTTooltipLocale;
  htPopover: HTPopoverLocale;
  htDropdown: HTDropdownLocale;
}

// Locale composable return type
export interface UseLocaleReturn {
  lang: ComputedRef<string>;
  messages: ComputedRef<Message>;
  t: (key: string, fallback?: string) => string;
  setLang: (newLang: string, newMessages?: Message) => void;
  addMessages: (newMessages: Messages) => void;

  // Enhanced reactive methods
  metadata: ComputedRef<LanguageMetadata | null>;
  family: ComputedRef<LanguageFamily | null>;
  isRTL: ComputedRef<boolean>;
  availableLanguages: ComputedRef<LanguageMetadata[]>;
  fallbackChain: ComputedRef<string[]>;
}

// Locale system interface
export interface LocaleSystem {
  lang: string;
  messages(): Message;
  use(newLang: string, newMessages?: Message): void;
  add(newMessages: Messages): void;
  message(key: string, fallback?: string): string;

  // Enhanced methods
  getMetadata(locale?: string): LanguageMetadata | null;
  getLanguageFamily(locale?: string): LanguageFamily | null;
  isRTL(locale?: string): boolean;
  getAvailableLanguages(): LanguageMetadata[];
  getFallbackChain(locale: string): string[];
}
