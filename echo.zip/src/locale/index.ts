import { computed, reactive, ref } from 'vue';
import { deepAssign } from '@/utils';
import arSA from './lang/ar-SA';
import deDE from './lang/de-DE';
import enUS from './lang/en-US';
// Import European languages (existing files only)
import esES from './lang/es-ES';
import frFR from './lang/fr-FR';
import itIT from './lang/it-IT';
// Import Asian languages (existing files only)
import jaJP from './lang/ja-JP';
import koKR from './lang/ko-KR';
import {
  getFallbackChain,
  getLanguageFamily as getLanguageFamilyFromMetadata,
  isRTLLanguage,
  LANGUAGE_METADATA,
} from './lang/metadata';
import nlNL from './lang/nl-NL';
import ptPT from './lang/pt-PT';
import ruRU from './lang/ru-RU';
import thTH from './lang/th-TH';
import zhCN from './lang/zh-CN';
// Note: Additional languages will be imported as they are created
// The following languages are defined in metadata but not yet implemented:
// pt-BR, pl-PL, ro-RO, sv-SE, nb-NO, da-DK, uk-UA, el-GR, bg-BG, hu-HU, cs-CZ, sk-SK, fi-FI, et-EE, lv-LV, lt-LT
// vi-VN, id-ID, hi-IN, he-IL, tr-TR, kk-KZ, mn-MN, kh-KH, lo-LA, bn-BD, eo, is-IS, sr-RS, sl-SI
// zh-TW, zh-HK, en-GB
import type {
  HTAffixLocale,
  HTAlertLocale,
  HTAnchorLocale,
  HTBackTopLocale,
  HTBadgeLocale,
  HTBreadcrumbLocale,
  HTButtonLocale,
  HTCalendarLocale,
  HTCheckboxLocale,
  HTCollapseLocale,
  HTDatePickerLocale,
  HTDialogLocale,
  HTDividerLocale,
  HTDropdownLocale,
  HTEmptyLocale,
  HTFieldLocale,
  HTFormLocale,
  HTImageLocale,
  HTListLocale,
  HTLoadingLocale,
  HTMessageLocale,
  HTModalLocale,
  HTNotificationLocale,
  HTPaginationLocale,
  HTPickerLocale,
  HTPopconfirmLocale,
  HTPopoverLocale,
  HTProgressLocale,
  HTPullRefreshLocale,
  HTRadioLocale,
  HTRateLocale,
  HTResultLocale,
  HTSelectLocale,
  HTSkeletonLocale,
  HTStepperLocale,
  HTStepsLocale,
  HTSwipeLocale,
  HTSwitchLocale,
  HTTabBarLocale,
  HTTableLocale,
  HTTagLocale,
  HTTimePickerLocale,
  HTToastLocale,
  HTTooltipLocale,
  HTTypographyLocale,
  HTUploadLocale,
  LanguageFamily,
  LanguageMetadata,
  Message,
  Messages,
  UseLocaleReturn,
} from './types';

// Re-export types and metadata
export type {
  Message,
  Messages,
  UseLocaleReturn,
  LanguageMetadata,
  LanguageFamily,
  HTLoadingLocale,
  HTListLocale,
  HTPullRefreshLocale,
  HTEmptyLocale,
  HTModalLocale,
  HTFormLocale,
  HTFieldLocale,
  HTButtonLocale,
  HTToastLocale,
  HTDialogLocale,
  HTPickerLocale,
  HTDatePickerLocale,
  HTTimePickerLocale,
  HTStepperLocale,
  HTRateLocale,
  HTStepsLocale,
  HTTabBarLocale,
  HTImageLocale,
  HTSwitchLocale,
  HTCheckboxLocale,
  HTRadioLocale,
  HTSelectLocale,
  HTUploadLocale,
  HTPaginationLocale,
  HTTableLocale,
  HTCalendarLocale,
  HTSwipeLocale,
  HTCollapseLocale,
  HTBadgeLocale,
  HTTagLocale,
  HTProgressLocale,
  HTSkeletonLocale,
  HTAffixLocale,
  HTBackTopLocale,
  HTAnchorLocale,
  HTBreadcrumbLocale,
  HTDividerLocale,
  HTResultLocale,
  HTTypographyLocale,
  HTAlertLocale,
  HTMessageLocale,
  HTNotificationLocale,
  HTPopconfirmLocale,
  HTTooltipLocale,
  HTPopoverLocale,
  HTDropdownLocale,
};

export { LANGUAGE_METADATA, getFallbackChain, isRTLLanguage, getLanguageFamilyFromMetadata as getLanguageFamily };

// Current language state
const lang = ref<string>('zh-CN');

// Available messages
const messages = reactive<Messages>({
  // Primary languages
  'zh-CN': zhCN,
  'en-US': enUS,

  // European languages (existing files only)
  'es-ES': esES,
  'fr-FR': frFR,
  'de-DE': deDE,
  'it-IT': itIT,
  'pt-PT': ptPT,
  'nl-NL': nlNL,
  'ru-RU': ruRU,

  // Asian languages (existing files only)
  'ja-JP': jaJP,
  'ko-KR': koKR,
  'th-TH': thTH,
  'ar-SA': arSA,

  // Note: Additional languages will be added as they are created
});

// Enhanced message resolution with fallback chains
function getMessageFromChain(key: string, locale: string, fallback?: string): string {
  const chain = getFallbackChain(locale);

  for (const langCode of chain) {
    if (messages[langCode]) {
      const value = getMessageFromLocale(key, messages[langCode]);
      if (typeof value === 'string' && value !== key) {
        return value;
      }
    }
  }

  return fallback !== undefined ? fallback : key;
}

function getMessageFromLocale(key: string, localeMessages: Message): string {
  const keys = key.split('.');
  let value: any = localeMessages;

  for (const k of keys) {
    if (value && typeof value === 'object' && k in value) {
      value = value[k];
    } else {
      return key;
    }
  }

  // Return the found value if it's a string, otherwise return the key
  return typeof value === 'string' ? value : key;
}

// Main locale system
export const Locale = {
  /**
   * Get current language
   */
  get lang(): string {
    return lang.value;
  },

  /**
   * Get messages for current language
   */
  messages(): Message {
    return messages[lang.value] || (messages['zh-CN'] as Message);
  },

  /**
   * Use a specific language
   */
  use(newLang: string, newMessages?: Message) {
    lang.value = newLang;
    if (newMessages) {
      this.add({ [newLang]: newMessages });
    }
  },

  /**
   * Add or merge messages for languages
   */
  add(newMessages: Messages = {}) {
    deepAssign(messages, newMessages);
  },

  /**
   * Get a specific message by key with fallback chain support
   * @returns Returns the translated string or fallback
   */
  message(key: string, fallback?: string): string {
    return getMessageFromChain(key, lang.value, fallback);
  },

  /**
   * Get metadata for a specific language
   */
  getMetadata(locale?: string): LanguageMetadata | null {
    const targetLocale = locale || lang.value;
    return LANGUAGE_METADATA[targetLocale] || null;
  },

  /**
   * Get language family for a specific language
   */
  getLanguageFamily(locale?: string): LanguageFamily | null {
    const targetLocale = locale || lang.value;
    return getLanguageFamilyFromMetadata(targetLocale) || null;
  },

  /**
   * Check if a language is RTL
   */
  isRTL(locale?: string): boolean {
    const targetLocale = locale || lang.value;
    return isRTLLanguage(targetLocale);
  },

  /**
   * Get list of available languages with metadata
   */
  getAvailableLanguages(): LanguageMetadata[] {
    return Object.values(LANGUAGE_METADATA);
  },

  /**
   * Get fallback chain for a specific language
   */
  getFallbackChain(locale: string): string[] {
    return getFallbackChain(locale);
  },

  /**
   * Check if a language is available
   */
  isAvailable(locale: string): boolean {
    return locale in LANGUAGE_METADATA;
  },

  /**
   * Get language code from browser locale
   */
  getBrowserLocale(): string | null {
    if (typeof navigator === 'undefined') return null;

    const browserLang = navigator.language || navigator.languages?.[0];
    if (!browserLang) return null;

    // Try exact match first
    if (this.isAvailable(browserLang)) {
      return browserLang;
    }

    // Try language part only (e.g., 'en' from 'en-US')
    const langPart = browserLang.split('-')[0];
    const matchingLang = Object.keys(LANGUAGE_METADATA).find((code) => code.startsWith(langPart + '-'));

    return matchingLang || null;
  },

  /**
   * Auto-detect and set best matching language
   */
  autoDetect(): string {
    const browserLocale = this.getBrowserLocale();
    if (browserLocale) {
      this.use(browserLocale);
      return browserLocale;
    }

    // Fall back to Chinese or English based on user preference
    this.use('zh-CN');
    return 'zh-CN';
  },
};

// Composable for reactive locale access
export function useLocale(): UseLocaleReturn {
  const currentLang = computed(() => lang.value);
  const currentMessages = computed(() => Locale.messages());
  const currentMetadata = computed(() => Locale.getMetadata());
  const currentFamily = computed(() => getLanguageFamilyFromMetadata(lang.value));
  const currentRTL = computed(() => Locale.isRTL());
  const availableLanguages = computed(() => Locale.getAvailableLanguages());
  const currentFallbackChain = computed(() => Locale.getFallbackChain(lang.value));

  const t = (key: string, fallback?: string) => {
    return Locale.message(key, fallback);
  };

  return {
    lang: currentLang,
    messages: currentMessages,
    t,
    setLang: Locale.use,
    addMessages: Locale.add,
    metadata: currentMetadata,
    family: currentFamily,
    isRTL: currentRTL,
    availableLanguages,
    fallbackChain: currentFallbackChain,
  };
}

// Export for direct access
export default Locale;
