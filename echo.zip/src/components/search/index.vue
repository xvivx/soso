<script setup lang="ts">
import { computed, ref, useSlots } from 'vue';
import { HTField } from '@/components/field';
import { searchProps } from './props';

defineOptions({ name: 'HTSearch' });

const props = defineProps(searchProps);
const emit = defineEmits(['update:modelValue', 'search', 'clear', 'focus', 'blur', 'input', 'cancel']);
const slots = useSlots();
const inputValue = ref(props.modelValue);

const onInput = (val: string) => {
  inputValue.value = val;
  emit('update:modelValue', val);
  emit('input', val);
};
const onSearch = () => {
  emit('search', inputValue.value);
};
const onClear = () => {
  inputValue.value = '';
  emit('update:modelValue', '');
  emit('clear');
};
const onCancel = () => {
  inputValue.value = '';
  emit('update:modelValue', '');
  emit('cancel');
};
const onFocus = (e: FocusEvent) => emit('focus', e);
const onBlur = (e: FocusEvent) => emit('blur', e);

const showAction = computed(() => props.showAction);
const background = computed(() => props.background);
</script>
<template>
  <div class="ht-search" :style="{ background: background }">
    <HTField
      v-model="inputValue"
      type="search"
      :left-icon="props.leftIcon"
      :right-icon="props.rightIcon"
      :clearable="props.clearable"
      :maxlength="props.maxlength"
      :placeholder="props.placeholder"
      :disabled="props.disabled"
      :readonly="props.readonly"
      :autofocus="props.autofocus"
      :input-align="props.inputAlign as any"
      @update:modelValue="onInput"
      @focus="onFocus"
      @blur="onBlur"
      @clear="onClear"
      @keypress.enter="onSearch"
    >
      <template v-if="slots.left" #left>
        <slot name="left" />
      </template>
      <template v-if="slots.right" #right>
        <slot name="right" />
      </template>
    </HTField>
    <slot name="active">
      <button v-if="showAction" class="ht-search__action" type="button" @click="onCancel">
        {{ props.actionText }}
      </button>
    </slot>
  </div>
</template>
<style>
@import url('./styles/index.css');
</style>
