export { default as HTSearch } from './index.vue';
export type { SearchProps } from './props';
