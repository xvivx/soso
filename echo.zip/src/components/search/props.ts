import type { ExtractPropTypes } from 'vue';
import { fieldSharedProps } from '../field/props';

// Vant4 Search 组件 API 补充属性
export const searchProps = {
  ...fieldSharedProps,
  background: {
    type: String,
    default: 'transparent',
  },
  showAction: {
    type: Boolean,
    default: false,
  },
  actionText: {
    type: String,
    default: 'Cancel',
  },
  placeholder: {
    type: String,
    default: '搜索',
  },
  label: String,
  leftIcon: {
    type: String,
    default: '',
  },
  rightIcon: String,
  clearable: {
    type: Boolean,
    default: true,
  },
  maxlength: Number,
  disabled: Boolean,
  readonly: Boolean,
  autofocus: Boolean,
  inputAlign: String as any,
  modelValue: {
    type: String,
    default: '',
  },
};

// 导出类型供外部使用（例如 TS 组件包装或泛型推导）。
export type SearchProps = ExtractPropTypes<typeof searchProps>;
