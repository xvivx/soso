import { nextTick } from 'vue';
import { mount, VueWrapper } from '@vue/test-utils';
import { useIntersectionObserver } from '@vueuse/core';
import { beforeEach, describe, expect, it, Mock, vi } from 'vitest';
import HTImage from '../index.vue';

// Mock @vueuse/core
vi.mock('@vueuse/core');

// Mock IntersectionObserver
const mockIntersectionObserver = vi.fn();
mockIntersectionObserver.mockReturnValue({
  observe: () => null,
  disconnect: () => null,
  unobserve: () => null,
});

vi.stubGlobal('IntersectionObserver', mockIntersectionObserver);

const mockUseIntersectionObserver = vi.mocked(useIntersectionObserver);

describe('HTImage Lazy Loading', () => {
  let wrapper: VueWrapper<InstanceType<typeof HTImage>>;
  let triggerIntersect: Mock<(entries: IntersectionObserverEntry[]) => void>;

  beforeEach(() => {
    // Reset mocks
    mockIntersectionObserver.mockClear();
    mockUseIntersectionObserver.mockClear();

    // Setup intersection observer mock
    triggerIntersect = vi.fn();

    mockUseIntersectionObserver.mockImplementation((target, callback) => {
      triggerIntersect = vi.fn((entries: IntersectionObserverEntry[], observer: IntersectionObserver) =>
        callback(entries, observer)
      );
      return {
        stop: vi.fn(),
        start: vi.fn(),
        isSupported: { value: true } as unknown as ComputedRef<boolean>,
        isActive: { value: true } as unknown as ComputedRef<boolean>,
        pause: vi.fn(),
        resume: vi.fn(),
      };
    });
  });

  describe('Lazy loading with IntersectionObserver', () => {
    it('应该在启用懒加载时创建IntersectionObserver', async () => {
      wrapper = mount(HTImage, {
        props: {
          src: 'https://example.com/test.jpg',
          lazyLoad: true,
        },
      });

      await nextTick();

      expect(mockUseIntersectionObserver).toHaveBeenCalledTimes(1);
    });

    it('应该在禁用懒加载时不创建IntersectionObserver', () => {
      wrapper = mount(HTImage, {
        props: {
          src: 'https://example.com/test.jpg',
          lazyLoad: false,
        },
      });

      expect(mockUseIntersectionObserver).toHaveBeenCalledTimes(0);
    });

    it('懒加载时图片src应该为空', () => {
      wrapper = mount(HTImage, {
        props: {
          src: 'https://example.com/test.jpg',
          lazyLoad: true,
        },
      });

      const imgElement = wrapper.find('img');
      expect(imgElement.attributes('src')).toBe('');
    });

    it('当元素进入视口时应该触发加载', async () => {
      wrapper = mount(HTImage, {
        props: {
          src: 'https://example.com/test.jpg',
          lazyLoad: true,
        },
      });

      await nextTick();

      // Initially should not be loading
      expect(wrapper.vm.loading).toBe(false);

      // Simulate intersection
      const mockEntry = { isIntersecting: true } as IntersectionObserverEntry;
      triggerIntersect([mockEntry]);

      await nextTick();

      expect(wrapper.vm.loading).toBe(true);
    });

    it('当元素离开视口时不应该触发加载', async () => {
      wrapper = mount(HTImage, {
        props: {
          src: 'https://example.com/test.jpg',
          lazyLoad: true,
        },
      });

      const loadSpy = vi.spyOn(wrapper.vm, 'load');

      // Simulate not intersecting
      const mockEntry = { isIntersecting: false } as IntersectionObserverEntry;
      triggerIntersect([mockEntry]);

      await nextTick();

      expect(loadSpy).not.toHaveBeenCalled();
    });

    it('加载完成后应该设置正确的src', async () => {
      wrapper = mount(HTImage, {
        props: {
          src: 'https://example.com/test.jpg',
          lazyLoad: true,
        },
      });

      await nextTick();

      // Simulate intersection and loading
      const mockEntry = { isIntersecting: true } as IntersectionObserverEntry;
      triggerIntersect([mockEntry]);

      await nextTick();

      // Simulate load completion by triggering load event
      const imgElement = wrapper.find('img');
      await imgElement.trigger('load');

      expect(imgElement.attributes('src')).toBe('https://example.com/test.jpg');
    });

    it('应该显示懒加载占位符当未加载时', () => {
      wrapper = mount(HTImage, {
        props: {
          src: 'https://example.com/test.jpg',
          lazyLoad: true,
        },
      });

      expect(wrapper.find('.ht-image__lazy-placeholder').exists()).toBe(true);
    });

    it('加载完成后应该隐藏占位符', async () => {
      wrapper = mount(HTImage, {
        props: {
          src: 'https://example.com/test.jpg',
          lazyLoad: true,
        },
      });

      await nextTick();

      // First trigger intersection to start loading
      const mockEntry = { isIntersecting: true } as IntersectionObserverEntry;
      triggerIntersect([mockEntry]);

      await nextTick();

      // Then simulate loading completion by triggering load event
      const imgElement = wrapper.find('img');
      await imgElement.trigger('load');

      await nextTick();

      expect(wrapper.find('.ht-image__lazy-placeholder').exists()).toBe(false);
    });
  });
});
