import { nextTick } from 'vue';
import { mount, VueWrapper } from '@vue/test-utils';
import { useIntersectionObserver } from '@vueuse/core';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import HTImage from '../index.vue';

// Mock @vueuse/core
vi.mock('@vueuse/core');

// Mock the img element
const mockImage = {
  src: '',
  onload: null as EventListener | null,
  onerror: null as EventListener | null,
  complete: false,
};

// Mock HTMLImageElement
global.Image = vi.fn(() => mockImage) as unknown as typeof Image;

// Mock useIntersectionObserver
const mockUseIntersectionObserver = vi.mocked(useIntersectionObserver);

describe('HTImage', () => {
  let wrapper: VueWrapper<InstanceType<typeof HTImage>>;

  beforeEach(() => {
    wrapper = mount(HTImage, {
      props: {
        src: 'https://example.com/test.jpg',
        alt: 'Test Image',
      },
    });
  });

  describe('基础渲染', () => {
    it('应该正确渲染默认图片组件', () => {
      const imageContainer = wrapper.find('.ht-image');
      expect(imageContainer.exists()).toBe(true);
      // Note: default variant doesn't add a class, so we just check the base class
      expect(imageContainer.classes()).toContain('ht-image');
    });

    it('应该应用正确的CSS类名', () => {
      expect(wrapper.find('.ht-image').exists()).toBe(true);
      expect(wrapper.find('.ht-image__img').exists()).toBe(true);
    });

    it('应该渲染图片元素', () => {
      const imgElement = wrapper.find('img');
      expect(imgElement.exists()).toBe(true);
      expect(imgElement.attributes('src')).toBe('https://example.com/test.jpg');
      expect(imgElement.attributes('alt')).toBe('Test Image');
    });
  });

  describe('Props 测试', () => {
    it('应该正确应用width和height属性', async () => {
      await wrapper.setProps({
        width: 200,
        height: 150,
      });

      const imageContainer = wrapper.find('.ht-image');
      expect(imageContainer.attributes('style')).toContain('width: 200px');
      expect(imageContainer.attributes('style')).toContain('height: 150px');
    });

    it('应该正确应用fit属性', async () => {
      await wrapper.setProps({ fit: 'cover' });

      const imgElement = wrapper.find('img');
      expect(imgElement.attributes('style')).toContain('object-fit: cover');
    });

    it('应该正确应用position属性', async () => {
      await wrapper.setProps({ position: 'top' });

      expect(wrapper.find('.ht-image--position-top').exists()).toBe(true);
    });

    it('应该正确应用radius属性', async () => {
      await wrapper.setProps({ radius: 8 });

      const imageContainer = wrapper.find('.ht-image');
      expect(imageContainer.attributes('style')).toContain('border-radius: 8px');
    });

    it('应该正确应用block属性', async () => {
      await wrapper.setProps({ block: true });

      expect(wrapper.find('.ht-image--block').exists()).toBe(true);
    });

    it('应该正确应用round属性', async () => {
      await wrapper.setProps({ round: true });

      expect(wrapper.find('.ht-image--round').exists()).toBe(true);
    });
  });

  describe('Variant 测试', () => {
    it('应该正确应用rounded变体', async () => {
      await wrapper.setProps({ variant: 'rounded' });

      expect(wrapper.find('.ht-image--rounded').exists()).toBe(true);
    });

    it('应该正确应用circle变体', async () => {
      await wrapper.setProps({ variant: 'circle' });

      expect(wrapper.find('.ht-image--circle').exists()).toBe(true);
    });

    it('应该正确应用cover变体', async () => {
      await wrapper.setProps({ variant: 'cover' });

      expect(wrapper.find('.ht-image--cover').exists()).toBe(true);
    });
  });

  describe('加载状态测试', () => {
    it('应该显示加载状态', async () => {
      const loadingWrapper = mount(HTImage, {
        props: {
          src: 'https://example.com/loading.jpg',
          showLoading: true,
        },
      });

      // Initially should be in loading state
      expect(loadingWrapper.vm.loading).toBe(true);
      expect(loadingWrapper.find('.ht-image__loading').exists()).toBe(true);
      expect(loadingWrapper.find('.ht-image--loading').exists()).toBe(true);
    });

    it('应该支持自定义加载插槽', async () => {
      const loadingWrapper = mount(HTImage, {
        props: {
          src: 'https://example.com/loading.jpg',
          showLoading: true,
        },
        slots: {
          loading: '<div class="custom-loading">Loading...</div>',
        },
      });

      expect(loadingWrapper.find('.custom-loading').exists()).toBe(true);
    });

    it('加载成功后应该隐藏加载状态', async () => {
      const loadingWrapper = mount(HTImage, {
        props: {
          src: 'https://example.com/success.jpg',
          showLoading: true,
        },
      });

      // Initially should be loading
      expect(loadingWrapper.vm.loading).toBe(true);

      // Simulate successful load by calling the handler directly
      const imgElement = loadingWrapper.find('img').element as HTMLImageElement;
      const loadEvent = new Event('load');
      Object.defineProperty(imgElement, 'onload', {
        value: loadEvent,
        writable: true,
      });

      // Trigger load event
      await loadingWrapper.find('img').trigger('load');
      await nextTick();

      expect(loadingWrapper.vm.loading).toBe(false);
      expect(loadingWrapper.vm.loaded).toBe(true);
      expect(loadingWrapper.find('.ht-image__loading').exists()).toBe(false);
      expect(loadingWrapper.find('.ht-image--loaded').exists()).toBe(true);
    });
  });

  describe('错误状态测试', () => {
    it('应该显示错误状态', async () => {
      const errorWrapper = mount(HTImage, {
        props: {
          src: 'invalid-url',
          showError: true,
        },
      });

      // Simulate error by triggering error event
      await errorWrapper.find('img').trigger('error');
      await nextTick();

      expect(errorWrapper.vm.error).toBe(true);
      expect(errorWrapper.find('.ht-image__error').exists()).toBe(true);
      // Note: img element is hidden when error occurs, so we check it doesn't exist
      expect(errorWrapper.find('img').exists()).toBe(false);
    });

    it('应该支持自定义错误插槽', async () => {
      const errorWrapper = mount(HTImage, {
        props: { src: 'invalid-url', showError: true },
        slots: {
          error: '<div class="custom-error">Failed to load</div>',
        },
      });

      // Simulate error by triggering error event
      await errorWrapper.find('img').trigger('error');
      await nextTick();

      expect(errorWrapper.find('.custom-error').exists()).toBe(true);
    });

    it('不应该显示错误状态当showError为false时', async () => {
      const errorWrapper = mount(HTImage, {
        props: {
          src: 'invalid-url',
          showError: false,
        },
      });

      // Simulate error by triggering error event
      await errorWrapper.find('img').trigger('error');
      await nextTick();

      expect(errorWrapper.vm.error).toBe(true);
      expect(errorWrapper.find('.ht-image__error').exists()).toBe(false);
    });
  });

  describe('懒加载测试', () => {
    beforeEach(() => {
      // Reset mock before each test
      mockUseIntersectionObserver.mockReset();
    });

    it('懒加载时不应立即设置src', async () => {
      const lazyWrapper = mount(HTImage, {
        props: {
          src: 'https://example.com/lazy.jpg',
          lazyLoad: true,
        },
      });

      const imgElement = lazyWrapper.find('img');
      expect(imgElement.attributes('src')).toBe('');
    });

    it('懒加载应该在加载后设置src', async () => {
      let intersectionCallback: ((entries: IntersectionObserverEntry[]) => void) | null = null;

      mockUseIntersectionObserver.mockImplementation((target, callback) => {
        intersectionCallback = callback;
        return {
          stop: vi.fn(),
          start: vi.fn(),
        };
      });

      const lazyWrapper = mount(HTImage, {
        props: {
          src: 'https://example.com/lazy.jpg',
          lazyLoad: true,
        },
      });

      // Simulate intersection (element comes into view)
      if (intersectionCallback) {
        const mockEntry = {
          isIntersecting: true,
        } as IntersectionObserverEntry;
        intersectionCallback([mockEntry]);
      }

      await nextTick();

      const imgElement = lazyWrapper.find('img');
      expect(imgElement.attributes('src')).toBe('https://example.com/lazy.jpg');
    });
  });

  describe('事件测试', () => {
    it('应该触发load事件', async () => {
      const eventWrapper = mount(HTImage, {
        props: {
          src: 'https://example.com/test.jpg',
        },
      });

      await eventWrapper.find('img').trigger('load');
      await nextTick();

      expect(eventWrapper.emitted('load')).toBeTruthy();
      expect(eventWrapper.emitted('load')?.[0]?.[0]).toBeInstanceOf(Event);
    });

    it('应该触发error事件', async () => {
      const eventWrapper = mount(HTImage, {
        props: {
          src: 'https://example.com/error.jpg',
        },
      });

      await eventWrapper.find('img').trigger('error');
      await nextTick();

      expect(eventWrapper.emitted('error')).toBeTruthy();
      expect(eventWrapper.emitted('error')?.[0]?.[0]).toBeInstanceOf(Event);
    });

    it('应该触发click事件', async () => {
      const eventWrapper = mount(HTImage, {
        props: {
          src: 'https://example.com/test.jpg',
        },
      });

      await eventWrapper.find('.ht-image').trigger('click');
      await nextTick();

      expect(eventWrapper.emitted('click')).toBeTruthy();
      expect(eventWrapper.emitted('click')?.[0]?.[0]).toBeInstanceOf(MouseEvent);
    });
  });

  describe('HTML属性测试', () => {
    it('应该正确应用crossorigin属性', async () => {
      await wrapper.setProps({ crossorigin: 'anonymous' });

      const imgElement = wrapper.find('img');
      expect(imgElement.attributes('crossorigin')).toBe('anonymous');
    });

    it('应该正确应用referrerpolicy属性', async () => {
      await wrapper.setProps({ referrerpolicy: 'no-referrer' });

      const imgElement = wrapper.find('img');
      expect(imgElement.attributes('referrerpolicy')).toBe('no-referrer');
    });

    it('应该正确应用decoding属性', async () => {
      await wrapper.setProps({ decoding: 'async' });

      const imgElement = wrapper.find('img');
      expect(imgElement.attributes('decoding')).toBe('async');
    });
  });

  describe('方法测试', () => {
    it('load方法应该触发图片加载', async () => {
      const methodWrapper = mount(HTImage, {
        props: {
          src: 'https://example.com/test.jpg',
        },
      });

      methodWrapper.vm.load();

      // After calling load, the component should be in loading state
      expect(methodWrapper.vm.loading).toBe(true);
    });

    it('reset方法应该重置所有状态', async () => {
      const methodWrapper = mount(HTImage, {
        props: {
          src: 'https://example.com/test.jpg',
        },
      });

      // Trigger load first to set some state
      await methodWrapper.find('img').trigger('load');
      await nextTick();

      // Now reset
      methodWrapper.vm.reset();
      await nextTick();

      expect(methodWrapper.vm.loading).toBe(false);
      expect(methodWrapper.vm.loaded).toBe(false);
      expect(methodWrapper.vm.error).toBe(false);
    });
  });

  describe('可访问性测试', () => {
    it('应该有正确的alt文本', () => {
      const imgElement = wrapper.find('img');
      expect(imgElement.attributes('alt')).toBe('Test Image');
    });

    it('应该支持键盘导航', async () => {
      const a11yWrapper = mount(HTImage, {
        props: {
          src: 'https://example.com/test.jpg',
          alt: 'Test Image',
        },
      });

      const imageContainer = a11yWrapper.find('.ht-image');

      // 验证容器元素存在且可访问
      expect(imageContainer.exists()).toBe(true);

      // 验证图片元素有正确的 alt 属性
      const imgElement = a11yWrapper.find('img');
      expect(imgElement.attributes('alt')).toBe('Test Image');
    });
  });

  describe('响应式测试', () => {
    it('应该在src变化时重新加载', async () => {
      const responsiveWrapper = mount(HTImage, {
        props: {
          src: 'https://example.com/original.jpg',
          lazyLoad: false, // Use non-lazy loading for this test
        },
      });

      // First load completes
      await responsiveWrapper.find('img').trigger('load');
      await nextTick();
      expect(responsiveWrapper.vm.loaded).toBe(true);

      // Change src
      await responsiveWrapper.setProps({ src: 'https://example.com/new-image.jpg' });
      await nextTick();

      // Should reset loaded and error state, and start loading
      expect(responsiveWrapper.vm.loaded).toBe(false);
      expect(responsiveWrapper.vm.loading).toBe(true); // Component immediately starts loading
      expect(responsiveWrapper.vm.error).toBe(false);
    });
  });

  describe('Vant兼容性测试', () => {
    it('应该支持所有Vant Image的props', () => {
      const vantProps = {
        src: 'https://example.com/vant.jpg',
        alt: 'Vant Image',
        fit: 'cover',
        position: 'top',
        width: 100,
        height: 100,
        round: true,
        block: true,
        radius: 8,
        lazyLoad: true,
        showError: true,
        showLoading: true,
        iconSize: 24,
        errorIcon: 'warning',
        loadingIcon: 'loading',
        iconPrefix: 'van-icon',
        crossorigin: 'anonymous',
        referrerpolicy: 'no-referrer',
        decoding: 'async',
      };

      const vantWrapper = mount(HTImage, {
        props: vantProps,
      });

      expect(vantWrapper.find('.ht-image').exists()).toBe(true);
      expect(vantWrapper.find('img').exists()).toBe(true);

      // Test some key props are applied
      expect(vantWrapper.vm.$props.src).toBe('https://example.com/vant.jpg');
      expect(vantWrapper.vm.$props.alt).toBe('Vant Image');
      expect(vantWrapper.vm.$props.fit).toBe('cover');
    });

    it('应该支持Vant的slot API', async () => {
      const vantWrapper = mount(HTImage, {
        props: { src: 'test.jpg', showLoading: true, showError: true },
        slots: {
          loading: '<div class="vant-loading">加载中...</div>',
          error: '<div class="vant-error">加载失败</div>',
        },
      });

      // Initially loading slot should be visible
      expect(vantWrapper.find('.vant-loading').exists()).toBe(true);

      // Trigger error to show error slot
      await vantWrapper.find('img').trigger('error');
      await nextTick();

      expect(vantWrapper.find('.vant-error').exists()).toBe(true);
    });
  });
});
