import { mount } from '@vue/test-utils';
import { describe, expect, it } from 'vitest';
import HTImage from '../index.vue';

describe('HTImage - Basic Tests', () => {
  it('应该正确渲染组件', () => {
    const wrapper = mount(HTImage, {
      props: {
        src: 'https://example.com/test.jpg',
        alt: 'Test Image',
      },
    });

    expect(wrapper.find('.ht-image').exists()).toBe(true);
    expect(wrapper.find('img').exists()).toBe(true);
    expect(wrapper.find('img').attributes('src')).toBe('https://example.com/test.jpg');
    expect(wrapper.find('img').attributes('alt')).toBe('Test Image');
  });

  it('应该正确应用基础类名', () => {
    const wrapper = mount(HTImage, {
      props: {
        src: 'test.jpg',
        alt: 'Test',
      },
    });

    expect(wrapper.find('.ht-image').exists()).toBe(true);
  });

  it('应该支持不同的variant', async () => {
    const wrapper = mount(HTImage, {
      props: {
        src: 'test.jpg',
        variant: 'rounded',
      },
    });

    expect(wrapper.find('.ht-image--rounded').exists()).toBe(true);
  });

  it('应该支持round属性', async () => {
    const wrapper = mount(HTImage, {
      props: {
        src: 'test.jpg',
        round: true,
      },
    });

    expect(wrapper.find('.ht-image--round').exists()).toBe(true);
  });
});
