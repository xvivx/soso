export const IMAGE_FITS = ['contain', 'cover', 'fill', 'none', 'scale-down'] as const;
export const IMAGE_POSITIONS = ['top', 'bottom', 'left', 'right', 'center'] as const;
export const IMAGE_VARIANTS = ['default', 'rounded', 'circle', 'cover'] as const;

export const DEFAULT_IMAGE_PROPS = {
  fit: 'fill' as const,
  showError: true,
  showLoading: true,
  variant: 'default' as const,
  block: false,
  round: false,
  lazyLoad: false,
} as const;

export const IMAGE_ICONS = {
  loading: 'photo',
  error: 'photo-fail',
} as const;

// Default icon size
export const DEFAULT_ICON_SIZE = 32;
