<script setup lang="ts">
import { computed, nextTick, onMounted, readonly, ref, watch } from 'vue';
import { useIntersectionObserver } from '@vueuse/core';
import { cva } from 'class-variance-authority';
import { addUnit, cn, isDef } from '@/utils';
import { DEFAULT_IMAGE_PROPS, IMAGE_ICONS } from './constants';
import type { HTImageEmits, HTImageProps } from './types';
import './styles/index.css';

// Props definition
const props = withDefaults(defineProps<HTImageProps>(), {
  ...DEFAULT_IMAGE_PROPS,
  alt: '',
  fit: 'fill',
  position: 'center',
  showError: true,
  showLoading: true,
  errorIcon: IMAGE_ICONS.error,
  loadingIcon: IMAGE_ICONS.loading,
});

// Events definition
const emit = defineEmits<HTImageEmits>();

// Template refs
const imageRef = ref<HTMLImageElement>();
const imageContainerRef = ref<HTMLDivElement>();

// Reactive state
const loading = ref(false);
const loaded = ref(false);
const error = ref(false);

// Base class name
const baseClass = 'ht-image';

// Component variants using cva
const imageVariants = cva(baseClass, {
  variants: {
    variant: {
      default: '',
      rounded: `${baseClass}--rounded`,
      circle: `${baseClass}--circle`,
      cover: `${baseClass}--cover`,
    },
    block: {
      true: `${baseClass}--block`,
    },
    round: {
      true: `${baseClass}--round`,
    },
    position: {
      top: `${baseClass}--position-top`,
      bottom: `${baseClass}--position-bottom`,
      left: `${baseClass}--position-left`,
      right: `${baseClass}--position-right`,
      center: `${baseClass}--position-center`,
    },
  },
  defaultVariants: {
    variant: 'default',
    position: 'center',
  },
} as const);

// Computed classes
const imageClasses = computed(() => {
  return cn(
    imageVariants({
      variant: props.variant,
      block: props.block,
      round: props.round,
      position: props.position,
    }),
    props.className,
    {
      [`${baseClass}--loading`]: loading.value,
      [`${baseClass}--loaded`]: loaded.value,
      [`${baseClass}--error`]: error.value,
    }
  );
});

const imageImgClasses = computed(() => {
  return cn(`${baseClass}__img`, {
    [`${baseClass}__img--loading`]: loading.value,
    [`${baseClass}__img--loaded`]: loaded.value,
    [`${baseClass}__img--error`]: error.value,
  });
});

// Computed styles
const imageStyles = computed(() => {
  const styles: Record<string, string> = {};

  if (isDef(props.width) && props.width !== '') {
    styles.width = addUnit(props.width)!;
  }
  if (isDef(props.height) && props.height !== '') {
    styles.height = addUnit(props.height)!;
  }
  if (isDef(props.radius) && props.radius !== '') {
    styles.borderRadius = addUnit(props.radius)!;
  }

  return styles;
});

const imageImgStyles = computed(() => {
  const styles: Record<string, string> = {};

  if (props.fit) {
    styles.objectFit = props.fit;
  }

  if (props.position && props.position !== 'center') {
    styles.objectPosition = props.position;
  }

  return styles;
});

// Computed src (for lazy loading)
const actualSrc = computed(() => {
  if (props.lazyLoad && !loading.value && !loaded.value) {
    return '';
  }
  return props.src;
});

// Icon size computation
const iconSize = computed(() => {
  return isDef(props.iconSize) ? addUnit(props.iconSize) : undefined;
});

// Icon components (placeholder - would be replaced with actual icon components)
const loadingIconComponent = computed(() => {
  // Return HTIcon or similar component with props.loadingIcon
  return 'div'; // Placeholder
});

const errorIconComponent = computed(() => {
  // Return HTIcon or similar component with props.errorIcon
  return 'div'; // Placeholder
});

const placeholderIconComponent = computed(() => {
  // Return HTIcon or similar component with default icon
  return 'div'; // Placeholder
});

// Event handlers
const handleLoad = (event: Event) => {
  if (loading.value) {
    loading.value = false;
    loaded.value = true;
    error.value = false;
    emit('load', event);
  }
};

const handleError = (event: Event) => {
  loading.value = false;
  loaded.value = false;
  error.value = true;
  emit('error', event);
};

const handleClick = (event: Event) => {
  emit('click', event);
};

// Methods
const load = () => {
  if (!props.src || loaded.value || loading.value) {
    return;
  }

  loading.value = true;
  error.value = false;
};

const triggerLoad = () => {
  const loadEvent = new Event('load');
  Object.defineProperty(loadEvent, 'target', {
    value: imageRef.value,
    enumerable: true,
  });
  handleLoad(loadEvent);
};

const reset = () => {
  loading.value = false;
  loaded.value = false;
  error.value = false;
};

// When lazyLoad is false, load immediately if src exists
if (!props.lazyLoad && props.src) {
  load();
}

// Check if image is already loaded (for SSR or cached images)
onMounted(() => {
  // Lazy loading with IntersectionObserver
  if (props.lazyLoad) {
    useIntersectionObserver(
      imageContainerRef,
      ([entry]) => {
        if (entry?.isIntersecting && !loaded.value && !loading.value) {
          load();
        }
      },
      {
        threshold: 0.1, // Trigger when 10% of the element is visible
      }
    );
  }

  nextTick(() => {
    if (imageRef.value?.complete && !props.lazyLoad) {
      triggerLoad();
    }
  });
});

// Watch src changes
watch(
  () => props.src,
  (newSrc, oldSrc) => {
    if (newSrc !== oldSrc) {
      reset();
      if (newSrc && (!props.lazyLoad || loaded.value)) {
        load();
      }
    }
  }
);

// Expose methods
defineExpose({
  load,
  reset,
  loading: readonly(loading),
  loaded: readonly(loaded),
  error: readonly(error),
});
</script>

<template>
  <div
    ref="imageContainerRef"
    :class="imageClasses"
    :style="imageStyles"
    v-bind="$attrs"
    @click="handleClick"
    @keydown.enter="handleClick"
  >
    <!-- Main image element -->
    <img
      v-if="!error && src"
      ref="imageRef"
      :src="actualSrc"
      :alt="alt"
      :class="imageImgClasses"
      :style="imageImgStyles"
      :crossorigin="crossorigin"
      :referrerpolicy="referrerpolicy"
      :decoding="decoding"
      @load="handleLoad"
      @error="handleError"
    />

    <!-- Loading state -->
    <div v-if="showLoading && loading && !error" :class="`${baseClass}__loading`">
      <slot name="loading">
        <component :is="loadingIconComponent" :class="`${baseClass}__loading-icon`" :size="iconSize" />
        <div :class="`${baseClass}__loading-text`" v-if="$slots.loadingText">
          <slot name="loadingText" />
        </div>
      </slot>
    </div>

    <!-- Error state -->
    <div v-if="showError && error" :class="`${baseClass}__error`">
      <slot name="error">
        <component :is="errorIconComponent" :class="`${baseClass}__error-icon`" :size="iconSize" />
        <div :class="`${baseClass}__error-text`" v-if="$slots.errorText">
          <slot name="errorText" />
        </div>
      </slot>
    </div>

    <!-- Lazy loading placeholder -->
    <div v-if="lazyLoad && !loaded && !error" :class="`${baseClass}__lazy-placeholder`">
      <slot name="placeholder">
        <component :is="placeholderIconComponent" :class="`${baseClass}__lazy-icon`" />
      </slot>
    </div>

    <!-- Default slot for additional content -->
    <slot />
  </div>
</template>
