export interface HTImageProps {
  // Core image properties - Vant compatible
  src?: string;
  alt?: string;

  // Display properties - Vant compatible
  fit?: 'contain' | 'cover' | 'fill' | 'none' | 'scale-down';
  position?: 'top' | 'bottom' | 'left' | 'right' | 'center';
  width?: string | number;
  height?: string | number;

  // Styling properties - Vant compatible
  round?: boolean;
  block?: boolean;
  radius?: string | number;

  // Behavior properties - Vant compatible
  lazyLoad?: boolean;
  showError?: boolean;
  showLoading?: boolean;

  // Icon properties - Vant compatible
  iconSize?: string | number;
  errorIcon?: string;
  loadingIcon?: string;
  iconPrefix?: string;

  // HTML attributes - Vant compatible
  crossorigin?: 'anonymous' | 'use-credentials' | '';
  referrerpolicy?:
    | 'no-referrer'
    | 'no-referrer-when-downgrade'
    | 'origin'
    | 'origin-when-cross-origin'
    | 'same-origin'
    | 'strict-origin'
    | 'strict-origin-when-cross-origin'
    | '';
  decoding?: 'async' | 'sync' | 'auto';

  // shadcn-vue extensions
  variant?: 'default' | 'rounded' | 'circle' | 'cover';
  className?: string;
  asChild?: boolean;
}

export interface HTImageEmits {
  load: [event: Event];
  error: [event: Event];
  click: [event: Event];
}

export interface HTImageSlots {
  default?: () => unknown;
  loading?: () => unknown;
  loadingText?: () => unknown;
  error?: () => unknown;
  errorText?: () => unknown;
  placeholder?: () => unknown;
}

export type ImageFit = 'contain' | 'cover' | 'fill' | 'none' | 'scale-down';
export type ImagePosition = 'top' | 'bottom' | 'left' | 'right' | 'center';
export type ImageVariant = 'default' | 'rounded' | 'circle' | 'cover';
