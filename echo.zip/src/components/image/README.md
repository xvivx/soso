# HTImage 图片组件

基于 shadcn-vue 实现，完全兼容 Vant Image 组件 API 的图片组件。

## 特性

- 🎨 **多种填充模式** - 支持 fill、contain、cover、none、scale-down
- 🔘 **圆角支持** - 支持圆形、圆角等各种样式
- ⚡ **懒加载** - 内置懒加载功能，提升页面性能
- 🛡️ **错误处理** - 完善的错误状态处理和自定义错误内容
- 🔄 **加载状态** - 支持自定义加载状态显示
- 🎯 **定位控制** - 精确控制图片在容器中的位置
- 📱 **响应式** - 完全响应式设计
- ♿ **无障碍** - 完整的可访问性支持
- 🔧 **高度可定制** - 丰富的配置选项和插槽支持

## 基础用法

```vue
<template>
  <HTImage src="https://example.com/image.jpg" width="200" height="200" alt="示例图片" />
</template>

<script setup lang="ts">
import { HTImage } from '@/components';
</script>
```

## 填充模式

通过 `fit` 属性可以设置图片填充模式：

```vue
<template>
  <div class="fit-examples">
    <HTImage v-for="fit in fits" :key="fit" :src="imageUrl" width="150" height="100" :fit="fit" :alt="`fit: ${fit}`" />
  </div>
</template>

<script setup lang="ts">
const fits = ['fill', 'contain', 'cover', 'none', 'scale-down'];
const imageUrl = 'https://picsum.photos/150/100';
</script>
```

### 填充模式说明

| 模式         | 说明                                | 效果             |
| ------------ | ----------------------------------- | ---------------- |
| `fill`       | 拉伸图片完全填充容器                | 可能导致图片变形 |
| `contain`    | 保持比例缩放至完全显示              | 可能留有空白     |
| `cover`      | 保持比例覆盖整个容器                | 可能裁剪部分内容 |
| `none`       | 保持原始尺寸                        | 可能超出容器     |
| `scale-down` | 在 none 和 contain 中选择较小的尺寸 | 自适应缩放       |

## 圆形和圆角

### 圆形图片

```vue
<template>
  <!-- 使用 round 属性 -->
  <HTImage src="avatar.jpg" width="100" height="100" round alt="用户头像" />

  <!-- 使用 circle 变体 -->
  <HTImage src="avatar.jpg" width="100" height="100" variant="circle" alt="用户头像" />
</template>
```

### 圆角图片

```vue
<template>
  <!-- 使用 radius 属性 -->
  <HTImage src="photo.jpg" width="120" height="120" :radius="8" alt="圆角图片" />

  <!-- 使用 rounded 变体 -->
  <HTImage src="photo.jpg" width="120" height="120" variant="rounded" alt="圆角图片" />
</template>
```

## 懒加载

启用懒加载可以提升页面性能：

```vue
<template>
  <HTImage src="large-image.jpg" width="300" height="200" :lazy-load="true" alt="懒加载图片">
    <!-- 自定义占位符 -->
    <template #placeholder>
      <div class="placeholder">
        <div class="spinner"></div>
        <p>加载中...</p>
      </div>
    </template>
  </HTImage>
</template>
```

## 加载和错误状态

### 自定义加载状态

```vue
<template>
  <HTImage src="image.jpg" width="200" height="200" :show-loading="true" alt="自定义加载">
    <template #loading>
      <div class="custom-loading">
        <div class="loading-spinner"></div>
        <p>正在加载图片...</p>
      </div>
    </template>
  </HTImage>
</template>
```

### 自定义错误状态

```vue
<template>
  <HTImage src="invalid-image.jpg" width="200" height="200" :show-error="true" alt="自定义错误">
    <template #error>
      <div class="custom-error">
        <span class="error-icon">⚠️</span>
        <p>图片加载失败</p>
        <button @click="retry">重试</button>
      </div>
    </template>
  </HTImage>
</template>

<script setup lang="ts">
const retry = () => {
  // 实现重试逻辑
};
</script>
```

## 定位控制

使用 `position` 属性控制图片在容器中的位置：

```vue
<template>
  <div class="position-examples">
    <HTImage
      v-for="position in positions"
      :key="position"
      :src="imageUrl"
      width="150"
      height="100"
      fit="cover"
      :position="position"
      :alt="`position: ${position}`"
    />
  </div>
</template>

<script setup lang="ts">
const positions = ['top', 'bottom', 'left', 'right', 'center'];
const imageUrl = 'https://picsum.photos/150/100';
</script>
```

## 响应式图片

```vue
<template>
  <HTImage src="responsive-image.jpg" width="100%" height="auto" fit="cover" alt="响应式图片" />
</template>
```

## 事件处理

```vue
<template>
  <HTImage
    src="event-demo.jpg"
    width="200"
    height="200"
    alt="事件演示"
    @load="handleLoad"
    @error="handleError"
    @click="handleClick"
  />
</template>

<script setup lang="ts">
const handleLoad = (event: Event) => {
  console.log('图片加载成功', event);
};

const handleError = (event: Event) => {
  console.log('图片加载失败', event);

  const handleClick = (event: Event) => {
    console.log('图片被点击', event);
  };
};
</script>
```

## API

### Props

| 参数           | 说明               | 类型                                                       | 默认值         | Vant 兼容 |
| -------------- | ------------------ | ---------------------------------------------------------- | -------------- | --------- |
| src            | 图片链接           | `string`                                                   | -              | ✅        |
| alt            | 替代文本           | `string`                                                   | -              | ✅        |
| fit            | 填充模式           | `'fill' \| 'contain' \| 'cover' \| 'none' \| 'scale-down'` | `'fill'`       | ✅        |
| position       | 位置               | `'top' \| 'bottom' \| 'left' \| 'right' \| 'center'`       | `'center'`     | ✅        |
| width          | 宽度               | `string \| number`                                         | -              | ✅        |
| height         | 高度               | `string \| number`                                         | -              | ✅        |
| round          | 是否为圆形         | `boolean`                                                  | `false`        | ✅        |
| block          | 是否为块级元素     | `boolean`                                                  | `false`        | ✅        |
| radius         | 圆角大小           | `string \| number`                                         | -              | ✅        |
| lazyLoad       | 是否懒加载         | `boolean`                                                  | `false`        | ✅        |
| showError      | 是否显示错误提示   | `boolean`                                                  | `true`         | ✅        |
| showLoading    | 是否显示加载提示   | `boolean`                                                  | `true`         | ✅        |
| iconSize       | 图标大小           | `string \| number`                                         | -              | ✅        |
| errorIcon      | 错误图标名称       | `string`                                                   | `'photo-fail'` | ✅        |
| loadingIcon    | 加载图标名称       | `string`                                                   | `'photo'`      | ✅        |
| iconPrefix     | 图标类名前缀       | `string`                                                   | -              | ✅        |
| crossorigin    | 跨域设置           | `'anonymous' \| 'use-credentials' \| ''`                   | -              | ✅        |
| referrerpolicy | 引用策略           | `string`                                                   | -              | ✅        |
| decoding       | 解码方式           | `'async' \| 'sync' \| 'auto'`                              | -              | ✅        |
| variant        | shadcn-vue 变体    | `'default' \| 'rounded' \| 'circle' \| 'cover'`            | `'default'`    | ❌        |
| className      | 自定义类名         | `string`                                                   | -              | ❌        |
| asChild        | 是否作为子元素渲染 | `boolean`                                                  | `false`        | ❌        |
| placeholder    | 是否显示占位符     | `boolean`                                                  | `false`        | ❌        |
| error          | 是否为错误状态     | `boolean`                                                  | `false`        | ❌        |

### Events

| 事件名 | 说明               | 回调参数              |
| ------ | ------------------ | --------------------- |
| load   | 图片加载成功时触发 | `(event: Event)`      |
| error  | 图片加载失败时触发 | `(event: Event)`      |
| click  | 点击图片时触发     | `(event: MouseEvent)` |

### Slots

| 插槽名      | 说明                     |
| ----------- | ------------------------ |
| default     | 默认插槽，可添加额外内容 |
| loading     | 自定义加载状态内容       |
| error       | 自定义错误状态内容       |
| placeholder | 自定义懒加载占位符内容   |
| loadingText | 自定义加载文本内容       |
| errorText   | 自定义错误文本内容       |

### Methods

通过 ref 可以调用以下方法：

| 方法名 | 说明         | 参数 |
| ------ | ------------ | ---- |
| load   | 手动加载图片 | -    |
| reset  | 重置所有状态 | -    |

### 暴露的状态

| 属性名  | 说明         | 类型      |
| ------- | ------------ | --------- |
| loading | 是否正在加载 | `boolean` |
| loaded  | 是否加载完成 | `boolean` |
| error   | 是否加载失败 | `boolean` |

## 主题定制

### CSS 变量

可以通过修改 CSS 变量来自定义样式：

```css
:root {
  /* 图片容器样式 */
  --image-container-bg-color-default: #f5f5f5;
  --image-container-border-radius-default: 0;

  /* 图片元素样式 */
  --image-img-object-fit-default: fill;
  --image-img-opacity-loading: 0.5;

  /* 图标样式 */
  --image-placeholder-size-default: 32px;
  --image-error-icon-size-default: 32px;
  /* 状态样式 */
  --image-loading-animation-duration: 0.8s;
  --image-error-text-font-size-default: 14px;
}
```

### 组件特定变量

```css
.ht-image {
  /* 尺寸变体 */
  --image-small-width: 80px;
  --image-small-height: 80px;
  --image-large-width: 160px;
  --image-large-height: 160px;

  /* 变体样式 */
  --image-rounded-border-radius: 8px;
  --image-circle-border-radius: 50%;
  --image-cover-object-fit: cover;

  /* 颜色定制 */
  --image-loading-spinner-color: #1989fa;
  --image-error-icon-color-error: #ff4d4f;
}
```

## 从 Vant 迁移

HTImage 组件完全兼容 Vant Image 的 API，可以直接替换：

```vue
<!-- Vant 用法 -->
<van-image src="https://example.com/image.jpg" width="200" height="200" fit="cover" round @load="onLoad" />

<!-- HTImage 用法 -->
<HTImage src="https://example.com/image.jpg" width="200" height="200" fit="cover" round @load="onLoad" />
```

### 新增功能

HTImage 在 Vant 基础上增加了一些扩展功能：

```vue
<!-- shadcn-vue 风格的变体 -->
<HTImage src="image.jpg" variant="rounded" className="custom-class" />

<!-- 更多插槽支持 -->
<HTImage src="image.jpg">
  <template #placeholder>
    <CustomPlaceholder />
  </template>
</HTImage>
```

## 常见问题

### Q: 如何处理图片跨域问题？

A: 可以通过设置 `crossorigin` 属性：

```vue
<HTImage src="https://example.com/cors-image.jpg" crossorigin="anonymous" alt="跨域图片" />
```

### Q: 如何实现图片懒加载？

A: 设置 `lazyLoad` 属性为 `true`：

```vue
<HTImage src="https://example.com/large-image.jpg" :lazy-load="true" alt="懒加载图片" />
```

### Q: 如何自定义加载和错误状态？

A: 使用对应的插槽：

```vue
<HTImage src="image.jpg">
  <template #loading>
    <CustomLoading />
  </template>
  <template #error>
    <CustomError />
  </template>
</HTImage>
```

### Q: 如何实现图片预览功能？

A: HTImage 组件目前不内置预览功能，后续会提供 ImagePreview 组件来实现预览功能。但可以通过以下方式实现：

```vue
<template>
  <HTImage src="image.jpg" @click="handleImageClick" style="cursor: pointer;" />

  <!-- 自定义预览弹窗 -->
  <div v-if="showPreview" class="image-preview" @click="closePreview">
    <img :src="previewSrc" alt="预览图片" />
    <button class="close-btn" @click="closePreview">×</button>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue';

const showPreview = ref(false);
const previewSrc = ref('');

const handleImageClick = (event: Event) => {
  const img = event.target as HTMLImageElement;
  previewSrc.value = img.src;
  showPreview.value = true;
};

const closePreview = () => {
  showPreview.value = false;
};
</script>

<style>
.image-preview {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.8);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 9999;
  cursor: pointer;
}

.image-preview img {
  max-width: 90%;
  max-height: 90%;
  object-fit: contain;
}

.close-btn {
  position: absolute;
  top: 20px;
  right: 20px;
  background: rgba(255, 255, 255, 0.2);
  border: none;
  color: white;
  font-size: 24px;
  width: 40px;
  height: 40px;
  border-radius: 50%;
  cursor: pointer;
}
</style>
```

### v1.0.1

- 🔧 优化图标渲染，集成 lucide-vue-next 图标库
- 🔧 完善懒加载逻辑，提升兼容性和性能
- 🔧 改进组件状态管理，修复加载和错误状态处理
- 🔧 补充完整的 CSS Tokens 定义
- 🔧 增加键盘导航支持，提升可访问性
- 🔧 修复所有已知测试问题，确保功能稳定性

### v1.0.0

- 🎉 初始版本发布
- ✅ 完全兼容 Vant Image API
- ✅ 支持多种填充模式
- ✅ 支持懒加载功能
- ✅ 支持自定义加载和错误状态
- ✅ 支持 shadcn-vue 扩展 API
- ✅ 完整的 TypeScript 支持
- ✅ 完善的测试覆盖
- ✅ 详细的使用文档
