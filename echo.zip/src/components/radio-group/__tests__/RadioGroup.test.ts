import { nextTick } from 'vue';
import { mount } from '@vue/test-utils';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import HTRadio from '../../radio/Radio.vue';
import HTRadioGroup from '../RadioGroup.vue';

describe('HTRadioGroup', () => {
  beforeEach(() => {
    document.body.innerHTML = '';
  });

  describe('基础渲染', () => {
    it('应该正确渲染单选组', () => {
      const wrapper = mount(HTRadioGroup, {
        slots: {
          default: `
            <ht-radio name="option-1">Option 1</ht-radio>
            <ht-radio name="option-2">Option 2</ht-radio>
          `,
        },
        global: {
          components: { 'ht-radio': HTRadio },
        },
      });

      expect(wrapper.find('.ht-radio-group').exists()).toBe(true);
      expect(wrapper.findAllComponents(HTRadio).length).toBe(2);
    });

    it('应该支持 horizontal 方向', () => {
      const wrapper = mount(HTRadioGroup, {
        props: {
          modelValue: null,
          direction: 'horizontal',
        },
        slots: {
          default: `
            <ht-radio name="option-1">Option 1</ht-radio>
            <ht-radio name="option-2">Option 2</ht-radio>
          `,
        },
        global: {
          components: { 'ht-radio': HTRadio },
        },
      });

      expect(wrapper.find('.ht-radio-group--horizontal').exists()).toBe(true);
    });

    it('应该支持 vertical 方向', () => {
      const wrapper = mount(HTRadioGroup, {
        props: {
          modelValue: null,
          direction: 'vertical',
        },
        slots: {
          default: `
            <ht-radio name="option-1">Option 1</ht-radio>
            <ht-radio name="option-2">Option 2</ht-radio>
          `,
        },
        global: {
          components: { 'ht-radio': HTRadio },
        },
      });

      expect(wrapper.find('.ht-radio-group--vertical').exists()).toBe(true);
    });
  });

  describe('v-model 双向绑定', () => {
    it('应该支持 v-model', async () => {
      const wrapper = mount({
        components: { HTRadioGroup, HTRadio },
        template: `
          <HTRadioGroup v-model="value">
            <HTRadio name="a">A</HTRadio>
            <HTRadio name="b">B</HTRadio>
          </HTRadioGroup>
        `,
        data() {
          return {
            value: 'a',
          };
        },
      });

      await nextTick();

      expect(wrapper.vm.value).toBe('a');

      const radios = wrapper.findAll('.ht-radio');
      await radios[1].trigger('click');
      await nextTick();

      expect(wrapper.vm.value).toBe('b');
    });

    it('应该在选择变化时触发 change 事件', async () => {
      const handleChange = vi.fn();

      const wrapper = mount({
        components: { HTRadioGroup, HTRadio },
        template: `
          <HTRadioGroup v-model="value" @change="handleChange">
            <HTRadio name="a">A</HTRadio>
            <HTRadio name="b">B</HTRadio>
          </HTRadioGroup>
        `,
        data() {
          return {
            value: null,
          };
        },
        methods: {
          handleChange,
        },
      });

      await nextTick();

      const radios = wrapper.findAll('.ht-radio');
      await radios[0].trigger('click');
      await nextTick();

      expect(handleChange).toHaveBeenCalled();
      expect(handleChange).toHaveBeenCalledWith('a');
    });
  });

  describe('禁用状态', () => {
    it('应该支持整组禁用', () => {
      const wrapper = mount(HTRadioGroup, {
        props: {
          modelValue: null,
          disabled: true,
        },
        slots: {
          default: `
            <ht-radio name="option-1">Option 1</ht-radio>
            <ht-radio name="option-2">Option 2</ht-radio>
          `,
        },
        global: {
          components: { 'ht-radio': HTRadio },
        },
      });

      const radios = wrapper.findAll('.ht-radio');
      radios.forEach((radio) => {
        expect(radio.attributes()).toHaveProperty('data-disabled');
      });
    });

    it('整组禁用时不应触发 change 事件', async () => {
      const handleChange = vi.fn();

      const wrapper = mount({
        components: { HTRadioGroup, HTRadio },
        template: `
          <HTRadioGroup v-model="value" :disabled="true" @change="handleChange">
            <HTRadio name="a">A</HTRadio>
            <HTRadio name="b">B</HTRadio>
          </HTRadioGroup>
        `,
        data() {
          return {
            value: null,
          };
        },
        methods: {
          handleChange,
        },
      });

      await nextTick();

      const radios = wrapper.findAll('.ht-radio');
      await radios[0].trigger('click');
      await nextTick();

      expect(handleChange).not.toHaveBeenCalled();
    });
  });

  describe('样式传递', () => {
    it('应该将 iconSize 传递给子 Radio', () => {
      const wrapper = mount(HTRadioGroup, {
        props: {
          modelValue: null,
          iconSize: 'small',
        },
        slots: {
          default: `
            <ht-radio name="option-1">Option 1</ht-radio>
          `,
        },
        global: {
          components: { 'ht-radio': HTRadio },
        },
      });

      const radio = wrapper.find('.ht-radio--small');
      expect(radio.exists()).toBe(true);
    });

    it('应该将 variant 传递给子 Radio', () => {
      const wrapper = mount(HTRadioGroup, {
        props: {
          modelValue: null,
          variant: 'secondary',
        },
        slots: {
          default: `
            <ht-radio name="option-1">Option 1</ht-radio>
          `,
        },
        global: {
          components: { 'ht-radio': HTRadio },
        },
      });

      const radio = wrapper.find('.ht-radio--secondary');
      expect(radio.exists()).toBe(true);
    });

    it('应该将 shape 传递给子 Radio', () => {
      const wrapper = mount(HTRadioGroup, {
        props: {
          modelValue: null,
          shape: 'dot',
        },
        slots: {
          default: `
            <ht-radio name="option-1">Option 1</ht-radio>
          `,
        },
        global: {
          components: { 'ht-radio': HTRadio },
        },
      });

      const radio = wrapper.find('.ht-radio__ring');
      expect(radio.exists()).toBe(true);
    });

    it('应该将 checkedColor 传递给子 Radio', () => {
      const wrapper = mount(HTRadioGroup, {
        props: {
          modelValue: null,
          checkedColor: '#ff0000',
        },
        slots: {
          default: `
            <ht-radio name="option-1">Option 1</ht-radio>
          `,
        },
        global: {
          components: { 'ht-radio': HTRadio },
        },
      });

      const radio = wrapper.find('.ht-radio');
      expect(radio.exists()).toBe(true);
    });

    it('应该将 labelPosition 传递给子 Radio', () => {
      const wrapper = mount(HTRadioGroup, {
        props: {
          modelValue: null,
          labelPosition: 'left',
        },
        slots: {
          default: `
            <ht-radio name="option-1">Option 1</ht-radio>
          `,
        },
        global: {
          components: { 'ht-radio': HTRadio },
        },
      });

      const inner = wrapper.find('.ht-radio__inner');
      expect(inner.classes()).toContain('flex-row-reverse');
    });
  });

  describe('边界情况', () => {
    it('应该处理空子组件', () => {
      const wrapper = mount(HTRadioGroup);
      expect(wrapper.find('.ht-radio-group').exists()).toBe(true);
    });

    it('应该处理初始值与选项不匹配的情况', async () => {
      const wrapper = mount({
        components: { HTRadioGroup, HTRadio },
        template: `
          <HTRadioGroup v-model="value">
            <HTRadio name="a">A</HTRadio>
            <HTRadio name="b">B</HTRadio>
          </HTRadioGroup>
        `,
        data() {
          return {
            value: 'non-existent',
          };
        },
      });

      await nextTick();
      expect(wrapper.vm.value).toBe('non-existent');
    });
  });
});
