<script setup lang="ts">
import { watch } from 'vue';
import { cva } from 'class-variance-authority';
import { RadioGroupRoot, type AcceptableValue } from 'reka-ui';
import { RADIO_GROUP_KEY } from '@/utils/index';
import { useChildren, useCustomFieldValue } from '@/hooks';
import type { RadioGroupProps } from './types';

const props = withDefaults(defineProps<RadioGroupProps>(), {
  disabled: false,
  shape: 'round',
  variant: 'primary',
});

const model = defineModel<AcceptableValue>('modelValue');
const emits = defineEmits<{
  (e: 'change', val: AcceptableValue): void;
}>();

const { linkChildren } = useChildren(RADIO_GROUP_KEY);
linkChildren({ props });
useCustomFieldValue(() => model.value);

watch(
  () => model.value,
  (val) => {
    emits('change', val as AcceptableValue);
  },
  { immediate: false }
);

const variants = cva('ht-radio-group flex', {
  variants: {
    direction: {
      horizontal: 'ht-radio-group--horizontal',
      vertical: 'ht-radio-group--vertical',
    },
  },
  defaultVariants: {
    direction: props.direction,
  },
});
</script>

<template>
  <RadioGroupRoot v-model="model" :disabled="disabled" :class="variants({ direction })">
    <slot />
  </RadioGroupRoot>
</template>

<style>
:root {
  --radio-group-container-gap-default: var(--dimensions-spacing-inset-lg); /** 组内单选框默认间距 */
  --radio-group-container-flex-direction-default: column; /** 组内布局方向 */
}
.ht-radio-group {
  gap: var(--radio-group-container-gap-default);
  flex-direction: var(--radio-group-container-flex-direction-default);
}
.ht-radio-group--horizontal {
  --radio-group-container-flex-direction-default: row;
}
.ht-radio-group--vertical {
  --radio-group-container-flex-direction-default: column;
}
</style>
