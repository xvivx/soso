import type { AcceptableValue } from 'reka-ui';

export type IconSize = number | string | 'small';

export type RadioLabelPosition = 'left' | 'right';
export type RadioGroupDirection = 'vertical' | 'horizontal';
export type RadioShape = 'round' | 'dot';
export type RadioVariant = 'primary' | 'secondary';

export interface RadioGroupProps {
  modelValue: AcceptableValue;
  disabled?: boolean;
  direction?: RadioGroupDirection;
  labelPosition?: RadioLabelPosition;
  iconSize?: IconSize;
  checkedColor?: string;
  shape?: RadioShape;
  variant?: RadioVariant;
}

export type RadioGroupProvide = {
  props: RadioGroupProps;
};
