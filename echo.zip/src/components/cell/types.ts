import type { HTMLAttributes } from 'vue';

export type CellArrowDirection = 'up' | 'down' | 'left' | 'right';

export interface CellProps {
  class?: HTMLAttributes['class'];
  tag?: string;
  title?: string;
  value?: string;
  label?: string;
  icon?: string;
  isLink?: boolean;
  arrowDirection?: CellArrowDirection;
  size?: 'normal' | 'large';
  center?: boolean;
  clickable?: boolean;
  isBorder?: boolean;
  required?: boolean;
}

export interface CellExpose {
  focus?: () => void;
}
