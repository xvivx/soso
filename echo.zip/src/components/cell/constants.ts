import { cva } from 'class-variance-authority';

export const cellVariants = cva('cell-base', {
  variants: {
    size: {
      normal: 'cell-size-normal',
      large: 'cell-size-large',
    },
    center: {
      true: 'cell-center',
    },
    clickable: {
      true: 'cell-clickable',
    },
    isBorder: {
      true: 'cell-border',
    },
    required: {
      true: 'cell-required',
    },
  },
  defaultVariants: {
    size: 'normal',
    isBorder: true,
  },
});
