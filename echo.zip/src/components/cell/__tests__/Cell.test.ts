import { fireEvent, render, screen } from '@testing-library/vue';
import { describe, expect, it, vi } from 'vitest';
import HTCell from '../index.vue';

describe('HTCell', () => {
  it('应该正确渲染默认单元格', () => {
    const { container } = render(HTCell, {
      props: {
        title: 'Cell Title',
      },
    });

    const cell = container.querySelector('.cell-base');
    expect(cell).toBeTruthy();
    expect(screen.getByText('Cell Title')).toBeTruthy();
  });

  it('应该支持自定义标签', () => {
    const { container } = render(HTCell, {
      props: {
        tag: 'section',
        title: 'Section Cell',
      },
    });

    const section = container.querySelector('section');
    expect(section).toBeTruthy();
    expect(section?.tagName).toBe('SECTION');
    expect(section?.classList.contains('cell-base')).toBe(true);
  });

  it('应该渲染标题和值', () => {
    render(HTCell, {
      props: {
        title: 'Cell Title',
        value: 'Cell Value',
      },
    });

    expect(screen.getByText('Cell Title')).toBeTruthy();
    expect(screen.getByText('Cell Value')).toBeTruthy();
  });

  it('应该渲染标签', () => {
    render(HTCell, {
      props: {
        title: 'Cell Title',
        label: 'Cell Label',
      },
    });

    expect(screen.getByText('Cell Title')).toBeTruthy();
    expect(screen.getByText('Cell Label')).toBeTruthy();
  });

  it('应该支持图标', () => {
    const { container } = render(HTCell, {
      props: {
        title: 'Cell Title',
        icon: 'test-icon',
      },
    });

    const iconContainer = container.querySelector('.cell-icon');
    const icon = container.querySelector('.cell-icon-default.test-icon');
    expect(iconContainer).toBeTruthy();
    expect(icon).toBeTruthy();
  });

  it('应该支持右侧图标插槽', () => {
    const { container } = render(HTCell, {
      props: {
        title: 'Cell Title',
      },
      slots: {
        'right-icon': '<i class="custom-right-icon">→</i>',
      },
    });

    const rightIcon = container.querySelector('.cell-right-icon');
    const customIcon = container.querySelector('.custom-right-icon');
    expect(rightIcon).toBeTruthy();
    expect(customIcon).toBeTruthy();
  });

  it('应该支持链接模式', () => {
    const { container } = render(HTCell, {
      props: {
        title: 'Cell Title',
        isLink: true,
      },
    });

    const rightIcon = container.querySelector('.cell-right-icon');
    const arrow = container.querySelector('.cell-arrow');
    expect(rightIcon).toBeTruthy();
    expect(arrow).toBeTruthy();
  });

  it('应该支持不同尺寸', () => {
    const { container } = render(HTCell, {
      props: {
        title: 'Large Cell',
        size: 'large',
      },
    });

    const cell = container.querySelector('.cell-base');
    expect(cell?.classList.contains('cell-size-large')).toBe(true);
  });

  it('应该支持居中对齐', () => {
    const { container } = render(HTCell, {
      props: {
        title: 'Centered Cell',
        center: true,
      },
    });

    const cell = container.querySelector('.cell-base');
    expect(cell?.classList.contains('cell-center')).toBe(true);
  });

  it('应该支持可点击状态', () => {
    const { container } = render(HTCell, {
      props: {
        title: 'Clickable Cell',
        clickable: true,
      },
    });

    const cell = container.querySelector('.cell-base');
    expect(cell?.classList.contains('cell-clickable')).toBe(true);
  });

  it('应该支持必填标记', () => {
    const { container } = render(HTCell, {
      props: {
        title: 'Required Cell',
        required: true,
      },
    });

    const cell = container.querySelector('.cell-base');
    expect(cell?.classList.contains('cell-required')).toBe(true);
  });

  it('应该支持边框控制', () => {
    const { container } = render(HTCell, {
      props: {
        title: 'No Border Cell',
        isBorder: false,
      },
    });

    const cell = container.querySelector('.cell-base');
    expect(cell?.classList.contains('cell-border')).toBe(false);
  });

  it('默认应该有边框', () => {
    const { container } = render(HTCell, {
      props: {
        title: 'Default Cell',
      },
    });

    const cell = container.querySelector('.cell-base');
    expect(cell?.classList.contains('cell-border')).toBe(true);
  });

  it('应该支持自定义类名', () => {
    const { container } = render(HTCell, {
      props: {
        title: 'Custom Cell',
        class: 'custom-cell-class',
      },
    });

    const cell = container.querySelector('.cell-base');
    expect(cell?.classList.contains('custom-cell-class')).toBe(true);
  });

  it('应该支持点击事件', async () => {
    const clickHandler = vi.fn();
    const { container } = render(HTCell, {
      props: {
        title: 'Clickable Cell',
        onClick: clickHandler,
      },
    });

    const cell = container.querySelector('.cell-base');
    expect(cell).toBeTruthy();

    if (cell) {
      await fireEvent.click(cell);
      expect(clickHandler).toHaveBeenCalledTimes(1);
    }
  });

  it('应该支持图标插槽', () => {
    const { container } = render(HTCell, {
      props: {
        title: 'Cell with Icon Slot',
      },
      slots: {
        icon: '<i class="custom-icon">★</i>',
      },
    });

    const iconContainer = container.querySelector('.cell-icon');
    const customIcon = container.querySelector('.custom-icon');
    expect(iconContainer).toBeTruthy();
    expect(customIcon).toBeTruthy();
  });

  it('应该支持标题插槽', () => {
    const { container } = render(HTCell, {
      slots: {
        title: '<span class="custom-title">Custom Title</span>',
      },
    });

    const titleContainer = container.querySelector('.cell-title');
    const customTitle = container.querySelector('.custom-title');
    expect(titleContainer).toBeTruthy();
    expect(customTitle).toBeTruthy();
    expect(screen.getByText('Custom Title')).toBeTruthy();
  });

  it('应该支持标签插槽', () => {
    render(HTCell, {
      props: {
        title: 'Cell Title',
      },
      slots: {
        label: '<span class="custom-label">Custom Label</span>',
      },
    });

    const customLabel = screen.getByText('Custom Label');
    expect(customLabel).toBeTruthy();
  });

  it('应该支持默认插槽作为值', () => {
    render(HTCell, {
      props: {
        title: 'Cell Title',
      },
      slots: {
        default: '<span class="custom-value">Custom Value</span>',
      },
    });

    const customValue = screen.getByText('Custom Value');
    expect(customValue).toBeTruthy();
  });

  it('应该支持箭头方向', () => {
    const { container } = render(HTCell, {
      props: {
        title: 'Cell Title',
        isLink: true,
        arrowDirection: 'up',
      },
    });

    const arrow = container.querySelector('.cell-arrow-up');
    expect(arrow).toBeTruthy();
  });

  it('应该正确处理复杂组合', () => {
    const clickHandler = vi.fn();
    const { container } = render(HTCell, {
      props: {
        title: 'Complex Cell',
        label: 'Description',
        value: 'Value',
        icon: 'test-icon',
        size: 'large',
        center: true,
        clickable: true,
        required: true,
        isLink: true,
        class: 'complex-cell',
        onClick: clickHandler,
      },
    });

    const cell = container.querySelector('.cell-base');
    expect(cell?.classList.contains('cell-size-large')).toBe(true);
    expect(cell?.classList.contains('cell-center')).toBe(true);
    expect(cell?.classList.contains('cell-clickable')).toBe(true);
    expect(cell?.classList.contains('cell-required')).toBe(true);
    expect(cell?.classList.contains('complex-cell')).toBe(true);

    expect(screen.getByText('Complex Cell')).toBeTruthy();
    expect(screen.getByText('Description')).toBeTruthy();
    expect(screen.getByText('Value')).toBeTruthy();

    const iconContainer = container.querySelector('.cell-icon');
    const rightIcon = container.querySelector('.cell-right-icon');
    expect(iconContainer).toBeTruthy();
    expect(rightIcon).toBeTruthy();
  });
});
