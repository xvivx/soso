<script setup lang="ts">
import { computed } from 'vue';
import { cn } from '@/utils';
import { cellVariants } from './constants';
import type { CellProps } from './types';
import './style/index.css';

const props = withDefaults(defineProps<CellProps>(), {
  tag: 'div',
  size: 'normal',
  isBorder: true,
});

const emit = defineEmits<{
  (e: 'click', event: MouseEvent): void;
}>();

function handleClick(event: MouseEvent) {
  emit('click', event);
}

const classes = computed(() => {
  return cn(
    cellVariants({
      size: props.size,
      center: props.center,
      clickable: props.clickable || props.isLink,
      isBorder: props.isBorder,
      required: props.required,
    }),
    props.class
  );
});
</script>

<template>
  <component :is="props.tag" :class="classes" @click="handleClick">
    <div v-if="props.icon || $slots.icon" class="cell-icon">
      <slot name="icon">
        <i v-if="props.icon" class="cell-icon-default" :class="props.icon" />
      </slot>
    </div>
    <div class="cell-title" v-if="props.title || props.label || $slots.title">
      <slot name="title">
        <span v-if="props.title">{{ props.title }}</span>
      </slot>
      <div class="cell-label" v-if="props.label || $slots.label">
        <slot name="label">{{ props.label }}</slot>
      </div>
    </div>
    <div class="cell-value" v-if="props.value || $slots.default">
      <slot>{{ props.value }}</slot>
    </div>
    <div v-if="props.isLink || $slots['right-icon']" class="cell-right-icon">
      <slot name="right-icon">
        <i v-if="props.isLink" class="cell-arrow" :class="`cell-arrow-${props.arrowDirection}`" />
      </slot>
    </div>
  </component>
</template>

<!-- <style>
@import '';
</style> -->
