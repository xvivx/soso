<script setup lang="ts">
import { computed, reactive, ref, watch, type PropType } from 'vue';
import { HTIcon } from '@/components';
import { preventDefault } from '@/utils/index';
import { useCustomFieldValue } from '@/hooks';

const props = defineProps({
  modelValue: {
    type: Number,
    default: 0,
  },
  label: String,
  min: {
    type: Number,
    default: 0,
  },
  max: {
    type: Number,
    default: Infinity,
  },
  step: {
    type: Number,
    default: 1,
  },
  disabled: Boolean,
  inputWidth: {
    type: [String, Number],
    default: '100%',
  },
  decimalLength: Number,
  name: String,
  size: String,
  disableInput: Boolean,
  beforeChange: Function as PropType<(value: number) => Promise<boolean> | boolean>,
  defaultValue: {
    type: Number,
    default: 0,
  },
  allowEmpty: Boolean,
  placeholder: String,
});

const emit = defineEmits(['update:modelValue', 'change', 'blur', 'focus', 'overlimit', 'plus', 'minus']);

const value = ref(props.modelValue ?? props.defaultValue);

const state = reactive({ focused: false });

useCustomFieldValue(() => value.value);

const inputRef = ref<HTMLInputElement | null>(null);

watch(
  () => props.modelValue,
  (val) => {
    value.value = val;
  }
);

const isMinusDisabled = computed(() => props.disabled || value.value <= props.min);
const isPlusDisabled = computed(() => props.disabled || value.value >= props.max);

function formatValue(val: number | string) {
  let n = Number(val);
  if (props.decimalLength !== undefined) {
    n = Number(n.toFixed(props.decimalLength));
  }
  if (!props.allowEmpty && isNaN(n)) n = props.min;
  n = Math.max(props.min, Math.min(props.max, n));
  return n;
}

async function handleChange(newValue: number) {
  if (props.beforeChange) {
    const result = await props.beforeChange(newValue);
    if (!result) return;
  }
  value.value = newValue;
  emit('update:modelValue', newValue);
  emit('change', newValue);
}

function onMinus() {
  if (isMinusDisabled.value) {
    emit('overlimit', 'minus');
    return;
  }
  emit('minus');
  inputRef.value?.focus();
  handleChange(formatValue(value.value - props.step));
}

function onPlus() {
  if (isPlusDisabled.value) {
    emit('overlimit', 'plus');
    return;
  }
  emit('plus');
  inputRef.value?.focus();
  handleChange(formatValue(value.value + props.step));
}

function onInput(e: Event) {
  const target = e.target as HTMLInputElement;
  const val = target.value;
  if (val === '' && props.allowEmpty) {
    handleChange('' as any);
    return;
  }
  handleChange(formatValue(val));
}

function onBlur(e: FocusEvent) {
  state.focused = false;
  emit('blur', e);
}

function onFocus(e: FocusEvent) {
  state.focused = true;
  emit('focus', e);
}

let longPressTimer: number | null = null;
function startLongPress(type: 'plus' | 'minus', e: Event) {
  preventDefault(e);
  if (type === 'plus') onPlus();
  else onMinus();
  longPressTimer = window.setInterval(() => {
    if (type === 'plus') onPlus();
    else onMinus();
  }, 200);
}
function stopLongPress(e: Event) {
  preventDefault(e);
  if (longPressTimer) {
    clearInterval(longPressTimer);
    longPressTimer = null;
  }
}
</script>

<template>
  <div
    class="ht-stepper"
    :class="{
      'is-disabled': props.disabled,
      'ht-field__container--focused': state.focused,
      'is-small': props.size === 'small',
    }"
  >
    <button
      class="ht-stepper__minus"
      :disabled="isMinusDisabled"
      @mousedown.prevent="(e) => startLongPress('minus', e)"
      @mouseup="stopLongPress"
      @mouseleave="stopLongPress"
      @touchstart.prevent="(e) => startLongPress('minus', e)"
      @touchend="stopLongPress"
    >
      <HTIcon name="minus" size="16" />
    </button>
    <div class="ht-stepper__inner" :class="{ 'has-label': label }">
      <div class="ht-stepper__inner-label">{{ label }}</div>
      <input
        type="number"
        ref="inputRef"
        class="ht-stepper__input"
        :style="{ width: props.inputWidth }"
        :value="value"
        :disabled="props.disableInput || props.disabled"
        :placeholder="props.placeholder"
        @input="onInput"
        @blur="onBlur"
        @focus="onFocus"
      />
    </div>
    <button
      class="ht-stepper__plus"
      :disabled="isPlusDisabled"
      @mousedown.prevent="(e) => startLongPress('plus', e)"
      @mouseup="stopLongPress"
      @mouseleave="stopLongPress"
      @touchstart.prevent="(e) => startLongPress('plus', e)"
      @touchend="stopLongPress"
    >
      <HTIcon name="plus" size="16" />
    </button>
  </div>
</template>

<style>
@import './style/index.css';
</style>
