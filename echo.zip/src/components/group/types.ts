import type { HTMLAttributes } from 'vue';

export interface GroupProps {
  class?: HTMLAttributes['class'];
  title?: string;

  // 显式声明 VariantProps 中的属性以确保类型推断
  inset?: boolean;
  border?: boolean;
}
