import { render, screen } from '@testing-library/vue';
import { describe, expect, it } from 'vitest';
import HTGroup from '../index.vue';

describe('HTGroup', () => {
  it('应该正确渲染默认分组', () => {
    const { container } = render(HTGroup, {
      slots: {
        default: 'Group Content',
      },
    });

    const group = container.querySelector('.cell-group');
    expect(group).toBeTruthy();
    expect(screen.getByText('Group Content')).toBeTruthy();
  });

  it('应该支持自定义标题', () => {
    render(HTGroup, {
      props: {
        title: 'Custom Title',
      },
      slots: {
        default: 'Group Content',
      },
    });

    expect(screen.getByText('Custom Title')).toBeTruthy();
    expect(screen.getByText('Group Content')).toBeTruthy();
  });

  it('应该正确渲染标题和内容区域', () => {
    const { container } = render(HTGroup, {
      props: {
        title: 'Test Title',
      },
      slots: {
        default: 'Test Content',
      },
    });

    const titleElement = container.querySelector('.cell-group-title');
    const contentElement = container.querySelector('.cell-group-content');

    expect(titleElement).toBeTruthy();
    expect(contentElement).toBeTruthy();
    expect(titleElement?.textContent).toBe('Test Title');
    expect(contentElement?.textContent).toBe('Test Content');
  });

  it('应该支持inset属性', () => {
    const { container } = render(HTGroup, {
      props: {
        inset: true,
      },
      slots: {
        default: 'Content',
      },
    });

    const group = container.querySelector('.cell-group');
    expect(group?.classList.contains('cell-group-inset')).toBe(true);
  });

  it('应该支持border属性', () => {
    const { container } = render(HTGroup, {
      props: {
        border: false,
      },
      slots: {
        default: 'Content',
      },
    });

    const group = container.querySelector('.cell-group');
    expect(group?.classList.contains('cell-group-border')).toBe(false);
  });

  it('默认应该有border', () => {
    const { container } = render(HTGroup, {
      slots: {
        default: 'Content',
      },
    });

    const group = container.querySelector('.cell-group');
    expect(group?.classList.contains('cell-group-border')).toBe(true);
  });

  it('应该支持同时设置inset和border', () => {
    const { container } = render(HTGroup, {
      props: {
        inset: true,
        border: true,
      },
      slots: {
        default: 'Content',
      },
    });

    const group = container.querySelector('.cell-group');
    expect(group?.classList.contains('cell-group-inset')).toBe(true);
    expect(group?.classList.contains('cell-group-border')).toBe(true);
  });

  it('应该支持自定义类名', () => {
    const { container } = render(HTGroup, {
      props: {
        class: 'custom-class',
      },
      slots: {
        default: 'Content',
      },
    });

    const group = container.querySelector('.cell-group');
    expect(group?.classList.contains('custom-class')).toBe(true);
  });

  it('没有标题时不应该渲染标题元素', () => {
    const { container } = render(HTGroup, {
      slots: {
        default: 'Content only',
      },
    });

    const titleElement = container.querySelector('.cell-group-title');
    expect(titleElement).toBeFalsy();
    expect(screen.getByText('Content only')).toBeTruthy();
  });

  it('应该支持复杂的插槽内容', () => {
    render(HTGroup, {
      props: {
        title: 'Complex Group',
      },
      slots: {
        default: `
          <div class="item">Item 1</div>
          <div class="item">Item 2</div>
          <div class="item">Item 3</div>
        `,
      },
    });

    expect(screen.getByText('Complex Group')).toBeTruthy();
    expect(screen.getByText('Item 1')).toBeTruthy();
    expect(screen.getByText('Item 2')).toBeTruthy();
    expect(screen.getByText('Item 3')).toBeTruthy();
  });
});
