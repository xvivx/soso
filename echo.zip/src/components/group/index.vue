<script setup lang="ts">
import { computed } from 'vue';
import { cn } from '@/utils';
import { groupVariants } from './constants';
import type { GroupProps } from './types';

const props = withDefaults(defineProps<GroupProps>(), {
  border: true,
});

const classes = computed(() => cn(groupVariants({ inset: props.inset, border: props.border }), props.class));
</script>

<template>
  <div :class="classes">
    <div v-if="props.title" class="cell-group-title">{{ props.title }}</div>
    <div class="cell-group-content">
      <slot />
    </div>
  </div>
</template>

<style>
@import './style/index.css';
</style>
