import { cva } from 'class-variance-authority';

export const groupVariants = cva('cell-group', {
  variants: {
    inset: {
      true: 'cell-group-inset',
    },
    border: {
      true: 'cell-group-border',
    },
  },
  defaultVariants: {
    border: true,
  },
});
