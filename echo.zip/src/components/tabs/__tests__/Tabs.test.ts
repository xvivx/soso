import { nextTick } from 'vue';
import { mount } from '@vue/test-utils';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import HTTab from '../Tab.vue';
import HTTabs from '../Tabs.vue';

describe('HTTabs', () => {
  beforeEach(() => {
    document.body.innerHTML = '';
  });

  describe('基础渲染', () => {
    it('应该正确渲染默认 tabs', () => {
      const wrapper = mount(HTTabs, {
        slots: {
          default: `
            <ht-tab title="标签 1">内容 1</ht-tab>
            <ht-tab title="标签 2">内容 2</ht-tab>
            <ht-tab title="标签 3">内容 3</ht-tab>
          `,
        },
        global: {
          components: { 'ht-tab': HTTab },
        },
      });

      expect(wrapper.find('.ht-tabs').exists()).toBe(true);
      expect(wrapper.find('.ht-tabs--line').exists()).toBe(true);
      expect(wrapper.find('.ht-tabs__wrap').exists()).toBe(true);
      expect(wrapper.find('.ht-tabs__nav').exists()).toBe(true);
    });

    it('应该正确渲染 card 类型', () => {
      const wrapper = mount(HTTabs, {
        props: {
          type: 'card',
        },
        slots: {
          default: `
            <ht-tab title="标签 1">内容 1</ht-tab>
            <ht-tab title="标签 2">内容 2</ht-tab>
          `,
        },
        global: {
          components: { 'ht-tab': HTTab },
        },
      });

      expect(wrapper.find('.ht-tabs--card').exists()).toBe(true);
      expect(wrapper.find('.ht-tabs__nav--card').exists()).toBe(true);
    });

    it('应该支持自定义 class', () => {
      const wrapper = mount(HTTabs, {
        props: {
          className: 'custom-tabs-class',
        },
        slots: {
          default: `
            <ht-tab title="标签 1">内容 1</ht-tab>
          `,
        },
        global: {
          components: { 'ht-tab': HTTab },
        },
      });

      expect(wrapper.find('.custom-tabs-class').exists()).toBe(true);
    });

    it('应该正确渲染 tab 标题', async () => {
      const wrapper = mount(HTTabs, {
        slots: {
          default: `
            <ht-tab title="标签 1">内容 1</ht-tab>
            <ht-tab title="标签 2">内容 2</ht-tab>
            <ht-tab title="标签 3">内容 3</ht-tab>
          `,
        },
        global: {
          components: { 'ht-tab': HTTab },
        },
      });

      await nextTick();

      const tabs = wrapper.findAll('.ht-tabs__tab');
      expect(tabs).toHaveLength(3);
      expect(tabs[0].text()).toContain('标签 1');
      expect(tabs[1].text()).toContain('标签 2');
      expect(tabs[2].text()).toContain('标签 3');
    });
  });

  describe('激活状态', () => {
    it('应该默认激活第一个 tab', async () => {
      const wrapper = mount(HTTabs, {
        slots: {
          default: `
            <ht-tab title="标签 1">内容 1</ht-tab>
            <ht-tab title="标签 2">内容 2</ht-tab>
          `,
        },
        global: {
          components: { 'ht-tab': HTTab },
        },
      });

      await nextTick();

      const firstTab = wrapper.findAll('.ht-tabs__tab')[0];
      expect(firstTab.classes()).toContain('ht-tabs__tab--active');
      expect(firstTab.attributes('aria-selected')).toBe('true');
    });

    it('应该支持通过 active 属性设置激活的 tab', async () => {
      const wrapper = mount(HTTabs, {
        props: {
          active: 1,
        },
        slots: {
          default: `
            <ht-tab title="标签 1">内容 1</ht-tab>
            <ht-tab title="标签 2">内容 2</ht-tab>
            <ht-tab title="标签 3">内容 3</ht-tab>
          `,
        },
        global: {
          components: { 'ht-tab': HTTab },
        },
      });

      await nextTick();

      const tabs = wrapper.findAll('.ht-tabs__tab');
      expect(tabs[1].classes()).toContain('ht-tabs__tab--active');
    });

    it('应该支持通过 name 设置激活的 tab', async () => {
      const wrapper = mount(HTTabs, {
        props: {
          active: 'tab2',
        },
        slots: {
          default: `
            <ht-tab name="tab1" title="标签 1">内容 1</ht-tab>
            <ht-tab name="tab2" title="标签 2">内容 2</ht-tab>
            <ht-tab name="tab3" title="标签 3">内容 3</ht-tab>
          `,
        },
        global: {
          components: { 'ht-tab': HTTab },
        },
      });

      await nextTick();

      const tabs = wrapper.findAll('.ht-tabs__tab');
      expect(tabs[1].classes()).toContain('ht-tabs__tab--active');
    });

    it('应该正确显示激活 tab 的内容', async () => {
      const wrapper = mount(HTTabs, {
        props: {
          active: 1,
        },
        slots: {
          default: `
            <ht-tab title="标签 1">内容 1</ht-tab>
            <ht-tab title="标签 2">内容 2</ht-tab>
          `,
        },
        global: {
          components: { 'ht-tab': HTTab },
        },
      });

      await nextTick();

      const tabs = wrapper.findAll('.ht-tab');
      expect(tabs[1].classes()).toContain('ht-tab--active');
    });
  });

  describe('交互行为', () => {
    it('应该响应点击切换 tab', async () => {
      const wrapper = mount(HTTabs, {
        slots: {
          default: `
            <ht-tab title="标签 1">内容 1</ht-tab>
            <ht-tab title="标签 2">内容 2</ht-tab>
            <ht-tab title="标签 3">内容 3</ht-tab>
          `,
        },
        global: {
          components: { 'ht-tab': HTTab },
        },
      });

      await nextTick();

      const tabs = wrapper.findAll('.ht-tabs__tab');

      // 默认第一个激活
      expect(tabs[0].classes()).toContain('ht-tabs__tab--active');

      // 点击第二个 tab
      await tabs[1].trigger('click');
      await nextTick();

      expect(tabs[0].classes()).not.toContain('ht-tabs__tab--active');
      expect(tabs[1].classes()).toContain('ht-tabs__tab--active');

      // 点击第三个 tab
      await tabs[2].trigger('click');
      await nextTick();

      expect(tabs[1].classes()).not.toContain('ht-tabs__tab--active');
      expect(tabs[2].classes()).toContain('ht-tabs__tab--active');
    });

    it('应该触发 change 事件', async () => {
      const handleChange = vi.fn();

      const wrapper = mount(HTTabs, {
        props: {
          onChange: handleChange,
        },
        slots: {
          default: `
            <ht-tab name="tab1" title="标签 1">内容 1</ht-tab>
            <ht-tab name="tab2" title="标签 2">内容 2</ht-tab>
          `,
        },
        global: {
          components: { 'ht-tab': HTTab },
        },
      });

      await nextTick();

      const tabs = wrapper.findAll('.ht-tabs__tab');
      await tabs[1].trigger('click');
      await nextTick();

      expect(handleChange).toHaveBeenCalledWith('tab2', '标签 2');
    });

    it('应该触发 update:active 事件', async () => {
      const wrapper = mount(HTTabs, {
        slots: {
          default: `
            <ht-tab name="tab1" title="标签 1">内容 1</ht-tab>
            <ht-tab name="tab2" title="标签 2">内容 2</ht-tab>
          `,
        },
        global: {
          components: { 'ht-tab': HTTab },
        },
      });

      await nextTick();

      const tabs = wrapper.findAll('.ht-tabs__tab');
      await tabs[1].trigger('click');
      await nextTick();

      const emitted = wrapper.emitted('update:active');
      expect(emitted).toBeTruthy();
      expect(emitted![0]).toEqual(['tab2']);
    });

    it('应该触发 clickTab 事件', async () => {
      const handleClickTab = vi.fn();

      const wrapper = mount(HTTabs, {
        props: {
          onClickTab: handleClickTab,
        },
        slots: {
          default: `
            <ht-tab name="tab1" title="标签 1">内容 1</ht-tab>
            <ht-tab name="tab2" title="标签 2">内容 2</ht-tab>
          `,
        },
        global: {
          components: { 'ht-tab': HTTab },
        },
      });

      await nextTick();

      const tabs = wrapper.findAll('.ht-tabs__tab');
      await tabs[1].trigger('click');
      await nextTick();

      expect(handleClickTab).toHaveBeenCalled();
      const callArgs = handleClickTab.mock.calls[0][0];
      expect(callArgs.name).toBe('tab2');
      expect(callArgs.title).toBe('标签 2');
      expect(callArgs.disabled).toBe(false);
    });

    it('不应该在切换到相同 tab 时触发事件', async () => {
      const handleChange = vi.fn();

      const wrapper = mount(HTTabs, {
        props: {
          onChange: handleChange,
        },
        slots: {
          default: `
            <ht-tab title="标签 1">内容 1</ht-tab>
            <ht-tab title="标签 2">内容 2</ht-tab>
          `,
        },
        global: {
          components: { 'ht-tab': HTTab },
        },
      });

      await nextTick();

      const tabs = wrapper.findAll('.ht-tabs__tab');

      // 点击当前已激活的 tab
      await tabs[0].trigger('click');
      await nextTick();

      expect(handleChange).not.toHaveBeenCalled();
    });
  });

  describe('禁用状态', () => {
    it('应该正确渲染禁用的 tab', async () => {
      const wrapper = mount(HTTabs, {
        slots: {
          default: `
            <ht-tab title="标签 1">内容 1</ht-tab>
            <ht-tab title="标签 2" disabled>内容 2</ht-tab>
            <ht-tab title="标签 3">内容 3</ht-tab>
          `,
        },
        global: {
          components: { 'ht-tab': HTTab },
        },
      });

      await nextTick();

      const tabs = wrapper.findAll('.ht-tabs__tab');
      expect(tabs[1].classes()).toContain('ht-tabs__tab--disabled');
      expect(tabs[1].attributes('aria-disabled')).toBe('true');
    });

    it('不应该切换到禁用的 tab', async () => {
      const handleChange = vi.fn();

      const wrapper = mount(HTTabs, {
        props: {
          onChange: handleChange,
        },
        slots: {
          default: `
            <ht-tab title="标签 1">内容 1</ht-tab>
            <ht-tab title="标签 2" disabled>内容 2</ht-tab>
          `,
        },
        global: {
          components: { 'ht-tab': HTTab },
        },
      });

      await nextTick();

      const tabs = wrapper.findAll('.ht-tabs__tab');

      // 点击禁用的 tab
      await tabs[1].trigger('click');
      await nextTick();

      expect(handleChange).not.toHaveBeenCalled();
      expect(tabs[0].classes()).toContain('ht-tabs__tab--active');
      expect(tabs[1].classes()).not.toContain('ht-tabs__tab--active');
    });

    it('应该允许点击禁用的 tab 但不切换', async () => {
      const handleClickTab = vi.fn();

      const wrapper = mount(HTTabs, {
        props: {
          onClickTab: handleClickTab,
        },
        slots: {
          default: `
            <ht-tab title="标签 1">内容 1</ht-tab>
            <ht-tab title="标签 2" disabled>内容 2</ht-tab>
          `,
        },
        global: {
          components: { 'ht-tab': HTTab },
        },
      });

      await nextTick();

      const tabs = wrapper.findAll('.ht-tabs__tab');
      await tabs[1].trigger('click');
      await nextTick();

      // clickTab 事件应该被触发
      expect(handleClickTab).toHaveBeenCalled();
      const callArgs = handleClickTab.mock.calls[0][0];
      expect(callArgs.disabled).toBe(true);

      // 但不应该切换
      expect(tabs[0].classes()).toContain('ht-tabs__tab--active');
    });
  });

  describe('Badge 和 Dot', () => {
    it('应该正确渲染 badge', async () => {
      const wrapper = mount(HTTabs, {
        slots: {
          default: `
            <ht-tab title="标签 1" badge="5">内容 1</ht-tab>
            <ht-tab title="标签 2" badge="99+">内容 2</ht-tab>
          `,
        },
        global: {
          components: { 'ht-tab': HTTab },
        },
      });

      await nextTick();

      const badges = wrapper.findAll('.ht-tabs__tab-badge');
      expect(badges).toHaveLength(2);
      expect(badges[0].text()).toBe('5');
      expect(badges[1].text()).toBe('99+');
    });

    it('应该正确渲染 dot', async () => {
      const wrapper = mount(HTTabs, {
        slots: {
          default: `
            <ht-tab title="标签 1" dot>内容 1</ht-tab>
            <ht-tab title="标签 2">内容 2</ht-tab>
          `,
        },
        global: {
          components: { 'ht-tab': HTTab },
        },
      });

      await nextTick();

      const dots = wrapper.findAll('.ht-tabs__tab-dot');
      expect(dots).toHaveLength(1);
    });

    it('应该同时支持 badge 和 title', async () => {
      const wrapper = mount(HTTabs, {
        slots: {
          default: `
            <ht-tab title="消息" badge="10">内容 1</ht-tab>
          `,
        },
        global: {
          components: { 'ht-tab': HTTab },
        },
      });

      await nextTick();

      const tab = wrapper.find('.ht-tabs__tab');
      expect(tab.text()).toContain('消息');
      expect(tab.text()).toContain('10');
    });
  });

  describe('样式配置', () => {
    it('应该支持自定义颜色', async () => {
      const wrapper = mount(HTTabs, {
        props: {
          color: '#ff0000',
        },
        slots: {
          default: `
            <ht-tab title="标签 1">内容 1</ht-tab>
          `,
        },
        global: {
          components: { 'ht-tab': HTTab },
        },
      });

      await nextTick();

      const nav = wrapper.find('.ht-tabs__nav');
      expect(nav.attributes('style')).toContain('border-color: rgb(255, 0, 0)');
    });

    it('应该支持自定义背景色', async () => {
      const wrapper = mount(HTTabs, {
        props: {
          background: '#f5f5f5',
        },
        slots: {
          default: `
            <ht-tab title="标签 1">内容 1</ht-tab>
          `,
        },
        global: {
          components: { 'ht-tab': HTTab },
        },
      });

      await nextTick();

      const nav = wrapper.find('.ht-tabs__nav');
      expect(nav.attributes('style')).toContain('background: rgb(245, 245, 245)');
    });

    it('应该支持自定义线条宽度', async () => {
      const wrapper = mount(HTTabs, {
        props: {
          type: 'line',
          lineWidth: 60,
        },
        slots: {
          default: `
            <ht-tab title="标签 1">内容 1</ht-tab>
          `,
        },
        global: {
          components: { 'ht-tab': HTTab },
        },
      });

      await nextTick();
      await nextTick();
      await nextTick();
      await nextTick();

      const line = wrapper.find('.ht-tabs__line');
      expect(line.exists()).toBe(true);
      const style = line.attributes('style');
      expect(style).toBeDefined();
      expect(style).toContain('width: 60px');
    });

    it('应该支持自定义线条高度', async () => {
      const wrapper = mount(HTTabs, {
        props: {
          type: 'line',
          lineHeight: 4,
        },
        slots: {
          default: `
            <ht-tab title="标签 1">内容 1</ht-tab>
          `,
        },
        global: {
          components: { 'ht-tab': HTTab },
        },
      });

      await nextTick();
      await nextTick();
      await nextTick();
      await nextTick();

      const line = wrapper.find('.ht-tabs__line');
      expect(line.exists()).toBe(true);
      const style = line.attributes('style');
      expect(style).toBeDefined();
      expect(style).toContain('height: 4px');
    });

    it('应该应用 shrink 样式', async () => {
      const wrapper = mount(HTTabs, {
        props: {
          shrink: true,
        },
        slots: {
          default: `
            <ht-tab title="标签 1">内容 1</ht-tab>
            <ht-tab title="标签 2">内容 2</ht-tab>
          `,
        },
        global: {
          components: { 'ht-tab': HTTab },
        },
      });

      await nextTick();

      const nav = wrapper.find('.ht-tabs__nav');
      expect(nav.classes()).toContain('ht-tabs__nav--shrink');
    });

    it('应该支持 ellipsis 配置', async () => {
      const wrapper = mount(HTTabs, {
        props: {
          ellipsis: true,
        },
        slots: {
          default: `
            <ht-tab title="这是一个很长的标签标题">内容 1</ht-tab>
          `,
        },
        global: {
          components: { 'ht-tab': HTTab },
        },
      });

      await nextTick();

      const tabText = wrapper.find('.ht-tabs__tab-text');
      expect(tabText.exists()).toBe(true);
      expect(tabText.classes()).toContain('ht-tabs__tab-text--ellipsis');
    });
  });

  describe('插槽', () => {
    it('应该支持 nav-left 插槽', async () => {
      const wrapper = mount(HTTabs, {
        slots: {
          default: `
            <ht-tab title="标签 1">内容 1</ht-tab>
          `,
          'nav-left': '<div class="custom-nav-left">左侧内容</div>',
        },
        global: {
          components: { 'ht-tab': HTTab },
        },
      });

      await nextTick();

      expect(wrapper.find('.custom-nav-left').exists()).toBe(true);
      expect(wrapper.text()).toContain('左侧内容');
    });

    it('应该支持 nav-right 插槽', async () => {
      const wrapper = mount(HTTabs, {
        slots: {
          default: `
            <ht-tab title="标签 1">内容 1</ht-tab>
          `,
          'nav-right': '<div class="custom-nav-right">右侧内容</div>',
        },
        global: {
          components: { 'ht-tab': HTTab },
        },
      });

      await nextTick();

      expect(wrapper.find('.custom-nav-right').exists()).toBe(true);
      expect(wrapper.text()).toContain('右侧内容');
    });
  });

  describe('beforeChange 钩子', () => {
    it('应该支持同步 beforeChange 返回 true', async () => {
      const beforeChange = vi.fn(() => true);
      const handleChange = vi.fn();

      const wrapper = mount(HTTabs, {
        props: {
          beforeChange,
          onChange: handleChange,
        },
        slots: {
          default: `
            <ht-tab title="标签 1">内容 1</ht-tab>
            <ht-tab title="标签 2">内容 2</ht-tab>
          `,
        },
        global: {
          components: { 'ht-tab': HTTab },
        },
      });

      await nextTick();

      const tabs = wrapper.findAll('.ht-tabs__tab');
      await tabs[1].trigger('click');
      await nextTick();

      expect(beforeChange).toHaveBeenCalledWith(1);
      expect(handleChange).toHaveBeenCalled();
      expect(tabs[1].classes()).toContain('ht-tabs__tab--active');
    });

    it('应该支持同步 beforeChange 返回 false', async () => {
      const beforeChange = vi.fn(() => false);
      const handleChange = vi.fn();

      const wrapper = mount(HTTabs, {
        props: {
          beforeChange,
          onChange: handleChange,
        },
        slots: {
          default: `
            <ht-tab title="标签 1">内容 1</ht-tab>
            <ht-tab title="标签 2">内容 2</ht-tab>
          `,
        },
        global: {
          components: { 'ht-tab': HTTab },
        },
      });

      await nextTick();

      const tabs = wrapper.findAll('.ht-tabs__tab');
      await tabs[1].trigger('click');
      await nextTick();

      expect(beforeChange).toHaveBeenCalledWith(1);
      expect(handleChange).not.toHaveBeenCalled();
      expect(tabs[0].classes()).toContain('ht-tabs__tab--active');
      expect(tabs[1].classes()).not.toContain('ht-tabs__tab--active');
    });

    it('应该支持异步 beforeChange', async () => {
      const beforeChange = vi.fn(() => Promise.resolve(true));
      const handleChange = vi.fn();

      const wrapper = mount(HTTabs, {
        props: {
          beforeChange,
          onChange: handleChange,
        },
        slots: {
          default: `
            <ht-tab title="标签 1">内容 1</ht-tab>
            <ht-tab title="标签 2">内容 2</ht-tab>
          `,
        },
        global: {
          components: { 'ht-tab': HTTab },
        },
      });

      await nextTick();

      const tabs = wrapper.findAll('.ht-tabs__tab');
      await tabs[1].trigger('click');
      await nextTick();
      await nextTick(); // 等待 Promise resolve

      expect(beforeChange).toHaveBeenCalled();
      expect(handleChange).toHaveBeenCalled();
      expect(tabs[1].classes()).toContain('ht-tabs__tab--active');
    });

    it('应该支持异步 beforeChange 拒绝', async () => {
      const beforeChange = vi.fn(() => Promise.resolve(false));
      const handleChange = vi.fn();

      const wrapper = mount(HTTabs, {
        props: {
          beforeChange,
          onChange: handleChange,
        },
        slots: {
          default: `
            <ht-tab title="标签 1">内容 1</ht-tab>
            <ht-tab title="标签 2">内容 2</ht-tab>
          `,
        },
        global: {
          components: { 'ht-tab': HTTab },
        },
      });

      await nextTick();

      const tabs = wrapper.findAll('.ht-tabs__tab');
      await tabs[1].trigger('click');
      await nextTick();
      await nextTick(); // 等待 Promise resolve

      expect(beforeChange).toHaveBeenCalled();
      expect(handleChange).not.toHaveBeenCalled();
      expect(tabs[0].classes()).toContain('ht-tabs__tab--active');
    });
  });

  describe('方法调用', () => {
    it('应该支持 scrollTo 方法', async () => {
      const wrapper = mount(HTTabs, {
        slots: {
          default: `
            <ht-tab name="tab1" title="标签 1">内容 1</ht-tab>
            <ht-tab name="tab2" title="标签 2">内容 2</ht-tab>
            <ht-tab name="tab3" title="标签 3">内容 3</ht-tab>
          `,
        },
        global: {
          components: { 'ht-tab': HTTab },
        },
      });

      await nextTick();

      // 通过 name 滚动到指定 tab
      wrapper.vm.scrollTo('tab3');
      await nextTick();

      const tabs = wrapper.findAll('.ht-tabs__tab');
      expect(tabs[2].classes()).toContain('ht-tabs__tab--active');
    });

    it('应该支持 resize 方法', async () => {
      const wrapper = mount(HTTabs, {
        slots: {
          default: `
            <ht-tab title="标签 1">内容 1</ht-tab>
            <ht-tab title="标签 2">内容 2</ht-tab>
          `,
        },
        global: {
          components: { 'ht-tab': HTTab },
        },
      });

      await nextTick();

      // 调用 resize 方法
      expect(() => wrapper.vm.resize()).not.toThrow();
    });
  });

  describe('响应式更新', () => {
    it('应该响应 active prop 变化', async () => {
      const wrapper = mount(HTTabs, {
        props: {
          active: 0,
        },
        slots: {
          default: `
            <ht-tab title="标签 1">内容 1</ht-tab>
            <ht-tab title="标签 2">内容 2</ht-tab>
            <ht-tab title="标签 3">内容 3</ht-tab>
          `,
        },
        global: {
          components: { 'ht-tab': HTTab },
        },
      });

      await nextTick();

      let tabs = wrapper.findAll('.ht-tabs__tab');
      expect(tabs[0].classes()).toContain('ht-tabs__tab--active');

      // 更新 active prop
      await wrapper.setProps({ active: 2 });
      await nextTick();

      tabs = wrapper.findAll('.ht-tabs__tab');
      expect(tabs[0].classes()).not.toContain('ht-tabs__tab--active');
      expect(tabs[2].classes()).toContain('ht-tabs__tab--active');
    });

    it('应该响应颜色 prop 变化', async () => {
      const wrapper = mount(HTTabs, {
        props: {
          type: 'line',
          color: '#ff0000',
        },
        slots: {
          default: `
            <ht-tab title="标签 1">内容 1</ht-tab>
          `,
        },
        global: {
          components: { 'ht-tab': HTTab },
        },
      });

      await nextTick();
      await nextTick();

      // 更新颜色
      await wrapper.setProps({ color: '#00ff00' });
      await nextTick();

      const nav = wrapper.find('.ht-tabs__nav');
      expect(nav.attributes('style')).toContain('border-color: rgb(0, 255, 0)');
    });
  });

  describe('showHeader 配置', () => {
    it('应该支持隐藏头部', () => {
      const wrapper = mount(HTTabs, {
        props: {
          showHeader: false,
        },
        slots: {
          default: `
            <ht-tab title="标签 1">内容 1</ht-tab>
            <ht-tab title="标签 2">内容 2</ht-tab>
          `,
        },
        global: {
          components: { 'ht-tab': HTTab },
        },
      });

      expect(wrapper.find('.ht-tabs__wrap').exists()).toBe(false);
      expect(wrapper.find('.ht-tabs__content').exists()).toBe(true);
    });
  });

  describe('可访问性', () => {
    it('应该有正确的 ARIA 属性', async () => {
      const wrapper = mount(HTTabs, {
        slots: {
          default: `
            <ht-tab title="标签 1">内容 1</ht-tab>
            <ht-tab title="标签 2">内容 2</ht-tab>
          `,
        },
        global: {
          components: { 'ht-tab': HTTab },
        },
      });

      await nextTick();

      const nav = wrapper.find('.ht-tabs__nav');
      expect(nav.attributes('role')).toBe('tablist');

      const tabs = wrapper.findAll('.ht-tabs__tab');
      tabs.forEach((tab) => {
        expect(tab.attributes('role')).toBe('tab');
        expect(tab.attributes('aria-selected')).toBeDefined();
      });

      const panels = wrapper.findAll('.ht-tab');
      panels.forEach((panel) => {
        expect(panel.attributes('role')).toBe('tabpanel');
        expect(panel.attributes('aria-hidden')).toBeDefined();
      });
    });
  });

  describe('sticky 吸顶', () => {
    it('应该支持 sticky 属性', async () => {
      const wrapper = mount(HTTabs, {
        props: {
          sticky: true,
        },
        slots: {
          default: `
            <ht-tab title="标签 1">内容 1</ht-tab>
            <ht-tab title="标签 2">内容 2</ht-tab>
          `,
        },
        global: {
          components: { 'ht-tab': HTTab },
        },
      });

      await nextTick();

      // sticky 组件应该存在
      expect(wrapper.find('.sticky').exists()).toBe(true);
    });

    it('应该支持自定义 offsetTop', async () => {
      const wrapper = mount(HTTabs, {
        props: {
          sticky: true,
          offsetTop: 50,
        },
        slots: {
          default: `
            <ht-tab title="标签 1">内容 1</ht-tab>
            <ht-tab title="标签 2">内容 2</ht-tab>
          `,
        },
        global: {
          components: { 'ht-tab': HTTab },
        },
      });

      await nextTick();

      expect(wrapper.find('.sticky').exists()).toBe(true);
    });

    it('应该触发 scroll 事件', async () => {
      const handleScroll = vi.fn();

      const wrapper = mount(HTTabs, {
        props: {
          sticky: true,
          onScroll: handleScroll,
        },
        slots: {
          default: `
            <ht-tab title="标签 1">内容 1</ht-tab>
            <ht-tab title="标签 2">内容 2</ht-tab>
          `,
        },
        global: {
          components: { 'ht-tab': HTTab },
        },
      });

      await nextTick();

      // 注意：实际的 scroll 事件需要真实的滚动才能触发
      // 这里只是检查事件处理器是否正确绑定
      expect(wrapper.find('.sticky').exists()).toBe(true);
    });

    it('非 sticky 模式不应该渲染 sticky 组件', async () => {
      const wrapper = mount(HTTabs, {
        props: {
          sticky: false,
        },
        slots: {
          default: `
            <ht-tab title="标签 1">内容 1</ht-tab>
            <ht-tab title="标签 2">内容 2</ht-tab>
          `,
        },
        global: {
          components: { 'ht-tab': HTTab },
        },
      });

      await nextTick();

      expect(wrapper.find('.sticky').exists()).toBe(false);
    });
  });

  describe('swipeable 和 animated', () => {
    it('应该支持 swipeable 属性', async () => {
      const wrapper = mount(HTTabs, {
        props: {
          swipeable: true,
        },
        slots: {
          default: `
            <ht-tab title="标签 1">内容 1</ht-tab>
            <ht-tab title="标签 2">内容 2</ht-tab>
            <ht-tab title="标签 3">内容 3</ht-tab>
          `,
        },
        global: {
          components: { 'ht-tab': HTTab },
        },
      });

      await nextTick();

      // 应该渲染 TabsContent 和 Swipe 组件
      expect(wrapper.find('.ht-tabs__content').exists()).toBe(true);
      expect(wrapper.find('.ht-tabs__content--animated').exists()).toBe(true);
    });

    it('应该支持 animated 属性', async () => {
      const wrapper = mount(HTTabs, {
        props: {
          animated: true,
        },
        slots: {
          default: `
            <ht-tab title="标签 1">内容 1</ht-tab>
            <ht-tab title="标签 2">内容 2</ht-tab>
          `,
        },
        global: {
          components: { 'ht-tab': HTTab },
        },
      });

      await nextTick();

      expect(wrapper.find('.ht-tabs__content--animated').exists()).toBe(true);
    });

    it('应该同时支持 swipeable 和 animated', async () => {
      const wrapper = mount(HTTabs, {
        props: {
          swipeable: true,
          animated: true,
        },
        slots: {
          default: `
            <ht-tab title="标签 1">内容 1</ht-tab>
            <ht-tab title="标签 2">内容 2</ht-tab>
          `,
        },
        global: {
          components: { 'ht-tab': HTTab },
        },
      });

      await nextTick();

      expect(wrapper.find('.ht-tabs__content--animated').exists()).toBe(true);
    });

    it('应该支持自定义 duration', async () => {
      const wrapper = mount(HTTabs, {
        props: {
          animated: true,
          duration: 0.5,
        },
        slots: {
          default: `
            <ht-tab title="标签 1">内容 1</ht-tab>
            <ht-tab title="标签 2">内容 2</ht-tab>
          `,
        },
        global: {
          components: { 'ht-tab': HTTab },
        },
      });

      await nextTick();

      // duration 应该传递给 TabsContent
      expect(wrapper.find('.ht-tabs__content').exists()).toBe(true);
    });

    it('swipeable 模式下点击 tab 应该正常切换', async () => {
      const handleChange = vi.fn();

      const wrapper = mount(HTTabs, {
        props: {
          swipeable: true,
          onChange: handleChange,
        },
        slots: {
          default: `
            <ht-tab title="标签 1">内容 1</ht-tab>
            <ht-tab title="标签 2">内容 2</ht-tab>
            <ht-tab title="标签 3">内容 3</ht-tab>
          `,
        },
        global: {
          components: { 'ht-tab': HTTab },
        },
      });

      await nextTick();
      await nextTick();

      const tabs = wrapper.findAll('.ht-tabs__tab');
      await tabs[1].trigger('click');
      await nextTick();
      await nextTick();

      expect(handleChange).toHaveBeenCalledWith(1, '标签 2');
      expect(tabs[1].classes()).toContain('ht-tabs__tab--active');
    });
  });

  describe('边界情况', () => {
    it('应该处理空内容', () => {
      const wrapper = mount(HTTabs);

      expect(wrapper.find('.ht-tabs').exists()).toBe(true);
    });

    it('应该处理单个 tab', async () => {
      const wrapper = mount(HTTabs, {
        slots: {
          default: `
            <ht-tab title="唯一标签">唯一内容</ht-tab>
          `,
        },
        global: {
          components: { 'ht-tab': HTTab },
        },
      });

      await nextTick();

      const tabs = wrapper.findAll('.ht-tabs__tab');
      expect(tabs).toHaveLength(1);
      expect(tabs[0].classes()).toContain('ht-tabs__tab--active');
    });

    it('应该处理超出范围的 active 值', async () => {
      const wrapper = mount(HTTabs, {
        props: {
          active: 999,
        },
        slots: {
          default: `
            <ht-tab title="标签 1">内容 1</ht-tab>
            <ht-tab title="标签 2">内容 2</ht-tab>
          `,
        },
        global: {
          components: { 'ht-tab': HTTab },
        },
      });

      await nextTick();

      // 应该回退到第一个 tab
      const tabs = wrapper.findAll('.ht-tabs__tab');
      expect(tabs[0].classes()).toContain('ht-tabs__tab--active');
    });

    it('应该处理不存在的 name 值', async () => {
      const wrapper = mount(HTTabs, {
        props: {
          active: 'non-existent',
        },
        slots: {
          default: `
            <ht-tab name="tab1" title="标签 1">内容 1</ht-tab>
            <ht-tab name="tab2" title="标签 2">内容 2</ht-tab>
          `,
        },
        global: {
          components: { 'ht-tab': HTTab },
        },
      });

      await nextTick();

      // 应该回退到第一个 tab
      const tabs = wrapper.findAll('.ht-tabs__tab');
      expect(tabs[0].classes()).toContain('ht-tabs__tab--active');
    });
  });

  describe('rendered 事件', () => {
    it('应该在 tab 首次渲染时触发 rendered 事件', async () => {
      const handleRendered = vi.fn();

      mount(HTTabs, {
        props: {
          lazyRender: true,
          onRendered: handleRendered,
        },
        slots: {
          default: `
            <ht-tab name="tab1" title="标签 1">内容 1</ht-tab>
            <ht-tab name="tab2" title="标签 2">内容 2</ht-tab>
          `,
        },
        global: {
          components: { 'ht-tab': HTTab },
        },
      });

      await nextTick();
      await nextTick();

      // 第一个 tab 默认激活，应该触发 rendered
      expect(handleRendered).toHaveBeenCalled();
    });
  });
});
