import { nextTick } from 'vue';
import { mount } from '@vue/test-utils';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import HTTab from '../Tab.vue';
import HTTabs from '../Tabs.vue';

describe('HTTab', () => {
  beforeEach(() => {
    document.body.innerHTML = '';
  });

  describe('基础渲染', () => {
    it('应该正确渲染在 Tabs 组件内', async () => {
      const wrapper = mount(HTTabs, {
        slots: {
          default: `
            <ht-tab title="标签 1">内容 1</ht-tab>
            <ht-tab title="标签 2">内容 2</ht-tab>
          `,
        },
        global: {
          components: { 'ht-tab': HTTab },
        },
      });

      await nextTick();

      const tabs = wrapper.findAll('.ht-tab');
      expect(tabs).toHaveLength(2);
    });

    it('应该显示插槽内容', async () => {
      const wrapper = mount(HTTabs, {
        slots: {
          default: `
            <ht-tab title="标签 1">这是标签 1 的内容</ht-tab>
          `,
        },
        global: {
          components: { 'ht-tab': HTTab },
        },
      });

      await nextTick();

      expect(wrapper.text()).toContain('这是标签 1 的内容');
    });

    it('应该有正确的基础类名', async () => {
      const wrapper = mount(HTTabs, {
        slots: {
          default: `
            <ht-tab title="标签 1">内容 1</ht-tab>
          `,
        },
        global: {
          components: { 'ht-tab': HTTab },
        },
      });

      await nextTick();

      const tab = wrapper.find('.ht-tab');
      expect(tab.exists()).toBe(true);
    });

    it('应该支持自定义 className', async () => {
      const wrapper = mount(HTTabs, {
        slots: {
          default: `
            <ht-tab title="标签 1" class-name="custom-tab-class">内容 1</ht-tab>
          `,
        },
        global: {
          components: { 'ht-tab': HTTab },
        },
      });

      await nextTick();

      expect(wrapper.find('.custom-tab-class').exists()).toBe(true);
    });
  });

  describe('激活状态', () => {
    it('默认应该激活第一个 tab', async () => {
      const wrapper = mount(HTTabs, {
        slots: {
          default: `
            <ht-tab title="标签 1">内容 1</ht-tab>
            <ht-tab title="标签 2">内容 2</ht-tab>
          `,
        },
        global: {
          components: { 'ht-tab': HTTab },
        },
      });

      await nextTick();

      const tabs = wrapper.findAll('.ht-tab');
      expect(tabs[0].classes()).toContain('ht-tab--active');
      expect(tabs[1].classes()).not.toContain('ht-tab--active');
    });

    it('应该根据 active prop 激活指定 tab', async () => {
      const wrapper = mount(HTTabs, {
        props: {
          active: 1,
        },
        slots: {
          default: `
            <ht-tab title="标签 1">内容 1</ht-tab>
            <ht-tab title="标签 2">内容 2</ht-tab>
          `,
        },
        global: {
          components: { 'ht-tab': HTTab },
        },
      });

      await nextTick();

      const tabs = wrapper.findAll('.ht-tab');
      expect(tabs[0].classes()).not.toContain('ht-tab--active');
      expect(tabs[1].classes()).toContain('ht-tab--active');
    });

    it('应该在切换时更新激活状态', async () => {
      const wrapper = mount(HTTabs, {
        slots: {
          default: `
            <ht-tab title="标签 1">内容 1</ht-tab>
            <ht-tab title="标签 2">内容 2</ht-tab>
          `,
        },
        global: {
          components: { 'ht-tab': HTTab },
        },
      });

      await nextTick();

      const tabHeaders = wrapper.findAll('.ht-tabs__tab');

      // 点击第二个 tab
      await tabHeaders[1].trigger('click');
      await nextTick();

      const tabContents = wrapper.findAll('.ht-tab');
      expect(tabContents[0].classes()).not.toContain('ht-tab--active');
      expect(tabContents[1].classes()).toContain('ht-tab--active');
    });
  });

  describe('懒加载', () => {
    it('默认应该支持懒加载', async () => {
      const wrapper = mount(HTTabs, {
        props: {
          lazyRender: true,
        },
        slots: {
          default: `
            <ht-tab title="标签 1">内容 1</ht-tab>
            <ht-tab title="标签 2">内容 2</ht-tab>
          `,
        },
        global: {
          components: { 'ht-tab': HTTab },
        },
      });

      await nextTick();
      await nextTick();

      const tabs = wrapper.findAll('.ht-tab');

      // 第一个 tab 应该显示
      expect(tabs[0].isVisible()).toBe(true);

      // 第二个 tab 应该隐藏（使用 v-show）
      expect(tabs[1].element.style.display).toBe('none');
    });

    it('应该在激活后渲染内容', async () => {
      const wrapper = mount(HTTabs, {
        props: {
          lazyRender: true,
        },
        slots: {
          default: `
            <ht-tab title="标签 1"><div class="content-1">内容 1</div></ht-tab>
            <ht-tab title="标签 2"><div class="content-2">内容 2</div></ht-tab>
          `,
        },
        global: {
          components: { 'ht-tab': HTTab },
        },
      });

      await nextTick();
      await nextTick();

      // 初始状态，第二个 tab 的内容不应该存在
      expect(wrapper.find('.content-2').exists()).toBe(false);

      // 点击第二个 tab
      const tabHeaders = wrapper.findAll('.ht-tabs__tab');
      await tabHeaders[1].trigger('click');
      await nextTick();
      await nextTick();

      // 现在第二个 tab 的内容应该存在
      expect(wrapper.find('.content-2').exists()).toBe(true);
    });

    it('应该支持禁用懒加载', async () => {
      const wrapper = mount(HTTabs, {
        props: {
          lazyRender: false,
        },
        slots: {
          default: `
            <ht-tab title="标签 1"><div class="content-1">内容 1</div></ht-tab>
            <ht-tab title="标签 2"><div class="content-2">内容 2</div></ht-tab>
          `,
        },
        global: {
          components: { 'ht-tab': HTTab },
        },
      });

      await nextTick();

      // 所有内容都应该渲染
      expect(wrapper.find('.content-1').exists()).toBe(true);
      expect(wrapper.find('.content-2').exists()).toBe(true);
    });
  });

  describe('Props', () => {
    it('应该支持 name 属性', async () => {
      const handleChange = vi.fn();

      const wrapper = mount(HTTabs, {
        props: {
          onChange: handleChange,
        },
        slots: {
          default: `
            <ht-tab name="custom-name" title="标签 1">内容 1</ht-tab>
            <ht-tab name="another-name" title="标签 2">内容 2</ht-tab>
          `,
        },
        global: {
          components: { 'ht-tab': HTTab },
        },
      });

      await nextTick();

      const tabHeaders = wrapper.findAll('.ht-tabs__tab');
      await tabHeaders[1].trigger('click');
      await nextTick();

      expect(handleChange).toHaveBeenCalledWith('another-name', '标签 2');
    });

    it('应该支持 title 属性', async () => {
      const wrapper = mount(HTTabs, {
        slots: {
          default: `
            <ht-tab title="自定义标题">内容 1</ht-tab>
          `,
        },
        global: {
          components: { 'ht-tab': HTTab },
        },
      });

      await nextTick();

      const tabHeader = wrapper.find('.ht-tabs__tab');
      expect(tabHeader.text()).toContain('自定义标题');
    });

    it('应该支持 disabled 属性', async () => {
      const wrapper = mount(HTTabs, {
        slots: {
          default: `
            <ht-tab title="标签 1">内容 1</ht-tab>
            <ht-tab title="标签 2" disabled>内容 2</ht-tab>
          `,
        },
        global: {
          components: { 'ht-tab': HTTab },
        },
      });

      await nextTick();

      const tabHeaders = wrapper.findAll('.ht-tabs__tab');
      expect(tabHeaders[1].classes()).toContain('ht-tabs__tab--disabled');
    });

    it('应该支持 badge 属性', async () => {
      const wrapper = mount(HTTabs, {
        slots: {
          default: `
            <ht-tab title="标签 1" badge="5">内容 1</ht-tab>
          `,
        },
        global: {
          components: { 'ht-tab': HTTab },
        },
      });

      await nextTick();

      const badge = wrapper.find('.ht-tabs__tab-badge');
      expect(badge.exists()).toBe(true);
      expect(badge.text()).toBe('5');
    });

    it('应该支持 dot 属性', async () => {
      const wrapper = mount(HTTabs, {
        slots: {
          default: `
            <ht-tab title="标签 1" dot>内容 1</ht-tab>
          `,
        },
        global: {
          components: { 'ht-tab': HTTab },
        },
      });

      await nextTick();

      const dot = wrapper.find('.ht-tabs__tab-dot');
      expect(dot.exists()).toBe(true);
    });
  });

  describe('可访问性', () => {
    it('应该有正确的 role 属性', async () => {
      const wrapper = mount(HTTabs, {
        slots: {
          default: `
            <ht-tab title="标签 1">内容 1</ht-tab>
          `,
        },
        global: {
          components: { 'ht-tab': HTTab },
        },
      });

      await nextTick();

      const tab = wrapper.find('.ht-tab');
      expect(tab.attributes('role')).toBe('tabpanel');
    });

    it('应该有正确的 aria-hidden 属性', async () => {
      const wrapper = mount(HTTabs, {
        slots: {
          default: `
            <ht-tab title="标签 1">内容 1</ht-tab>
            <ht-tab title="标签 2">内容 2</ht-tab>
          `,
        },
        global: {
          components: { 'ht-tab': HTTab },
        },
      });

      await nextTick();

      const tabs = wrapper.findAll('.ht-tab');

      // 第一个 tab 激活，应该 aria-hidden="false"
      expect(tabs[0].attributes('aria-hidden')).toBe('false');

      // 第二个 tab 未激活，应该 aria-hidden="true"
      expect(tabs[1].attributes('aria-hidden')).toBe('true');
    });

    it('切换后应该更新 aria-hidden', async () => {
      const wrapper = mount(HTTabs, {
        slots: {
          default: `
            <ht-tab title="标签 1">内容 1</ht-tab>
            <ht-tab title="标签 2">内容 2</ht-tab>
          `,
        },
        global: {
          components: { 'ht-tab': HTTab },
        },
      });

      await nextTick();

      const tabHeaders = wrapper.findAll('.ht-tabs__tab');
      await tabHeaders[1].trigger('click');
      await nextTick();

      const tabs = wrapper.findAll('.ht-tab');
      expect(tabs[0].attributes('aria-hidden')).toBe('true');
      expect(tabs[1].attributes('aria-hidden')).toBe('false');
    });
  });

  describe('显示/隐藏逻辑', () => {
    it('应该显示激活的 tab', async () => {
      const wrapper = mount(HTTabs, {
        slots: {
          default: `
            <ht-tab title="标签 1">内容 1</ht-tab>
            <ht-tab title="标签 2">内容 2</ht-tab>
          `,
        },
        global: {
          components: { 'ht-tab': HTTab },
        },
      });

      await nextTick();

      const tabs = wrapper.findAll('.ht-tab');
      expect(tabs[0].isVisible()).toBe(true);
    });

    it('应该隐藏未激活的 tab（启用懒加载时）', async () => {
      const wrapper = mount(HTTabs, {
        props: {
          lazyRender: true,
        },
        slots: {
          default: `
            <ht-tab title="标签 1">内容 1</ht-tab>
            <ht-tab title="标签 2">内容 2</ht-tab>
          `,
        },
        global: {
          components: { 'ht-tab': HTTab },
        },
      });

      await nextTick();
      await nextTick();

      const tabs = wrapper.findAll('.ht-tab');
      // 第二个 tab 应该隐藏（使用 v-show）
      expect(tabs[1].element.style.display).toBe('none');
    });

    it('应该在禁用懒加载时显示所有 tab', async () => {
      const wrapper = mount(HTTabs, {
        props: {
          lazyRender: false,
        },
        slots: {
          default: `
            <ht-tab title="标签 1">内容 1</ht-tab>
            <ht-tab title="标签 2">内容 2</ht-tab>
          `,
        },
        global: {
          components: { 'ht-tab': HTTab },
        },
      });

      await nextTick();

      const tabs = wrapper.findAll('.ht-tab');

      // 第一个是激活的，应该可见
      expect(tabs[0].classes()).toContain('ht-tab--active');
      expect(tabs[0].isVisible()).toBe(true);

      // 第二个虽然不激活，但因为禁用了懒加载，应该也可见
      expect(tabs[1].isVisible()).toBe(true);
    });
  });

  describe('边界情况', () => {
    it('应该处理空内容', async () => {
      const wrapper = mount(HTTabs, {
        slots: {
          default: `
            <ht-tab title="空标签"></ht-tab>
          `,
        },
        global: {
          components: { 'ht-tab': HTTab },
        },
      });

      await nextTick();

      const tab = wrapper.find('.ht-tab');
      expect(tab.exists()).toBe(true);
    });

    it('应该处理没有 title 的情况', async () => {
      const wrapper = mount(HTTabs, {
        slots: {
          default: `
            <ht-tab>内容</ht-tab>
          `,
        },
        global: {
          components: { 'ht-tab': HTTab },
        },
      });

      await nextTick();

      const tab = wrapper.find('.ht-tab');
      expect(tab.exists()).toBe(true);
    });

    it('应该处理动态内容', async () => {
      const wrapper = mount(
        {
          components: { HTTabs, HTTab },
          template: `
            <ht-tabs>
              <ht-tab title="标签 1"><div id="dynamic">{{ message }}</div></ht-tab>
            </ht-tabs>
          `,
          data() {
            return {
              message: '初始内容',
            };
          },
        },
        {
          global: {
            components: { HTTabs, HTTab },
          },
        }
      );

      await nextTick();

      expect(wrapper.text()).toContain('初始内容');
    });
  });

  describe('生命周期', () => {
    it('应该在挂载时注册到父组件', async () => {
      const wrapper = mount(HTTabs, {
        slots: {
          default: `
            <ht-tab title="标签 1">内容 1</ht-tab>
            <ht-tab title="标签 2">内容 2</ht-tab>
          `,
        },
        global: {
          components: { 'ht-tab': HTTab },
        },
      });

      await nextTick();

      // 验证两个 tab 都被渲染
      const tabHeaders = wrapper.findAll('.ht-tabs__tab');
      expect(tabHeaders).toHaveLength(2);
    });

    it('应该在卸载时从父组件注销', async () => {
      const wrapper = mount(
        {
          components: { 'ht-tabs': HTTabs, 'ht-tab': HTTab },
          template: `
            <ht-tabs>
              <ht-tab v-if="show" title="标签 1">内容 1</ht-tab>
              <ht-tab title="标签 2">内容 2</ht-tab>
            </ht-tabs>
          `,
          data() {
            return {
              show: true,
            };
          },
        },
        {
          global: {
            components: { 'ht-tabs': HTTabs, 'ht-tab': HTTab },
          },
        }
      );

      await nextTick();

      let tabHeaders = wrapper.findAll('.ht-tabs__tab');
      expect(tabHeaders).toHaveLength(2);

      // 移除第一个 tab
      await wrapper.setData({ show: false });
      await nextTick();

      tabHeaders = wrapper.findAll('.ht-tabs__tab');
      expect(tabHeaders).toHaveLength(1);
    });
  });

  describe('复杂内容', () => {
    it('应该支持富文本内容', async () => {
      const wrapper = mount(HTTabs, {
        slots: {
          default: `
            <ht-tab title="标签 1">
              <h1>标题</h1>
              <p>段落内容</p>
              <ul>
                <li>列表项 1</li>
                <li>列表项 2</li>
              </ul>
            </ht-tab>
          `,
        },
        global: {
          components: { 'ht-tab': HTTab },
        },
      });

      await nextTick();

      const tab = wrapper.find('.ht-tab');
      expect(tab.find('h1').exists()).toBe(true);
      expect(tab.find('p').exists()).toBe(true);
      expect(tab.find('ul').exists()).toBe(true);
    });

    it('应该支持嵌套组件', async () => {
      const CustomComponent = {
        name: 'CustomComponent',
        template: '<div class="custom-component">自定义组件</div>',
      };

      const wrapper = mount(HTTabs, {
        slots: {
          default: `
            <ht-tab title="标签 1">
              <custom-component />
            </ht-tab>
          `,
        },
        global: {
          components: {
            'ht-tab': HTTab,
            'custom-component': CustomComponent,
          },
        },
      });

      await nextTick();

      expect(wrapper.find('.custom-component').exists()).toBe(true);
    });
  });

  describe('rendered 事件集成', () => {
    it('应该在首次激活时通知父组件', async () => {
      const handleRendered = vi.fn();

      const wrapper = mount(HTTabs, {
        props: {
          lazyRender: true,
          onRendered: handleRendered,
        },
        slots: {
          default: `
            <ht-tab name="tab1" title="标签 1">内容 1</ht-tab>
            <ht-tab name="tab2" title="标签 2">内容 2</ht-tab>
          `,
        },
        global: {
          components: { 'ht-tab': HTTab },
        },
      });

      await nextTick();
      await nextTick();

      // 第一个 tab 默认激活，应该触发 rendered
      expect(handleRendered).toHaveBeenCalledWith('tab1', '标签 1');

      // 切换到第二个 tab
      const tabHeaders = wrapper.findAll('.ht-tabs__tab');
      await tabHeaders[1].trigger('click');
      await nextTick();
      await nextTick();

      // 第二个 tab 首次激活，应该触发 rendered
      expect(handleRendered).toHaveBeenCalledWith('tab2', '标签 2');
      expect(handleRendered).toHaveBeenCalledTimes(2);
    });
  });
});
