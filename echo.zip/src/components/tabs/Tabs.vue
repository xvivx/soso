<template>
  <div ref="rootRef" :class="cn('ht-tabs', `ht-tabs--${type}`, className)">
    <div
      v-if="showHeader"
      ref="wrapRef"
      :class="cn('ht-tabs__wrap', { 'ht-tabs__wrap--border': props.type === 'line' && props.border })"
    >
      <HTSticky v-if="sticky" :offset-top="offsetTop" :container="rootRef" @scroll="onStickyScroll">
        <div
          ref="navRef"
          role="tablist"
          :class="
            cn('ht-tabs__nav', `ht-tabs__nav--${type}`, {
              'ht-tabs__nav--shrink': shrink,
              'ht-tabs__nav--scrollable': scrollable,
            })
          "
          :style="navStyle"
        >
          <slot name="nav-left" />

          <div
            v-for="(child, index) in children"
            :key="child.name ?? index"
            :ref="(el) => setTitleRefs(index)(el)"
            role="tab"
            :aria-selected="currentIndex === index"
            :aria-disabled="child.disabled"
            :class="
              cn('ht-tabs__tab', {
                'ht-tabs__tab--active': currentIndex === index,
                'ht-tabs__tab--disabled': child.disabled,
              })
            "
            :style="getTabStyle(index)"
            @click="onClickTab(index, $event)"
          >
            <span :class="cn('ht-tabs__tab-text', { 'ht-tabs__tab-text--ellipsis': ellipsis })">
              {{ child.title ?? '' }}
            </span>
            <span v-if="child.badge" class="ht-tabs__tab-badge">{{ child.badge }}</span>
            <span v-if="child.dot" class="ht-tabs__tab-dot" />
          </div>

          <div v-if="type === 'line'" class="ht-tabs__line" :style="state.lineStyle" />

          <slot name="nav-right" />
        </div>
      </HTSticky>
      <div
        v-else
        ref="navRef"
        role="tablist"
        :class="
          cn('ht-tabs__nav', `ht-tabs__nav--${type}`, {
            'ht-tabs__nav--shrink': shrink,
            'ht-tabs__nav--scrollable': scrollable,
          })
        "
        :style="navStyle"
      >
        <slot name="nav-left" />

        <div
          v-for="(child, index) in children"
          :key="child.name ?? index"
          :ref="(el) => setTitleRefs(index)(el)"
          role="tab"
          :aria-selected="currentIndex === index"
          :aria-disabled="child.disabled"
          :class="
            cn('ht-tabs__tab', {
              'ht-tabs__tab--active': currentIndex === index,
              'ht-tabs__tab--disabled': child.disabled,
            })
          "
          :style="getTabStyle(index)"
          @click="onClickTab(index, $event)"
        >
          <span :class="cn('ht-tabs__tab-text', { 'ht-tabs__tab-text--ellipsis': ellipsis })">
            {{ child.title ?? '' }}
          </span>
          <span v-if="child.badge" class="ht-tabs__tab-badge">{{ child.badge }}</span>
          <span v-if="child.dot" class="ht-tabs__tab-dot" />
        </div>

        <div v-if="type === 'line'" class="ht-tabs__line" :style="state.lineStyle" />

        <slot name="nav-right" />
      </div>
    </div>

    <TabsContent
      ref="contentRef"
      :count="children.length"
      :inited="state.inited"
      :animated="animated"
      :duration="duration"
      :swipeable="swipeable"
      :lazy-render="lazyRender"
      :current-index="state.currentIndex"
      @change="setCurrentIndex"
    >
      <slot />
    </TabsContent>
  </div>
</template>

<script setup lang="ts">
import { computed, nextTick, onMounted, provide, reactive, ref, watch } from 'vue';
import { cn } from '@/utils';
import HTSticky from '../sticky/index.vue';
import TabsContent from './TabsContent.vue';
import type { HTTabsEmits, HTTabsProps, TabsProvide } from './types';
import './style/index.css';

const props = withDefaults(defineProps<HTTabsProps>(), {
  type: 'line',
  border: false,
  sticky: false,
  shrink: false,
  active: 0,
  duration: 0.3,
  animated: false,
  ellipsis: true,
  swipeable: false,
  scrollspy: false,
  offsetTop: 0,
  lazyRender: true,
  showHeader: true,
  swipeThreshold: 5,
});

const emit = defineEmits<HTTabsEmits>();

const rootRef = ref<HTMLElement>();
const wrapRef = ref<HTMLElement>();
const navRef = ref<HTMLElement>();
const titleRefs = ref<HTMLElement[]>([]);
const contentRef = ref<InstanceType<typeof TabsContent>>();

// 用于记录 sticky 固定状态，保留供未来功能扩展
let _stickyFixed = false;

const state = reactive({
  inited: false,
  currentIndex: 0,
  lineStyle: {} as Record<string, string>,
});

// 子组件集合
const children = reactive<
  Array<{
    name?: string | number;
    title?: string;
    disabled?: boolean;
    badge?: string | number;
    dot?: boolean;
  }>
>([]);

const currentIndex = computed(() => state.currentIndex);
const currentName = computed(() => {
  const child = children[state.currentIndex];
  return child?.name ?? state.currentIndex;
});

const scrollable = computed(() => {
  return children.length > Number(props.swipeThreshold) || !props.ellipsis || props.shrink;
});

const navStyle = computed(() => ({
  borderColor: props.color,
  background: props.background,
}));

const getTabStyle = (index: number) => {
  const style: Record<string, string> = {};
  const isActive = state.currentIndex === index;
  if (isActive && props.titleActiveColor) {
    style.color = props.titleActiveColor;
  } else if (!isActive && props.titleInactiveColor) {
    style.color = props.titleInactiveColor;
  }
  return style;
};

const setTitleRefs = (index: number) => {
  return (el: unknown) => {
    if (el) {
      titleRefs.value[index] = el as HTMLElement;
    }
  };
};

const setLine = () => {
  const shouldAnimate = state.inited;

  nextTick(() => {
    const titles = titleRefs.value;
    if (!titles || !titles[state.currentIndex] || props.type !== 'line') {
      return;
    }

    const title = titles[state.currentIndex];
    if (!title) return;

    const { lineWidth, lineHeight } = props;
    const left = title.offsetLeft + title.offsetWidth / 2;

    const lineStyle: Record<string, string> = {
      width: lineWidth ? `${lineWidth}px` : '40px',
      backgroundColor: props.color || 'var(--tabs-indicator-color-default)',
      transform: `translateX(${left}px) translateX(-50%)`,
    };

    if (shouldAnimate) {
      lineStyle.transitionDuration = `${props.duration}s`;
    }

    if (lineHeight) {
      const height = `${lineHeight}px`;
      lineStyle.height = height;
      lineStyle.borderRadius = height;
    }

    state.lineStyle = lineStyle;
  });
};

const findAvailableTab = (index: number) => {
  const diff = index < state.currentIndex ? -1 : 1;

  while (index >= 0 && index < children.length) {
    if (!children[index]?.disabled) {
      return index;
    }
    index += diff;
  }
  return undefined;
};

const scrollIntoView = (immediate = false) => {
  const nav = navRef.value;
  const titles = titleRefs.value;

  if (!scrollable.value || !nav || !titles || !titles[state.currentIndex]) {
    return;
  }

  const title = titles[state.currentIndex];
  if (!title) return;

  const to = title.offsetLeft - (nav.offsetWidth - title.offsetWidth) / 2;

  nav.scrollTo({
    left: to,
    behavior: immediate ? 'auto' : 'smooth',
  });
};

const setCurrentIndex = (index: number, skipScrollIntoView = false) => {
  const newIndex = findAvailableTab(index);

  if (newIndex === undefined) {
    return;
  }

  const child = children[newIndex];
  if (!child) return;

  const oldIndex = state.currentIndex;
  const name = child.name ?? newIndex;

  if (oldIndex !== newIndex) {
    state.currentIndex = newIndex;
    if (!skipScrollIntoView) {
      scrollIntoView();
    }
    setLine();
    emit('update:active', name);
    emit('change', name, child.title || '');
  }
};

const onClickTab = (index: number, event: MouseEvent) => {
  const child = children[index];
  if (!child) return;

  const name = child.name ?? index;

  emit('clickTab', {
    name,
    title: child.title || '',
    event,
    disabled: child.disabled || false,
  });

  if (!child.disabled) {
    if (props.beforeChange) {
      const result = props.beforeChange(name);
      if (result instanceof Promise) {
        result.then((shouldChange) => {
          if (shouldChange) setCurrentIndex(index);
        });
      } else if (result) {
        setCurrentIndex(index);
      }
    } else {
      setCurrentIndex(index);
    }
  }
};

const scrollTo = (name: string | number) => {
  const index = children.findIndex((child, idx) => (child.name ?? idx) === name);
  if (index !== -1) {
    setCurrentIndex(index);
  }
};

const resize = () => {
  setLine();
  nextTick(() => {
    scrollIntoView(true);
    contentRef.value?.swipeRef?.resize?.();
  });
};

const onRendered = (name: string | number, title?: string) => {
  emit('rendered', name, title);
};

const onStickyScroll = (params: { isFixed: boolean; scrollTop: number }) => {
  _stickyFixed = params.isFixed;
  emit('scroll', params);
};

// 注册子组件
const registerChild = (child: {
  name?: string | number;
  title?: string;
  disabled?: boolean;
  badge?: string | number;
  dot?: boolean;
}) => {
  children.push(child);
  return children.length - 1;
};

const unregisterChild = (child: {
  name?: string | number;
  title?: string;
  disabled?: boolean;
  badge?: string | number;
  dot?: boolean;
}) => {
  const index = children.indexOf(child);
  if (index !== -1) {
    children.splice(index, 1);
  }
};

// Provide
const tabsId = `tabs-${Math.random().toString(36).slice(2, 11)}`;
provide<TabsProvide>('TABS_KEY', {
  id: tabsId,
  props,
  setLine,
  scrollable,
  onRendered,
  currentName,
  setTitleRefs,
  scrollIntoView,
});

provide('registerChild', registerChild);
provide('unregisterChild', unregisterChild);
provide('currentIndex', currentIndex);

watch(
  () => props.active,
  (value) => {
    const index = children.findIndex((child, idx) => (child.name ?? idx) === value);
    if (index !== -1 && index !== state.currentIndex) {
      setCurrentIndex(index);
    }
  }
);

watch(
  () => [props.color, props.duration, props.lineWidth, props.lineHeight],
  () => {
    setLine();
  }
);

onMounted(() => {
  const index = children.findIndex((child, idx) => (child.name ?? idx) === props.active);
  state.currentIndex = index !== -1 ? index : 0;

  nextTick(() => {
    state.inited = true;
    setLine();
    scrollIntoView(true);
  });
});

defineExpose({
  resize,
  scrollTo,
});
</script>
