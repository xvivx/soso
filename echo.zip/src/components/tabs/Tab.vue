<template>
  <component
    :is="shouldUseSwipeItem ? HTSwipeItem : 'div'"
    v-show="isActive || !lazyRender || shouldUseSwipeItem"
    :class="cn('ht-tab', { 'ht-tab--active': isActive }, className)"
    role="tabpanel"
    :aria-hidden="!isActive"
  >
    <slot v-if="shouldRender" />
  </component>
</template>

<script setup lang="ts">
import { computed, inject, onBeforeUnmount, onMounted, ref, watch, type ComputedRef } from 'vue';
import { cn } from '@/utils';
import HTSwipeItem from '../swipe/SwipeItem.vue';
import type { HTTabProps } from './types';

const props = withDefaults(defineProps<HTTabProps>(), {
  disabled: false,
  dot: false,
  showZeroBadge: true,
});

const registerChild =
  inject<
    (child: {
      name?: string | number;
      title?: string;
      disabled?: boolean;
      badge?: string | number;
      dot?: boolean;
    }) => number
  >('registerChild');

const unregisterChild =
  inject<
    (child: {
      name?: string | number;
      title?: string;
      disabled?: boolean;
      badge?: string | number;
      dot?: boolean;
    }) => void
  >('unregisterChild');

const currentIndex = inject<ComputedRef<number>>('currentIndex');
const parent = inject<{
  id: string;
  props: {
    lazyRender?: boolean;
    animated?: boolean;
    swipeable?: boolean;
  };
  onRendered?: (name: string | number, title?: string) => void;
}>('TABS_KEY');

const inited = ref(false);
const index = ref(-1);
const child = ref<{
  name?: string | number;
  title?: string;
  disabled?: boolean;
  badge?: string | number;
  dot?: boolean;
}>();

const isActive = computed(() => {
  if (index.value === -1) return false;
  return currentIndex?.value === index.value;
});

const lazyRender = computed(() => {
  return parent?.props.lazyRender ?? true;
});

const shouldRender = computed(() => {
  return inited.value || !lazyRender.value || isActive.value;
});

const shouldUseSwipeItem = computed(() => {
  return parent?.props.animated || parent?.props.swipeable;
});

watch(isActive, (val) => {
  if (val && !inited.value) {
    inited.value = true;
    if (parent?.onRendered) {
      parent.onRendered(props.name ?? index.value, props.title);
    }
  }
});

onMounted(() => {
  if (registerChild) {
    child.value = {
      name: props.name,
      title: props.title,
      disabled: props.disabled,
      badge: props.badge,
      dot: props.dot,
    };
    index.value = registerChild(child.value);
  }
});

onBeforeUnmount(() => {
  if (unregisterChild && child.value) {
    unregisterChild(child.value);
  }
});
</script>
