<template>
  <div
    :class="
      cn('ht-tabs__content', {
        'ht-tabs__content--animated': animated || swipeable,
      })
    "
  >
    <component
      :is="animated || swipeable ? HTSwipe : 'div'"
      v-if="animated || swipeable"
      ref="swipeRef"
      :loop="false"
      :class="cn('ht-tabs__track')"
      :duration="duration * 1000"
      :touchable="swipeable"
      :show-indicators="false"
      :autoplay="0"
      :initial-swipe="currentIndex"
      @change="onChange"
    >
      <slot />
    </component>
    <slot v-else />
  </div>
</template>

<script setup lang="ts">
import { computed, onMounted, ref, watch } from 'vue';
import { cn } from '@/utils';
import HTSwipe from '../swipe/index.vue';
import type { SwipeExpose } from '../swipe/types';

export interface TabsContentProps {
  count: number;
  inited: boolean;
  animated: boolean;
  duration: number | string;
  swipeable: boolean;
  lazyRender: boolean;
  currentIndex: number;
}

interface TabsContentEmits {
  (e: 'change', index: number): void;
}

const props = defineProps<TabsContentProps>();
const emit = defineEmits<TabsContentEmits>();

const swipeRef = ref<SwipeExpose>();

const duration = computed(() => +props.duration);

const onChange = (index: number) => emit('change', index);

const swipeToCurrentTab = (index: number) => {
  const swipe = swipeRef.value;
  if (swipe && swipe.swipeTo) {
    swipe.swipeTo(index, { immediate: !props.inited });
  }
};

watch(() => props.currentIndex, swipeToCurrentTab);

onMounted(() => {
  swipeToCurrentTab(props.currentIndex);
});

defineExpose({ swipeRef });
</script>
