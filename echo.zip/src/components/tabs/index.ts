import HTTab from './Tab.vue';
import HTTabs from './Tabs.vue';

export { HTTabs, HTTab };
export * from './types';
