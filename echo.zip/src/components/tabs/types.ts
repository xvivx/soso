import type { ComputedRef, CSSProperties } from 'vue';

export type TabsType = 'line' | 'card';

export interface HTTabsProps {
  // Vant 兼容 API
  type?: TabsType;
  color?: string;
  border?: boolean;
  sticky?: boolean;
  shrink?: boolean;
  active?: string | number;
  duration?: number | string;
  animated?: boolean;
  ellipsis?: boolean;
  swipeable?: boolean;
  scrollspy?: boolean;
  offsetTop?: number | string;
  background?: string;
  lazyRender?: boolean;
  showHeader?: boolean;
  lineWidth?: number | string;
  lineHeight?: number | string;
  swipeThreshold?: number | string;
  titleActiveColor?: string;
  titleInactiveColor?: string;
  beforeChange?: (name: string | number) => boolean | Promise<boolean>;

  // 扩展属性
  className?: string;
}

export interface HTTabsEmits {
  (e: 'update:active', name: string | number): void;
  (e: 'change', name: string | number, title: string): void;
  (e: 'scroll', params: { scrollTop: number; isFixed: boolean }): void;
  (e: 'rendered', name: string | number, title?: string): void;
  (
    e: 'clickTab',
    params: {
      name: string | number;
      title: string;
      event: MouseEvent;
      disabled: boolean;
    }
  ): void;
}

export interface HTTabProps {
  // Vant 兼容 API
  name?: string | number;
  title?: string;
  disabled?: boolean;
  dot?: boolean;
  badge?: string | number;
  showZeroBadge?: boolean;
  titleStyle?: string | CSSProperties;
  titleClass?: string;

  // 扩展属性
  className?: string;
}

export interface HTTabEmits {
  (e: 'click', event: MouseEvent): void;
}

export interface TabsProvide {
  id: string;
  props: HTTabsProps;
  setLine: () => void;
  scrollable: ComputedRef<boolean>;
  onRendered: (name: string | number, title?: string) => void;
  currentName: ComputedRef<string | number | undefined>;
  setTitleRefs: (index: number) => (el: unknown) => void;
  scrollIntoView: (immediate?: boolean) => void;
}

export interface TabsExpose {
  resize: () => void;
  scrollTo: (name: string | number) => void;
}
