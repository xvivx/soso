# HTTabs 标签页

基于 Vue 3 实现，完全兼容 Vant Tabs 组件 API 的标签页组件。

## 特性

- ✅ 完全兼容 Vant Tabs/Tab API
- ✅ 支持 line 和 card 两种类型
- ✅ 支持徽章和红点
- ✅ 支持禁用状态
- ✅ 支持自定义颜色
- ✅ 支持收缩布局和滚动
- ✅ 完整的 TypeScript 类型定义
- ✅ 基于三级 Token 系统的样式设计

## 基础用法

```vue
<template>
  <HTTabs v-model:active="active">
    <HTTab title="标签 1" name="tab1">内容 1</HTTab>
    <HTTab title="标签 2" name="tab2">内容 2</HTTab>
    <HTTab title="标签 3" name="tab3">内容 3</HTTab>
  </HTTabs>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import { HTTab, HTTabs } from '@/components/tabs';

const active = ref('tab1');
</script>
```

## 卡片类型

```vue
<HTTabs v-model:active="active" type="card">
  <HTTab title="标签 1">内容 1</HTTab>
  <HTTab title="标签 2">内容 2</HTTab>
  <HTTab title="标签 3">内容 3</HTTab>
</HTTabs>
```

## 徽章和红点

```vue
<HTTabs v-model:active="active">
  <HTTab title="标签 1" badge="5">内容 1</HTTab>
  <HTTab title="标签 2" dot>内容 2</HTTab>
  <HTTab title="标签 3">内容 3</HTTab>
</HTTabs>
```

## 禁用标签

```vue
<HTTabs v-model:active="active">
  <HTTab title="标签 1">内容 1</HTTab>
  <HTTab title="标签 2" disabled>内容 2</HTTab>
  <HTTab title="标签 3">内容 3</HTTab>
</HTTabs>
```

## 自定义颜色

```vue
<HTTabs v-model:active="active" color="#07c160" title-active-color="#07c160">
  <HTTab title="标签 1">内容 1</HTTab>
  <HTTab title="标签 2">内容 2</HTTab>
</HTTabs>
```

## 收缩布局

```vue
<HTTabs v-model:active="active" shrink>
  <HTTab title="标签 1">内容 1</HTTab>
  <HTTab title="标签 2">内容 2</HTTab>
  <!-- 更多标签... -->
</HTTabs>
```

## 滚动标签

当标签数量超过 `swipeThreshold` 时，标签栏会自动开启滚动。

```vue
<HTTabs v-model:active="active" :swipe-threshold="5">
  <HTTab v-for="i in 10" :key="i" :title="`标签 ${i}`">
    内容 {{ i }}
  </HTTab>
</HTTabs>
```

## API

### HTTabs Props

| 参数                 | 说明                           | 类型                                                      | 默认值   | Vant 兼容 |
| -------------------- | ------------------------------ | --------------------------------------------------------- | -------- | --------- |
| active               | 当前激活标签的标识符           | `string \| number`                                        | `0`      | ✅        |
| type                 | 标签类型                       | `'line' \| 'card'`                                        | `'line'` | ✅        |
| color                | 标签主题色                     | `string`                                                  | -        | ✅        |
| border               | 是否显示外边框                 | `boolean`                                                 | `false`  | ✅        |
| sticky               | 是否使用粘性定位               | `boolean`                                                 | `false`  | ✅        |
| shrink               | 是否收缩标签                   | `boolean`                                                 | `false`  | ✅        |
| duration             | 动画时间（秒）                 | `number \| string`                                        | `0.3`    | ✅        |
| animated             | 是否开启切换动画               | `boolean`                                                 | `false`  | ✅        |
| ellipsis             | 是否省略过长标题               | `boolean`                                                 | `true`   | ✅        |
| swipeable            | 是否开启手势滑动               | `boolean`                                                 | `false`  | ✅        |
| scrollspy            | 是否开启滚动导航               | `boolean`                                                 | `false`  | ✅        |
| offset-top           | 粘性定位布局下与顶部的最小距离 | `number \| string`                                        | `0`      | ✅        |
| background           | 标签栏背景色                   | `string`                                                  | -        | ✅        |
| lazy-render          | 是否开启延迟渲染               | `boolean`                                                 | `true`   | ✅        |
| show-header          | 是否显示标签栏                 | `boolean`                                                 | `true`   | ✅        |
| line-width           | 底部条宽度                     | `number \| string`                                        | -        | ✅        |
| line-height          | 底部条高度                     | `number \| string`                                        | -        | ✅        |
| swipe-threshold      | 滚动阈值                       | `number \| string`                                        | `5`      | ✅        |
| title-active-color   | 标签选中态颜色                 | `string`                                                  | -        | ✅        |
| title-inactive-color | 标签未选中态颜色               | `string`                                                  | -        | ✅        |
| before-change        | 切换前的回调函数               | `(name: string \| number) => boolean \| Promise<boolean>` | -        | ✅        |

### HTTabs Events

| 事件名        | 说明                                             | 回调参数                                 |
| ------------- | ------------------------------------------------ | ---------------------------------------- |
| update:active | 当前激活的标签改变时触发                         | `name: string \| number`                 |
| change        | 当前激活的标签改变时触发                         | `name: string \| number, title: string`  |
| click-tab     | 点击标签时触发                                   | `{ name, title, event, disabled }`       |
| scroll        | 滚动时触发（仅在 sticky 模式下）                 | `{ scrollTop, isFixed }`                 |
| rendered      | 标签内容首次渲染时触发（仅在开启延迟渲染后触发） | `name: string \| number, title?: string` |

### HTTabs Slots

| 名称      | 说明           |
| --------- | -------------- |
| default   | 标签页内容     |
| nav-left  | 标签栏左侧内容 |
| nav-right | 标签栏右侧内容 |

### HTTabs Methods

通过 ref 可以获取到 Tabs 实例并调用实例方法。

| 方法名   | 说明                                                       | 参数                     | 返回值 |
| -------- | ---------------------------------------------------------- | ------------------------ | ------ |
| resize   | 外层元素大小或组件显示状态变化时，可以调用此方法来触发重绘 | -                        | -      |
| scrollTo | 滚动到指定的标签页                                         | `name: string \| number` | -      |

### HTTab Props

| 参数            | 说明                               | 类型                      | 默认值       | Vant 兼容 |
| --------------- | ---------------------------------- | ------------------------- | ------------ | --------- |
| name            | 标签名称，作为匹配的标识符         | `string \| number`        | 标签的索引值 | ✅        |
| title           | 标签标题                           | `string`                  | -            | ✅        |
| disabled        | 是否禁用标签                       | `boolean`                 | `false`      | ✅        |
| dot             | 是否在标题右上角显示小红点         | `boolean`                 | `false`      | ✅        |
| badge           | 图标右上角徽标的内容               | `string \| number`        | -            | ✅        |
| show-zero-badge | 当 badge 为数字 0 时，是否展示徽标 | `boolean`                 | `true`       | ✅        |
| title-style     | 自定义标题样式                     | `string \| CSSProperties` | -            | ✅        |
| title-class     | 自定义标题类名                     | `string`                  | -            | ✅        |

### HTTab Slots

| 名称    | 说明       |
| ------- | ---------- |
| default | 标签页内容 |

## 主题定制

组件使用 CSS 变量进行样式定制，可以通过覆盖以下变量来自定义样式：

```css
:root {
  /* 容器 */
  --tabs-container-width-default: 100%;
  --tabs-container-height-default: auto;

  /* 标签栏 */
  --tabs-tab-bar-height-default: 48px;
  --tabs-tab-bar-bg-color-default: #ffffff;
  --tabs-tab-bar-border-color-default: #eeeeee;

  /* 指示器 */
  --tabs-indicator-height-default: 3px;
  --tabs-indicator-color-default: #1677ff;
  --tabs-indicator-border-radius-default: 3px;

  /* 标签 */
  --tab-text-font-size-default: 14px;
  --tab-text-color-default: #8c8c8c;
  --tab-text-color-active: #1677ff;
  --tab-text-font-weight-default: 500;

  /* 过渡 */
  --tabs-transition-duration: 0.3s;
}
```

## 与 Vant 的差异

本组件完全兼容 Vant Tabs 组件的 API，可以无缝替换。主要特点：

1. 基于 Vue 3 Composition API 实现
2. 使用 CSS 变量系统进行主题定制
3. 完整的 TypeScript 类型支持
4. 遵循项目的三级 Token 规范

## 注意事项

1. `HTTab` 组件必须作为 `HTTabs` 的直接子组件使用
2. 默认开启延迟渲染（`lazyRender`），未激活的标签内容不会渲染
3. 当使用 `name` 属性时，`v-model:active` 绑定的值应该与 `name` 保持一致
