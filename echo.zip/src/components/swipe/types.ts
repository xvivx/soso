import type { Ref } from 'vue';

export const swipeProps = {
  /** 宽度，支持 px vw 等单位，默认单位为 px */
  width: [Number, String],
  /** 高度，支持 px vw 等单位，默认单位为 px */
  height: [Number, String],
  /** 初始位置索引值 */
  initialSwipe: {
    type: [Number, String],
    default: 0,
  },
  /** 是否开启循环播放 */
  loop: {
    type: Boolean,
    default: true,
  },
  /** 是否显示指示器 */
  showIndicators: {
    type: Boolean,
    default: true,
  },
  /** 指示器位置 */
  indicatorPosition: {
    type: String as () => 'inside' | 'outside' | 'none',
    default: 'inside',
  },
  /** 箭头显示时机 */
  arrow: {
    type: String as () => 'always' | 'hover' | 'never',
    default: 'hover',
  },
  /** 指示器触发方式 */
  trigger: {
    type: String as () => 'hover' | 'click',
    default: 'hover',
  },
  /** 是否为纵向滚动 */
  vertical: {
    type: Boolean,
    default: false,
  },
  /** 自动播放间隔，单位为毫秒，为 0 时不自动播放 */
  autoplay: {
    type: [Number, String],
    default: 3000,
  },
  /** 动画时长，单位为毫秒 */
  duration: {
    type: [Number, String],
    default: 500,
  },
  /** 是否可以通过手势滑动 */
  touchable: {
    type: Boolean,
    default: true,
  },
  /** 是否阻止滑动事件冒泡 */
  stopPropagation: {
    type: Boolean,
    default: true,
  },
  /** 指示器颜色 */
  indicatorColor: String,
  /** 滑动阈值，标识需要滑动多少比例才能切换到下一张 */
  swipeThreshold: {
    type: [Number, String],
    default: 0.15,
  },
  /** 是否开启懒加载 */
  lazyRender: {
    type: Boolean,
    default: true,
  },
  /** 类型 */
  type: {
    type: String as () => '' | 'card',
    default: '',
  },
  /** 卡片模式下的缩放比例 */
  cardScale: {
    type: [Number, String],
    default: 0.83,
  },
  /** 鼠标悬停时暂停自动播放 */
  pauseOnHover: {
    type: Boolean,
    default: true,
  },
};

export interface SwipeProps {
  width?: number | string;
  height?: number | string;
  initialSwipe?: number | string;
  loop?: boolean;
  showIndicators?: boolean;
  indicatorPosition?: 'inside' | 'outside' | 'none';
  arrow?: 'always' | 'hover' | 'never';
  trigger?: 'hover' | 'click';
  vertical?: boolean;
  autoplay?: number | string;
  duration?: number | string;
  touchable?: boolean;
  stopPropagation?: boolean;
  indicatorColor?: string;
  swipeThreshold?: number | string;
  lazyRender?: boolean;
  type?: '' | 'card';
  cardScale?: number | string;
  pauseOnHover?: boolean;
}

export interface SwipeEmits {
  (e: 'change', index: number): void;
  (e: 'dragStart', { index }: { index: number }): void;
  (e: 'dragEnd', { index }: { index: number }): void;
}

export interface SwipeExpose {
  prev: () => void;
  next: () => void;
  swipeTo: (index: number, options?: { immediate?: boolean }) => void;
  resize: () => void;
}

export const swipeItemProps = {
  name: {
    type: [Number, String],
  },
};

export interface SwipeItemProps {
  name?: number | string;
}

export interface SwipeProvide {
  props: Ref<SwipeProps>;
  size: Ref<number>;
  count: Ref<number>;
  active: Ref<number>;
  swiping: Ref<boolean>;
  offsetSize: Ref<number>;
  childOffset: Ref<number[]>;
  items: Ref<number[]>;
  addSwipeItem: (id: number) => void;
  removeSwipeItem: (id: number) => void;
}

export const SWIPE_KEY = Symbol('swipe');
