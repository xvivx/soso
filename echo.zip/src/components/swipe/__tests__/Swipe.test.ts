import { h } from 'vue';
import { render } from '@testing-library/vue';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import HTSwipe from '../index.vue';
import HTSwipeItem from '../SwipeItem.vue';

// Mock ResizeObserver
global.ResizeObserver = vi.fn().mockImplementation(() => ({
  observe: vi.fn(),
  unobserve: vi.fn(),
  disconnect: vi.fn(),
}));

describe('HTSwipe', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('应该正确渲染默认轮播', () => {
    const { container } = render(HTSwipe, {
      slots: {
        default: () => [h(HTSwipeItem, {}, () => 'Item 1'), h(HTSwipeItem, {}, () => 'Item 2')],
      },
    });

    const swipeContainer = container.querySelector('.swipe-base');
    expect(swipeContainer).toBeTruthy();

    const track = container.querySelector('.swipe-track');
    expect(track).toBeTruthy();
  });

  it('应该支持垂直方向', () => {
    const { container } = render(HTSwipe, {
      props: {
        vertical: true,
      },
      slots: {
        default: () => [h(HTSwipeItem, {}, () => 'Item 1'), h(HTSwipeItem, {}, () => 'Item 2')],
      },
    });

    const swipeContainer = container.querySelector('.swipe-base');
    expect(swipeContainer?.classList.contains('swipe-vertical')).toBe(true);
  });

  it('应该支持自定义宽度和高度', () => {
    const { container } = render(HTSwipe, {
      props: {
        width: 400,
        height: 300,
      },
      slots: {
        default: () => [h(HTSwipeItem, {}, () => 'Item 1'), h(HTSwipeItem, {}, () => 'Item 2')],
      },
    });

    const swipe = container.querySelector('.swipe-base');
    expect(swipe?.getAttribute('style')).toContain('width: 400px');
    expect(swipe?.getAttribute('style')).toContain('height: 300px');
  });

  it('应该支持循环播放', () => {
    const { container } = render(HTSwipe, {
      props: {
        loop: true,
      },
      slots: {
        default: () => [h(HTSwipeItem, {}, () => 'Item 1'), h(HTSwipeItem, {}, () => 'Item 2')],
      },
    });

    const swipeContainer = container.querySelector('.swipe-base');
    expect(swipeContainer).toBeTruthy();
  });

  it('应该支持自定义动画时长', () => {
    const { container } = render(HTSwipe, {
      props: {
        duration: 1000,
      },
      slots: {
        default: () => [h(HTSwipeItem, {}, () => 'Item 1'), h(HTSwipeItem, {}, () => 'Item 2')],
      },
    });

    const track = container.querySelector('.swipe-track');
    expect(track).toBeTruthy();
  });
});
