<template>
  <div :class="classes" :style="itemStyle">
    <slot v-if="rendered" />
  </div>
</template>

<script setup lang="ts">
import { computed, inject, onMounted, onUnmounted } from 'vue';
import { SWIPE_KEY, type SwipeProvide } from './types';

const id = Math.random();
const swipe = inject<SwipeProvide>(SWIPE_KEY);
if (!swipe) {
  throw new Error('[SwipeItem] must be placed inside Swipe');
}

// 通过父组件items动态获取索引
const index = computed(() => swipe.items.value.indexOf(id));

// 懒加载：在桥接过渡时也需要渲染（存在临时偏移的项）
const rendered = computed(() => {
  // Element Plus 行为：卡片模式始终渲染所有项
  if (swipe.props.value.type === 'card') {
    return true;
  }
  if (!swipe.props.value.lazyRender) return true;
  const i = index.value;
  const active = swipe.active.value;
  const offset = swipe.childOffset.value[i] || 0;
  return active === i || offset !== 0;
});

const classes = computed(() => {
  const base = 'swipe-item';
  if (swipe.props.value.type === 'card') {
    const i = index.value;
    const active = swipe.active.value;
    return [
      base,
      'swipe-card-item',
      i === active ? 'swipe-card-item-active' : '',
      i === (active - 1 + swipe.count.value) % swipe.count.value ? 'swipe-card-item-prev' : '',
      i === (active + 1) % swipe.count.value ? 'swipe-card-item-next' : '',
      swipe.props.value.vertical ? 'swipe-card-item-vertical' : '',
    ]
      .filter(Boolean)
      .join(' ');
  }
  return base;
});

const itemStyle = computed(() => {
  const style: Record<string, string> = {};
  // 卡片模式不叠加子项偏移
  if (swipe.props.value.type === 'card') {
    return style;
  }
  const offset = swipe.childOffset.value[index.value] || 0;
  if (offset !== 0) {
    const dir = swipe.props.value.vertical ? 'Y' : 'X';
    style.transform = `translate${dir}(${offset}px)`;
  }
  return style;
});

onMounted(() => {
  swipe.addSwipeItem(id);
});

onUnmounted(() => {
  swipe.removeSwipeItem(id);
});
</script>
