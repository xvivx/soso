<template>
  <div
    ref="root"
    :class="classes.container"
    :style="style"
    @touchstart="touchHandler.onTouchStart"
    @touchmove="touchHandler.onTouchMove"
    @touchend="touchHandler.onTouchEnd"
    @touchcancel="touchHandler.onTouchCancel"
    @mousedown="onMouseDown"
    @mousemove="onMouseMove"
    @mouseup="onMouseUp"
    @mouseenter="onMouseEnter"
    @mouseleave="onMouseLeave"
    @wheel="onWheel"
    @dragstart="preventDefault"
  >
    <div ref="track" :class="classes.track" :style="trackStyle" @transitionend="onTransitionEnd">
      <slot />
    </div>

    <!-- 指示器 -->
    <div v-if="showIndicators && count > 1" :class="classes.indicators">
      <div
        v-for="(_, index) in count"
        :key="index"
        :class="getIndicatorClasses(index)"
        @click="onIndicatorClick(index)"
        @mouseenter="onIndicatorEnter(index)"
      />
    </div>

    <!-- 箭头按钮 -->
    <button
      v-if="count > 1 && (arrow === 'always' || (arrow === 'hover' && state.isHovering))"
      type="button"
      :class="classes.arrowPrev"
      @click="prev"
    >
      <slot name="arrow-left">
        <svg viewBox="0 0 24 24" width="1em" height="1em">
          <path fill="currentColor" d="M15.41 7.41L14 6l-6 6 6 6 1.41-1.41L10.83 12z" />
        </svg>
      </slot>
    </button>

    <button
      v-if="count > 1 && (arrow === 'always' || (arrow === 'hover' && state.isHovering))"
      type="button"
      :class="classes.arrowNext"
      @click="next"
    >
      <slot name="arrow-right">
        <svg viewBox="0 0 24 24" width="1em" height="1em">
          <path fill="currentColor" d="M10 6L8.59 7.41 13.17 12l-4.58 4.59L10 18l6-6z" />
        </svg>
      </slot>
    </button>
  </div>
</template>

<script setup lang="ts">
import {
  computed,
  nextTick,
  onActivated,
  onBeforeUnmount,
  onDeactivated,
  onMounted,
  provide,
  reactive,
  ref,
  watch,
} from 'vue';
import { useTouch, type TouchEventData } from '../../utils/touch';
import { SWIPE_KEY, swipeProps, type SwipeEmits, type SwipeExpose } from './types';
import './style/index.css';

const props = defineProps(swipeProps);
const emit = defineEmits<SwipeEmits>();

// 组件引用
const root = ref<HTMLElement | undefined>();
const track = ref<HTMLElement | undefined>();

// 状态变量
const state = reactive({
  size: 0,
  count: 0,
  active: 0,
  swiping: false,
  offset: 0,
  childOffset: [] as number[],
  items: [] as number[],
  isHovering: false,
});
const touching = ref(false); // 是否正在触摸
const autoplayTimer = ref<ReturnType<typeof setTimeout>>();

// 计算属性
const vertical = computed(() => props.vertical);
const duration = computed(() => +props.duration);
const offsetSize = computed(() => (vertical.value ? 'offsetHeight' : 'offsetWidth'));
const trackSize = computed(() => state.count * state.size);
// 新增：为模板中的count提供计算属性
const count = computed(() => state.count);
const activeIndicator = computed(() => (state.active + state.count) % state.count);
const withLoop = computed(() => props.loop && state.count > 1);
const showIndicators = computed(() => props.showIndicators && props.indicatorPosition !== 'none');
const classes = computed(() => {
  const isVertical = !!props.vertical;
  const pos = props.indicatorPosition || 'inside';
  const container = 'swipe-base' + (isVertical ? ' swipe-vertical' : '') + (props.type === 'card' ? ' swipe-card' : '');
  const track = 'swipe-track' + (isVertical ? ' swipe-track-vertical' : '');
  const indicators =
    'swipe-indicators ' + (isVertical ? `swipe-indicators-${pos}-vertical` : `swipe-indicators-${pos}-horizontal`);
  const arrowPrev =
    'swipe-arrow swipe-arrow-prev' + (isVertical ? ' swipe-arrow-vertical swipe-arrow-prev-vertical' : '');
  const arrowNext =
    'swipe-arrow swipe-arrow-next' + (isVertical ? ' swipe-arrow-vertical swipe-arrow-next-vertical' : '');
  return { container, track, indicators, arrowPrev, arrowNext };
});
const getIndicatorClasses = (index: number) => {
  const base = 'swipe-indicator';
  return `${base} ${index === activeIndicator.value ? `${base}-active` : ''}`;
};

// 样式计算
const style = computed(() => {
  const style: Record<string, string> = {};
  if (props.width) {
    style.width = isNaN(+props.width) ? (props.width as string) : `${props.width}px`;
  }
  if (props.height) {
    style.height = isNaN(+props.height) ? (props.height as string) : `${props.height}px`;
  }
  return style;
});

const trackStyle = computed(() => {
  const style: Record<string, string> = {
    transitionDuration: `${state.swiping ? 0 : duration.value}ms`,
  };

  // 卡片模式不通过轨道位移实现切换
  if (props.type === 'card') {
    return style;
  }

  if (state.size) {
    const offsetDirection = vertical.value ? 'Y' : 'X';
    style.transform = `translate${offsetDirection}(${state.offset}px)`;
  }

  return style;
});

// 方法
const resize = () => {
  if (!root.value) return;

  const rect = root.value.getBoundingClientRect();
  state.size = vertical.value ? rect.height : rect.width;

  if (state.active >= state.count) {
    state.active = state.count - 1;
  }

  updateOffset();
};

const updateOffset = (targetActive = state.active) => {
  let targetOffset = 0;

  if (state.count > 0 && state.size > 0) {
    targetOffset = -targetActive * state.size;
  }

  state.offset = targetOffset;
};

const slideTo = (index: number, options: { immediate?: boolean } = {}) => {
  if (!state.count) return;

  if (withLoop.value) {
    index = (index + state.count) % state.count;
  } else {
    index = Math.min(Math.max(0, index), state.count - 1);
  }

  if (options.immediate) {
    state.swiping = true;
    state.active = index;
    if (props.type !== 'card') updateOffset(index);

    nextTick(() => {
      state.swiping = false;
      state.active = index;
      emit('change', index);
    });
  } else {
    state.swiping = false;
    state.active = index;
    if (props.type !== 'card') updateOffset(index);
    emit('change', index);
  }
};

const prev = () => {
  if (!state.count) return;

  // 卡片模式：与 Element Plus 一致，直接按索引切换
  if (props.type === 'card') {
    const targetIndex = (state.active - 1 + state.count) % state.count;
    slideTo(targetIndex);
    return;
  }

  // 首项向前，需要桥接到最后一项
  if (withLoop.value && state.active === 0) {
    isBridging.value = true;
    // 将最后一个子项临时放到最前面
    resetItemOffsets();
    state.childOffset[state.count - 1] = -trackSize.value;
    bridgeTo = state.count - 1;
    // 执行一次过渡：向右移动一个尺寸
    state.swiping = false; // 开启过渡
    state.offset = state.size; // 向右（或向下）移动一个屏幕
    return;
  }

  const targetIndex = withLoop.value ? (state.active - 1 + state.count) % state.count : Math.max(0, state.active - 1);
  slideTo(targetIndex);
};

const next = () => {
  if (!state.count) return;

  // 卡片模式：与 Element Plus 一致，直接按索引切换
  if (props.type === 'card') {
    const targetIndex = (state.active + 1) % state.count;
    slideTo(targetIndex);
    return;
  }

  // 末项向后，需要桥接到第一项
  if (withLoop.value && state.active === state.count - 1) {
    isBridging.value = true;
    // 将第一个子项临时放到最后面
    resetItemOffsets();
    state.childOffset[0] = trackSize.value;
    bridgeTo = 0;
    // 执行一次过渡：继续向左移动一个尺寸
    state.swiping = false; // 开启过渡
    state.offset = -trackSize.value; // 移动到 -count*size
    return;
  }

  const targetIndex = withLoop.value ? (state.active + 1) % state.count : Math.min(state.count - 1, state.active + 1);
  slideTo(targetIndex);
};

// 循环模式下的特殊处理
const setLoopItemOffsets = () => {
  if (!withLoop.value || !state.count) return;
  if (props.type === 'card') return; // 卡片模式不需要临时子项偏移

  // 重置所有子项偏移
  state.childOffset = Array(state.count).fill(0);

  if (state.active === 0) {
    // 如果当前是第一个，将最后一个克隆到前面
    state.childOffset[state.count - 1] = -trackSize.value;
  } else if (state.active === state.count - 1) {
    // 如果当前是最后一个，将第一个克隆到后面
    state.childOffset[0] = trackSize.value;
  }
};

const resetItemOffsets = () => {
  state.childOffset = Array(state.count).fill(0);
};

const onTransitionEnd = () => {
  if (state.swiping) return;
  if (bridgeTo !== undefined) {
    state.swiping = true; // 关闭轨道过渡，进行瞬时复位
    // 先跳到真实索引，保留临时偏移一帧，避免视觉空窗
    state.active = bridgeTo;
    updateOffset(bridgeTo);
    bridgeTo = undefined;
    nextTick(() => {
      // 强制浏览器重排，确保轨道立即生效
      if (track.value) void track.value.offsetHeight;
      // 下一帧清理临时偏移并恢复过渡
      resetItemOffsets();
      state.swiping = false;
      isBridging.value = false;
      emit('change', state.active);
    });
    return;
  }
  // 非桥接场景：重置所有子项的临时偏移
  resetItemOffsets();
};

// 触摸事件处理
let bridgeTo: number | undefined;
const isBridging = ref(false);

// 使用新的触摸工具
const touchHandler = useTouch(
  {
    onStart: () => {
      if (!props.touchable) return;

      touching.value = true;
      state.swiping = true;

      // 停止自动播放
      stopAutoplay();

      emit('dragStart', { index: state.active });
    },

    onMove: (data: TouchEventData) => {
      if (!touching.value || !props.touchable) return;

      const { deltaX, deltaY, isVertical } = data;

      if (isVertical && vertical.value) {
        // 垂直滑动且组件为垂直模式
        moveVertical(deltaY);
      } else if (!isVertical && !vertical.value) {
        // 水平滑动且组件为水平模式
        moveHorizontal(deltaX);
      }
    },

    onEnd: (data: TouchEventData) => {
      if (!touching.value || !props.touchable) return;

      const { deltaX, deltaY, offsetX, offsetY, duration, isVertical } = data;
      const speed = isVertical ? offsetY / duration : offsetX / duration;
      const shouldSwipe = speed > 0.25 || (isVertical ? offsetY : offsetX) > state.size * +props.swipeThreshold;

      if (shouldSwipe) {
        const delta = isVertical ? deltaY : deltaX;
        const offset = Math.abs(delta);

        // 确定滑动方向
        if (offset > 0) {
          delta > 0 ? prev() : next();
        }
      } else {
        // 回到原位
        updateOffset();
      }

      touching.value = false;
      state.swiping = false;

      emit('dragEnd', { index: state.active });

      // 恢复自动播放
      startAutoplay();
    },
  },
  {
    preventDefault: false,
    smartPreventDefault: true,
    edgeThreshold: 30,
    stopPropagation: props.stopPropagation,
    threshold: 5,
  }
);

const moveVertical = (delta: number) => {
  const clampedDelta = withLoop.value ? delta : Math.max(Math.min(delta, state.size), -state.size);
  state.offset = clampedDelta + -state.active * state.size;
};

const moveHorizontal = (delta: number) => {
  const clampedDelta = withLoop.value ? delta : Math.max(Math.min(delta, state.size), -state.size);
  state.offset = clampedDelta + -state.active * state.size;
};

// 鼠标与滚轮事件处理
const onMouseDown = touchHandler.onMouseDown;
const onMouseMove = touchHandler.onMouseMove;
const onMouseUp = touchHandler.onMouseUp;
const onMouseEnter = () => {
  state.isHovering = true;
  if (props.pauseOnHover) stopAutoplay();
};
const onMouseLeave = () => {
  state.isHovering = false;
  if (props.pauseOnHover) startAutoplay();
  if (touching.value) {
    // 手动触发触摸结束事件
    touching.value = false;
    state.swiping = false;
    emit('dragEnd', { index: state.active });
    startAutoplay();
  }
};
const onWheel = (event: WheelEvent) => {
  if (!props.touchable) return;
  if (props.stopPropagation) event.stopPropagation();
  event.preventDefault();
  if (event.deltaY > 0) {
    next();
  } else {
    prev();
  }
};
const preventDefault = (event: Event) => event.preventDefault();

// 指示器点击/悬停触发
const onIndicatorClick = (index: number) => {
  if (props.trigger === 'click') slideTo(index);
};
const onIndicatorEnter = (index: number) => {
  if (props.trigger === 'hover') slideTo(index);
};

// 自动播放
const autoplay = () => {
  if (+props.autoplay <= 0 || state.count <= 1) return;

  stopAutoplay();
  autoplayTimer.value = setTimeout(() => {
    next();
    autoplay();
  }, +props.autoplay);
};

const stopAutoplay = () => {
  if (autoplayTimer.value) {
    clearTimeout(autoplayTimer.value);
    autoplayTimer.value = undefined;
  }
};

const startAutoplay = () => {
  if (+props.autoplay > 0) {
    autoplay();
  }
};

// 子项管理
const addSwipeItem = (id: number) => {
  state.items.push(id);
  state.count = state.items.length;
  state.childOffset = Array(state.count).fill(0);
};

const removeSwipeItem = (id: number) => {
  const idx = state.items.indexOf(id);
  if (idx !== -1) {
    state.items.splice(idx, 1);
    state.childOffset.splice(idx, 1);
  }
  state.count = state.items.length;
  if (state.active >= state.count) {
    state.active = Math.max(0, state.count - 1);
  }
};

// 监听器
watch(
  () => props.initialSwipe,
  (value) => {
    if (state.count) {
      slideTo(+value, { immediate: true });
    }
  }
);

watch(
  () => state.active,
  () => {
    if (isBridging.value) return;
    resetItemOffsets();
    setLoopItemOffsets();
  }
);

watch(
  () => state.count,
  () => {
    if (state.count > 0) {
      slideTo(+props.initialSwipe, { immediate: true });
    }
  }
);

watch(
  () => props.autoplay,
  () => {
    stopAutoplay();
    startAutoplay();
  }
);

// 生命周期钩子
onMounted(() => {
  nextTick(() => {
    resize();
    slideTo(+props.initialSwipe, { immediate: true });
    startAutoplay();
  });

  window.addEventListener('resize', resize);
  window.addEventListener('orientationchange', resize);
});

onBeforeUnmount(() => {
  stopAutoplay();
  window.removeEventListener('resize', resize);
  window.removeEventListener('orientationchange', resize);
});

onActivated(() => {
  startAutoplay();
});

onDeactivated(() => {
  stopAutoplay();
});

// 向子组件提供数据
provide(SWIPE_KEY, {
  props: computed(() => props),
  size: computed(() => state.size),
  count: computed(() => state.count),
  active: computed(() => state.active),
  swiping: computed(() => state.swiping),
  offsetSize,
  childOffset: computed(() => state.childOffset),
  items: computed(() => state.items),
  addSwipeItem,
  removeSwipeItem,
});

// 暴露方法
defineExpose<SwipeExpose>({
  prev,
  next,
  swipeTo: slideTo,
  resize,
});
</script>
