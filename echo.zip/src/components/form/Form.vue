<script setup lang="ts">
import { FORM_KEY, preventDefault } from '@/utils/index';
import { useChildren } from '@/hooks';
import type { FieldValidateError, FieldValidateTrigger, FieldValidationStatus } from '../field/types';
import { type FormExpose, type FormProps } from './types';

const props = withDefaults(defineProps<FormProps>(), {
  submitOnEnter: true,
  showErrorMessage: true,
  validateTrigger: 'onBlur' as FieldValidateTrigger,
});

const emits = defineEmits<{
  (e: 'submit', values: any): void;
  (e: 'failed', errorInfo: { values: any; errors: FieldValidateError[] }): void;
}>();
const { children, linkChildren } = useChildren(FORM_KEY);

const getFieldsByNames = (names?: string[]) => {
  if (names) {
    return children.filter((field) => names.includes(field.name));
  }
  return children;
};

const validateSeq = (names?: string[]) =>
  new Promise<void>((resolve, reject) => {
    const errors: FieldValidateError[] = [];
    const fields = getFieldsByNames(names);

    fields
      .reduce(
        (promise, field) =>
          promise.then(() => {
            if (!errors.length) {
              return field.validate().then((error?: FieldValidateError) => {
                if (error) {
                  errors.push(error);
                }
              });
            }
          }),
        Promise.resolve()
      )
      .then(() => {
        if (errors.length) {
          reject(errors);
        } else {
          resolve();
        }
      });
  });

const validateAll = (names?: string[]) =>
  new Promise<void>((resolve, reject) => {
    const fields = getFieldsByNames(names);
    Promise.all(fields.map((item) => item.validate())).then((errors) => {
      errors = errors.filter(Boolean);

      if (errors.length) {
        reject(errors);
      } else {
        resolve();
      }
    });
  });

const validateField = (name: string) => {
  const matched = children.find((item) => item.name === name);

  if (matched) {
    return new Promise<void>((resolve, reject) => {
      matched.validate().then((error?: FieldValidateError) => {
        if (error) {
          reject(error);
        } else {
          resolve();
        }
      });
    });
  }

  return Promise.reject();
};

const validate = (name?: string | string[]) => {
  if (typeof name === 'string') {
    return validateField(name);
  }
  return props.validateFirst ? validateSeq(name) : validateAll(name);
};

const resetValidation = (name?: string | string[]) => {
  if (typeof name === 'string') {
    name = [name];
  }

  const fields = getFieldsByNames(name);
  fields.forEach((item) => {
    item.resetValidation();
  });
};

const getValidationStatus = () =>
  children.reduce<Record<string, FieldValidationStatus>>((form, field) => {
    form[field.name] = field.getValidationStatus();
    return form;
  }, {});

const scrollToField = (name: string, options?: boolean | ScrollIntoViewOptions) => {
  children.some((item) => {
    if (item.name === name) {
      item.$el.scrollIntoView(options);
      return true;
    }
    return false;
  });
};

const getValues = () =>
  children.reduce<Record<string, unknown>>((form, field) => {
    if (field.name !== undefined) {
      form[field.name] = field.formValue.value;
    }
    return form;
  }, {});

const submit = () => {
  const values = getValues();

  validate()
    .then(() => emits('submit', values))
    .catch((errors: FieldValidateError[]) => {
      emits('failed', { values, errors });
      const { scrollToError, scrollToErrorPosition } = props;

      if (scrollToError && errors[0]?.name) {
        scrollToField(
          errors[0].name,
          scrollToErrorPosition
            ? {
                block: scrollToErrorPosition,
              }
            : undefined
        );
      }
    });
};

const onSubmit = (event: Event) => {
  preventDefault(event);
  submit();
};

linkChildren({ props });
defineExpose<FormExpose>({
  submit,
  validate,
  getValues,
  scrollToField,
  resetValidation,
  getValidationStatus,
});
</script>

<template>
  <form class="ht-form" :onSubmit="onSubmit">
    <slot />
  </form>
</template>

<style>
:root {
  --form-container-padding-default: 0; /** 表单容器默认内边距 */
  --form-container-bg-color-default: #ffffff; /** 表单容器默认背景色 */
}
@layer components {
  .ht-form {
    padding: var(--form-container-padding-default);
    background-color: var(--form-container-bg-color-default);
  }
}
</style>
