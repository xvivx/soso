import type { ComponentPublicInstance } from 'vue';
import type { FieldTextAlign, FieldValidateTrigger, FieldValidationStatus } from '../field/types';

export interface FormProps {
  colon?: boolean;
  disabled?: boolean;
  readonly?: boolean;
  required?: boolean | 'auto';
  showError?: boolean;
  labelWidth?: number | string;
  labelAlign?: FieldTextAlign;
  inputAlign?: FieldTextAlign;
  scrollToError?: boolean;
  scrollToErrorPosition?: ScrollLogicalPosition;
  validateFirst?: boolean;
  submitOnEnter?: boolean;
  showErrorMessage?: boolean;
  errorMessageAlign?: FieldTextAlign;
  validateTrigger?: FieldValidateTrigger | FieldValidateTrigger[];
}

export type FormProvide = {
  props: FormProps;
};

export type FormExpose = {
  submit: () => void;
  validate: (name?: string | string[] | undefined) => Promise<void>;
  getValues: () => Record<string, unknown>;
  scrollToField: (name: string, options?: boolean | ScrollIntoViewOptions | undefined) => void;
  resetValidation: (name?: string | string[] | undefined) => void;
  getValidationStatus: () => Record<string, FieldValidationStatus>;
};

export type FormInstance = ComponentPublicInstance<FormProps, FormExpose>;
