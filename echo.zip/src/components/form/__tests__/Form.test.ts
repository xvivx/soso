import { reactive, ref } from 'vue';
import { mount } from '@vue/test-utils';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import Field from '../../field/index.vue';
import Form from '../Form.vue';

describe('Form 组件', () => {
  beforeEach(() => {
    document.body.innerHTML = '';
  });

  describe('基础渲染', () => {
    it('应该渲染为 form 标签', () => {
      const wrapper = mount(Form);
      expect(wrapper.find('form').exists()).toBe(true);
      expect(wrapper.find('.ht-form').exists()).toBe(true);
    });
  });

  describe('表单提交', () => {
    it('提交表单时验证通过应该调用 getValues', async () => {
      const wrapper = mount(
        {
          components: { Form, Field },
          template: `
            <Form ref="formRef">
              <Field name="username" v-model="formData.username" label="用户名" />
              <Field name="email" v-model="formData.email" label="邮箱" />
            </Form>
          `,
          setup() {
            const formData = {
              username: 'test',
              email: 'test@example.com',
            };
            return { formData };
          },
        },
        { attachTo: document.body }
      );

      const formRef = wrapper.findComponent({ name: 'Form' });
      await wrapper.vm.$nextTick();
      // 等待Field组件挂载和注册
      await new Promise((resolve) => setTimeout(resolve, 10));

      const values = (formRef.vm as any).getValues();

      expect(values).toBeDefined();
      expect(values.username).toBe('test');
      expect(values.email).toBe('test@example.com');

      wrapper.unmount();
    });

    it('提交时应该阻止默认表单提交行为', async () => {
      const wrapper = mount(Form);
      const form = wrapper.find('form');

      const event = new Event('submit', { bubbles: true, cancelable: true });
      const preventDefaultSpy = vi.spyOn(event, 'preventDefault');

      form.element.dispatchEvent(event);

      expect(preventDefaultSpy).toHaveBeenCalled();
    });

    it('验证失败时应该触发 failed 事件', async () => {
      const onFailed = vi.fn();
      const wrapper = mount(
        {
          components: { Form, Field },
          template: `
            <Form ref="formRef" @failed="onFailed">
              <Field 
                name="username" 
                v-model="formData.username" 
                :rules="[{ required: true, message: '用户名必填' }]"
                label="用户名"
              />
            </Form>
          `,
          setup() {
            const formData = {
              username: '',
            };
            return { formData, onFailed };
          },
        },
        { attachTo: document.body }
      );

      const formRef = wrapper.findComponent({ name: 'Form' });
      await wrapper.vm.$nextTick();
      // 等待Field组件挂载和注册
      await new Promise((resolve) => setTimeout(resolve, 10));

      // 调用 submit 方法，验证失败时会触发 failed 事件
      (formRef.vm as any).submit();
      await wrapper.vm.$nextTick();
      // 等待验证完成
      await new Promise((resolve) => setTimeout(resolve, 10));

      // 验证 failed 事件被触发
      expect(onFailed).toHaveBeenCalled();
      // 验证事件参数包含 values 和 errors
      const callArgs = onFailed.mock.calls[0][0];
      expect(callArgs).toHaveProperty('values');
      expect(callArgs).toHaveProperty('errors');
      expect(Array.isArray(callArgs.errors)).toBe(true);
      expect(callArgs.errors.length).toBeGreaterThan(0);

      wrapper.unmount();
    });
  });

  describe('表单验证', () => {
    it('validate 方法应该验证所有字段', async () => {
      const wrapper = mount(
        {
          components: { Form, Field },
          template: `
            <Form ref="formRef">
              <Field 
                name="username" 
                v-model="formData.username" 
                :rules="[{ required: true, message: '用户名必填' }]"
                label="用户名"
              />
              <Field 
                name="email" 
                v-model="formData.email" 
                :rules="[{ required: true, message: '邮箱必填' }]"
                label="邮箱"
              />
              <Field 
                name="phone" 
                v-model="formData.phone" 
                :rules="[{ required: true, message: '手机号必填' }]"
                label="手机号"
              />
            </Form>
          `,
          setup() {
            const formData = {
              username: '',
              email: '',
              phone: '',
            };
            return { formData };
          },
        },
        { attachTo: document.body }
      );

      const formRef = wrapper.findComponent({ name: 'Form' });
      await wrapper.vm.$nextTick();
      // 等待Field组件挂载和注册
      await new Promise((resolve) => setTimeout(resolve, 10));

      // validate 方法返回 rejected Promise，不会抛出错误
      await expect((formRef.vm as any).validate()).rejects.toBeDefined();

      // 验证所有字段都被验证了（通过检查验证状态）
      const status = (formRef.vm as any).getValidationStatus();
      expect(status.username).toBe('failed');
      expect(status.email).toBe('failed');
      expect(status.phone).toBe('failed');

      wrapper.unmount();
    });

    it('validate 方法应该验证指定字段（字符串）', async () => {
      const wrapper = mount(
        {
          components: { Form, Field },
          template: `
            <Form ref="formRef">
              <Field 
                name="username" 
                v-model="formData.username" 
                :rules="[{ required: true, message: '用户名必填' }]"
                label="用户名"
              />
              <Field 
                name="email" 
                v-model="formData.email" 
                :rules="[{ required: true, message: '邮箱必填' }]"
                label="邮箱"
              />
            </Form>
          `,
          setup() {
            const formData = {
              username: '',
              email: 'test@example.com',
            };
            return { formData };
          },
        },
        { attachTo: document.body }
      );

      const formRef = wrapper.findComponent({ name: 'Form' });
      await wrapper.vm.$nextTick();
      // 等待Field组件挂载和注册
      await new Promise((resolve) => setTimeout(resolve, 10));

      // validate 方法返回 rejected Promise
      await expect((formRef.vm as any).validate('username')).rejects.toBeDefined();

      // 验证只有指定的字段被验证了
      const status = (formRef.vm as any).getValidationStatus();
      expect(status.username).toBe('failed');
      expect(status.email).toBe('unvalidated'); // email 不应该被验证

      wrapper.unmount();
    });

    it('validate 方法应该验证指定字段（数组）', async () => {
      const wrapper = mount(
        {
          components: { Form, Field },
          template: `
            <Form ref="formRef">
              <Field 
                name="username" 
                v-model="formData.username" 
                :rules="[{ required: true, message: '用户名必填' }]"
                label="用户名"
              />
              <Field 
                name="email" 
                v-model="formData.email" 
                :rules="[{ required: true, message: '邮箱必填' }]"
                label="邮箱"
              />
              <Field 
                name="phone" 
                v-model="formData.phone" 
                :rules="[{ required: true, message: '手机号必填' }]"
                label="手机号"
              />
            </Form>
          `,
          setup() {
            const formData = {
              username: '',
              email: '',
              phone: '123456',
            };
            return { formData };
          },
        },
        { attachTo: document.body }
      );

      const formRef = wrapper.findComponent({ name: 'Form' });
      await wrapper.vm.$nextTick();
      // 等待Field组件挂载和注册
      await new Promise((resolve) => setTimeout(resolve, 10));

      // validate 方法返回 rejected Promise
      await expect((formRef.vm as any).validate(['username', 'email'])).rejects.toBeDefined();

      // 验证只有指定的字段被验证了
      const status = (formRef.vm as any).getValidationStatus();
      expect(status.username).toBe('failed');
      expect(status.email).toBe('failed');
      expect(status.phone).toBe('unvalidated'); // phone 不应该被验证

      wrapper.unmount();
    });

    it('validateFirst 为 true 时应该顺序验证，遇到错误即停止', async () => {
      const wrapper = mount(
        {
          components: { Form, Field },
          template: `
            <Form ref="formRef" :validateFirst="true">
              <Field 
                name="field1" 
                v-model="formData.field1" 
                :rules="[{ required: true, message: '字段1必填' }]"
                label="字段1"
              />
              <Field 
                name="field2" 
                v-model="formData.field2" 
                :rules="[{ required: true, message: '字段2必填' }]"
                label="字段2"
              />
              <Field 
                name="field3" 
                v-model="formData.field3" 
                :rules="[{ required: true, message: '字段3必填' }]"
                label="字段3"
              />
            </Form>
          `,
          setup() {
            const formData = {
              field1: '',
              field2: '',
              field3: '',
            };
            return { formData };
          },
        },
        { attachTo: document.body }
      );

      const formRef = wrapper.findComponent({ name: 'Form' });
      await wrapper.vm.$nextTick();
      // 等待Field组件挂载和注册
      await new Promise((resolve) => setTimeout(resolve, 10));

      // validate 方法返回 rejected Promise
      await expect((formRef.vm as any).validate()).rejects.toBeDefined();

      // validateFirst 为 true 时，遇到第一个错误即停止
      const rejectedPromise = (formRef.vm as any).validate();
      await expect(rejectedPromise).rejects.toHaveProperty('length', 1);

      wrapper.unmount();
    });
  });

  describe('重置验证', () => {
    it('resetValidation 方法应该重置所有字段的验证状态', async () => {
      const wrapper = mount(
        {
          components: { Form, Field },
          template: `
            <Form ref="formRef">
              <Field 
                name="username" 
                v-model="formData.username" 
                :rules="[{ required: true, message: '用户名必填' }]"
                label="用户名"
              />
            </Form>
          `,
          setup() {
            const formData = {
              username: '',
            };
            return { formData };
          },
        },
        { attachTo: document.body }
      );

      const formRef = wrapper.findComponent({ name: 'Form' });
      await wrapper.vm.$nextTick();
      // 等待Field组件挂载和注册
      await new Promise((resolve) => setTimeout(resolve, 10));

      // 先触发验证（使用 expect().rejects）
      await expect((formRef.vm as any).validate()).rejects.toBeDefined();

      // 重置验证
      (formRef.vm as any).resetValidation();
      await wrapper.vm.$nextTick();

      // 验证状态应该被重置
      const status = (formRef.vm as any).getValidationStatus();
      expect(status.username).toBe('unvalidated');

      wrapper.unmount();
    });

    it('resetValidation 方法应该重置指定字段的验证状态（字符串）', async () => {
      const wrapper = mount(
        {
          components: { Form, Field },
          template: `
            <Form ref="formRef">
              <Field 
                name="username" 
                v-model="formData.username" 
                :rules="[{ required: true, message: '用户名必填' }]"
                label="用户名"
              />
              <Field 
                name="email" 
                v-model="formData.email" 
                :rules="[{ required: true, message: '邮箱必填' }]"
                label="邮箱"
              />
            </Form>
          `,
          setup() {
            const formData = {
              username: '',
              email: '',
            };
            return { formData };
          },
        },
        { attachTo: document.body }
      );

      const formRef = wrapper.findComponent({ name: 'Form' });
      await wrapper.vm.$nextTick();
      // 等待Field组件挂载和注册
      await new Promise((resolve) => setTimeout(resolve, 10));

      // 先触发验证（使用 expect().rejects）
      await expect((formRef.vm as any).validate()).rejects.toBeDefined();

      // 重置指定字段的验证
      (formRef.vm as any).resetValidation('username');
      await wrapper.vm.$nextTick();

      // 验证只有 username 被重置，email 保持 failed 状态
      const status = (formRef.vm as any).getValidationStatus();
      expect(status.username).toBe('unvalidated');
      expect(status.email).toBe('failed'); // email 没有被重置

      wrapper.unmount();
    });

    it('resetValidation 方法应该重置指定字段的验证状态（数组）', async () => {
      const wrapper = mount(
        {
          components: { Form, Field },
          template: `
            <Form ref="formRef">
              <Field 
                name="username" 
                v-model="formData.username" 
                :rules="[{ required: true, message: '用户名必填' }]"
                label="用户名"
              />
              <Field 
                name="email" 
                v-model="formData.email" 
                :rules="[{ required: true, message: '邮箱必填' }]"
                label="邮箱"
              />
              <Field 
                name="phone" 
                v-model="formData.phone" 
                :rules="[{ required: true, message: '手机号必填' }]"
                label="手机号"
              />
            </Form>
          `,
          setup() {
            const formData = {
              username: '',
              email: '',
              phone: '',
            };
            return { formData };
          },
        },
        { attachTo: document.body }
      );

      const formRef = wrapper.findComponent({ name: 'Form' });
      await wrapper.vm.$nextTick();
      // 等待Field组件挂载和注册
      await new Promise((resolve) => setTimeout(resolve, 10));

      // 先触发验证（使用 expect().rejects）
      await expect((formRef.vm as any).validate()).rejects.toBeDefined();

      // 重置指定字段的验证
      (formRef.vm as any).resetValidation(['username', 'email']);
      await wrapper.vm.$nextTick();

      // 验证只有 username 和 email 被重置，phone 保持 failed 状态
      const status = (formRef.vm as any).getValidationStatus();
      expect(status.username).toBe('unvalidated');
      expect(status.email).toBe('unvalidated');
      expect(status.phone).toBe('failed'); // phone 没有被重置

      wrapper.unmount();
    });
  });

  describe('获取表单值', () => {
    it('getValues 方法应该返回所有字段的值', async () => {
      const wrapper = mount(
        {
          components: { Form, Field },
          template: `
            <Form ref="formRef">
              <Field name="username" v-model="formData.username" />
              <Field name="email" v-model="formData.email" />
              <Field name="age" v-model="formData.age" />
            </Form>
          `,
          setup() {
            const formData = {
              username: 'testuser',
              email: 'test@example.com',
              age: '25',
            };
            return { formData };
          },
        },
        { attachTo: document.body }
      );

      const formRef = wrapper.findComponent({ name: 'Form' });
      await wrapper.vm.$nextTick();
      // 等待Field组件挂载和注册
      await new Promise((resolve) => setTimeout(resolve, 10));

      const values = (formRef.vm as any).getValues();

      expect(values).toBeDefined();
      expect(typeof values).toBe('object');
      expect(values.username).toBe('testuser');
      expect(values.email).toBe('test@example.com');
      expect(values.age).toBe('25');

      wrapper.unmount();
    });

    it('getValues 应该只返回有 name 属性的字段', async () => {
      const wrapper = mount(
        {
          components: { Form, Field },
          template: `
            <Form ref="formRef">
              <Field name="username" v-model="formData.username" />
              <Field v-model="formData.noName" />
            </Form>
          `,
          setup() {
            const formData = {
              username: 'testuser',
              noName: 'value',
            };
            return { formData };
          },
        },
        { attachTo: document.body }
      );

      const formRef = wrapper.findComponent({ name: 'Form' });
      await wrapper.vm.$nextTick();
      // 等待Field组件挂载和注册
      await new Promise((resolve) => setTimeout(resolve, 10));

      const values = (formRef.vm as any).getValues();

      expect(values.username).toBe('testuser');
      expect(values.noName).toBeUndefined();
      expect(Object.keys(values).length).toBe(1);

      wrapper.unmount();
    });
  });

  describe('获取验证状态', () => {
    it('getValidationStatus 方法应该返回所有字段的验证状态', async () => {
      const wrapper = mount(
        {
          components: { Form, Field },
          template: `
            <Form ref="formRef">
              <Field 
                name="username" 
                v-model="formData.username" 
                :rules="[{ required: true, message: '用户名必填' }]"
              />
              <Field 
                name="email" 
                v-model="formData.email" 
              />
            </Form>
          `,
          setup() {
            const formData = {
              username: 'testuser',
              email: 'test@example.com',
            };
            return { formData };
          },
        },
        { attachTo: document.body }
      );

      const formRef = wrapper.findComponent({ name: 'Form' });
      await wrapper.vm.$nextTick();

      const status = (formRef.vm as any).getValidationStatus();

      expect(status).toBeDefined();
      expect(typeof status).toBe('object');
      expect(status.username).toBeDefined();
      expect(status.email).toBeDefined();

      wrapper.unmount();
    });
  });

  describe('滚动到字段', () => {
    it('scrollToField 方法应该滚动到指定字段', async () => {
      const wrapper = mount(
        {
          components: { Form, Field },
          template: `
            <Form ref="formRef">
              <Field name="field1" v-model="formData.field1" />
              <Field name="field2" v-model="formData.field2" />
              <Field name="field3" v-model="formData.field3" />
            </Form>
          `,
          setup() {
            const formData = {
              field1: '',
              field2: '',
              field3: '',
            };
            return { formData };
          },
        },
        { attachTo: document.body }
      );

      const formRef = wrapper.findComponent({ name: 'Form' });
      const fields = wrapper.findAllComponents(Field);
      const field1 = fields[0];
      const field2 = fields[1];
      const field3 = fields[2];

      const scrollIntoViewSpy1 = vi.fn();
      const scrollIntoViewSpy2 = vi.fn();
      const scrollIntoViewSpy3 = vi.fn();
      field1.element.scrollIntoView = scrollIntoViewSpy1;
      field2.element.scrollIntoView = scrollIntoViewSpy2;
      field3.element.scrollIntoView = scrollIntoViewSpy3;

      // 滚动到 field2
      (formRef.vm as any).scrollToField('field2');

      // 验证只有 field2 的 scrollIntoView 被调用
      expect(scrollIntoViewSpy1).not.toHaveBeenCalled();
      expect(scrollIntoViewSpy2).toHaveBeenCalled();
      expect(scrollIntoViewSpy3).not.toHaveBeenCalled();

      wrapper.unmount();
    });

    it('scrollToField 方法应该支持滚动选项', async () => {
      const wrapper = mount(
        {
          components: { Form, Field },
          template: `
            <Form ref="formRef">
              <Field name="field1" v-model="formData.field1" />
            </Form>
          `,
          setup() {
            const formData = {
              field1: '',
            };
            return { formData };
          },
        },
        { attachTo: document.body }
      );

      const formRef = wrapper.findComponent({ name: 'Form' });
      const field1 = wrapper.findComponent(Field);

      const scrollIntoViewSpy = vi.fn();
      field1.element.scrollIntoView = scrollIntoViewSpy;

      (formRef.vm as any).scrollToField('field1', { block: 'center' });

      expect(scrollIntoViewSpy).toHaveBeenCalledWith({ block: 'center' });

      wrapper.unmount();
    });

    it('scrollToError 为 true 时验证失败应该滚动到错误字段', async () => {
      const wrapper = mount(
        {
          components: { Form, Field },
          template: `
            <Form ref="formRef" :scrollToError="true">
              <Field 
                name="field1" 
                v-model="formData.field1" 
                :rules="[{ required: true, message: '字段1必填' }]"
                label="字段1"
              />
              <Field 
                name="field2" 
                v-model="formData.field2" 
                :rules="[{ required: true, message: '字段2必填' }]"
                label="字段2"
              />
            </Form>
          `,
          setup() {
            const formData = {
              field1: '',
              field2: '',
            };
            return { formData };
          },
        },
        { attachTo: document.body }
      );

      const formRef = wrapper.findComponent({ name: 'Form' });
      const field1 = wrapper.findAllComponents(Field)[0];

      const scrollIntoViewSpy = vi.fn();
      const field1El = field1.element as HTMLElement;
      field1El.scrollIntoView = scrollIntoViewSpy;

      await (formRef.vm as any).submit();
      await wrapper.vm.$nextTick();
      // 需要等待验证完成
      await new Promise((resolve) => setTimeout(resolve, 10));

      expect(scrollIntoViewSpy).toHaveBeenCalled();

      wrapper.unmount();
    });

    it('scrollToErrorPosition 应该影响滚动位置', async () => {
      const wrapper = mount(
        {
          components: { Form, Field },
          template: `
            <Form ref="formRef" :scrollToError="true" scrollToErrorPosition="center">
              <Field 
                name="field1" 
                v-model="formData.field1" 
                :rules="[{ required: true, message: '字段1必填' }]"
                label="字段1"
              />
            </Form>
          `,
          setup() {
            const formData = {
              field1: '',
            };
            return { formData };
          },
        },
        { attachTo: document.body }
      );

      const formRef = wrapper.findComponent({ name: 'Form' });
      const field1 = wrapper.findComponent(Field);

      const scrollIntoViewSpy = vi.fn();
      const field1El = field1.element as HTMLElement;
      field1El.scrollIntoView = scrollIntoViewSpy;

      await (formRef.vm as any).submit();
      await wrapper.vm.$nextTick();
      // 需要等待验证完成
      await new Promise((resolve) => setTimeout(resolve, 10));

      expect(scrollIntoViewSpy).toHaveBeenCalledWith({ block: 'center' });

      wrapper.unmount();
    });
  });

  describe('表单属性传递', () => {
    it('应该通过 provide 传递表单属性到子字段', async () => {
      const wrapper = mount(
        {
          components: { Form, Field },
          template: `
            <Form 
              ref="formRef"
              :disabled="true"
              :readonly="true"
              labelAlign="right"
            >
              <Field name="username" v-model="formData.username" label="用户名" />
            </Form>
          `,
          setup() {
            const formData = {
              username: '',
            };
            return { formData };
          },
        },
        { attachTo: document.body }
      );

      const field = wrapper.findComponent(Field);
      await wrapper.vm.$nextTick();

      const input = field.find('input');
      expect(input.attributes('disabled')).toBeDefined();
      expect(input.attributes('readonly')).toBeDefined();

      wrapper.unmount();
    });

    it('showErrorMessage 为 false 时应该隐藏错误消息', async () => {
      const wrapper = mount(
        {
          components: { Form, Field },
          template: `
            <Form ref="formRef" :showErrorMessage="false">
              <Field 
                name="username" 
                v-model="formData.username" 
                :rules="[{ required: true, message: '用户名必填' }]"
                label="用户名"
              />
            </Form>
          `,
          setup() {
            const formData = {
              username: '',
            };
            return { formData };
          },
        },
        { attachTo: document.body }
      );

      const formRef = wrapper.findComponent({ name: 'Form' });
      const field = wrapper.findComponent(Field);
      await wrapper.vm.$nextTick();
      // 等待Field组件挂载和注册
      await new Promise((resolve) => setTimeout(resolve, 10));

      // 验证失败
      await expect((formRef.vm as any).validate()).rejects.toBeDefined();
      await wrapper.vm.$nextTick();

      // 验证错误消息的 DOM 元素不存在（因为 showErrorMessage=false）
      const errorMessage = field.find('.ht-field__error-message');
      expect(errorMessage.exists()).toBe(false);

      // 验证字段状态确实是 failed（说明验证执行了，只是消息被隐藏）
      const status = (formRef.vm as any).getValidationStatus();
      expect(status.username).toBe('failed');

      wrapper.unmount();
    });

    it('validateTrigger 为 onChange 时应该通过 Form 传递给 Field', async () => {
      const wrapper = mount(
        {
          components: { Form, Field },
          template: `
            <Form ref="formRef" validateTrigger="onChange">
              <Field 
                name="username" 
                v-model="formData.username" 
                :rules="[{ required: true, message: '用户名必填' }]"
                label="用户名"
              />
            </Form>
          `,
          setup() {
            const formData = ref({
              username: '',
            });
            return { formData };
          },
        },
        { attachTo: document.body }
      );

      await wrapper.vm.$nextTick();
      // 等待Field组件挂载和注册
      await new Promise((resolve) => setTimeout(resolve, 10));

      const formRef = wrapper.findComponent({ name: 'Form' });

      // 初始状态应该是 unvalidated
      let status = (formRef.vm as any).getValidationStatus();
      expect(status.username).toBe('unvalidated');

      // 修改 formData，这会触发 Field 的 watch(modelValue)，进而调用 validateWithTrigger('onChange')
      (wrapper.vm as any).formData.username = 'testuser';
      await wrapper.vm.$nextTick();
      // 等待验证完成
      await new Promise((resolve) => setTimeout(resolve, 50));

      // 验证状态应该变为 passed（说明 onChange 触发了验证）
      status = (formRef.vm as any).getValidationStatus();
      expect(status.username).toBe('passed');

      wrapper.unmount();
    });
  });

  describe('边界情况', () => {
    it('没有子字段时 validate 应该成功', async () => {
      const wrapper = mount(Form);

      await expect((wrapper.vm as any).validate()).resolves.toBeUndefined();
    });

    it('没有子字段时 getValues 应该返回空对象', () => {
      const wrapper = mount(Form);
      const values = (wrapper.vm as any).getValues();

      expect(values).toEqual({});
    });

    it('没有子字段时 getValidationStatus 应该返回空对象', () => {
      const wrapper = mount(Form);
      const status = (wrapper.vm as any).getValidationStatus();

      expect(status).toEqual({});
    });

    it('验证不存在的字段应该返回 rejected Promise', async () => {
      const wrapper = mount(Form);

      await expect((wrapper.vm as any).validate('nonExistentField')).rejects.toBeUndefined();
    });

    it('滚动到不存在的字段不应该抛出错误', () => {
      const wrapper = mount(Form);

      expect(() => {
        (wrapper.vm as any).scrollToField('nonExistentField');
      }).not.toThrow();
    });

    it('重置不存在的字段验证不应该抛出错误', () => {
      const wrapper = mount(Form);

      expect(() => {
        (wrapper.vm as any).resetValidation('nonExistentField');
      }).not.toThrow();
    });
  });

  describe('复杂场景', () => {
    it('应该支持动态添加和移除字段', async () => {
      const wrapper = mount(
        {
          components: { Form, Field },
          template: `
            <Form ref="formRef">
              <Field 
                v-for="field in fields" 
                :key="field.name"
                :name="field.name" 
                v-model="formData[field.name]" 
              />
            </Form>
          `,
          setup() {
            const fields = ref([{ name: 'field1' }, { name: 'field2' }]);
            const formData: Record<string, string> = reactive({
              field1: 'value1',
              field2: 'value2',
            });
            return { fields, formData };
          },
        },
        { attachTo: document.body }
      );

      const formRef = wrapper.findComponent({ name: 'Form' });
      await wrapper.vm.$nextTick();
      // 等待Field组件挂载和注册
      await new Promise((resolve) => setTimeout(resolve, 10));

      // 初始状态：2个字段
      let values = (formRef.vm as any).getValues();
      expect(Object.keys(values).length).toBe(2);
      expect(values.field1).toBe('value1');
      expect(values.field2).toBe('value2');

      // 动态添加字段 field3
      (wrapper.vm as any).fields.push({ name: 'field3' });
      (wrapper.vm as any).formData.field3 = 'value3';
      await wrapper.vm.$nextTick();
      // 等待新Field组件挂载和注册
      await new Promise((resolve) => setTimeout(resolve, 10));

      // 验证添加后：3个字段
      values = (formRef.vm as any).getValues();
      expect(Object.keys(values).length).toBe(3);
      expect(values.field1).toBe('value1');
      expect(values.field2).toBe('value2');
      expect(values.field3).toBe('value3');

      // 动态移除字段 field2
      const field2Index = (wrapper.vm as any).fields.findIndex((f: any) => f.name === 'field2');
      (wrapper.vm as any).fields.splice(field2Index, 1);
      await wrapper.vm.$nextTick();
      // 等待Field组件卸载
      await new Promise((resolve) => setTimeout(resolve, 10));

      // 验证移除后：只剩2个字段（field1 和 field3）
      values = (formRef.vm as any).getValues();
      expect(Object.keys(values).length).toBe(2);
      expect(values.field1).toBe('value1');
      expect(values.field2).toBeUndefined(); // field2 已被移除
      expect(values.field3).toBe('value3');

      wrapper.unmount();
    });

    it('应该支持多层嵌套的表单结构', async () => {
      const wrapper = mount(
        {
          components: { Form, Field },
          template: `
            <Form ref="formRef">
              <div class="section">
                <Field name="field1" v-model="formData.field1" />
                <div class="nested">
                  <Field name="field2" v-model="formData.field2" />
                </div>
              </div>
            </Form>
          `,
          setup() {
            const formData = {
              field1: 'value1',
              field2: 'value2',
            };
            return { formData };
          },
        },
        { attachTo: document.body }
      );

      const formRef = wrapper.findComponent({ name: 'Form' });
      await wrapper.vm.$nextTick();

      const values = (formRef.vm as any).getValues();
      expect(Object.keys(values).length).toBe(2);

      wrapper.unmount();
    });

    it('混合有验证和无验证的字段应该正常工作', async () => {
      const wrapper = mount(
        {
          components: { Form, Field },
          template: `
            <Form ref="formRef">
              <Field 
                name="required" 
                v-model="formData.required" 
                :rules="[{ required: true, message: '必填' }]"
              />
              <Field 
                name="optional" 
                v-model="formData.optional" 
              />
            </Form>
          `,
          setup() {
            const formData = {
              required: 'value',
              optional: '',
            };
            return { formData };
          },
        },
        { attachTo: document.body }
      );

      const formRef = wrapper.findComponent({ name: 'Form' });

      await expect((formRef.vm as any).validate()).resolves.toBeUndefined();

      wrapper.unmount();
    });
  });
});
