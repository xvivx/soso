// 导出 vue-lazyload 组件和类型
// 地址：https://github.com/hilongjw/vue-lazyload
import {
  default as Lazyload,
  type loadImageAsyncOption,
  type VueLazyloadHandler,
  type VueLazyloadOptions,
  type VueReactiveListener,
} from 'vue-lazyload';

export default Lazyload;
export { Lazyload };
export type { VueLazyloadOptions, VueLazyloadHandler, VueReactiveListener, loadImageAsyncOption };
