<script setup lang="ts">
import { computed, nextTick, onMounted, provide, reactive, ref, useId, useSlots, watch } from 'vue';
import { HTIcon } from '@/components/icon';
import { clamp, FORM_KEY, formatNumber, isDef, preventDefault, resetScroll, toArray } from '@/utils/index';
import { CUSTOM_FIELD_INJECTION_KEY, useExpose, useParent } from '@/hooks';
import { fieldProps } from './props';
import type {
  FieldExpose,
  FieldFormatTrigger,
  FieldRule,
  FieldValidateError,
  FieldValidateTrigger,
  FieldValidationStatus,
} from './types';
import {
  cutString,
  getRuleMessage,
  getStringLength,
  isEmptyValue,
  resizeTextarea,
  runRuleValidator,
  runSyncRule,
} from './utils';

const props = defineProps(fieldProps);

const slots = useSlots();

const emit = defineEmits([
  'blur',
  'focus',
  'clear',
  'keypress',
  'clickInput',
  'endValidate',
  'startValidate',
  'clickLeftIcon',
  'clickRightIcon',
  'clickTips',
  'update:modelValue',
]);

const id = useId();
const { parent: form } = useParent(FORM_KEY);

const state = reactive({
  status: 'unvalidated' as FieldValidationStatus,
  focused: false,
  validateMessage: '',
  passwordVisible: false, // 密码可见性状态
});

const inputRef = ref<HTMLInputElement>();
const customValue = ref<() => unknown>();

const getModelValue = () => String(props.modelValue ?? '');

const getProp = (key: keyof typeof props): any => {
  if (isDef(props[key])) {
    return props[key];
  }
  if (form && isDef(form.props[key])) {
    return form.props[key];
  }
  return undefined;
};

// textarea 行数，默认 5
const rows = computed(() => {
  if (props.rows && typeof props.rows === 'number') return props.rows;
  return 5;
});

// 错误信息显示，优先 props.errorMessage，否则校验消息
const errorMessage = computed(() => {
  if (props.errorMessage) return props.errorMessage;
  return state.validateMessage;
});

const showClear = computed(() => {
  const readonly = getProp('readonly');

  if (props.clearable && !readonly) {
    const hasValue = getModelValue() !== '';
    const trigger = props.clearTrigger === 'always' || (props.clearTrigger === 'focus' && state.focused);

    return hasValue && trigger;
  }
  return false;
});

const formValue = computed(() => {
  if (customValue.value && slots.input) {
    return customValue.value();
  }
  return props.modelValue;
});

const showRequiredMark = computed(() => {
  const required = getProp('required');
  if (required === 'auto') {
    return props.rules?.some((rule: FieldRule) => rule.required);
  }
  return required;
});

// 搜索框相关计算属性
const isSearchType = computed(() => props.type === 'search');
const showSearchIcon = computed(() => isSearchType.value && !props.leftIcon);

// 密码类型相关
const isPasswordType = computed(() => props.type === 'password');
const showPasswordToggle = computed(() => isPasswordType.value && getModelValue() !== '');
const actualInputType = computed(() => {
  if (isPasswordType.value) {
    return state.passwordVisible ? 'text' : 'password';
  }
  return props.type;
});

// 切换密码可见性
const togglePasswordVisibility = () => {
  state.passwordVisible = !state.passwordVisible;
};

// 点击搜索图标
const onClickSearchIcon = (event: MouseEvent) => {
  emit('clickLeftIcon', event);
  focus();
};

const runRules = (rules: FieldRule[]) =>
  rules.reduce(
    (promise, rule: FieldRule) =>
      promise.then(() => {
        if (state.status === 'failed') {
          return;
        }

        let { value } = formValue;

        if (rule.formatter) {
          value = rule.formatter(value, rule);
        }

        if (!runSyncRule(value, rule)) {
          state.status = 'failed';
          state.validateMessage = getRuleMessage(value, rule) as string;
          return;
        }

        if (rule.validator) {
          if (isEmptyValue(value) && rule.validateEmpty === false) {
            return;
          }

          return runRuleValidator(value, rule).then((result) => {
            if (result && typeof result === 'string') {
              state.status = 'failed';
              state.validateMessage = result;
            } else if (result === false) {
              state.status = 'failed';
              state.validateMessage = getRuleMessage(value, rule) as string;
            }
          });
        }
      }),
    Promise.resolve()
  );

const resetValidation = () => {
  state.status = 'unvalidated';
  state.validateMessage = '';
};
const endValidate = () =>
  emit('endValidate', {
    status: state.status,
    message: state.validateMessage,
  });
const validate = (rules = props.rules) =>
  new Promise<FieldValidateError | void>((resolve) => {
    resetValidation();
    if (rules) {
      emit('startValidate');
      runRules(rules).then(() => {
        if (state.status === 'failed') {
          resolve({
            name: props.name,
            message: state.validateMessage,
          } as any);
          endValidate();
        } else {
          state.status = 'passed';
          resolve();
          endValidate();
        }
      });
    } else {
      resolve();
    }
  });
const validateWithTrigger = (trigger: FieldValidateTrigger) => {
  if (form && props.rules) {
    const { validateTrigger } = form.props;
    const defaultTrigger = toArray(validateTrigger).includes(trigger);
    const rules = props.rules.filter((rule) => {
      if (rule.trigger) {
        return toArray(rule.trigger).includes(trigger);
      }
      return defaultTrigger;
    });

    if (rules.length) {
      validate(rules);
    }
  }
  return false;
};

const limitValueLength = (value: string) => {
  const { maxlength } = props;
  if (isDef(maxlength) && getStringLength(value) > +maxlength) {
    const modelValue = getModelValue();
    if (modelValue && getStringLength(modelValue) === +maxlength) {
      return modelValue;
    }
    // Remove redundant interpolated values,
    // make it consistent with the native input maxlength behavior.
    const selectionEnd = inputRef.value?.selectionEnd;
    if (state.focused && selectionEnd) {
      const valueArr = [...value];
      const exceededLength = valueArr.length - +maxlength;
      valueArr.splice(selectionEnd - exceededLength, exceededLength);
      return valueArr.join('');
    }
    return cutString(value, +maxlength);
  }
  return value;
};

const updateValue = (value: string, trigger: FieldFormatTrigger = 'onChange') => {
  const originalValue = value;
  value = limitValueLength(value);

  const limitDiffLen = getStringLength(originalValue) - getStringLength(value);

  if (props.type === 'number' || props.type === 'digit') {
    const isNumber = props.type === 'number';
    value = formatNumber(value, isNumber, isNumber);

    if (trigger === 'onBlur' && value !== '' && (props.min !== undefined || props.max !== undefined)) {
      const adjustedValue = clamp(+value, props.min ?? -Infinity, props.max ?? Infinity);

      if (+value !== adjustedValue) {
        value = adjustedValue.toString();
      }
    }
  }

  let formatterDiffLen = 0;
  if (props.formatter && trigger === props.formatTrigger) {
    const { formatter, maxlength } = props;
    value = formatter(value);
    if (isDef(maxlength) && getStringLength(value) > +maxlength) {
      value = cutString(value, +maxlength);
    }
    if (inputRef.value && state.focused) {
      const { selectionEnd } = inputRef.value;
      const bcoVal = cutString(originalValue, selectionEnd!);
      formatterDiffLen = getStringLength(formatter(bcoVal)) - getStringLength(bcoVal);
    }
  }

  if (inputRef.value && inputRef.value.value !== value) {
    if (state.focused) {
      let { selectionStart, selectionEnd } = inputRef.value;
      inputRef.value.value = value;

      if (isDef(selectionStart) && isDef(selectionEnd)) {
        const valueLen = getStringLength(value);
        selectionStart = selectionStart ?? 0;
        selectionEnd = selectionEnd ?? 0;

        if (limitDiffLen) {
          selectionStart -= limitDiffLen;
          selectionEnd -= limitDiffLen;
        } else if (formatterDiffLen) {
          selectionStart += formatterDiffLen;
          selectionEnd += formatterDiffLen;
        }

        inputRef.value.setSelectionRange(Math.min(selectionStart, valueLen), Math.min(selectionEnd, valueLen));
      }
    } else {
      inputRef.value.value = value;
    }
  }

  if (value !== props.modelValue) {
    emit('update:modelValue', value);
  }
};

const onInput = (event: Event) => {
  // skip update value when composing
  if (!event.target!.composing) {
    updateValue((event.target as HTMLInputElement).value);
  }
};

const blur = () => inputRef.value?.blur();
const focus = () => inputRef.value?.focus();

const adjustTextareaSize = () => {
  const input = inputRef.value;
  if (props.type === 'textarea' && props.autosize && input) {
    resizeTextarea(input, props.autosize);
  }
};

const onFocus = (event: Event) => {
  state.focused = true;
  emit('focus', event);

  if (getProp('readonly')) {
    blur();
  }
};
const onBlur = (event: Event) => {
  updateValue(getModelValue(), 'onBlur');
  emit('blur', event);

  if (getProp('readonly')) {
    return;
  }

  validateWithTrigger('onBlur');
  resetScroll();
  setTimeout(() => {
    state.focused = false;
  }, 100);
};
const onClickInput = (event: MouseEvent) => emit('clickInput', event);

const onClickLeftIcon = (event: MouseEvent) => emit('clickLeftIcon', event);

const onClickRightIcon = (event: MouseEvent) => emit('clickRightIcon', event);

const onClear = (event?: MouseEvent) => {
  if (event) {
    preventDefault(event);
  }

  // 清除输入框的值
  if (inputRef.value) {
    inputRef.value.value = '';
  }

  // 更新内部状态
  emit('update:modelValue', '');
  emit('clear', event);

  // 重新校验和重置状态
  resetValidation();

  // 保持焦点（如果需要的话）
  nextTick(() => {
    if (inputRef.value && state.focused) {
      inputRef.value.focus();
    }
  });
};

const showError = computed(() => {
  if (typeof props.error === 'boolean') {
    return props.error;
  }
  if (form && form.props.showError && state.status === 'failed') {
    return true;
  }
  return false;
});

const onKeypress = (event: KeyboardEvent) => {
  const ENTER_CODE = 13;

  if (event.keyCode === ENTER_CODE) {
    const submitOnEnter = form && form.props.submitOnEnter;
    if (!submitOnEnter && props.type !== 'textarea') {
      preventDefault(event);
    }

    // trigger blur after click keyboard search button
    if (props.type === 'search') {
      blur();
    }
  }

  emit('keypress', event);
};

const getInputId = () => props.id || `${id}-input`;

const getValidationStatus = () => state.status;

const controlClass = computed(() => {
  return [
    'ht-field__control',
    `ht-field__control-${getProp('inputAlign')}`,
    {
      error: showError.value,
      custom: !!slots.input,
      'min-height': props.type === 'textarea' && !props.autosize,
    },
  ];
});

provide(CUSTOM_FIELD_INJECTION_KEY, {
  customValue,
  resetValidation,
  validateWithTrigger,
});

watch(
  () => props.modelValue,
  () => {
    updateValue(getModelValue());
    resetValidation();
    validateWithTrigger('onChange');
    nextTick(adjustTextareaSize);
  }
);

onMounted(() => {
  updateValue(getModelValue(), props.formatTrigger);
  nextTick(adjustTextareaSize);
});

useExpose<FieldExpose>({
  blur,
  focus,
  validate,
  formValue,
  resetValidation,
  getValidationStatus,
  clear: onClear,
});
</script>

<template>
  <div class="ht-field" :class="[`ht-field--${props.size}`]">
    <div class="ht-field__header" v-if="props.label">
      <label
        class="ht-field__label"
        :id="`${id}-label`"
        :for="getInputId()"
        data-allow-mismatch="attribute"
        @click.prevent="focus"
      >
        {{ props.label }}
        <span v-if="showRequiredMark" class="ht-field__required">*</span>
        <span v-if="props.optional" class="ht-field__optional">({{ props.optional }})</span>
        <HTIcon
          v-if="props.tips"
          class="ht-field__tips"
          name="warning-o"
          size="16"
          @click.prevent="emit('clickTips')"
        />
      </label>
      <div v-if="props.showWordLimit && props.maxlength" class="ht-field__word-limit">
        <span class="ht-field__word-num">{{ getModelValue().length }}</span
        >/<span>{{ props.maxlength }}</span>
      </div>
    </div>
    <div
      class="ht-field__container"
      :class="{
        'ht-field__container--search': isSearchType,
        'ht-field__container--focused': state.focused,
        'ht-field__container--textarea': type === 'textarea',
      }"
    >
      <div class="ht-field__wrapper" :class="{ 'ht-textarea__wrapper': props.type === 'textarea' }">
        <!-- 左侧图标：优先插槽，其次 props.leftIcon，搜索图标互斥 -->
        <div v-if="slots['left']" class="ht-field__left-icon" @click="onClickLeftIcon">
          <slot name="left" />
        </div>
        <div v-else-if="props.leftIcon" class="ht-field__left-icon" @click="onClickLeftIcon">
          <!-- 左侧图标库 -->
          <HTIcon :name="props.leftIcon" />
        </div>
        <div v-else-if="showSearchIcon" class="ht-field__search-icon" @click="onClickSearchIcon">
          <HTIcon name="search" size="24" />
        </div>
        <template v-if="slots.input">
          <slot name="input" />
        </template>
        <template v-else>
          <textarea
            v-if="props.type === 'textarea'"
            ref="inputRef"
            :name="props.name"
            :id="getInputId()"
            :rows="rows"
            :class="controlClass"
            :disabled="getProp('disabled')"
            :readonly="getProp('readonly')"
            :autofocus="props.autofocus"
            :placeholder="props.placeholder"
            :autocomplete="props.autocomplete"
            :autocapitalize="props.autocapitalize"
            :autocorrect="props.autocorrect"
            :enterkeyhint="props.enterkeyhint"
            :spellcheck="props.spellcheck"
            :inputmode="props.inputmode"
            :aria-labelledby="props.label ? `${id}-label` : undefined"
            data-allow-mismatch="attribute"
            @blur="onBlur"
            @focus="onFocus"
            @input="onInput"
            @click="onClickInput"
            @change="onInput"
            @keypress="onKeypress"
          />
          <input
            v-else
            ref="inputRef"
            :name="props.name"
            :class="controlClass"
            :id="getInputId()"
            :disabled="getProp('disabled')"
            :readonly="getProp('readonly')"
            :autofocus="props.autofocus"
            :placeholder="props.placeholder"
            :autocomplete="props.autocomplete"
            :autocapitalize="props.autocapitalize"
            :autocorrect="props.autocorrect"
            :enterkeyhint="props.enterkeyhint"
            :spellcheck="props.spellcheck"
            :inputmode="props.inputmode"
            :type="actualInputType"
            :aria-labelledby="props.label ? `${id}-label` : undefined"
            data-allow-mismatch="attribute"
            @blur="onBlur"
            @focus="onFocus"
            @input="onInput"
            @click="onClickInput"
            @change="onInput"
            @keypress="onKeypress"
          />
        </template>
        <div class="ht-field__input-suffix" v-if="showClear || showPasswordToggle || props.rightIcon || slots['right']">
          <!-- 清除按钮 -->
          <div v-if="showClear" class="ht-field__clear" @mousedown.prevent="onClear">
            <HTIcon name="cross" size="16" />
          </div>
          <!-- 密码可见性切换图标 -->
          <div
            v-if="showPasswordToggle"
            class="ht-field__password-toggle"
            @mousedown.prevent="togglePasswordVisibility"
          >
            <HTIcon v-if="state.passwordVisible" name="closed-eye" size="20" />
            <HTIcon v-else name="eye-o" size="20" />
          </div>
          <!-- 右侧图标 -->
          <div v-if="props.rightIcon || slots['right']" class="ht-field__right-icon" @click="onClickRightIcon">
            <slot name="right">
              <HTIcon :name="props.rightIcon" />
            </slot>
          </div>
        </div>
      </div>
      <div v-if="slots.button" class="ht-field__button">
        <slot name="button" />
      </div>
    </div>

    <div v-if="errorMessage || message" :class="[{ 'ht-field__error-message': errorMessage }, 'ht-field__message']">
      <slot name="error-message" :message="errorMessage">{{ errorMessage || message }}</slot>
    </div>
  </div>
</template>

<style>
@import url(./styles/index.css);
</style>
