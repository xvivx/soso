import { type ExtractPropTypes, type HTMLAttributes, type PropType } from 'vue';
import { extend, makeNumericProp, makeStringProp, numericProp, unknownProp } from '@/utils/index';
import type {
  FieldAutosizeConfig,
  FieldClearTrigger,
  FieldFormatTrigger,
  FieldRule,
  FieldTextAlign,
  FieldType,
} from './types';

// provide to Search component to inherit
export const fieldSharedProps = {
  id: String,
  name: String,
  leftIcon: String,
  rightIcon: String,
  autofocus: Boolean,
  clearable: Boolean,
  maxlength: numericProp,
  max: Number,
  min: Number,
  formatter: Function as PropType<(value: string) => string>,
  clearIcon: makeStringProp('clear'),
  modelValue: makeNumericProp(''),
  inputAlign: String as PropType<FieldTextAlign>,
  placeholder: {
    type: String,
    default: '请输入内容',
  },
  autocomplete: String,
  autocapitalize: String,
  autocorrect: String,
  errorMessage: String,
  enterkeyhint: String,
  clearTrigger: makeStringProp<FieldClearTrigger>('focus'),
  formatTrigger: makeStringProp<FieldFormatTrigger>('onChange'),
  spellcheck: {
    type: Boolean,
    default: null,
  },
  error: {
    type: Boolean,
    default: null,
  },
  disabled: {
    type: Boolean,
    default: null,
  },
  readonly: {
    type: Boolean,
    default: null,
  },
  inputmode: String as PropType<HTMLAttributes['inputmode']>,
  required: {
    type: [Boolean, String] as PropType<boolean | 'auto'>,
    default: null,
  },
  iconPrefix: String,
};

export const fieldProps = extend(fieldSharedProps, {
  size: {
    type: String as PropType<'normal' | 'large'>,
    default: 'large',
  },
  rows: numericProp,
  type: makeStringProp<FieldType>('text'),
  rules: Array as PropType<FieldRule[]>,
  autosize: [Boolean, Object] as PropType<boolean | FieldAutosizeConfig>,
  label: numericProp,
  labelWidth: numericProp,
  labelClass: unknownProp,
  labelAlign: String as PropType<FieldTextAlign>,
  showWordLimit: Boolean,
  colon: {
    type: Boolean,
    default: null,
  },
  optional: String,
  tips: Boolean,
  message: String,
});

export type FieldProps = ExtractPropTypes<typeof fieldProps>;
