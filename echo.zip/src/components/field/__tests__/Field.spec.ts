import { mount } from '@vue/test-utils';
import { describe, expect, it } from 'vitest';
import Field from '../index.vue';

describe('Field 组件', () => {
  describe('基础渲染与结构', () => {
    it('渲染输入框并显示占位符', () => {
      const wrapper = mount(Field);
      expect(wrapper.find('input').attributes('placeholder')).toBe('请输入内容');
    });

    it('支持设置 modelValue', () => {
      const wrapper = mount(Field, { props: { modelValue: '测试内容' } });
      expect(wrapper.find('input').element.value).toBe('测试内容');
    });

    it('支持 type 属性切换类型', () => {
      const wrapper = mount(Field, { props: { type: 'password' } });
      expect(wrapper.find('input').attributes('type')).toBe('password');
    });

    it('支持输入框对齐方式', () => {
      const wrapper = mount(Field, { props: { inputAlign: 'center' } });
      expect(wrapper.find('.ht-field__control').classes()).toContain('ht-field__control-center');
    });

    it('支持左右图标', () => {
      const wrapper = mount(Field, { props: { leftIcon: 'search', rightIcon: 'close' } });
      expect(wrapper.find('.ht-field__left-icon').exists()).toBe(true);
      expect(wrapper.find('.ht-field__right-icon').exists()).toBe(true);
    });

    it('显示字数统计', () => {
      const wrapper = mount(Field, {
        props: { showWordLimit: true, maxlength: 10, modelValue: '测试', label: '标签' },
      });
      const wordLimit = wrapper.find('.ht-field__word-limit');
      expect(wordLimit.exists()).toBe(true);
      expect(wordLimit.text()).toBe('2/10');
    });

    it('显示必填标记', () => {
      const wrapper = mount(Field, { props: { required: true, label: '姓名' } });
      expect(wrapper.html()).toContain('*');
    });

    it('显示错误信息 errorMessage', () => {
      const wrapper = mount(Field, { props: { errorMessage: '错误信息' } });
      expect(wrapper.text()).toContain('错误信息');
    });
  });

  describe('属性行为', () => {
    it('支持 clearable 属性并显示清除按钮', async () => {
      const wrapper = mount(Field, { props: { clearable: true, modelValue: 'abc' } });
      await wrapper.find('input').trigger('focus');
      expect(wrapper.find('.ht-field__clear').exists()).toBe(true);
    });

    it('支持 disabled 属性', () => {
      const wrapper = mount(Field, { props: { disabled: true } });
      expect(wrapper.find('input').attributes('disabled')).toBeDefined();
    });

    it('支持 readonly 属性', () => {
      const wrapper = mount(Field, { props: { readonly: true } });
      expect(wrapper.find('input').attributes('readonly')).toBeDefined();
    });
  });

  describe('事件', () => {
    it('触发输入事件并更新值', async () => {
      const wrapper = mount(Field, { props: { modelValue: '' } });
      const input = wrapper.find('input');
      await input.setValue('abc');
      const events = wrapper.emitted('update:modelValue');
      expect(events).toBeTruthy();
      expect(events![events!.length - 1][0]).toBe('abc');
    });

    it('触发 focus 与 blur 事件', async () => {
      const wrapper = mount(Field);
      const input = wrapper.find('input');
      await input.trigger('focus');
      await input.trigger('blur');
      expect(wrapper.emitted('focus')).toBeTruthy();
      expect(wrapper.emitted('blur')).toBeTruthy();
    });

    it('点击清除按钮触发 clear 事件并清空值', async () => {
      const wrapper = mount(Field, { props: { clearable: true, modelValue: 'abc' } });
      const input = wrapper.find('input');
      await input.trigger('focus');
      const clear = wrapper.find('.ht-field__clear');
      expect(clear.exists()).toBe(true);
      await clear.trigger('mousedown');
      expect(wrapper.emitted('clear')).toBeTruthy();
      const updates = wrapper.emitted('update:modelValue');
      expect(updates![updates!.length - 1][0]).toBe('');
    });

    it('触发 keypress 事件 (Enter)', async () => {
      const wrapper = mount(Field);
      const input = wrapper.find('input');
      await input.trigger('keypress', { keyCode: 13 });
      expect(wrapper.emitted('keypress')).toBeTruthy();
    });

    it('点击输入区域触发 clickInput 事件', async () => {
      const wrapper = mount(Field);
      const input = wrapper.find('input');
      await input.trigger('click');
      expect(wrapper.emitted('clickInput')).toBeTruthy();
    });

    it('点击左右图标触发对应事件', async () => {
      const wrapper = mount(Field, { props: { leftIcon: 'search', rightIcon: 'close' } });
      await wrapper.find('.ht-field__left-icon').trigger('click');
      await wrapper.find('.ht-field__right-icon').trigger('click');
      expect(wrapper.emitted('clickLeftIcon')).toBeTruthy();
      expect(wrapper.emitted('clickRightIcon')).toBeTruthy();
    });

    it('点击提示图标触发 clickTips 事件', async () => {
      const wrapper = mount(Field, { props: { tips: true, label: '标题' } });
      const tipsIcon = wrapper.find('.ht-field__tips');
      expect(tipsIcon.exists()).toBe(true);
      await tipsIcon.trigger('click');
      expect(wrapper.emitted('clickTips')).toBeTruthy();
    });
  });

  describe('校验', () => {
    it('调用 validate 触发 startValidate 与 endValidate 事件', async () => {
      const wrapper = mount(Field, { props: { modelValue: '' } });
      await (wrapper.vm as any).validate([{ required: true, message: '必填' }]);
      expect(wrapper.emitted('startValidate')).toBeTruthy();
      expect(wrapper.emitted('endValidate')).toBeTruthy();
    });
  });

  describe('格式化与输入规则', () => {
    it('formatter 在 onChange 时即时格式化', async () => {
      const wrapper = mount(Field, {
        props: {
          modelValue: '',
          formatter: (v: string) => v.toUpperCase(),
          formatTrigger: 'onChange',
        },
      });
      const input = wrapper.find('input');
      await input.setValue('ab');
      const updates = wrapper.emitted('update:modelValue');
      expect(updates![updates!.length - 1][0]).toBe('AB');
      expect((input.element as HTMLInputElement).value).toBe('AB');
    });

    it('formatter 在 onBlur 时失焦后格式化', async () => {
      const wrapper = mount(Field, {
        props: {
          modelValue: '',
          formatter: (v: string) => v.toUpperCase(),
          formatTrigger: 'onBlur',
        },
      });
      const input = wrapper.find('input');
      await input.setValue('ab');
      await wrapper.setProps({ modelValue: 'ab' });

      // 变化时不应格式化
      let updates = wrapper.emitted('update:modelValue');
      expect(updates![updates!.length - 1][0]).toBe('ab');
      await input.trigger('blur');
      updates = wrapper.emitted('update:modelValue');
      expect(updates![updates!.length - 1][0]).toBe('AB');
    });

    it('number 类型 blur 时应用 min / max 裁剪', async () => {
      const wrapper = mount(Field, {
        props: { modelValue: '', type: 'number', min: 3, max: 5 },
      });
      const input = wrapper.find('input');
      await input.setValue('10');
      await wrapper.setProps({ modelValue: '10' });

      await input.trigger('blur');
      let updates = wrapper.emitted('update:modelValue');
      expect(updates![updates!.length - 1][0]).toBe('5');
      await input.setValue('1');
      await wrapper.setProps({ modelValue: '1' });

      await input.trigger('blur');
      updates = wrapper.emitted('update:modelValue');
      expect(updates![updates!.length - 1][0]).toBe('3');
    });

    it('digit 类型过滤非数字字符', async () => {
      const wrapper = mount(Field, { props: { modelValue: '', type: 'digit' } });
      const input = wrapper.find('input');
      await input.setValue('12a3b');
      const updates = wrapper.emitted('update:modelValue');
      expect(updates![updates!.length - 1][0]).toBe('123');
    });
  });

  describe('交互扩展', () => {
    it('password 类型显示可见性切换并切换类型', async () => {
      const wrapper = mount(Field, { props: { type: 'password', modelValue: 'abc' } });
      expect(wrapper.find('.ht-field__password-toggle').exists()).toBe(true);
      const input = wrapper.find('input');
      expect(input.attributes('type')).toBe('password');
      await wrapper.find('.ht-field__password-toggle').trigger('mousedown');
      expect(input.attributes('type')).toBe('text');
    });

    it('clearTrigger = focus 时未聚焦不显示清除按钮', async () => {
      const wrapper = mount(Field, { props: { clearable: true, clearTrigger: 'focus', modelValue: 'abc' } });
      expect(wrapper.find('.ht-field__clear').exists()).toBe(false);
      await wrapper.find('input').trigger('focus');
      expect(wrapper.find('.ht-field__clear').exists()).toBe(true);
    });

    it('clearTrigger = always 总是显示清除按钮', () => {
      const wrapper = mount(Field, { props: { clearable: true, clearTrigger: 'always', modelValue: 'abc' } });
      expect(wrapper.find('.ht-field__clear').exists()).toBe(true);
    });

    it('required=auto 时根据规则自动显示 *', () => {
      const wrapper = mount(Field, {
        props: {
          required: 'auto',
          label: '标题',
          modelValue: '',
          rules: [{ required: true, message: '必填' }],
        },
      });
      expect(wrapper.html()).toContain('*');
    });
  });

  describe('异步校验', () => {
    it('异步 validator 返回错误字符串时显示并触发事件', async () => {
      const wrapper = mount(Field, { props: { modelValue: '' } });
      await (wrapper.vm as any).validate([
        {
          validator: () => Promise.resolve('异步错误'),
        },
      ]);
      expect(wrapper.emitted('startValidate')).toBeTruthy();
      expect(wrapper.emitted('endValidate')).toBeTruthy();
      expect(wrapper.text()).toContain('异步错误');
    });
  });

  describe('Textarea 特性', () => {
    it('type=textarea 时渲染 textarea 标签', () => {
      const wrapper = mount(Field, { props: { type: 'textarea' } });
      expect(wrapper.find('textarea').exists()).toBe(true);
      expect(wrapper.find('input').exists()).toBe(false);
    });

    it('textarea 支持 rows 属性', () => {
      const wrapper = mount(Field, { props: { type: 'textarea', rows: 3 } });
      expect(wrapper.find('textarea').attributes('rows')).toBe('3');
    });

    it('textarea 支持 maxlength 属性', () => {
      const wrapper = mount(Field, { props: { type: 'textarea', maxlength: 100 } });
      expect(wrapper.find('textarea').attributes('maxlength')).toBe('100');
    });
  });

  describe('校验规则扩展', () => {
    it('必填规则校验失败时显示错误', async () => {
      const wrapper = mount(Field, { props: { modelValue: '' } });
      await (wrapper.vm as any).validate([{ required: true, message: '此项必填' }]);
      expect(wrapper.text()).toContain('此项必填');
    });

    it('pattern 规则校验不匹配时失败', async () => {
      const wrapper = mount(Field, { props: { modelValue: 'abc' } });
      await (wrapper.vm as any).validate([{ pattern: /^\d+$/, message: '请输入数字' }]);
      expect(wrapper.text()).toContain('请输入数字');
    });

    it('多规则按顺序执行，第一个失败则停止', async () => {
      const wrapper = mount(Field, { props: { modelValue: '' } });
      await (wrapper.vm as any).validate([
        { required: true, message: '必填' },
        { pattern: /^\d+$/, message: '数字' },
      ]);
      expect(wrapper.text()).toContain('必填');
      expect(wrapper.text()).not.toContain('数字');
    });
  });

  describe('高级组合', () => {
    it('formatter 与 maxlength 组合时先格式化再截断', async () => {
      const wrapper = mount(Field, {
        props: {
          modelValue: '',
          formatter: (v: string) => v.toUpperCase(),
          formatTrigger: 'onChange',
          maxlength: 3,
        },
      });
      const input = wrapper.find('input');
      await input.setValue('abcde');
      const updates = wrapper.emitted('update:modelValue');
      expect(updates![updates!.length - 1][0]).toBe('ABC');
    });

    it('显示 optional 可选标记', () => {
      const wrapper = mount(Field, { props: { label: '姓名', optional: '可选' } });
      expect(wrapper.text()).toContain('(可选)');
    });

    it('显示 message 提示信息', () => {
      const wrapper = mount(Field, { props: { message: '请输入正确格式' } });
      expect(wrapper.text()).toContain('请输入正确格式');
    });
  });

  describe('暴露方法', () => {
    it('调用 focus 方法聚焦输入框', async () => {
      const wrapper = mount(Field, { attachTo: document.body });
      (wrapper.vm as any).focus();
      await wrapper.vm.$nextTick();
      expect(document.activeElement).toBe(wrapper.find('input').element);
      wrapper.unmount();
    });

    it('调用 blur 方法失焦输入框', async () => {
      const wrapper = mount(Field, { attachTo: document.body });
      const input = wrapper.find('input').element as HTMLInputElement;
      input.focus();
      (wrapper.vm as any).blur();
      await wrapper.vm.$nextTick();
      expect(document.activeElement).not.toBe(input);
      wrapper.unmount();
    });

    it('调用 clear 方法清空值', async () => {
      const wrapper = mount(Field, { props: { modelValue: 'abc' } });
      (wrapper.vm as any).clear();
      await wrapper.vm.$nextTick();
      const updates = wrapper.emitted('update:modelValue');
      expect(updates![updates!.length - 1][0]).toBe('');
    });
  });
});
