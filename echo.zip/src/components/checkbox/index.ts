import HTCheckbox from './Checkbox.vue';

export default HTCheckbox;
export type { CheckboxProps, CheckboxVariant } from './types';
