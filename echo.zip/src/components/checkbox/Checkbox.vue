<script setup lang="ts">
import { computed } from 'vue';
import { CheckboxIndicator, CheckboxRoot } from 'reka-ui';
import { addUnit, CHECKBOX_GROUP_KEY, cn } from '@/utils/index';
import { useCustomFieldValue, useParent } from '@/hooks';
import type { CheckboxProps } from './types';

const props = withDefaults(defineProps<CheckboxProps>(), {
  disabled: false,
  labelDisabled: false,
  indeterminate: false,
  bindGroup: true,
  shape: 'square',
  variant: 'primary',
});

const emit = defineEmits<{
  (e: 'click', ev: MouseEvent): void;
  (e: 'change', value: boolean): void;
  (e: 'update:modelValue', value: boolean): void;
}>();

const { parent: checkboxGroup } = useParent(CHECKBOX_GROUP_KEY);

// 本地状态（单独使用时）
const localChecked = defineModel<boolean>('modelValue', { default: false });

// 从 CheckboxGroup 继承的属性
const checkboxGroupDisabled = computed(() => checkboxGroup?.props.disabled);
const checkboxGroupIconSize = computed(() => checkboxGroup?.props.iconSize);
const checkboxGroupCheckedColor = computed(() => checkboxGroup?.props.checkedColor);
const checkboxGroupLabelPosition = computed(() => checkboxGroup?.props.labelPosition);
const checkboxGroupShape = computed(() => checkboxGroup?.props.shape);
const checkboxGroupModel = computed(() => checkboxGroup?.props.modelValue || []);

// 判断是否在 CheckboxGroup 中
const inGroup = computed(() => !!checkboxGroup && props.bindGroup);

// 当前状态
const isDisabled = computed(() => !!props.disabled || !!checkboxGroupDisabled.value);

// 与 Form 集成
useCustomFieldValue(() => {
  if (inGroup.value && props.name !== undefined) {
    return checkboxGroup!.props.modelValue;
  }
  return localChecked.value;
});

// 计算选中状态
const isChecked = computed(() => {
  if (!inGroup.value) {
    return localChecked.value;
  }
  if (props.name !== undefined) {
    return checkboxGroupModel.value.includes(props.name);
  }
  return false;
});

const resolvedIconSize = computed(() => addUnit(props.iconSize ?? checkboxGroupIconSize.value));
const resolvedCheckedColor = computed(() => props.checkedColor ?? checkboxGroupCheckedColor.value);
const labelPosition = computed(() => props.labelPosition ?? checkboxGroupLabelPosition.value ?? 'right');
const shape = computed(() => props.shape ?? checkboxGroupShape.value ?? 'square');

// 单独使用时的 model-value（支持半选）
const standaloneModelValue = computed(() => {
  if (props.indeterminate) return 'indeterminate';
  return isChecked.value;
});

// 处理单独使用时的变化
function handleModelValueChange(value: boolean | 'indeterminate') {
  // 在 Group 中时不处理，让 CheckboxGroupRoot 自动管理
  if (inGroup.value) return;

  // 单独使用时处理
  if (isDisabled.value) return;

  const newValue = value === true;
  localChecked.value = newValue;
  emit('update:modelValue', newValue);
  emit('change', newValue);
}

function onClick(e: MouseEvent) {
  if (isDisabled.value) {
    e.preventDefault();
    e.stopPropagation();
    return;
  }
  emit('click', e);
}
</script>

<template>
  <CheckboxRoot
    :value="inGroup && props.name !== undefined ? props.name : undefined"
    :model-value="inGroup ? undefined : standaloneModelValue"
    :disabled="isDisabled"
    :class="
      cn('ht-checkbox inline-flex items-center', {
        'cursor-not-allowed': isDisabled,
        'cursor-pointer': !isDisabled,
        'ht-checkbox--disabled': isDisabled,
        'ht-checkbox--checked': isChecked,
        'ht-checkbox--indeterminate': props.indeterminate,
        'ht-checkbox--square': shape === 'square',
        'ht-checkbox--round': shape === 'round',
        'ht-checkbox--primary': props.variant === 'primary',
        'ht-checkbox--secondary': props.variant === 'secondary',
      })
    "
    @click="onClick"
    @update:model-value="handleModelValueChange"
    :style="{
      '--checkbox-color-checked': resolvedCheckedColor,
    }"
  >
    <span :class="cn('ht-checkbox__inner inline-flex items-center', { 'flex-row-reverse': labelPosition === 'left' })">
      <span
        class="ht-checkbox__icon inline-flex items-center justify-center [&_img]:block [&_img]:h-full [&_img]:w-full [&_img]:object-contain [&_svg]:block [&_svg]:h-full [&_svg]:w-full"
        :style="{ width: resolvedIconSize, height: resolvedIconSize }"
      >
        <slot name="icon" :checked="isChecked" :disabled="isDisabled" :indeterminate="props.indeterminate">
          <span class="ht-checkbox__box relative box-border h-full w-full border-solid">
            <!-- 半选图标 - 优先显示 -->
            <template v-if="props.indeterminate">
              <span class="ht-checkbox__indicator absolute inset-0 flex items-center justify-center">
                <svg
                  class="ht-checkbox__indeterminate-icon"
                  width="7"
                  height="1"
                  viewBox="0 0 7 1"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path d="M6.83333 0.666667H0V0H6.83333V0.666667Z" fill="currentColor" />
                </svg>
              </span>
            </template>

            <!-- 选中图标 - CheckboxIndicator -->
            <template v-else-if="isChecked">
              <CheckboxIndicator class="ht-checkbox__indicator absolute inset-0 flex items-center justify-center">
                <svg
                  class="ht-checkbox__check"
                  width="7"
                  height="5"
                  viewBox="0 0 7 5"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M6.94271 0.482096L2.86165 4.37923C2.73286 4.5022 2.52986 4.50217 2.40104 4.37923L0 2.08626L0.460612 1.60417L2.63118 3.67676L6.4821 0L6.94271 0.482096Z"
                    fill="currentColor"
                  />
                </svg>
              </CheckboxIndicator>
            </template>
          </span>
        </slot>
      </span>

      <span
        :class="
          cn('ht-checkbox__label inline-block', {
            'pointer-events-none': labelDisabled,
          })
        "
      >
        <slot :checked="isChecked" :disabled="isDisabled" :indeterminate="props.indeterminate" />
      </span>
    </span>
  </CheckboxRoot>
</template>

<style>
:root {
  /* Layout */
  --checkbox-container-gap-default: 8px;
  --checkbox-icon-size-default: 12px;
  --checkbox-icon-inner-padding: 2px;
  --checkbox-icon-border-radius-default: 2px;
  --checkbox-icon-border-width-default: 1px;

  /* Colors - Default */
  --checkbox-icon-border-color-default: #e9eaeb;

  /* Colors - Primary */
  --checkbox-icon-bg-color-primary-checked: #000;
  --checkbox-icon-border-color-primary-hover: #717680;
  --checkbox-icon-bg-color-primary-checked-hover: #717680;

  /* Colors - Secondary */
  --checkbox-icon-bg-color-secondary-checked: #16b364;
  --checkbox-icon-border-color-secondary-hover: #099250;
  --checkbox-icon-bg-color-secondary-checked-hover: #099250;

  /* Colors - Icon */
  --checkbox-icon-color-checked: #ffffff;

  /* Colors - Disabled */
  --checkbox-icon-bg-color-disabled: #f5f5f5;
  --checkbox-icon-border-color-disabled: #f5f5f5;
  --checkbox-icon-color-disabled: #d5d7da;

  /* Text */
  --checkbox-text-font-size-default: 14px;
  --checkbox-text-color-default: #333333;
  --checkbox-text-color-disabled: #8c8c8c;
  --checkbox-text-line-height-default: 1.5;

  /* Other */
  --checkbox-opacity-disabled: 0.5;
  --checkbox-transition-duration: 0.2s;
}

@layer components {
  .ht-checkbox {
    color: var(--checkbox-text-color-default);
    font-size: var(--checkbox-text-font-size-default);
    line-height: var(--checkbox-text-line-height-default);
    outline: none;
  }

  .ht-checkbox__inner {
    gap: var(--checkbox-container-gap-default);
  }

  .ht-checkbox__icon {
    width: var(--checkbox-icon-size-default);
    height: var(--checkbox-icon-size-default);
  }

  .ht-checkbox__box {
    border-radius: var(--checkbox-icon-border-radius-default);
    border-width: var(--checkbox-icon-border-width-default);
    border-style: solid;
    border-color: var(--checkbox-icon-border-color-default);
    background-color: transparent;
    transition:
      border-color var(--checkbox-transition-duration) ease,
      background-color var(--checkbox-transition-duration) ease,
      transform var(--checkbox-transition-duration) cubic-bezier(0.2, 0.8, 0.2, 1);
  }

  /* Shape variants */
  .ht-checkbox--square .ht-checkbox__box {
    border-radius: var(--checkbox-icon-border-radius-default);
  }

  .ht-checkbox--round .ht-checkbox__box {
    border-radius: 50%;
  }

  .ht-checkbox__indicator {
    pointer-events: none;
    padding: var(--checkbox-icon-inner-padding);
  }

  .ht-checkbox__check,
  .ht-checkbox__indeterminate-icon {
    width: 100%;
    height: 100%;
    color: var(--checkbox-icon-color-checked);
    transition: all var(--checkbox-transition-duration) ease;
  }

  /* Primary Variant */
  /* Hover 状态 - 未选中 */
  .ht-checkbox--primary:hover:not(.ht-checkbox--disabled):not(.ht-checkbox--checked):not(.ht-checkbox--indeterminate)
    .ht-checkbox__box {
    border-color: var(--checkbox-icon-border-color-primary-hover);
  }

  /* 选中状态 */
  .ht-checkbox--primary.ht-checkbox--checked .ht-checkbox__box,
  .ht-checkbox--primary[data-state='checked'] .ht-checkbox__box {
    border-color: var(--checkbox-color-checked, var(--checkbox-icon-bg-color-primary-checked));
    background-color: var(--checkbox-color-checked, var(--checkbox-icon-bg-color-primary-checked));
  }

  /* Hover 选中状态 */
  .ht-checkbox--primary.ht-checkbox--checked:hover:not(.ht-checkbox--disabled) .ht-checkbox__box,
  .ht-checkbox--primary[data-state='checked']:hover:not([data-disabled]) .ht-checkbox__box {
    background-color: var(--checkbox-icon-bg-color-primary-checked-hover);
    border-color: var(--checkbox-icon-bg-color-primary-checked-hover);
  }

  /* 半选状态 */
  .ht-checkbox--primary.ht-checkbox--indeterminate .ht-checkbox__box,
  .ht-checkbox--primary[data-state='indeterminate'] .ht-checkbox__box {
    border-color: var(--checkbox-color-checked, var(--checkbox-icon-bg-color-primary-checked));
    background-color: var(--checkbox-color-checked, var(--checkbox-icon-bg-color-primary-checked));
  }

  /* Hover 半选状态 */
  .ht-checkbox--primary.ht-checkbox--indeterminate:hover:not(.ht-checkbox--disabled) .ht-checkbox__box,
  .ht-checkbox--primary[data-state='indeterminate']:hover:not([data-disabled]) .ht-checkbox__box {
    background-color: var(--checkbox-icon-bg-color-primary-checked-hover);
    border-color: var(--checkbox-icon-bg-color-primary-checked-hover);
  }

  /* Secondary Variant */
  /* Hover 状态 - 未选中 */
  .ht-checkbox--secondary:hover:not(.ht-checkbox--disabled):not(.ht-checkbox--checked):not(.ht-checkbox--indeterminate)
    .ht-checkbox__box {
    border-color: var(--checkbox-icon-border-color-secondary-hover);
  }

  /* 选中状态 */
  .ht-checkbox--secondary.ht-checkbox--checked .ht-checkbox__box,
  .ht-checkbox--secondary[data-state='checked'] .ht-checkbox__box {
    border-color: var(--checkbox-icon-bg-color-secondary-checked);
    background-color: var(--checkbox-icon-bg-color-secondary-checked);
  }

  /* Hover 选中状态 */
  .ht-checkbox--secondary.ht-checkbox--checked:hover:not(.ht-checkbox--disabled) .ht-checkbox__box,
  .ht-checkbox--secondary[data-state='checked']:hover:not([data-disabled]) .ht-checkbox__box {
    background-color: var(--checkbox-icon-bg-color-secondary-checked-hover);
    border-color: var(--checkbox-icon-bg-color-secondary-checked-hover);
  }

  /* 半选状态 */
  .ht-checkbox--secondary.ht-checkbox--indeterminate .ht-checkbox__box,
  .ht-checkbox--secondary[data-state='indeterminate'] .ht-checkbox__box {
    border-color: var(--checkbox-icon-bg-color-secondary-checked);
    background-color: var(--checkbox-icon-bg-color-secondary-checked);
  }

  /* Hover 半选状态 */
  .ht-checkbox--secondary.ht-checkbox--indeterminate:hover:not(.ht-checkbox--disabled) .ht-checkbox__box,
  .ht-checkbox--secondary[data-state='indeterminate']:hover:not([data-disabled]) .ht-checkbox__box {
    background-color: var(--checkbox-icon-bg-color-secondary-checked-hover);
    border-color: var(--checkbox-icon-bg-color-secondary-checked-hover);
  }

  /* 禁用状态 */
  .ht-checkbox--disabled,
  .ht-checkbox[data-disabled] {
    opacity: var(--checkbox-opacity-disabled);
    color: var(--checkbox-text-color-disabled);
    cursor: not-allowed !important;
  }

  /* 禁用状态 - 未选中 */
  .ht-checkbox--disabled:not(.ht-checkbox--checked):not(.ht-checkbox--indeterminate) .ht-checkbox__box,
  .ht-checkbox[data-disabled]:not([data-state='checked']):not([data-state='indeterminate']) .ht-checkbox__box {
    background-color: var(--checkbox-icon-bg-color-disabled);
    border-color: var(--checkbox-icon-border-color-disabled);
  }

  /* 禁用状态 - 选中 */
  .ht-checkbox--disabled.ht-checkbox--checked .ht-checkbox__box,
  .ht-checkbox[data-disabled][data-state='checked'] .ht-checkbox__box {
    background-color: var(--checkbox-icon-bg-color-disabled);
    border-color: var(--checkbox-icon-border-color-disabled);
  }

  /* 禁用状态 - 半选 */
  .ht-checkbox--disabled.ht-checkbox--indeterminate .ht-checkbox__box,
  .ht-checkbox[data-disabled][data-state='indeterminate'] .ht-checkbox__box {
    background-color: var(--checkbox-icon-bg-color-disabled);
    border-color: var(--checkbox-icon-border-color-disabled);
  }

  /* 禁用状态 - SVG 图标颜色 */
  .ht-checkbox--disabled .ht-checkbox__check,
  .ht-checkbox--disabled .ht-checkbox__indeterminate-icon,
  .ht-checkbox[data-disabled] .ht-checkbox__check,
  .ht-checkbox[data-disabled] .ht-checkbox__indeterminate-icon {
    color: var(--checkbox-icon-color-disabled);
  }

  .ht-checkbox__label {
    line-height: var(--checkbox-icon-size-default);
  }
}
</style>
