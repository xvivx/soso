import type { CheckboxLabelPosition, CheckboxShape, IconSize } from '@/components/checkbox-group/types';

export type CheckboxVariant = 'primary' | 'secondary';

export interface CheckboxProps {
  name?: string | number;
  modelValue?: boolean;
  disabled?: boolean;
  shape?: CheckboxShape;
  iconSize?: IconSize;
  checkedColor?: string;
  labelPosition?: CheckboxLabelPosition;
  labelDisabled?: boolean;
  indeterminate?: boolean; // 半选状态
  bindGroup?: boolean; // 是否在 CheckboxGroup 中使用
  variant?: CheckboxVariant; // 颜色变体
}
