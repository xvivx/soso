import HTCheckboxGroup from './CheckboxGroup.vue';

export default HTCheckboxGroup;
export type {
  CheckboxGroupProps,
  CheckboxGroupDirection,
  CheckboxLabelPosition,
  CheckboxShape,
  IconSize,
} from './types';
