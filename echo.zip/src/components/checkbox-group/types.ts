export type IconSize = number | string;

export type CheckboxLabelPosition = 'left' | 'right';
export type CheckboxGroupDirection = 'vertical' | 'horizontal';
export type CheckboxShape = 'square' | 'round';

export interface CheckboxGroupProps {
  modelValue: (string | number)[];
  disabled?: boolean;
  max?: number;
  direction?: CheckboxGroupDirection;
  labelPosition?: CheckboxLabelPosition;
  iconSize?: IconSize;
  checkedColor?: string;
  shape?: CheckboxShape;
}

export type CheckboxGroupProvide = {
  props: CheckboxGroupProps;
  updateValue: (value: (string | number)[]) => void;
};
