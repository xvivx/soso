<script setup lang="ts">
import { watch } from 'vue';
import { cva } from 'class-variance-authority';
import { CheckboxGroupRoot } from 'reka-ui';
import { CHECKBOX_GROUP_KEY } from '@/utils/index';
import { useChildren, useCustomFieldValue } from '@/hooks';
import type { CheckboxGroupProps } from './types';

const props = withDefaults(defineProps<CheckboxGroupProps>(), {
  disabled: false,
  direction: 'vertical',
});

const model = defineModel<(string | number)[]>('modelValue');
const emits = defineEmits<{
  (e: 'change', val: (string | number)[]): void;
}>();

const { linkChildren } = useChildren(CHECKBOX_GROUP_KEY);

const updateValue = (value: (string | number)[]) => {
  model.value = value;
};

linkChildren({ props, updateValue });
useCustomFieldValue(() => model.value);

watch(
  () => model.value,
  (val) => {
    emits('change', val as (string | number)[]);
    // 更新给子组件
    updateValue(val || []);
  },
  { immediate: false }
);

const variants = cva('ht-checkbox-group flex', {
  variants: {
    direction: {
      horizontal: 'ht-checkbox-group--horizontal',
      vertical: 'ht-checkbox-group--vertical',
    },
  },
  defaultVariants: {
    direction: props.direction,
  },
});
</script>

<template>
  <CheckboxGroupRoot
    :model-value="model"
    :disabled="disabled"
    :class="variants({ direction })"
    @update:model-value="(val) => (model = val)"
  >
    <slot />
  </CheckboxGroupRoot>
</template>

<style>
:root {
  --checkbox-group-container-gap-default: 16px;
  --checkbox-group-container-flex-direction-default: column;
  --checkbox-group-container-flex-wrap-default: wrap;
}
.ht-checkbox-group {
  gap: var(--checkbox-group-container-gap-default);
  flex-direction: var(--checkbox-group-container-flex-direction-default);
  flex-wrap: var(--checkbox-group-container-flex-wrap-default);
}
.ht-checkbox-group--horizontal {
  --checkbox-group-container-flex-direction-default: row;
}
.ht-checkbox-group--vertical {
  --checkbox-group-container-flex-direction-default: column;
}
</style>
