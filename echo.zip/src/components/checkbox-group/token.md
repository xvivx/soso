
--checkbox-group-container-gap-default
组内复选框默认间距
16px
--checkbox-group-container-flex-direction-default
组内布局方向
row
--checkbox-group-container-flex-wrap-default
组内是否换行
wrap