import { mount } from '@vue/test-utils';
import { describe, expect, it } from 'vitest';
import HTConfigProvider from '../ConfigProvider.vue';

describe('HTConfigProvider', () => {
  it('renders correctly with default props', () => {
    const wrapper = mount(HTConfigProvider);

    expect(wrapper.find('.ht-config-provider').exists()).toBe(true);
    expect(wrapper.element.tagName).toBe('DIV');
  });

  it('applies custom tag name', () => {
    const wrapper = mount(HTConfigProvider, {
      props: {
        tag: 'section',
      },
    });

    expect(wrapper.element.tagName).toBe('SECTION');
  });

  it('applies theme class name', () => {
    const wrapper = mount(HTConfigProvider, {
      props: {
        theme: 'dark',
      },
    });

    // 在实际测试中，主题类名会通过 useTheme hook 应用到 document.documentElement
    // 这里我们只检查组件是否正确渲染
    expect(wrapper.find('.ht-config-provider').exists()).toBe(true);
  });

  it('provides config context', async () => {
    const wrapper = mount(HTConfigProvider, {
      props: {
        theme: 'dark',
        iconPrefix: 'custom-icon',
        zIndex: 3000,
      },
      slots: {
        default: '<div>Child content</div>',
      },
    });

    expect(wrapper.text()).toBe('Child content');
    expect(wrapper.find('.ht-config-provider').exists()).toBe(true);
  });

  it('renders with custom style for local scope', () => {
    const themeVars = {
      primaryColor: '#ff0000',
      buttonBgColorPrimary: '#ff0000',
    };

    const wrapper = mount(HTConfigProvider, {
      props: {
        themeVars,
        themeVarsScope: 'local',
      },
    });

    const style = wrapper.attributes('style');
    expect(style).toContain('--ht-primary-color');
    expect(style).toContain('#ff0000');
  });

  it('does not apply inline style for global scope', () => {
    const themeVars = {
      primaryColor: '#ff0000',
    };

    const wrapper = mount(HTConfigProvider, {
      props: {
        themeVars,
        themeVarsScope: 'global',
      },
    });

    const style = wrapper.attributes('style');
    expect(style).toBeUndefined();
  });
});
