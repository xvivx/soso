import type { ExtractPropTypes, PropType } from 'vue';
import type { Message } from '@/locale';

export type ConfigProviderTheme = 'light' | 'dark' | 'auto';
export type ConfigProviderThemeVarsScope = 'local' | 'global';

export interface ConfigProviderProvide {
  theme?: ConfigProviderTheme;
  iconPrefix?: string;
  zIndex?: number;
  locale?: string;
  localeMessages?: Message;
}

/**
 * useConfigProvider 返回类型
 */
export interface UseConfigProviderReturn {
  theme: import('vue').ComputedRef<ConfigProviderTheme>;
  iconPrefix: import('vue').ComputedRef<string>;
  zIndex: import('vue').ComputedRef<number | undefined>;
  locale: import('vue').ComputedRef<string>;
  localeMessages: import('vue').ComputedRef<Message>;
}
// todo: 后续根据项目token定义进行调整
export interface ThemeVars {
  // 基础颜色变量 (基于项目 H5组件三级token.md)
  black?: string;
  white?: string;
  gray1?: string;
  gray2?: string;
  gray3?: string;
  gray4?: string;
  gray5?: string;
  gray6?: string;
  gray7?: string;
  gray8?: string;
  red?: string;
  blue?: string;
  orange?: string;
  orangeDark?: string;
  orangeLight?: string;
  green?: string;

  // 渐变色
  gradientRed?: string;
  gradientOrange?: string;

  // 组件颜色
  primaryColor?: string;
  successColor?: string;
  dangerColor?: string;
  warningColor?: string;
  textColor?: string;
  textColor2?: string;
  textColor3?: string;
  activeColor?: string;
  activeOpacity?: number;
  disabledOpacity?: number;
  background?: string;
  background2?: string;

  // 间距
  paddingBase?: string;
  paddingXs?: string;
  paddingSm?: string;
  paddingMd?: string;
  paddingLg?: string;
  paddingXl?: string;

  // 字体
  fontSizeXs?: string;
  fontSizeSm?: string;
  fontSizeMd?: string;
  fontSizeLg?: string;
  fontBold?: number;
  lineHeightXs?: string;
  lineHeightSm?: string;
  lineHeightMd?: string;
  lineHeightLg?: string;
  baseFont?: string;
  priceFont?: string;

  // 动画
  durationBase?: string;
  durationFast?: string;
  easeOut?: string;
  easeIn?: string;

  // 边框
  borderColor?: string;
  borderWidth?: string;
  radiusSm?: string;
  radiusMd?: string;
  radiusLg?: string;
  radiusMax?: string;

  // 按钮变量 (基于项目token)
  buttonContainerHeightDefault?: string;
  buttonContainerHeightLarge?: string;
  buttonContainerHeightSmall?: string;
  buttonContainerHeightMini?: string;
  buttonBgColorPrimary?: string;
  buttonBgColorPrimaryHover?: string;
  buttonBgColorSuccess?: string;
  buttonBgColorWarning?: string;
  buttonBgColorDanger?: string;
  buttonTextFontSizeDefault?: string;
  buttonTextFontSizeLarge?: string;
  buttonTextFontSizeSmall?: string;
  buttonTextFontSizeMini?: string;

  // 弹窗变量
  popupContainerZIndexDefault?: number;
  popupContainerBorderRadiusDefault?: string;
  popupContainerBoxShadowDefault?: string;

  // 其他组件变量... (可根据需要扩展)
}

export const configProviderProps = {
  tag: {
    type: String as PropType<keyof HTMLElementTagNameMap>,
    default: 'div',
  },
  theme: {
    type: String as PropType<ConfigProviderTheme>,
    default: 'light',
  },
  themeVars: {
    type: Object as PropType<Partial<ThemeVars>>,
    default: () => ({}),
  },
  themeVarsDark: {
    type: Object as PropType<Partial<ThemeVars>>,
    default: () => ({}),
  },
  themeVarsLight: {
    type: Object as PropType<Partial<ThemeVars>>,
    default: () => ({}),
  },
  themeVarsScope: {
    type: String as PropType<ConfigProviderThemeVarsScope>,
    default: 'local',
  },
  zIndex: {
    type: Number,
    default: undefined,
  },
  iconPrefix: {
    type: String,
    default: 'ht-icon',
  },
  locale: {
    type: String,
    default: 'zh-CN',
  },
};

export type ConfigProviderProps = ExtractPropTypes<typeof configProviderProps>;
