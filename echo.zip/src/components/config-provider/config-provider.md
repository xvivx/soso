---
title: ConfigProvider 全局配置
description: 用于全局配置 HT UI 组件，提供深色模式、主题定制等能力
---

# ConfigProvider 全局配置

HTConfigProvider 用于全局配置 HT UI 组件，提供深色模式、主题定制、Token 覆盖等能力。

## 基础用法

包裹整个应用或特定组件区域来应用全局配置。

```vue
<template>
  <HTConfigProvider theme="light">
    <div class="app">
      <HTButton type="primary">主要按钮</HTButton>
      <HTButton type="success">成功按钮</HTButton>
    </div>
  </HTConfigProvider>
</template>

<script setup lang="ts">
import { HTButton, HTConfigProvider } from '@/components';
</script>
```

## 深色模式

将 `theme` 属性设置为 `dark` 来开启深色模式。

```vue
<template>
  <HTConfigProvider theme="dark">
    <div class="dark-app">
      <HTButton type="primary">深色模式按钮</HTButton>
      <HTCard>深色模式卡片</HTCard>
    </div>
  </HTConfigProvider>
</template>

<script setup lang="ts">
import { HTButton, HTCard, HTConfigProvider } from '@/components';
</script>
```

### 自动主题

设置 `theme` 为 `auto` 来跟随系统主题设置。

```vue
<template>
  <HTConfigProvider theme="auto">
    <div class="auto-theme-app">
      <p>当前主题: {{ currentTheme }}</p>
      <HTButton>自适应主题按钮</HTButton>
    </div>
  </HTConfigProvider>
</template>

<script setup lang="ts">
import { computed, onMounted, ref } from 'vue';
import { HTButton, HTConfigProvider } from '@/components';

const currentTheme = ref('light');

onMounted(() => {
  const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
  currentTheme.value = mediaQuery.matches ? 'dark' : 'light';

  mediaQuery.addEventListener('change', (e) => {
    currentTheme.value = e.matches ? 'dark' : 'light';
  });
});
</script>
```

## 定制主题变量

通过 `theme-vars` 属性来覆盖 CSS 变量，实现主题定制。

### 基础定制

```vue
<template>
  <HTConfigProvider :theme-vars="themeVars">
    <div class="custom-theme">
      <HTButton type="primary">自定义主题按钮</HTButton>
      <HTButton type="success">自定义成功按钮</HTButton>
    </div>
  </HTConfigProvider>
</template>

<script setup lang="ts">
import { reactive } from 'vue';
import { HTButton, HTConfigProvider, type ThemeVars } from '@/components';

const themeVars: ThemeVars = {
  primaryColor: '#722ed1',
  successColor: '#52c41a',
  buttonBgColorPrimary: '#722ed1',
  buttonBgColorSuccess: '#52c41a',
  buttonTextFontSizeDefault: '18px',
};
</script>
```

### 深色模式定制

为不同主题模式设置不同的变量。

```vue
<template>
  <HTConfigProvider theme="dark" :theme-vars="baseThemeVars" :theme-vars-dark="darkThemeVars">
    <div class="dark-custom">
      <HTButton type="primary">深色自定义按钮</HTButton>
    </div>
  </HTConfigProvider>
</template>

<script setup lang="ts">
import { reactive } from 'vue';
import { HTButton, HTConfigProvider, type ThemeVars } from '@/components';

const baseThemeVars: ThemeVars = {
  primaryColor: '#1890ff',
};

const darkThemeVars: ThemeVars = {
  primaryColor: '#177ddc',
  buttonBgColorPrimary: '#177ddc',
  background: '#141414',
};
</script>
```

## 作用域控制

通过 `theme-vars-scope` 属性控制主题变量的作用范围。

### 局部作用域（默认）

```vue
<template>
  <div>
    <!-- 只影响内部组件 -->
    <HTConfigProvider :theme-vars="localVars" theme-vars-scope="local">
      <div class="local-section">
        <HTButton>局部主题按钮</HTButton>
      </div>
    </HTConfigProvider>

    <!-- 不受影响 -->
    <HTButton>默认主题按钮</HTButton>
  </div>
</template>

<script setup lang="ts">
import { HTButton, HTConfigProvider, type ThemeVars } from '@/components';

const localVars: ThemeVars = {
  primaryColor: '#f5222d',
};
</script>
```

### 全局作用域

```vue
<template>
  <!-- 影响整个页面的组件 -->
  <HTConfigProvider :theme-vars="globalVars" theme-vars-scope="global">
    <div class="global-section">
      <HTButton>全局主题按钮</HTButton>
    </div>
  </HTConfigProvider>
</template>

<script setup lang="ts">
import { HTButton, HTConfigProvider, type ThemeVars } from '@/components';

const globalVars: ThemeVars = {
  primaryColor: '#fa8c16',
};
</script>
```

## 动态主题切换

通过响应式数据实现动态主题切换。

```vue
<template>
  <div>
    <div class="theme-controls">
      <HTButton @click="toggleTheme">切换主题</HTButton>
      <HTButton @click="changePrimaryColor">随机主色</HTButton>
    </div>

    <HTConfigProvider :theme="currentTheme" :theme-vars="currentThemeVars">
      <div class="dynamic-content">
        <HTButton type="primary">动态主题按钮</HTButton>
        <HTButton type="success">成功按钮</HTButton>
        <HTButton type="warning">警告按钮</HTButton>
        <HTButton type="danger">危险按钮</HTButton>
      </div>
    </HTConfigProvider>
  </div>
</template>

<script setup lang="ts">
import { computed, reactive, ref } from 'vue';
import { HTButton, HTConfigProvider, type ConfigProviderTheme, type ThemeVars } from '@/components';

const currentTheme = ref<ConfigProviderTheme>('light');
const primaryColor = ref('#1677ff');

const currentThemeVars = computed<ThemeVars>(() => ({
  primaryColor: primaryColor.value,
  buttonBgColorPrimary: primaryColor.value,
}));

const toggleTheme = () => {
  currentTheme.value = currentTheme.value === 'light' ? 'dark' : 'light';
};

const changePrimaryColor = () => {
  const colors = ['#f5222d', '#fa8c16', '#fadb14', '#52c41a', '#1890ff', '#722ed1', '#eb2f96'];
  const randomColor = colors[Math.floor(Math.random() * colors.length)];
  primaryColor.value = randomColor;
};
</script>
```

## 全局配置

### z-index 配置

```vue
<template>
  <HTConfigProvider :z-index="3000">
    <div class="z-index-demo">
      <HTButton @click="showModal">显示弹窗</HTButton>
      <!-- 所有弹窗的 z-index 都会基于 3000 -->
    </div>
  </HTConfigProvider>
</template>

<script setup lang="ts">
import { HTButton, HTConfigProvider } from '@/components';

const showModal = () => {
  // 显示弹窗逻辑
};
</script>
```

### 图标前缀配置

```vue
<template>
  <HTConfigProvider icon-prefix="custom-icon">
    <div class="icon-demo">
      <!-- 所有图标都会使用 custom-icon- 前缀 -->
      <custom-icon-home />
      <custom-icon-settings />
    </div>
  </HTConfigProvider>
</template>
```

## 使用 Token 系统组件

在子组件中获取和使用全局配置。

```vue
<template>
  <div>
    <HTConfigProvider :theme-vars="configVars">
      <MyCustomComponent />
    </HTConfigProvider>
  </div>
</template>

<script setup lang="ts">
import { computed, inject } from 'vue';
import { HTConfigProvider, type ConfigProviderProvide } from '@/components';
import MyCustomComponent from './MyCustomComponent.vue';

const configVars = {
  primaryColor: '#13c2c2',
  buttonBgColorPrimary: '#13c2c2',
};
</script>
```

```vue
<!-- MyCustomComponent.vue -->
<template>
  <div class="custom-component">
    <HTButton :style="{ backgroundColor: currentConfig.theme?.primaryColor }"> 使用全局配置的按钮 </HTButton>
  </div>
</template>

<script setup lang="ts">
import { computed, inject } from 'vue';
import type { ConfigProviderProvide } from '@/components';

// 获取全局配置
const globalConfig = inject<ConfigProviderProvide>('config-provider');

const currentConfig = computed(() => ({
  theme: globalConfig?.value,
  iconPrefix: globalConfig?.value?.iconPrefix,
  zIndex: globalConfig?.value?.zIndex,
}));
</script>
```

## API

### Props

| 参数             | 说明                         | 类型                          | 默认值      |
| ---------------- | ---------------------------- | ----------------------------- | ----------- |
| theme            | 主题风格                     | `'light' \| 'dark' \| 'auto'` | `'light'`   |
| theme-vars       | 自定义主题变量               | `Partial<ThemeVars>`          | `{}`        |
| theme-vars-dark  | 仅在深色模式下生效的主题变量 | `Partial<ThemeVars>`          | `{}`        |
| theme-vars-light | 仅在浅色模式下生效的主题变量 | `Partial<ThemeVars>`          | `{}`        |
| theme-vars-scope | 主题变量作用域               | `'local' \| 'global'`         | `'local'`   |
| tag              | 根节点 HTML 标签名           | `keyof HTMLElementTagNameMap` | `'div'`     |
| z-index          | 全局 z-index 基础值          | `number`                      | `undefined` |
| icon-prefix      | 图标类名前缀                 | `string`                      | `'ht-icon'` |
| locale           | 语言环境                     | `string`                      | `'zh-CN'`   |

### ThemeVars 类型

主题变量包含以下类别：

- **基础颜色**: `primaryColor`, `successColor`, `dangerColor`, `warningColor`
- **中性色**: `gray1` ~ `gray8`, `black`, `white`
- **字体**: `fontSizeXs` ~ `fontSizeLg`, `fontBold`, `lineHeightXs` ~ `lineHeightLg`
- **间距**: `paddingBase` ~ `paddingXl`
- **边框**: `borderColor`, `borderWidth`, `radiusSm` ~ `radiusMax`
- **动画**: `durationBase`, `durationFast`, `easeOut`, `easeIn`
- **组件特定**: `button*`, `popup*` 等组件变量

完整的变量列表请参考 `H5组件三级token.md` 文档。

### 类型定义

```typescript
import type { ConfigProviderProps, ConfigProviderTheme, ConfigProviderThemeVarsScope, ThemeVars } from '@/components';
```

## 最佳实践

### 1. 主题设计原则

- 使用语义化的颜色变量，如 `primaryColor`、`successColor`
- 保持足够的对比度，确保可访问性
- 在深色模式下适当降低饱和度和亮度

### 2. 性能优化

- 优先使用 `theme-vars-scope="local"` 来限制作用域
- 避免频繁更新主题变量，使用 `computed` 缓存计算结果
- 大量主题变量更新时，考虑批量处理

### 3. 组件开发

- 在组件内部使用 CSS 变量来引用主题配置
- 为关键的颜色和尺寸提供变量接口
- 保持与设计系统的一致性

### 4. 响应式设计

- 考虑不同设备尺寸下的主题适配
- 为暗色模式提供专门的优化
- 支持用户自定义主题偏好
