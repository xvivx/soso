<template>
  <component :is="tag" :class="'ht-config-provider'" :style="computedStyle">
    <slot />
  </component>
</template>

<script setup lang="ts">
import { computed, provide, ref, watchEffect, type CSSProperties } from 'vue';
import { Locale } from '@/locale';
import { useCSSVariables, useGlobalZIndex, useIconPrefix, useTheme } from './hooks';
import { configProviderProps, type ConfigProviderProvide } from './types';
import { ConfigProviderKey } from './useConfigProvider';

// 定义 props
const props = defineProps(configProviderProps);

// 主题管理
const themeRef = ref(props.theme);
const { currentTheme } = useTheme(themeRef);

// 监听 props.theme 变化
watchEffect(() => {
  themeRef.value = props.theme;
});

// CSS 变量管理
const { cssVars } = useCSSVariables(
  computed(() => props.themeVars),
  computed(() => props.themeVarsDark),
  computed(() => props.themeVarsLight),
  currentTheme,
  computed(() => props.themeVarsScope)
);

// 全局 z-index 管理
useGlobalZIndex(computed(() => props.zIndex));

// 图标前缀管理
const { currentIconPrefix } = useIconPrefix(computed(() => props.iconPrefix));

// Locale 管理
const currentLocale = computed(() => props.locale);
const currentLocaleMessages = computed(() => Locale.messages());

// 监听 locale 变化
watchEffect(() => {
  if (props.locale && props.locale !== Locale.lang) {
    Locale.use(props.locale);
  }
});

// 计算样式
const computedStyle = computed<CSSProperties | undefined>(() => {
  // 仅在局部作用域时应用内联样式
  if (props.themeVarsScope === 'local') {
    return cssVars.value as CSSProperties;
  }
  return undefined;
});

// 提供给子组件的配置
const provideConfig = computed<ConfigProviderProvide>(() => ({
  theme: props.theme,
  iconPrefix: currentIconPrefix.value,
  zIndex: props.zIndex,
  locale: currentLocale.value,
  localeMessages: currentLocaleMessages.value,
}));

// 向子组件提供配置
provide(ConfigProviderKey, provideConfig);

// 监听配置变化，触发响应式更新
watchEffect(() => {
  // 这里可以添加一些全局配置的逻辑
  // 比如更新全局 CSS 变量、发布配置变化事件等
});
</script>

<style scoped>
.ht-config-provider {
  /* ConfigProvider 容器样式 */
}
</style>
