import { computed, inject, type ComputedRef, type InjectionKey } from 'vue';
import type { ConfigProviderProvide, UseConfigProviderReturn } from './types';

export const ConfigProviderKey: InjectionKey<ComputedRef<ConfigProviderProvide>> = Symbol('config-provider');

export function useConfigProvider(): UseConfigProviderReturn {
  const config = inject(ConfigProviderKey);

  if (!config) {
    return {
      theme: computed(() => 'light' as const),
      iconPrefix: computed(() => 'ht-icon'),
      zIndex: computed(() => undefined),
      locale: computed(() => 'zh-CN'),
      localeMessages: computed(() => ({})),
    };
  }

  return {
    theme: computed(() => config.value.theme || ('light' as const)),
    iconPrefix: computed(() => config.value.iconPrefix || 'ht-icon'),
    zIndex: computed(() => config.value.zIndex),
    locale: computed(() => config.value.locale || 'zh-CN'),
    localeMessages: computed(() => config.value.localeMessages || {}),
  };
}
