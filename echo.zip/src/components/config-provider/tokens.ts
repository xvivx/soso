import type { ThemeVars } from './types';

/**
 * 将驼峰式转换为 kebab-case
 * 例如: buttonPrimaryColor -> button-primary-color
 */
export function kebabCase(str: string): string {
  return str
    .replace(/([a-z])([A-Z])/g, '$1-$2')
    .replace(/([A-Z])([A-Z][a-z])/g, '$1-$2')
    .toLowerCase();
}

/**
 * 插入破折号处理数字后缀
 * 例如: gray1 -> gray-1, fontSizeXs -> font-size-xs
 */
export function insertDash(str: string): string {
  return str.replace(/([a-zA-Z])(\d)/g, '$1-$2');
}

/**
 * 将主题变量映射为 CSS 变量
 * 例如: { primaryColor: '#1677FF' } -> { '--ht-primary-color': '#1677FF' }
 */
export function mapThemeVarsToCSSVars(themeVars: Partial<ThemeVars>): Record<string, string | number> {
  const cssVars: Record<string, string | number> = {};

  Object.keys(themeVars).forEach((key) => {
    const value = themeVars[key as keyof ThemeVars];
    if (value !== undefined) {
      // 转换为 kebab-case 并添加前缀
      const formattedKey = insertDash(kebabCase(key));
      cssVars[`--ht-${formattedKey}`] = value;
    }
  });

  return cssVars;
}

/**
 * 默认主题变量（基于项目token定义）
 */
export const defaultThemeVars: ThemeVars = {
  // 基础颜色
  black: '#000000',
  white: '#ffffff',
  gray1: '#f7f8fa',
  gray2: '#f2f3f5',
  gray3: '#ebedf0',
  gray4: '#dcdee0',
  gray5: '#c8c9cc',
  gray6: '#969799',
  gray7: '#646566',
  gray8: '#323233',
  red: '#ee0a24',
  blue: '#1989fa',
  orange: '#ff976a',
  orangeDark: '#ed6a0c',
  orangeLight: '#fffbe8',
  green: '#07c160',

  // 渐变色
  gradientRed: 'linear-gradient(to right, #ff6034, #ee0a24)',
  gradientOrange: 'linear-gradient(to right, #ffd01e, #ff8917)',

  // 组件颜色
  primaryColor: '#1677ff',
  successColor: '#52c41a',
  dangerColor: '#ff4d4f',
  warningColor: '#faad14',
  textColor: '#333333',
  textColor2: '#666666',
  textColor3: '#999999',
  activeColor: '#f2f3f5',
  activeOpacity: 0.6,
  disabledOpacity: 0.5,
  background: '#ffffff',
  background2: '#fafafa',

  // 间距
  paddingBase: '4px',
  paddingXs: '8px',
  paddingSm: '12px',
  paddingMd: '16px',
  paddingLg: '24px',
  paddingXl: '32px',

  // 字体
  fontSizeXs: '10px',
  fontSizeSm: '12px',
  fontSizeMd: '14px',
  fontSizeLg: '16px',
  fontBold: 600,
  lineHeightXs: '14px',
  lineHeightSm: '18px',
  lineHeightMd: '20px',
  lineHeightLg: '22px',
  baseFont:
    '-apple-system, BlinkMacSystemFont, "Helvetica Neue", Helvetica, "Segoe UI", Arial, Roboto, "PingFang SC", "miui", "Hiragino Sans GB", "Microsoft Yahei", sans-serif',
  priceFont: 'Avenir-Heavy, PingFang SC, Helvetica Neue, Arial, sans-serif',

  // 动画
  durationBase: '0.3s',
  durationFast: '0.2s',
  easeOut: 'ease-out',
  easeIn: 'ease-in',

  // 边框
  borderColor: '#eeeeee',
  borderWidth: '1px',
  radiusSm: '2px',
  radiusMd: '4px',
  radiusLg: '8px',
  radiusMax: '999px',

  // 按钮变量（基于项目token）
  buttonContainerHeightDefault: '44px',
  buttonContainerHeightLarge: '52px',
  buttonContainerHeightSmall: '36px',
  buttonContainerHeightMini: '28px',
  buttonBgColorPrimary: '#1677ff',
  buttonBgColorPrimaryHover: '#0958d9',
  buttonBgColorSuccess: '#52c41a',
  buttonBgColorWarning: '#faad14',
  buttonBgColorDanger: '#ff4d4f',
  buttonTextFontSizeDefault: '16px',
  buttonTextFontSizeLarge: '18px',
  buttonTextFontSizeSmall: '14px',
  buttonTextFontSizeMini: '12px',

  // 弹窗变量
  popupContainerZIndexDefault: 2000,
  popupContainerBorderRadiusDefault: '16px',
  popupContainerBoxShadowDefault: '0 4px 16px rgba(0, 0, 0, 0.1)',
};

/**
 * 深色主题变量覆盖
 */
export const darkThemeVars: Partial<ThemeVars> = {
  gray1: '#1a1a1a',
  gray2: '#2a2a2a',
  gray3: '#3a3a3a',
  gray4: '#4a4a4a',
  gray5: '#5a5a5a',
  gray6: '#6a6a6a',
  gray7: '#7a7a7a',
  gray8: '#8a8a8a',
  background: '#1a1a1a',
  background2: '#2a2a2a',
  textColor: '#ffffff',
  textColor2: '#cccccc',
  textColor3: '#999999',
  borderColor: '#3a3a3a',
  activeColor: '#3a3a3a',
};
