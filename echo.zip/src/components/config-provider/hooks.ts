import { computed, onMounted, onUnmounted, watch, type Ref } from 'vue';
import { mapThemeVarsToCSSVars } from './tokens';
import type { ConfigProviderTheme, ThemeVars } from './types';

/**
 * 主题管理组合式函数
 */
export function useTheme(theme: Ref<ConfigProviderTheme>) {
  const isClient = typeof window !== 'undefined';

  // 自动检测系统主题
  const getSystemTheme = (): ConfigProviderTheme => {
    if (!isClient) return 'light';
    return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
  };

  // 当前实际主题（考虑 auto 模式）
  const currentTheme = computed(() => {
    if (theme.value === 'auto') {
      return getSystemTheme();
    }
    return theme.value;
  });

  // 应用主题类名
  const applyTheme = (newTheme: ConfigProviderTheme, oldTheme?: ConfigProviderTheme) => {
    if (!isClient) return;

    // 移除旧主题类名
    if (oldTheme) {
      document.documentElement.classList.remove(`ht-theme-${oldTheme}`);
    }

    // 添加新主题类名
    document.documentElement.classList.add(`ht-theme-${newTheme}`);
  };

  // 监听系统主题变化
  let mediaQuery: MediaQueryList | null = null;

  const setupSystemThemeListener = () => {
    if (!isClient || theme.value !== 'auto') return;

    mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
    mediaQuery.addEventListener('change', handleSystemThemeChange);
  };

  const removeSystemThemeListener = () => {
    if (mediaQuery) {
      mediaQuery.removeEventListener('change', handleSystemThemeChange);
      mediaQuery = null;
    }
  };

  const handleSystemThemeChange = () => {
    if (theme.value === 'auto') {
      applyTheme(getSystemTheme());
    }
  };

  // 监听主题变化
  const stopWatcher = watch(
    theme,
    (newTheme, oldTheme) => {
      if (newTheme === 'auto') {
        setupSystemThemeListener();
        applyTheme(getSystemTheme(), oldTheme);
      } else {
        removeSystemThemeListener();
        applyTheme(newTheme, oldTheme);
      }
    },
    { immediate: true }
  );

  onMounted(() => {
    if (theme.value === 'auto') {
      setupSystemThemeListener();
    }
  });

  onUnmounted(() => {
    removeSystemThemeListener();
    stopWatcher();
  });

  return {
    currentTheme,
    applyTheme,
    setupSystemThemeListener,
    removeSystemThemeListener,
  };
}

/**
 * CSS 变量管理组合式函数
 */
export function useCSSVariables(
  themeVars: Ref<Partial<ThemeVars>>,
  themeVarsDark: Ref<Partial<ThemeVars>>,
  themeVarsLight: Ref<Partial<ThemeVars>>,
  currentTheme: Ref<ConfigProviderTheme>,
  scope: Ref<'local' | 'global'>
) {
  const isClient = typeof window !== 'undefined';

  // 计算合并后的主题变量
  const mergedThemeVars = computed(() => {
    const baseVars = themeVars.value || {};
    const themeSpecificVars = currentTheme.value === 'dark' ? themeVarsDark.value : themeVarsLight.value;

    return { ...baseVars, ...themeSpecificVars };
  });

  // 转换为 CSS 变量
  const cssVars = computed(() => mapThemeVarsToCSSVars(mergedThemeVars.value));

  // 同步 CSS 变量到根元素
  const syncCSSVarsToRoot = (
    newVars: Record<string, string | number>,
    oldVars: Record<string, string | number> = {}
  ) => {
    if (!isClient) return;

    const root = document.documentElement;

    // 更新或添加新变量
    Object.keys(newVars).forEach((key) => {
      if (newVars[key] !== oldVars[key]) {
        root.style.setProperty(key, String(newVars[key]));
      }
    });

    // 移除旧变量
    Object.keys(oldVars).forEach((key) => {
      if (!newVars[key]) {
        root.style.removeProperty(key);
      }
    });
  };

  // 监听作用域变化
  const stopScopeWatcher = watch(scope, (newScope, oldScope) => {
    if (!isClient) return;

    if (oldScope === 'global') {
      // 从全局移除
      syncCSSVarsToRoot({}, cssVars.value);
    }
    if (newScope === 'global') {
      // 添加到全局
      syncCSSVarsToRoot(cssVars.value, {});
    }
  });

  // 监听变量变化
  const stopVarsWatcher = watch(
    cssVars,
    (newVars, oldVars) => {
      if (scope.value === 'global') {
        syncCSSVarsToRoot(newVars, oldVars as Record<string, string | number>);
      }
    },
    { deep: true }
  );

  // 初始化全局变量
  onMounted(() => {
    if (scope.value === 'global') {
      syncCSSVarsToRoot(cssVars.value, {});
    }
  });

  onUnmounted(() => {
    stopScopeWatcher();
    stopVarsWatcher();
  });

  return {
    mergedThemeVars,
    cssVars,
  };
}

/**
 * 全局 z-index 管理组合式函数
 */
export function useGlobalZIndex(zIndex: Ref<number | undefined>) {
  const isClient = typeof window !== 'undefined';

  // 设置全局 z-index 基础值
  const setGlobalZIndex = (value: number) => {
    if (!isClient) return;
    // 可以设置一个全局的 CSS 变量或者存储在某个地方
    document.documentElement.style.setProperty('--ht-z-index-base', String(value));
  };

  // 监听 z-index 变化
  const stopWatcher = watch(
    zIndex,
    (newZIndex) => {
      if (newZIndex !== undefined) {
        setGlobalZIndex(newZIndex);
      }
    },
    { immediate: true }
  );

  onUnmounted(() => {
    stopWatcher();
  });

  return {
    setGlobalZIndex,
  };
}

/**
 * 图标前缀管理组合式函数
 */
export function useIconPrefix(iconPrefix: Ref<string>) {
  const currentIconPrefix = computed(() => iconPrefix.value || 'ht-icon');

  return {
    currentIconPrefix,
  };
}
