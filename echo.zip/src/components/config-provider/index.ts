import HTConfigProvider from './ConfigProvider.vue';

// 默认导出
export default HTConfigProvider;

// 命名导出
export { HTConfigProvider };

// 导出类型和常量
export {
  configProviderProps,
  type ConfigProviderProps,
  type ConfigProviderTheme,
  type ConfigProviderThemeVarsScope,
  type ConfigProviderProvide,
  type UseConfigProviderReturn,
  type ThemeVars,
} from './types';

export { mapThemeVarsToCSSVars, kebabCase, insertDash, defaultThemeVars, darkThemeVars } from './tokens';

export { useTheme, useCSSVariables, useGlobalZIndex, useIconPrefix } from './hooks';

// 声明全局组件类型（用于 tsx 支持）
declare module 'vue' {
  export interface GlobalComponents {
    HTConfigProvider: typeof HTConfigProvider;
  }
}
