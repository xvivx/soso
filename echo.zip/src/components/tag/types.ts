export type TagSize = 'small' | 'large';

export type TagType = 'default' | 'primary' | 'success' | 'warning' | 'danger' | 'info';

export interface TagProps {
  size?: TagSize;
  type?: TagType;
  color?: string;
  show?: boolean;
  plain?: boolean;
  round?: boolean;
  mark?: boolean;
  textColor?: string;
  closeable?: boolean;
  tabindex?: string | number;
  role?: string;
  'aria-label'?: string;
  'aria-live'?: 'off' | 'assertive' | 'polite';
  'aria-atomic'?: boolean | 'true' | 'false';
  'aria-describedby'?: string;
  'aria-labelledby'?: string;
  // reka-ui Primitive props
  as?: string | object;
  asChild?: boolean;
}

export interface TagEmits {
  (e: 'close', event: MouseEvent): void;
}
