export { default as HTTag } from './Tag.vue';
export type { TagProps, TagType, TagSize } from './types';
