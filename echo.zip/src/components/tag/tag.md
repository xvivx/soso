# Tag 标签

用于标记和分类的标签组件。

## 基础用法

通过 `type` 属性控制标签颜色。

:::demo

```vue
<template>
  <div class="demo-tag">
    <HTTag>标签</HTTag>
    <HTTag type="primary">标签</HTTag>
    <HTTag type="success">标签</HTTag>
    <HTTag type="warning">标签</HTTag>
    <HTTag type="danger">标签</HTTag>
    <HTTag type="info">标签</HTTag>
  </div>
</template>

<style scoped>
.demo-tag {
  display: flex;
  gap: 8px;
  flex-wrap: wrap;
}
</style>
```

:::

## 朴素样式

通过 `plain` 属性设置为朴素样式。

:::demo

```vue
<template>
  <div class="demo-tag">
    <HTTag plain>标签</HTTag>
    <HTTag type="primary" plain>标签</HTTag>
    <HTTag type="success" plain>标签</HTTag>
    <HTTag type="warning" plain>标签</HTTag>
    <HTTag type="danger" plain>标签</HTTag>
    <HTTag type="info" plain>标签</HTTag>
  </div>
</template>

<style scoped>
.demo-tag {
  display: flex;
  gap: 8px;
  flex-wrap: wrap;
}
</style>
```

:::

## 圆角样式

通过 `round` 属性设置为圆角样式。

:::demo

```vue
<template>
  <div class="demo-tag">
    <HTTag round>标签</HTTag>
    <HTTag type="primary" round>标签</HTTag>
    <HTTag type="success" round>标签</HTTag>
    <HTTag type="warning" round>标签</HTTag>
    <HTTag type="danger" round>标签</HTTag>
  </div>
</template>

<style scoped>
.demo-tag {
  display: flex;
  gap: 8px;
  flex-wrap: wrap;
}
</style>
```

:::

## 标记样式

通过 `mark` 属性设置为标记样式（圆角在右侧）。

:::demo

```vue
<template>
  <div class="demo-tag">
    <HTTag mark>标签</HTTag>
    <HTTag type="primary" mark>标签</HTTag>
    <HTTag type="success" mark>标签</HTTag>
  </div>
</template>

<style scoped>
.demo-tag {
  display: flex;
  gap: 8px;
  flex-wrap: wrap;
}
</style>
```

:::

## 可关闭标签

通过 `closeable` 属性控制标签是否可关闭，点击关闭图标后会触发 `close` 事件。

:::demo

```vue
<template>
  <div class="demo-tag">
    <HTTag v-if="show.default" closeable @close="show.default = false">
      标签
    </HTTag>
    <HTTag
      v-if="show.primary"
      type="primary"
      closeable
      @close="show.primary = false"
    >
      标签
    </HTTag>
    <HTTag
      v-if="show.success"
      type="success"
      closeable
      @close="show.success = false"
    >
      标签
    </HTTag>
  </div>
</template>

<script setup>
import { reactive } from 'vue';

const show = reactive({
  default: true,
  primary: true,
  success: true,
});
</script>

<style scoped>
.demo-tag {
  display: flex;
  gap: 8px;
  flex-wrap: wrap;
}
</style>
```

:::

## 标签尺寸

通过 `size` 属性调整标签大小。

:::demo

```vue
<template>
  <div class="demo-tag">
    <HTTag size="small">小号标签</HTTag>
    <HTTag>默认标签</HTTag>
    <HTTag size="large">大号标签</HTTag>
  </div>
</template>

<style scoped>
.demo-tag {
  display: flex;
  gap: 8px;
  flex-wrap: wrap;
  align-items: center;
}
</style>
```

:::

## 自定义颜色

通过 `color` 和 `text-color` 属性设置标签颜色。

:::demo

```vue
<template>
  <div class="demo-tag">
    <HTTag color="#7232dd">标签</HTTag>
    <HTTag color="#7232dd" plain>标签</HTTag>
    <HTTag color="#ffe1e1" text-color="#ad0000">标签</HTTag>
  </div>
</template>

<style scoped>
.demo-tag {
  display: flex;
  gap: 8px;
  flex-wrap: wrap;
}
</style>
```

:::

## API

### Props

| 参数 | 说明 | 类型 | 默认值 |
| --- | --- | --- | --- |
| type | 类型 | `'default' \| 'primary' \| 'success' \| 'warning' \| 'danger' \| 'info'` | `'default'` |
| size | 尺寸 | `'small' \| 'large'` | - |
| color | 标签颜色 | `string` | - |
| show | 是否展示标签 | `boolean` | `true` |
| plain | 是否为朴素样式 | `boolean` | `false` |
| round | 是否为圆角样式 | `boolean` | `false` |
| mark | 是否为标记样式 | `boolean` | `false` |
| text-color | 文本颜色，优先级高于 color | `string` | - |
| closeable | 是否可关闭 | `boolean` | `false` |

### Events

| 事件名 | 说明 | 回调参数 |
| --- | --- | --- |
| close | 关闭标签时触发 | `event: MouseEvent` |

### Slots

| 名称 | 说明 |
| --- | --- |
| default | 标签显示内容 |
