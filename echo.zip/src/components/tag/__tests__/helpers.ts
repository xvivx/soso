import { nextTick } from 'vue';
import { mount } from '@vue/test-utils';
import { vi } from 'vitest';
import { HTTag } from '@/components';
import type { TagProps } from '@/components/tag/types';
import { TAG_FIXTURES } from './fixtures';

export function createTagWrapper(props: Partial<TagProps> = {}, slotContent = '测试标签', attrs: any = {}) {
  return mount(HTTag, {
    props: { ...TAG_FIXTURES.default.props, ...props },
    slots: {
      default: slotContent,
    },
    attrs,
  });
}

export function expectTagToHaveClasses(wrapper: any, expectedClasses: string | string[]) {
  const tagElement = wrapper.find('.ht-tag');
  const classes = Array.isArray(expectedClasses) ? expectedClasses : [expectedClasses];

  classes.forEach((className) => {
    expect(tagElement.classes()).toContain(className);
  });
}

export function expectTagNotToHaveClasses(wrapper: any, unexpectedClasses: string | string[]) {
  const tagElement = wrapper.find('.ht-tag');
  const classes = Array.isArray(unexpectedClasses) ? unexpectedClasses : [unexpectedClasses];

  classes.forEach((className) => {
    expect(tagElement.classes()).not.toContain(className);
  });
}

export async function waitForTransition(
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  _wrapper?: any
) {
  await nextTick();
  // 等待过渡动画完成
  await new Promise((resolve) => setTimeout(resolve, 300));
  await nextTick();
}

export function getCloseButton(wrapper: any) {
  return wrapper.find('.ht-tag__close');
}

export function clickCloseButton(wrapper: any) {
  const closeButton = getCloseButton(wrapper);
  if (closeButton.exists()) {
    closeButton.trigger('click');
  }
}

export function getTagElement(wrapper: any) {
  return wrapper.find('.ht-tag');
}

export function getTagStyles(wrapper: any) {
  const tagElement = getTagElement(wrapper);
  return tagElement.attributes('style') || '';
}

export function expectTagToBeVisible(wrapper: any) {
  const tagElement = getTagElement(wrapper);
  expect(tagElement.exists()).toBe(true);
  expect(tagElement.isVisible()).toBe(true);
}

export function expectTagToBeHidden(wrapper: any) {
  const tagElement = getTagElement(wrapper);
  // 由于使用 v-if，元素可能完全不存在
  if (tagElement.exists()) {
    expect(tagElement.isVisible()).toBe(false);
  }
}

export function getComputedStyleProperty(wrapper: any, property: string) {
  const tagElement = getTagElement(wrapper);
  return getComputedStyle(tagElement.element).getPropertyValue(property);
}

export function mockMouseEvent(type = 'click') {
  return {
    type,
    bubbles: true,
    cancelable: true,
    preventDefault: vi.fn(),
    stopPropagation: vi.fn(),
  } as any;
}

export function createTagWithContent(content: string, props: Partial<TagProps> = {}) {
  return mount(HTTag, {
    props: { ...TAG_FIXTURES.default.props, ...props },
    slots: {
      default: content,
    },
  });
}

export function expectTagToHaveAttribute(wrapper: any, attribute: string, value?: string) {
  const tagElement = getTagElement(wrapper);
  expect(tagElement.exists()).toBe(true);

  if (value !== undefined) {
    expect(tagElement.attributes(attribute)).toBe(value);
  } else {
    expect(tagElement.attributes(attribute)).toBeDefined();
  }
}

export function expectTagNotToHaveAttribute(wrapper: any, attribute: string) {
  const tagElement = getTagElement(wrapper);
  if (tagElement.exists()) {
    expect(tagElement.attributes(attribute)).toBeUndefined();
  }
}
