import type { TagProps } from '@/components/tag/types';

export const DEFAULT_TAG_PROPS: TagProps = {
  type: 'default',
  show: true,
  plain: false,
  round: false,
  mark: false,
  closeable: false,
};

export const TAG_TYPES = ['default', 'primary', 'success', 'warning', 'danger', 'info'] as const;

export const TAG_SIZES = ['small', 'large'] as const;

export const TAG_FIXTURES = {
  default: {
    props: DEFAULT_TAG_PROPS,
    text: '默认标签',
    expectedClass: 'ht-tag--default',
  },
  primary: {
    props: { ...DEFAULT_TAG_PROPS, type: 'primary' },
    text: '主要标签',
    expectedClass: 'ht-tag--primary',
  },
  success: {
    props: { ...DEFAULT_TAG_PROPS, type: 'success' },
    text: '成功标签',
    expectedClass: 'ht-tag--success',
  },
  warning: {
    props: { ...DEFAULT_TAG_PROPS, type: 'warning' },
    text: '警告标签',
    expectedClass: 'ht-tag--warning',
  },
  danger: {
    props: { ...DEFAULT_TAG_PROPS, type: 'danger' },
    text: '危险标签',
    expectedClass: 'ht-tag--danger',
  },
  info: {
    props: { ...DEFAULT_TAG_PROPS, type: 'info' },
    text: '信息标签',
    expectedClass: 'ht-tag--info',
  },
  small: {
    props: { ...DEFAULT_TAG_PROPS, size: 'small' },
    text: '小号标签',
    expectedClass: 'ht-tag--small',
  },
  large: {
    props: { ...DEFAULT_TAG_PROPS, size: 'large' },
    text: '大号标签',
    expectedClass: 'ht-tag--large',
  },
  plain: {
    props: { ...DEFAULT_TAG_PROPS, plain: true },
    text: '朴素标签',
    expectedClass: 'ht-tag--plain',
  },
  round: {
    props: { ...DEFAULT_TAG_PROPS, round: true },
    text: '圆角标签',
    expectedClass: 'ht-tag--round',
  },
  mark: {
    props: { ...DEFAULT_TAG_PROPS, mark: true },
    text: '标记标签',
    expectedClass: 'ht-tag--mark',
  },
  closeable: {
    props: { ...DEFAULT_TAG_PROPS, closeable: true },
    text: '可关闭标签',
    expectedClass: 'ht-tag__close',
  },
  hidden: {
    props: { ...DEFAULT_TAG_PROPS, show: false },
    text: '隐藏标签',
    expectedClass: null,
  },
  customColor: {
    props: { ...DEFAULT_TAG_PROPS, color: '#7232dd' },
    text: '自定义颜色',
    expectedClass: null,
  },
  customTextColor: {
    props: { ...DEFAULT_TAG_PROPS, color: '#ffe1e1', textColor: '#ad0000' },
    text: '自定义文本色',
    expectedClass: null,
  },
  combined: {
    props: {
      ...DEFAULT_TAG_PROPS,
      type: 'primary',
      size: 'large',
      plain: true,
      round: true,
      closeable: true,
    },
    text: '组合样式',
    expectedClass: 'ht-tag--primary ht-tag--large ht-tag--plain ht-tag--round',
  },
} as const;

export const CUSTOM_COLORS = ['#7232dd', '#1677ff', '#52c41a', '#fa8c16', '#ff4d4f', '#13c2c2', '#722ed1', '#eb2f96'];

export const INVALID_PROPS = {
  invalidType: { ...DEFAULT_TAG_PROPS, type: 'invalid' as any },
  invalidSize: { ...DEFAULT_TAG_PROPS, size: 'invalid' as any },
  invalidColor: { ...DEFAULT_TAG_PROPS, color: '' },
  invalidTextColor: { ...DEFAULT_TAG_PROPS, textColor: '' },
};
