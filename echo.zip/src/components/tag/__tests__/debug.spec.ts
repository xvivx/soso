import { mount } from '@vue/test-utils';
import { describe, it } from 'vitest';
import { HTTag } from '@/components';

describe('HTTag Debug', () => {
  it('should have ARIA attributes', async () => {
    // Test simple aria attribute first
    const wrapper = mount(HTTag, {
      props: {
        'aria-label': 'Simple Test',
      },
      slots: {
        default: 'Test Tag',
      },
    });

    const tagElement = wrapper.find('.ht-tag');
    console.log('Simple HTML:', tagElement.html());
    console.log('Simple attributes:', tagElement.attributes());
  });

  it('should have correct styles', async () => {
    const wrapper = mount(HTTag, {
      props: {
        type: 'default',
        show: true,
        plain: false,
        color: '#000000',
        textColor: '#ffffff',
      },
      slots: {
        default: 'Test Tag',
      },
    });

    const tagElement = wrapper.find('.ht-tag');
    console.log('Tag styles:', tagElement.attributes('style'));
  });

  it('should have plain styles', async () => {
    const wrapper = mount(HTTag, {
      props: {
        type: 'primary',
        plain: true,
        color: '#1677ff',
      },
      slots: {
        default: 'Test Tag',
      },
    });

    const tagElement = wrapper.find('.ht-tag');
    console.log('Plain tag styles:', tagElement.attributes('style'));
    console.log('Plain tag classes:', tagElement.classes());
  });
});
