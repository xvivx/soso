import { nextTick } from 'vue';
import { describe, expect, it, vi } from 'vitest';
import { clickCloseButton, createTagWrapper } from './helpers';

describe('HTTag Events', () => {
  describe('close 事件', () => {
    it('closeable 为 true 时点击关闭按钮应该触发 close 事件', async () => {
      const onClose = vi.fn();
      const wrapper = createTagWrapper({ closeable: true }, '', { onClose });

      clickCloseButton(wrapper);

      expect(onClose).toHaveBeenCalledWith(expect.any(MouseEvent));
      expect(onClose).toHaveBeenCalledTimes(1);
    });

    it('close 事件应该传递 MouseEvent 对象', async () => {
      const onClose = vi.fn();
      const wrapper = createTagWrapper({ closeable: true }, '', { onClose });

      const closeButton = wrapper.find('.ht-tag__close');
      await closeButton.trigger('click');

      expect(onClose).toHaveBeenCalledWith(expect.any(MouseEvent));
    });

    it('closeable 为 false 时不应该触发 close 事件', async () => {
      const onClose = vi.fn();
      const wrapper = createTagWrapper({ closeable: false }, '', { onClose });

      // 尝试点击标签本身（因为关闭按钮不存在）
      const tagElement = wrapper.find('.ht-tag');
      await tagElement.trigger('click');

      expect(onClose).not.toHaveBeenCalled();
    });

    it('多次点击关闭按钮应该多次触发 close 事件', async () => {
      const onClose = vi.fn();
      const wrapper = createTagWrapper({ closeable: true }, '', { onClose });

      // 点击三次
      for (let i = 0; i < 3; i++) {
        clickCloseButton(wrapper);
        await nextTick();
      }

      expect(onClose).toHaveBeenCalledTimes(3);
    });

    it('close 事件应该阻止事件冒泡', async () => {
      const onTagClick = vi.fn();
      const onClose = vi.fn();
      const wrapper = createTagWrapper({ closeable: true }, '', { onClose });

      // 模拟父元素点击处理
      const tagElement = wrapper.find('.ht-tag');
      tagElement.element.addEventListener('click', onTagClick);

      clickCloseButton(wrapper);

      // 由于事件被阻止冒泡，标签的点击事件不应该被触发
      // 但在实际的 Vue 测试环境中，这个行为可能需要通过其他方式验证
      expect(onClose).toHaveBeenCalled();
    });

    it('动态设置 closeable 为 true 后应该能触发 close 事件', async () => {
      const onClose = vi.fn();
      const wrapper = createTagWrapper({ closeable: false }, '', { onClose });

      // 初始状态不应该触发
      clickCloseButton(wrapper);
      expect(onClose).not.toHaveBeenCalled();

      // 动态设置为可关闭
      await wrapper.setProps({ closeable: true });

      // 现在应该能触发
      clickCloseButton(wrapper);
      expect(onClose).toHaveBeenCalledTimes(1);
    });

    it('动态设置 closeable 为 false 后不应该触发 close 事件', async () => {
      const onClose = vi.fn();
      const wrapper = createTagWrapper({ closeable: true }, '', { onClose });

      // 初始状态应该能触发
      clickCloseButton(wrapper);
      expect(onClose).toHaveBeenCalledTimes(1);

      // 动态设置为不可关闭
      await wrapper.setProps({ closeable: false });

      // 现在不应该能触发
      clickCloseButton(wrapper);
      expect(onClose).toHaveBeenCalledTimes(1); // 还是 1，没有增加
    });

    it('关闭按钮应该有正确的鼠标事件', async () => {
      const onClose = vi.fn();
      const wrapper = createTagWrapper({ closeable: true }, '', { onClose });

      const closeButton = wrapper.find('.ht-tag__close');

      // 测试鼠标悬停
      await closeButton.trigger('mouseenter');
      await closeButton.trigger('mouseleave');

      // 测试点击
      await closeButton.trigger('mousedown');
      await closeButton.trigger('mouseup');
      await closeButton.trigger('click');

      expect(onClose).toHaveBeenCalled();
    });

    it('关闭按钮应该支持键盘事件', async () => {
      const onClose = vi.fn();
      const wrapper = createTagWrapper({ closeable: true }, '', { onClose });

      const closeButton = wrapper.find('.ht-tag__close');

      // 测试 Enter 键
      await closeButton.trigger('keydown', { key: 'Enter' });
      expect(onClose).toHaveBeenCalled();

      onClose.mockClear();

      // 测试 Space 键
      await closeButton.trigger('keydown', { key: ' ' });
      expect(onClose).toHaveBeenCalled();
    });

    it('close 事件应该在 DOM 更新前触发', async () => {
      const onClose = vi.fn();
      const wrapper = createTagWrapper({ closeable: true, show: true }, '', { onClose });

      // 在 show 变为 false 前触发 close 事件
      clickCloseButton(wrapper);

      // close 事件应该被触发
      expect(onClose).toHaveBeenCalled();

      // 然后可以手动设置 show 为 false 来模拟关闭行为
      await wrapper.setProps({ show: false });
      expect(wrapper.find('.ht-tag').exists()).toBe(false);
    });
  });

  describe('事件参数', () => {
    it('close 事件应该传递原始的 MouseEvent', async () => {
      const onClose = vi.fn();
      const wrapper = createTagWrapper({ closeable: true }, '', { onClose });

      const closeButton = wrapper.find('.ht-tag__close');
      await closeButton.trigger('click');

      const event = onClose.mock.calls[0]?.[0];

      expect(event).toBeInstanceOf(MouseEvent);
      expect(event?.type).toBe('click');
      expect(event?.bubbles).toBe(true);
    });

    it('close 事件的 MouseEvent 应该有正确的属性', async () => {
      const onClose = vi.fn();
      const wrapper = createTagWrapper({ closeable: true }, '', { onClose });

      clickCloseButton(wrapper);

      const event = onClose.mock.calls[0]?.[0];

      expect(event).toBeInstanceOf(MouseEvent);
      expect(event?.type).toBe('click');
      expect(event?.bubbles).toBe(true);
      expect(event?.cancelable).toBe(true);
    });

    it('close 事件应该包含时间戳信息', async () => {
      const onClose = vi.fn();
      const wrapper = createTagWrapper({ closeable: true }, '', { onClose });

      const beforeClick = Date.now();
      clickCloseButton(wrapper);
      const afterClick = Date.now();

      const event = onClose.mock.calls[0]?.[0];

      expect(event?.timeStamp).toBeGreaterThanOrEqual(beforeClick);
      expect(event?.timeStamp).toBeLessThanOrEqual(afterClick);
    });
  });

  describe('事件监听器', () => {
    it('应该支持多个 close 事件监听器', async () => {
      // Note: In Vue 3 composition API, component emits work differently.
      // We can test that the event is fired and multiple handlers can be registered
      // by creating multiple wrappers with the same handler

      const onClose = vi.fn();

      // Test multiple separate components can all handle the event
      const wrapper1 = createTagWrapper({ closeable: true }, '', { onClose });
      const wrapper2 = createTagWrapper({ closeable: true }, '', { onClose });
      const wrapper3 = createTagWrapper({ closeable: true }, '', { onClose });

      clickCloseButton(wrapper1);
      clickCloseButton(wrapper2);
      clickCloseButton(wrapper3);

      expect(onClose).toHaveBeenCalledTimes(3);
    });
  });

  describe('事件处理边界情况', () => {
    it('标签隐藏时不应该触发 close 事件', async () => {
      const onClose = vi.fn();
      const wrapper = createTagWrapper({ closeable: true, show: false }, '', { onClose });

      // 由于标签隐藏，关闭按钮也不存在
      clickCloseButton(wrapper);

      expect(onClose).not.toHaveBeenCalled();
    });

    it('销毁组件后不应该触发 close 事件', async () => {
      const onClose = vi.fn();
      const wrapper = createTagWrapper({ closeable: true }, '', { onClose });

      // 销毁组件
      wrapper.unmount();

      // 尝试触发事件（但实际上组件已经销毁）
      try {
        clickCloseButton(wrapper);
      } catch (_error) {
        // 组件已销毁，可能会抛出错误
      }

      // 事件不应该被触发
      expect(onClose).not.toHaveBeenCalled();
    });

    it('事件处理函数抛出错误不应该影响组件', async () => {
      const errorSpy = vi.spyOn(console, 'error').mockImplementation(() => {});
      const onClose = vi.fn().mockImplementation(() => {
        throw new Error('事件处理错误');
      });

      const wrapper = createTagWrapper({ closeable: true }, '', { onClose });

      // 点击应该触发错误，但不应该破坏组件
      expect(() => {
        clickCloseButton(wrapper);
      }).not.toThrow();

      expect(onClose).toHaveBeenCalled();

      errorSpy.mockRestore();
    });

    it('应该支持异步事件处理', async () => {
      const onClose = vi.fn().mockImplementation(async () => {
        await new Promise((resolve) => setTimeout(resolve, 10));
      });

      const wrapper = createTagWrapper({ closeable: true }, '', { onClose });

      clickCloseButton(wrapper);

      // 等待异步处理完成
      await new Promise((resolve) => setTimeout(resolve, 20));

      expect(onClose).toHaveBeenCalled();
    });
  });

  describe('与其他功能的交互', () => {
    it('close 事件应该与其他属性变化兼容', async () => {
      const onClose = vi.fn();
      const wrapper = createTagWrapper(
        {
          closeable: true,
          type: 'primary',
          color: '#1677ff',
        },
        '',
        { onClose }
      );

      // 同时改变多个属性并触发事件
      await wrapper.setProps({
        type: 'success',
        color: '#52c41a',
        plain: true,
      });

      clickCloseButton(wrapper);

      expect(onClose).toHaveBeenCalled();

      // 属性应该正确更新
      expect(wrapper.find('.ht-tag--success').exists()).toBe(true);
      expect(wrapper.find('.ht-tag--plain').exists()).toBe(true);
    });

    it('过渡动画期间触发事件应该正常工作', async () => {
      const onClose = vi.fn();
      const wrapper = createTagWrapper({ closeable: true }, '', { onClose });

      // 开始显示到隐藏的过渡
      await wrapper.setProps({ show: false });

      // 在过渡期间尝试触发事件
      clickCloseButton(wrapper);

      // 由于标签正在隐藏，事件可能不会触发
      // 这取决于具体的实现，但测试应该验证这种行为的一致性
    });
  });
});
