import { describe, expect, it } from 'vitest';
import { CUSTOM_COLORS, INVALID_PROPS, TAG_SIZES, TAG_TYPES } from './fixtures';
import { createTagWrapper, expectTagNotToHaveClasses, expectTagToHaveClasses, getTagStyles } from './helpers';

// 辅助函数：将颜色值转换为 rgb 格式进行比较
function hexToRgb(hex: string): string {
  const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
  return result ? `rgb(${parseInt(result[1]!, 16)}, ${parseInt(result[2]!, 16)}, ${parseInt(result[3]!, 16)})` : hex;
}

function parseHslToRgb(hsl: string): string {
  // 简单的 HSL 到 RGB 转换（仅用于测试）
  const match = hsl.match(/hsl\((\d+),\s*(\d+)%,\s*(\d+)%\)/);
  if (!match) return hsl;

  const h = parseInt(match[1]!) / 360;
  const s = parseInt(match[2]!) / 100;
  const l = parseInt(match[3]!) / 100;

  const hue2rgb = (p: number, q: number, t: number) => {
    if (t < 0) t += 1;
    if (t > 1) t -= 1;
    if (t < 1 / 6) return p + (q - p) * 6 * t;
    if (t < 1 / 2) return q;
    if (t < 2 / 3) return p + (q - p) * (2 / 3 - t) * 6;
    return p;
  };

  const q = l < 0.5 ? l * (1 + s) : l + s - l * s;
  const p = 2 * l - q;
  const r = Math.round(hue2rgb(p, q, h + 1 / 3) * 255);
  const g = Math.round(hue2rgb(p, q, h) * 255);
  const b = Math.round(hue2rgb(p, q, h - 1 / 3) * 255);

  return `rgb(${r}, ${g}, ${b})`;
}

describe('HTTag Props', () => {
  describe('type 属性', () => {
    it('应该接受有效的类型值', () => {
      TAG_TYPES.forEach((type) => {
        const wrapper = createTagWrapper({ type });
        expectTagToHaveClasses(wrapper, `ht-tag--${type}`);
      });
    });

    it('应该默认为 default 类型', () => {
      const wrapper = createTagWrapper();
      expectTagToHaveClasses(wrapper, 'ht-tag--default');
    });

    it('应该处理无效的类型值', () => {
      const wrapper = createTagWrapper({ type: 'invalid' as any });
      // 组件会直接使用传入的 type 值
      expectTagToHaveClasses(wrapper, 'ht-tag--invalid');
    });

    it('动态改变类型应该正确更新', async () => {
      const wrapper = createTagWrapper({ type: 'primary' });
      expectTagToHaveClasses(wrapper, 'ht-tag--primary');

      await wrapper.setProps({ type: 'success' });
      expectTagToHaveClasses(wrapper, 'ht-tag--success');
      expectTagNotToHaveClasses(wrapper, 'ht-tag--primary');
    });
  });

  describe('size 属性', () => {
    it('应该接受有效的尺寸值', () => {
      TAG_SIZES.forEach((size) => {
        const wrapper = createTagWrapper({ size });
        expectTagToHaveClasses(wrapper, `ht-tag--${size}`);
      });
    });

    it('应该默认没有尺寸类', () => {
      const wrapper = createTagWrapper();
      expect(wrapper.find('.ht-tag--small').exists()).toBe(false);
      expect(wrapper.find('.ht-tag--large').exists()).toBe(false);
    });

    it('应该处理无效的尺寸值', () => {
      const wrapper = createTagWrapper({ size: 'invalid' as any });
      // 无效尺寸应该不添加任何尺寸类
      expect(wrapper.find('.ht-tag--small').exists()).toBe(false);
      expect(wrapper.find('.ht-tag--large').exists()).toBe(false);
    });

    it('动态改变尺寸应该正确更新', async () => {
      const wrapper = createTagWrapper({ size: 'small' });
      expectTagToHaveClasses(wrapper, 'ht-tag--small');

      await wrapper.setProps({ size: 'large' });
      expectTagToHaveClasses(wrapper, 'ht-tag--large');
      expectTagNotToHaveClasses(wrapper, 'ht-tag--small');

      await wrapper.setProps({ size: undefined });
      expect(wrapper.find('.ht-tag--small').exists()).toBe(false);
      expect(wrapper.find('.ht-tag--large').exists()).toBe(false);
    });
  });

  describe('color 属性', () => {
    it('应该设置背景颜色', () => {
      const color = '#7232dd';
      const wrapper = createTagWrapper({ color });
      const styles = getTagStyles(wrapper);
      expect(styles).toContain('background:');
      expect(styles).toContain(hexToRgb(color));
    });

    it('应该支持十六进制颜色', () => {
      CUSTOM_COLORS.forEach((color) => {
        const wrapper = createTagWrapper({ color });
        const styles = getTagStyles(wrapper);
        expect(styles).toContain('background:');
        expect(styles).toContain(hexToRgb(color));
      });
    });

    it('应该支持 RGB 颜色', () => {
      const color = 'rgb(114, 50, 221)';
      const wrapper = createTagWrapper({ color });
      const styles = getTagStyles(wrapper);
      expect(styles).toContain(`background: ${color}`);
    });

    it('应该支持 RGBA 颜色', () => {
      const color = 'rgba(114, 50, 221, 0.8)';
      const wrapper = createTagWrapper({ color });
      const styles = getTagStyles(wrapper);
      expect(styles).toContain(`background: ${color}`);
    });

    it('应该支持 HSL 颜色', () => {
      const color = 'hsl(260, 65%, 53%)';
      const wrapper = createTagWrapper({ color });
      const styles = getTagStyles(wrapper);
      expect(styles).toContain('background:');
      expect(styles).toContain(parseHslToRgb(color));
    });

    it('应该支持颜色名称', () => {
      const color = 'purple';
      const wrapper = createTagWrapper({ color });
      const styles = getTagStyles(wrapper);
      expect(styles).toContain(`background: ${color}`);
    });

    it('动态改变颜色应该正确更新', async () => {
      const wrapper = createTagWrapper({ color: '#1677ff' });
      expect(getTagStyles(wrapper)).toContain('background:');
      expect(getTagStyles(wrapper)).toContain('rgb(22, 119, 255)');

      await wrapper.setProps({ color: '#52c41a' });
      expect(getTagStyles(wrapper)).toContain('background:');
      expect(getTagStyles(wrapper)).toContain('rgb(82, 196, 26)');
      expect(getTagStyles(wrapper)).not.toContain('rgb(22, 119, 255)');
    });

    it('应该处理空颜色值', () => {
      const wrapper = createTagWrapper({ color: '' });
      const styles = getTagStyles(wrapper);
      expect(styles).toBe('');
    });
  });

  describe('textColor 属性', () => {
    it('应该设置文本颜色', () => {
      const textColor = '#ffffff';
      const wrapper = createTagWrapper({ textColor });
      const styles = getTagStyles(wrapper);
      expect(styles).toContain('color:');
      expect(styles).toContain('rgb(255, 255, 255)');
    });

    it('应该优先于 color 属性', () => {
      const color = '#7232dd';
      const textColor = '#ffffff';
      const wrapper = createTagWrapper({ color, textColor });
      const styles = getTagStyles(wrapper);
      expect(styles).toContain('background:');
      expect(styles).toContain('rgb(114, 50, 221)');
      expect(styles).toContain('color:');
      expect(styles).toContain('rgb(255, 255, 255)');
    });

    it('动态改变文本颜色应该正确更新', async () => {
      const wrapper = createTagWrapper({ textColor: '#ffffff' });
      expect(getTagStyles(wrapper)).toContain('color:');
      expect(getTagStyles(wrapper)).toContain('rgb(255, 255, 255)');

      await wrapper.setProps({ textColor: '#000000' });
      expect(getTagStyles(wrapper)).toContain('color:');
      expect(getTagStyles(wrapper)).toContain('rgb(0, 0, 0)');
      expect(getTagStyles(wrapper)).not.toContain('rgb(255, 255, 255)');
    });
  });

  describe('plain 属性', () => {
    it('plain 为 true 时应该应用朴素样式', () => {
      const wrapper = createTagWrapper({ plain: true });
      expectTagToHaveClasses(wrapper, 'ht-tag--plain');
    });

    it('plain 为 false 时不应该应用朴素样式', () => {
      const wrapper = createTagWrapper({ plain: false });
      expect(wrapper.find('.ht-tag--plain').exists()).toBe(false);
    });

    it('朴素样式时应该设置边框颜色', () => {
      const color = '#1677ff';
      const wrapper = createTagWrapper({ color, plain: true });
      const styles = getTagStyles(wrapper);
      expect(styles).toContain('border-color:');
      expect(styles).toContain('rgb(22, 119, 255)');
      // 朴素样式通过 CSS 类设置背景，不通过内联样式
      expect(wrapper.find('.ht-tag--plain').exists()).toBe(true);
    });

    it('朴素样式时应该使用 color 作为文本颜色', () => {
      const color = '#1677ff';
      const wrapper = createTagWrapper({ color, plain: true });
      const styles = getTagStyles(wrapper);
      expect(styles).toContain('color:');
      expect(styles).toContain('rgb(22, 119, 255)');
    });

    it('朴素样式时 textColor 应该优先于 color', () => {
      const color = '#1677ff';
      const textColor = '#ffffff';
      const wrapper = createTagWrapper({ color, textColor, plain: true });
      const styles = getTagStyles(wrapper);
      expect(styles).toContain('color:');
      expect(styles).toContain('rgb(255, 255, 255)');
      // 边框颜色仍然是原始 color
      expect(styles).toContain('border-color: rgb(22, 119, 255)');
    });

    it('动态切换 plain 属性应该正确更新', async () => {
      const wrapper = createTagWrapper({ plain: false });
      expect(wrapper.find('.ht-tag--plain').exists()).toBe(false);

      await wrapper.setProps({ plain: true });
      expectTagToHaveClasses(wrapper, 'ht-tag--plain');

      await wrapper.setProps({ plain: false });
      expect(wrapper.find('.ht-tag--plain').exists()).toBe(false);
    });
  });

  describe('round 属性', () => {
    it('round 为 true 时应该应用圆角样式', () => {
      const wrapper = createTagWrapper({ round: true });
      expectTagToHaveClasses(wrapper, 'ht-tag--round');
    });

    it('round 为 false 时不应该应用圆角样式', () => {
      const wrapper = createTagWrapper({ round: false });
      expect(wrapper.find('.ht-tag--round').exists()).toBe(false);
    });

    it('动态切换 round 属性应该正确更新', async () => {
      const wrapper = createTagWrapper({ round: false });
      expect(wrapper.find('.ht-tag--round').exists()).toBe(false);

      await wrapper.setProps({ round: true });
      expectTagToHaveClasses(wrapper, 'ht-tag--round');

      await wrapper.setProps({ round: false });
      expect(wrapper.find('.ht-tag--round').exists()).toBe(false);
    });
  });

  describe('mark 属性', () => {
    it('mark 为 true 时应该应用标记样式', () => {
      const wrapper = createTagWrapper({ mark: true });
      expectTagToHaveClasses(wrapper, 'ht-tag--mark');
    });

    it('mark 为 false 时不应该应用标记样式', () => {
      const wrapper = createTagWrapper({ mark: false });
      expect(wrapper.find('.ht-tag--mark').exists()).toBe(false);
    });

    it('标记样式应该有伪元素', () => {
      const wrapper = createTagWrapper({ mark: true });
      const tagElement = wrapper.find('.ht-tag');
      expect(tagElement.exists()).toBe(true);
    });

    it('动态切换 mark 属性应该正确更新', async () => {
      const wrapper = createTagWrapper({ mark: false });
      expect(wrapper.find('.ht-tag--mark').exists()).toBe(false);

      await wrapper.setProps({ mark: true });
      expectTagToHaveClasses(wrapper, 'ht-tag--mark');

      await wrapper.setProps({ mark: false });
      expect(wrapper.find('.ht-tag--mark').exists()).toBe(false);
    });
  });

  describe('closeable 属性', () => {
    it('closeable 为 true 时应该显示关闭按钮', () => {
      const wrapper = createTagWrapper({ closeable: true });
      const closeButton = wrapper.find('.ht-tag__close');
      expect(closeButton.exists()).toBe(true);
    });

    it('closeable 为 false 时不应该显示关闭按钮', () => {
      const wrapper = createTagWrapper({ closeable: false });
      const closeButton = wrapper.find('.ht-tag__close');
      expect(closeButton.exists()).toBe(false);
    });

    it('动态切换 closeable 属性应该正确更新', async () => {
      const wrapper = createTagWrapper({ closeable: false });
      expect(wrapper.find('.ht-tag__close').exists()).toBe(false);

      await wrapper.setProps({ closeable: true });
      expect(wrapper.find('.ht-tag__close').exists()).toBe(true);

      await wrapper.setProps({ closeable: false });
      expect(wrapper.find('.ht-tag__close').exists()).toBe(false);
    });
  });

  describe('show 属性', () => {
    it('show 为 true 时应该显示标签', () => {
      const wrapper = createTagWrapper({ show: true });
      expect(wrapper.find('.ht-tag').exists()).toBe(true);
    });

    it('show 为 false 时应该隐藏标签', () => {
      const wrapper = createTagWrapper({ show: false });
      expect(wrapper.find('.ht-tag').exists()).toBe(false);
    });

    it('动态切换 show 属性应该正确更新', async () => {
      const wrapper = createTagWrapper({ show: true });
      expect(wrapper.find('.ht-tag').exists()).toBe(true);

      await wrapper.setProps({ show: false });
      expect(wrapper.find('.ht-tag').exists()).toBe(false);

      await wrapper.setProps({ show: true });
      expect(wrapper.find('.ht-tag').exists()).toBe(true);
    });
  });

  describe('属性组合', () => {
    it('应该支持多个属性同时设置', () => {
      const wrapper = createTagWrapper({
        type: 'primary',
        size: 'large',
        plain: true,
        round: true,
        mark: true,
        closeable: true,
        color: '#1677ff',
        textColor: '#ffffff',
      });

      expectTagToHaveClasses(wrapper, 'ht-tag--primary');
      expectTagToHaveClasses(wrapper, 'ht-tag--large');
      expectTagToHaveClasses(wrapper, 'ht-tag--plain');
      expectTagToHaveClasses(wrapper, 'ht-tag--round');
      expectTagToHaveClasses(wrapper, 'ht-tag--mark');
      expect(wrapper.find('.ht-tag__close').exists()).toBe(true);
    });

    it('属性组合时样式应该正确应用', () => {
      const wrapper = createTagWrapper({
        type: 'primary',
        color: '#1677ff',
        textColor: '#ffffff',
        plain: true,
      });

      const styles = getTagStyles(wrapper);
      // 朴素样式通过 CSS 类设置背景，不通过内联样式
      expect(wrapper.find('.ht-tag--plain').exists()).toBe(true);
      expect(wrapper.find('.ht-tag--primary').exists()).toBe(true);
      expect(styles).toContain('color: rgb(255, 255, 255)');
      expect(styles).toContain('border-color: rgb(22, 119, 255)');
    });
  });

  describe('无效值处理', () => {
    it('应该处理无效的 type 值', () => {
      const wrapper = createTagWrapper(INVALID_PROPS.invalidType);
      // 组件会直接使用传入的 type 值
      expectTagToHaveClasses(wrapper, 'ht-tag--invalid');
    });

    it('应该处理无效的 size 值', () => {
      const wrapper = createTagWrapper(INVALID_PROPS.invalidSize);
      expect(wrapper.find('.ht-tag--small').exists()).toBe(false);
      expect(wrapper.find('.ht-tag--large').exists()).toBe(false);
    });

    it('应该处理无效的 color 值', () => {
      const wrapper = createTagWrapper(INVALID_PROPS.invalidColor);
      const styles = getTagStyles(wrapper);
      expect(styles).toBe('');
    });

    it('应该处理无效的 textColor 值', () => {
      const wrapper = createTagWrapper(INVALID_PROPS.invalidTextColor);
      const styles = getTagStyles(wrapper);
      expect(styles).toBe('');
    });
  });

  describe('响应式属性更新', () => {
    it('批量更新属性应该正确应用', async () => {
      const wrapper = createTagWrapper({
        type: 'primary',
        size: 'small',
        plain: false,
      });

      await wrapper.setProps({
        type: 'success',
        size: 'large',
        plain: true,
        round: true,
        color: '#52c41a',
      });

      expectTagToHaveClasses(wrapper, 'ht-tag--success');
      expectTagToHaveClasses(wrapper, 'ht-tag--large');
      expectTagToHaveClasses(wrapper, 'ht-tag--plain');
      expectTagToHaveClasses(wrapper, 'ht-tag--round');
      const styles = getTagStyles(wrapper);
      expect(styles).toContain('color:');
      expect(styles).toContain('rgb(82, 196, 26)');
      expect(styles).toContain('border-color:');
      expect(styles).toContain('rgb(82, 196, 26)');
    });

    it('属性更新应该保持未变更的属性', async () => {
      const wrapper = createTagWrapper({
        type: 'primary',
        size: 'large',
        round: true,
        mark: true,
      });

      await wrapper.setProps({ type: 'success' });

      expectTagToHaveClasses(wrapper, 'ht-tag--success');
      expectTagToHaveClasses(wrapper, 'ht-tag--large');
      expectTagToHaveClasses(wrapper, 'ht-tag--round');
      expectTagToHaveClasses(wrapper, 'ht-tag--mark');
    });
  });
});
