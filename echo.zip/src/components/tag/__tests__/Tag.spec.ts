import { describe, expect, it } from 'vitest';
import type { TagType } from '@/components/tag/types';
import { TAG_SIZES, TAG_TYPES } from './fixtures';
import {
  createTagWrapper,
  expectTagToBeHidden,
  expectTagToBeVisible,
  expectTagToHaveClasses,
  waitForTransition,
} from './helpers';

describe('HTTag', () => {
  describe('基础渲染', () => {
    it('应该正确渲染默认标签', () => {
      const wrapper = createTagWrapper();
      expectTagToBeVisible(wrapper);
      expect(wrapper.text()).toBe('测试标签');
      expectTagToHaveClasses(wrapper, 'ht-tag');
      expectTagToHaveClasses(wrapper, 'ht-tag--default');
    });

    it('应该渲染插槽内容', () => {
      const wrapper = createTagWrapper({}, '自定义内容');
      expect(wrapper.text()).toBe('自定义内容');
    });

    it('应该渲染复杂的插槽内容', () => {
      const complexContent = `
        <div>
          <span>复杂内容</span>
          <i class="icon"></i>
        </div>
      `;
      const wrapper = createTagWrapper({}, complexContent);
      expect(wrapper.html()).toContain('复杂内容');
      expect(wrapper.find('span').exists()).toBe(true);
      expect(wrapper.find('i.icon').exists()).toBe(true);
    });

    it('应该支持 HTML 标签作为插槽内容', () => {
      const htmlContent = '<strong>加粗文本</strong>';
      const wrapper = createTagWrapper({}, htmlContent);
      expect(wrapper.find('strong').exists()).toBe(true);
      expect(wrapper.find('strong').text()).toBe('加粗文本');
    });
  });

  describe('类型样式', () => {
    it.each(TAG_TYPES)('应该正确应用 %s 类型样式', (type) => {
      const wrapper = createTagWrapper({ type });
      expectTagToHaveClasses(wrapper, `ht-tag--${type}`);
    });

    it('应该正确渲染不同类型标签的内容', () => {
      const typeTests: Array<{ type: TagType; text: string }> = [
        { type: 'primary', text: '主要' },
        { type: 'success', text: '成功' },
        { type: 'warning', text: '警告' },
        { type: 'danger', text: '危险' },
        { type: 'info', text: '信息' },
      ];

      typeTests.forEach(({ type, text }) => {
        const wrapper = createTagWrapper({ type }, text);
        expect(wrapper.text()).toBe(text);
        expectTagToHaveClasses(wrapper, `ht-tag--${type}`);
      });
    });
  });

  describe('尺寸变体', () => {
    it.each(TAG_SIZES)('应该正确应用 %s 尺寸样式', (size) => {
      const wrapper = createTagWrapper({ size });
      expectTagToHaveClasses(wrapper, `ht-tag--${size}`);
    });

    it('默认情况下不应该有尺寸类', () => {
      const wrapper = createTagWrapper();
      expect(wrapper.find('.ht-tag--small').exists()).toBe(false);
      expect(wrapper.find('.ht-tag--large').exists()).toBe(false);
    });
  });

  describe('样式变体', () => {
    it('应该正确应用朴素样式', () => {
      const wrapper = createTagWrapper({ plain: true });
      expectTagToHaveClasses(wrapper, 'ht-tag--plain');
    });

    it('应该正确应用圆角样式', () => {
      const wrapper = createTagWrapper({ round: true });
      expectTagToHaveClasses(wrapper, 'ht-tag--round');
    });

    it('应该正确应用标记样式', () => {
      const wrapper = createTagWrapper({ mark: true });
      expectTagToHaveClasses(wrapper, 'ht-tag--mark');
    });

    it('应该支持样式组合', () => {
      const wrapper = createTagWrapper({
        type: 'primary',
        size: 'large',
        plain: true,
        round: true,
        mark: true,
      });

      expectTagToHaveClasses(wrapper, 'ht-tag--primary');
      expectTagToHaveClasses(wrapper, 'ht-tag--large');
      expectTagToHaveClasses(wrapper, 'ht-tag--plain');
      expectTagToHaveClasses(wrapper, 'ht-tag--round');
      expectTagToHaveClasses(wrapper, 'ht-tag--mark');
    });
  });

  describe('显示控制', () => {
    it('show 为 true 时应该显示标签', () => {
      const wrapper = createTagWrapper({ show: true });
      expectTagToBeVisible(wrapper);
    });

    it('show 为 false 时应该隐藏标签', () => {
      const wrapper = createTagWrapper({ show: false });
      expectTagToBeHidden(wrapper);
    });

    it('动态切换 show 属性应该正确响应', async () => {
      const wrapper = createTagWrapper({ show: true });
      expectTagToBeVisible(wrapper);

      await wrapper.setProps({ show: false });
      expectTagToBeHidden(wrapper);

      await wrapper.setProps({ show: true });
      expectTagToBeVisible(wrapper);
    });
  });

  describe('可关闭标签', () => {
    it('closeable 为 true 时应该显示关闭按钮', () => {
      const wrapper = createTagWrapper({ closeable: true });
      const closeButton = wrapper.find('.ht-tag__close');
      expect(closeButton.exists()).toBe(true);
    });

    it('closeable 为 false 时不应该显示关闭按钮', () => {
      const wrapper = createTagWrapper({ closeable: false });
      const closeButton = wrapper.find('.ht-tag__close');
      expect(closeButton.exists()).toBe(false);
    });

    it('默认情况下不应该显示关闭按钮', () => {
      const wrapper = createTagWrapper();
      const closeButton = wrapper.find('.ht-tag__close');
      expect(closeButton.exists()).toBe(false);
    });
  });

  describe('自定义颜色', () => {
    it('应该支持自定义背景颜色', () => {
      const color = '#7232dd';
      const wrapper = createTagWrapper({ color });
      const tagElement = wrapper.find('.ht-tag');

      expect(tagElement.exists()).toBe(true);
      expect(tagElement.attributes('style')).toContain('background');
      // Vue 会将颜色转换为 RGB 格式
      expect(tagElement.attributes('style')).toContain('rgb(114, 50, 221)');
    });

    it('应该支持自定义文本颜色', () => {
      const color = '#ffe1e1';
      const textColor = '#ad0000';
      const wrapper = createTagWrapper({ color, textColor });
      const tagElement = wrapper.find('.ht-tag');

      expect(tagElement.exists()).toBe(true);
      const style = tagElement.attributes('style');
      expect(style).toContain('color');
      expect(style).toContain('rgb(173, 0, 0)');
    });

    it('朴素样式时应该应用边框颜色', () => {
      const color = '#1677ff';
      const wrapper = createTagWrapper({ color, plain: true });
      const tagElement = wrapper.find('.ht-tag');

      expect(tagElement.exists()).toBe(true);
      const style = tagElement.attributes('style');
      expect(style).toContain('border-color');
      expect(style).toContain('rgb(22, 119, 255)');
    });
  });

  describe('过渡动画', () => {
    it('应该应用过渡动画类名', () => {
      const wrapper = createTagWrapper();
      expect(wrapper.find('transition-stub').exists()).toBe(true);
    });

    it('切换显示状态时应该触发过渡', async () => {
      const wrapper = createTagWrapper({ show: true });
      expectTagToBeVisible(wrapper);

      await wrapper.setProps({ show: false });
      await waitForTransition(wrapper);
      expectTagToBeHidden(wrapper);
    });
  });

  describe('边界情况', () => {
    it('应该处理空内容', () => {
      const wrapper = createTagWrapper({}, '');
      expect(wrapper.text()).toBe('');
      expectTagToBeVisible(wrapper);
    });

    it('应该处理空白内容', () => {
      const wrapper = createTagWrapper({}, '   ');
      expect(wrapper.text().trim()).toBe('');
      expectTagToBeVisible(wrapper);
    });

    it('应该处理长文本内容', () => {
      const longText = '这是一个非常长的标签文本内容，用来测试标签在处理长文本时的表现';
      const wrapper = createTagWrapper({}, longText);
      expect(wrapper.text()).toBe(longText);
      expectTagToBeVisible(wrapper);
    });

    it('应该处理特殊字符内容', () => {
      const specialText = '特殊字符: <>&"\'';
      const wrapper = createTagWrapper({}, specialText);
      expect(wrapper.text()).toBe(specialText);
      expectTagToBeVisible(wrapper);
    });

    it('应该处理换行符内容', () => {
      const multilineText = '第一行\n第二行';
      const wrapper = createTagWrapper({}, multilineText);
      // HTML 会将换行符转换为空格
      expect(wrapper.text()).toBe('第一行 第二行');
      expectTagToBeVisible(wrapper);
    });
  });

  describe('响应式更新', () => {
    it('动态改变类型应该正确更新样式', async () => {
      const wrapper = createTagWrapper({ type: 'primary' });
      expectTagToHaveClasses(wrapper, 'ht-tag--primary');

      await wrapper.setProps({ type: 'success' });
      expectTagToHaveClasses(wrapper, 'ht-tag--success');
      expect(wrapper.find('.ht-tag--primary').exists()).toBe(false);
    });

    it('动态改变尺寸应该正确更新样式', async () => {
      const wrapper = createTagWrapper({ size: 'small' });
      expectTagToHaveClasses(wrapper, 'ht-tag--small');

      await wrapper.setProps({ size: 'large' });
      expectTagToHaveClasses(wrapper, 'ht-tag--large');
      expect(wrapper.find('.ht-tag--small').exists()).toBe(false);
    });

    it('动态改变样式变体应该正确更新', async () => {
      const wrapper = createTagWrapper({ plain: false, round: false });
      expect(wrapper.find('.ht-tag--plain').exists()).toBe(false);
      expect(wrapper.find('.ht-tag--round').exists()).toBe(false);

      await wrapper.setProps({ plain: true, round: true });
      expectTagToHaveClasses(wrapper, 'ht-tag--plain');
      expectTagToHaveClasses(wrapper, 'ht-tag--round');
    });

    it('动态改变颜色应该正确更新样式', async () => {
      const initialColor = '#1677ff';
      const newColor = '#52c41a';
      const wrapper = createTagWrapper({ color: initialColor });

      let tagElement = wrapper.find('.ht-tag');
      expect(tagElement.attributes('style')).toContain('background: rgb(22, 119, 255)');

      await wrapper.setProps({ color: newColor });
      tagElement = wrapper.find('.ht-tag');
      expect(tagElement.attributes('style')).toContain('background: rgb(82, 196, 26)');
      expect(tagElement.attributes('style')).not.toContain('rgb(22, 119, 255)');
    });
  });

  describe('可访问性', () => {
    it('应该渲染可访问的 HTML 结构', () => {
      const wrapper = createTagWrapper({}, '测试标签');
      const tagElement = wrapper.find('.ht-tag');

      expect(tagElement.exists()).toBe(true);
      expect(tagElement.element.tagName.toLowerCase()).toBe('div');
      expect(tagElement.text()).toBe('测试标签');
    });

    it('应该支持关闭按钮的键盘访问', () => {
      const wrapper = createTagWrapper({ closeable: true });
      const closeButton = wrapper.find('.ht-tag__close');

      expect(closeButton.exists()).toBe(true);
      // 关闭按钮应该可以响应键盘事件
      expect(() => {
        closeButton.trigger('keydown.enter');
        closeButton.trigger('keydown.space');
      }).not.toThrow();
    });
  });
});
