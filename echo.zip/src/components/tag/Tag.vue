<script setup lang="ts">
import { computed, type CSSProperties } from 'vue';
import { Primitive } from 'reka-ui';
import { HTIcon } from '@/components/icon';
import { cn } from '@/utils';
import type { TagEmits, TagProps } from './types';
import './style/tag.css';

const props = withDefaults(defineProps<TagProps>(), {
  type: 'default',
  show: true,
  plain: false,
  round: false,
  mark: false,
  closeable: false,
  as: 'div',
  asChild: false,
});

const emit = defineEmits<TagEmits>();

const onClose = (event: MouseEvent) => {
  event.stopPropagation();
  emit('close', event);
};

const getStyle = computed((): CSSProperties => {
  if (props.plain) {
    return {
      color: props.textColor || props.color,
      background: 'transparent',
      borderColor: props.color,
    };
  }
  return {
    color: props.textColor,
    background: props.color,
  };
});

const classes = computed(() => {
  return cn('ht-tag', `ht-tag--${props.type}`, {
    'ht-tag--plain': props.plain,
    'ht-tag--round': props.round,
    'ht-tag--mark': props.mark,
    'ht-tag--large': props.size === 'large',
    'ht-tag--small': props.size === 'small',
  });
});

// Primitive 属性
const primitiveProps = computed(() => {
  const attrs: Record<string, any> = {
    as: props.as,
    asChild: props.asChild,
    class: classes.value,
    style: getStyle.value,
  };

  // 只添加已定义的属性
  if (props.tabindex !== undefined) attrs.tabindex = props.tabindex;
  if (props.role !== undefined) attrs.role = props.role;
  if (props['aria-label'] !== undefined) attrs['aria-label'] = props['aria-label'];
  if (props['aria-live'] !== undefined) attrs['aria-live'] = props['aria-live'];
  if (props['aria-atomic'] !== undefined) attrs['aria-atomic'] = props['aria-atomic'];
  if (props['aria-describedby'] !== undefined) attrs['aria-describedby'] = props['aria-describedby'];
  if (props['aria-labelledby'] !== undefined) attrs['aria-labelledby'] = props['aria-labelledby'];

  return attrs;
});
</script>

<template>
  <Transition name="ht-fade">
    <Primitive v-if="show" v-bind="{ ...primitiveProps, ...$attrs }">
      <slot />
      <HTIcon v-if="closeable" name="cross" class="ht-tag__close" @click="onClose" />
    </Primitive>
  </Transition>
</template>
