export type PinInputType = 'text' | 'number';

export type PinInputDir = 'ltr' | 'rtl';

export interface PinInputProps {
  defaultValue?: string[];
  modelValue?: string[] | null;
  dir?: PinInputDir;
  invalid?: boolean;
  disabled?: boolean;
  length?: number;
  separator?: string;
  autoFocus?: boolean;
  placeholder?: string;
  mask?: boolean;
  type?: PinInputType;
  size?: number | string;
}

export interface PinInputEmits {
  'update:modelValue': [value: string[]];
  complete: [value: string[]];
}

export interface PinInputExpose {
  focus: (index?: number) => void;
  blur: () => void;
  clear: () => void;
}
