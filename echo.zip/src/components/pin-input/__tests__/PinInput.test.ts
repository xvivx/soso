import { nextTick } from 'vue';
import { screen } from '@testing-library/vue';
import { mount } from '@vue/test-utils';
import { beforeEach, describe, expect, it } from 'vitest';
import HTPinInput from '../PinInput.vue';
import type { PinInputExpose } from '../types';

describe('HTPinInput', () => {
  beforeEach(() => {
    document.body.innerHTML = '';
  });

  describe('基础渲染', () => {
    it('应该根据 length 渲染对应数量的输入框', () => {
      const wrapper = mount(HTPinInput, {
        props: {
          length: 6,
        },
        attachTo: document.body,
      });

      const inputs = wrapper.element.querySelectorAll('.ht-pin-input__input');
      expect(inputs.length).toBe(6);

      wrapper.unmount();
    });

    it('应该渲染分隔符', () => {
      const wrapper = mount(HTPinInput, {
        props: {
          length: 4,
          separator: '-',
        },
        attachTo: document.body,
      });

      const separators = wrapper.element.querySelectorAll('.ht-pin-input__separator');
      expect(separators.length).toBe(3);
      separators.forEach((sep: Element) => {
        expect(sep.textContent).toBe('-');
      });

      wrapper.unmount();
    });

    it('没有分隔符时不应该渲染分隔符元素', () => {
      const wrapper = mount(HTPinInput, {
        props: {
          length: 4,
        },
        attachTo: document.body,
      });

      const separators = wrapper.element.querySelectorAll('.ht-pin-input__separator');
      expect(separators.length).toBe(0);

      wrapper.unmount();
    });
  });

  describe('输入类型', () => {
    it('应该支持 text 类型', () => {
      const wrapper = mount(HTPinInput, {
        props: {
          type: 'text',
          length: 4,
        },
        attachTo: document.body,
      });

      const inputs = wrapper.element.querySelectorAll('.ht-pin-input__input');
      inputs.forEach((input: Element) => {
        const inputEl = input as HTMLInputElement;
        expect(inputEl.getAttribute('type')).toBe('text');
      });

      wrapper.unmount();
    });

    it('应该支持 number 类型', () => {
      const wrapper = mount(HTPinInput, {
        props: {
          type: 'number',
          length: 4,
        },
        attachTo: document.body,
      });

      const inputs = wrapper.element.querySelectorAll('.ht-pin-input__input');
      inputs.forEach((input: Element) => {
        const inputEl = input as HTMLInputElement;
        expect(inputEl.getAttribute('inputmode')).toBe('numeric');
      });

      wrapper.unmount();
    });
  });

  describe('禁用状态', () => {
    it('应该支持禁用', () => {
      const wrapper = mount(HTPinInput, {
        props: {
          length: 4,
          disabled: true,
        },
        attachTo: document.body,
      });

      const inputs = wrapper.element.querySelectorAll('.ht-pin-input__input');
      inputs.forEach((input: Element) => {
        expect((input as HTMLInputElement).disabled).toBe(true);
      });

      wrapper.unmount();
    });
  });

  describe('验证状态', () => {
    it('应该支持 invalid 状态', () => {
      const wrapper = mount(HTPinInput, {
        props: {
          length: 4,
          invalid: true,
        },
        attachTo: document.body,
      });

      // invalid 类直接在根元素上
      expect(wrapper.element.classList.contains('ht-pin-input--invalid')).toBe(true);

      wrapper.unmount();
    });
  });

  describe('自动聚焦', () => {
    it('应该支持 autoFocus', async () => {
      const wrapper = mount(HTPinInput, {
        props: {
          length: 4,
          autoFocus: true,
        },
        attachTo: document.body,
      });

      await nextTick();
      await new Promise((resolve) => setTimeout(resolve, 10));

      const firstInput = screen.getByLabelText('Pin input 1 of 4') as HTMLInputElement;

      expect(firstInput).toBeTruthy();
      expect(document.activeElement).toBe(firstInput);

      wrapper.unmount();
    });
  });

  describe('占位符', () => {
    it('应该支持自定义占位符', () => {
      const wrapper = mount(HTPinInput, {
        props: {
          length: 4,
          placeholder: '•',
        },
        attachTo: document.body,
      });

      const inputs = wrapper.element.querySelectorAll('.ht-pin-input__input');
      inputs.forEach((input: Element) => {
        expect((input as HTMLInputElement).placeholder).toBe('•');
      });

      wrapper.unmount();
    });
  });

  describe('方向', () => {
    it('应该支持 rtl 方向', () => {
      const wrapper = mount(HTPinInput, {
        props: {
          length: 4,
          dir: 'rtl',
        },
        attachTo: document.body,
      });

      expect(wrapper.element.getAttribute('dir')).toBe('rtl');

      wrapper.unmount();
    });
  });

  describe('掩码', () => {
    it('应该支持掩码模式隐藏输入内容', async () => {
      const wrapper = mount(HTPinInput, {
        props: {
          length: 4,
          mask: true,
          modelValue: ['1', '2', '3', '4'],
        },
        attachTo: document.body,
      });

      await nextTick();

      const inputs = wrapper.element.querySelectorAll('.ht-pin-input__input');
      inputs.forEach((input: Element) => {
        const inputEl = input as HTMLInputElement;
        expect(inputEl.type === 'password' || inputEl.getAttribute('type') === 'password').toBeTruthy();
      });

      wrapper.unmount();
    });
  });

  describe('尺寸', () => {
    it('应该支持数字尺寸（像素）', () => {
      const wrapper = mount(HTPinInput, {
        props: {
          length: 4,
          size: 60,
        },
        attachTo: document.body,
      });

      const input = wrapper.element.querySelector('.ht-pin-input__input') as HTMLElement;
      expect(input).toBeTruthy();
      expect(input.style.width).toBe('60px');
      expect(input.style.height).toBe('60px');

      wrapper.unmount();
    });

    it('应该支持字符串尺寸', () => {
      const wrapper = mount(HTPinInput, {
        props: {
          length: 4,
          size: '3rem',
        },
        attachTo: document.body,
      });

      const input = wrapper.element.querySelector('.ht-pin-input__input') as HTMLElement;
      expect(input).toBeTruthy();
      expect(input.style.width).toBe('3rem');
      expect(input.style.height).toBe('3rem');

      wrapper.unmount();
    });
  });

  describe('v-model', () => {
    it('应该支持 v-model 绑定值', async () => {
      const wrapper = mount(HTPinInput, {
        props: {
          length: 4,
          modelValue: ['1', '2', '3', '4'],
        },
        attachTo: document.body,
      });

      await nextTick();

      const inputs = wrapper.element.querySelectorAll('.ht-pin-input__input');
      expect((inputs[0] as HTMLInputElement).value).toBe('1');
      expect((inputs[1] as HTMLInputElement).value).toBe('2');
      expect((inputs[2] as HTMLInputElement).value).toBe('3');
      expect((inputs[3] as HTMLInputElement).value).toBe('4');

      wrapper.unmount();
    });

    it('应该处理部分填充的值', async () => {
      const wrapper = mount(HTPinInput, {
        props: {
          length: 4,
          modelValue: ['1', '2'],
        },
        attachTo: document.body,
      });

      await nextTick();

      const inputs = wrapper.element.querySelectorAll('.ht-pin-input__input');
      expect((inputs[0] as HTMLInputElement).value).toBe('1');
      expect((inputs[1] as HTMLInputElement).value).toBe('2');
      expect((inputs[2] as HTMLInputElement).value).toBe('');
      expect((inputs[3] as HTMLInputElement).value).toBe('');

      wrapper.unmount();
    });
  });

  describe('实例方法', () => {
    it('focus 方法应该聚焦到指定输入框', async () => {
      const wrapper = mount(HTPinInput, {
        props: {
          length: 4,
        },
        attachTo: document.body,
      });

      await nextTick();

      const instance = wrapper.vm as unknown as PinInputExpose;

      instance.focus(1);
      await nextTick();
      await new Promise((resolve) => setTimeout(resolve, 10));

      const secondInput = screen.getByLabelText('Pin input 2 of 4') as HTMLInputElement;
      expect(document.activeElement).toBe(secondInput);

      wrapper.unmount();
    });

    it('focus 方法默认聚焦到第一个输入框', async () => {
      const wrapper = mount(HTPinInput, {
        props: {
          length: 4,
        },
        attachTo: document.body,
      });

      await nextTick();

      const instance = wrapper.vm as unknown as PinInputExpose;

      instance.focus();
      await nextTick();
      await new Promise((resolve) => setTimeout(resolve, 10));

      const firstInput = screen.getByLabelText('Pin input 1 of 4') as HTMLInputElement;
      expect(document.activeElement).toBe(firstInput);

      wrapper.unmount();
    });

    it('blur 方法应该失焦所有输入框', async () => {
      const wrapper = mount(HTPinInput, {
        props: {
          length: 4,
        },
        attachTo: document.body,
      });

      await nextTick();

      const instance = wrapper.vm as unknown as PinInputExpose;

      instance.focus(0);
      await nextTick();
      await new Promise((resolve) => setTimeout(resolve, 10));

      const firstInput = screen.getByLabelText('Pin input 1 of 4') as HTMLInputElement;
      expect(document.activeElement).toBe(firstInput);

      instance.blur();
      await nextTick();

      expect(document.activeElement).not.toBe(firstInput);

      wrapper.unmount();
    });

    it('clear 方法应该清空所有输入并聚焦到第一个输入框', async () => {
      const wrapper = mount(HTPinInput, {
        props: {
          length: 4,
          modelValue: ['1', '2', '3', '4'],
        },
        attachTo: document.body,
      });

      await nextTick();

      const instance = wrapper.vm as unknown as PinInputExpose;

      instance.clear();
      await nextTick();
      await new Promise((resolve) => setTimeout(resolve, 10));

      const inputs = wrapper.element.querySelectorAll('.ht-pin-input__input');
      inputs.forEach((input: Element) => {
        expect((input as HTMLInputElement).value).toBe('');
      });

      const firstInput = screen.getByLabelText('Pin input 1 of 4') as HTMLInputElement;
      expect(document.activeElement).toBe(firstInput);

      wrapper.unmount();
    });
  });

  describe('边界情况', () => {
    it('应该处理空值', () => {
      const wrapper = mount(HTPinInput, {
        props: {
          length: 4,
          modelValue: null,
        },
        attachTo: document.body,
      });

      const inputs = wrapper.element.querySelectorAll('.ht-pin-input__input');
      inputs.forEach((input: Element) => {
        expect((input as HTMLInputElement).value).toBe('');
      });

      wrapper.unmount();
    });
  });
});
