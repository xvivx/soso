<script setup lang="ts">
import { computed, nextTick, onMounted, ref, watch } from 'vue';
import { PinInputInput, PinInputRoot } from 'reka-ui';
import { addUnit, cn } from '@/utils/index';
import { useCustomFieldValue } from '@/hooks';
import type { PinInputEmits, PinInputExpose, PinInputProps } from './types';

const props = withDefaults(defineProps<PinInputProps>(), {
  invalid: false,
  disabled: false,
  length: 4,
  autoFocus: false,
  placeholder: '',
  mask: false,
  type: 'text',
  dir: 'ltr',
  separator: '',
});

const emit = defineEmits<PinInputEmits>();

const model = defineModel<string[] | null>('modelValue');

useCustomFieldValue(() => model.value);

// 输入框引用数组
const inputRefs = ref<InstanceType<typeof PinInputInput>[]>([]);
// 当前聚焦的输入框索引
const focusedIndex = ref<number>(-1);

// 创建空数组
const createEmptyArray = () => Array(props.length).fill('');

// 计算输入框尺寸
const inputSize = computed(() => addUnit(props.size));

// 内部值状态
const internalValue = ref<string[]>(props.defaultValue || createEmptyArray());

// 同步 modelValue 和 internalValue
watch(
  () => model.value,
  (newValue) => {
    internalValue.value = newValue ? [...newValue] : createEmptyArray();
  },
  { immediate: true }
);

// 设置输入框引用
const setInputRef = (el: any, index: number) => {
  if (el) {
    inputRefs.value[index] = el;
  }
};

// 获取输入框 DOM 元素
const getInputElement = (index: number): HTMLInputElement | null => {
  return inputRefs.value[index]?.$el as HTMLInputElement | null;
};

// 聚焦到指定输入框
const focusInput = (index: number) => {
  if (index >= 0 && index < props.length && inputRefs.value[index]) {
    nextTick(() => {
      getInputElement(index)?.focus();
    });
  }
};

// 失焦所有输入框
const blurAll = () => {
  inputRefs.value.forEach((_, index) => {
    getInputElement(index)?.blur();
  });
};

// 清空所有输入
const clear = () => {
  model.value = createEmptyArray();
  nextTick(() => focusInput(0));
};

// 处理聚焦事件
const handleFocus = (index: number) => {
  focusedIndex.value = index;
  // 选中当前输入框的内容
  nextTick(() => getInputElement(index)?.select());
};

// 处理失焦事件
const handleBlur = () => {
  focusedIndex.value = -1;
};

// 处理点击事件
const handleClick = (index: number) => {
  if (!props.disabled) {
    focusInput(index);
  }
};

// 自动聚焦
onMounted(() => {
  if (props.autoFocus) {
    nextTick(() => focusInput(0));
  }
});

// 暴露方法
defineExpose<PinInputExpose>({
  focus: (index = 0) => focusInput(index),
  blur: blurAll,
  clear,
});
</script>

<template>
  <PinInputRoot
    v-model="internalValue"
    :disabled="disabled"
    :dir="dir"
    :type="type"
    :mask="mask"
    :class="
      cn('ht-pin-input relative inline-flex items-center', {
        'ht-pin-input--invalid': invalid,
      })
    "
    @complete="(value) => emit('complete', value)"
  >
    <template v-for="(_, index) in length" :key="index">
      <PinInputInput
        :ref="(el) => setInputRef(el, index)"
        :index="index"
        :disabled="disabled"
        :placeholder="placeholder"
        :aria-label="`Pin input ${index + 1} of ${length}`"
        :class="
          cn(
            'ht-pin-input__input flex-1 border border-solid bg-white text-center text-black transition-all outline-none',
            {
              'ht-pin-input__input--focused': focusedIndex === index,
            }
          )
        "
        :style="inputSize ? { width: inputSize, height: inputSize } : undefined"
        @focus="handleFocus(index)"
        @blur="handleBlur"
        @click="handleClick(index)"
      />
      <span
        v-if="separator && index < length - 1"
        class="ht-pin-input__separator inline-flex items-center justify-center text-gray-500 select-none"
      >
        {{ separator }}
      </span>
    </template>
  </PinInputRoot>
</template>

<style>
:root {
  --pin-input-gap-default: var(--dimensions-spacing-stack-smd); /* 输入框默认间距 */
  --pin-input-size-default: 48px; /* 单个输入框默认尺寸 */
  --pin-input-border-radius-default: var(--radius-md); /* 输入框圆角 */
  --pin-input-font-size-default: var(--font-size-md); /* 输入框字体大小 */
  --pin-input-border-color-default: var(--color-border-default); /* 默认边框颜色 */
  --pin-input-border-color-hover: var(--color-brand-border); /* hover 时的边框颜色 */
  --pin-input-border-color-focus: var(--color-brand-border); /* 聚焦时的边框颜色 */
  --pin-input-border-color-invalid: var(--color-feedback-error-border); /* 验证失败时的边框颜色 */
  --pin-input-bg-color-invalid: var(--color-feedback-error-background-subtle); /* 验证失败时的输入框背景色 */
  --pin-input-color-invalid: var(--color-feedback-error-content); /* 验证失败时的输入文字颜色 */
  --pin-input-bg-color-disabled: var(--color-surface-primary); /* 禁用态输入框背景色 */
  --pin-input-border-color-disabled: var(--color-border-disabled); /* 禁用态边框颜色 */
  --pin-input-color-disabled: var(--color-content-disabled); /* 禁用态输入文字颜色 */
  --pin-input-caret-color-default: var(--pin-input-border-color-focus); /* 光标颜色 */
}

@layer components {
  .ht-pin-input {
    gap: var(--pin-input-gap-default);
  }

  .ht-pin-input__input {
    width: var(--pin-input-size-default);
    height: var(--pin-input-size-default);
    font-size: var(--pin-input-font-size-default);
    border-radius: var(--pin-input-border-radius-default);
    border-color: var(--pin-input-border-color-default);
    caret-color: var(--pin-input-caret-color-default);
  }

  .ht-pin-input__input:hover:not(:disabled) {
    border-color: var(--pin-input-border-color-hover);
  }

  .ht-pin-input__input--focused {
    border-color: var(--pin-input-border-color-focus);
  }

  .ht-pin-input__input:disabled {
    background-color: var(--pin-input-bg-color-disabled);
    color: var(--pin-input-color-disabled);
    cursor: not-allowed;
  }

  .ht-pin-input__separator {
    font-size: var(--pin-input-font-size-default);
  }

  /* Invalid 状态 */
  .ht-pin-input--invalid .ht-pin-input__input {
    border-color: var(--pin-input-border-color-invalid);
  }

  .ht-pin-input--invalid .ht-pin-input__input--focused {
    box-shadow: 0 0 0 2px rgba(255, 77, 79, 0.1);
  }

  /* Invalid 背景色（当非禁用时生效） */
  .ht-pin-input--invalid .ht-pin-input__input:not(:disabled) {
    background-color: var(--pin-input-bg-color-invalid);
    color: var(--pin-input-color-invalid);
  }
}
</style>
