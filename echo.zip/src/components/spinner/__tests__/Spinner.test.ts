import { screen } from '@testing-library/vue';
import { beforeEach, describe, expect, it } from 'vitest';
import { renderWithMounting } from '../../../../test/utils';
import HTSpinner from '../Spinner.vue';

describe('HTSpinner', () => {
  beforeEach(() => {
    // 清理 DOM
    document.body.innerHTML = '';
  });

  describe('基础渲染', () => {
    it('应该正确渲染默认的 Spinner', () => {
      renderWithMounting(HTSpinner);

      const spinner = screen.getByTestId('loader-icon');
      expect(spinner).toBeInTheDocument();
      expect(spinner).toHaveAttribute('role', 'status');
      expect(spinner).toHaveAttribute('aria-label', 'Loading');
      expect(spinner).toHaveClass('size-4');
      expect(spinner).toHaveClass('animate-spin');
    });

    it('应该渲染 Lucide Loader2 图标', () => {
      renderWithMounting(HTSpinner);

      const loaderIcon = screen.getByTestId('loader-icon');
      expect(loaderIcon).toBeInTheDocument();
    });
  });

  describe('自定义样式', () => {
    it('应该支持自定义 CSS 类名', () => {
      renderWithMounting(HTSpinner, {
        props: {
          class: 'custom-spinner-class',
        },
      });

      const spinner = screen.getByTestId('loader-icon');
      expect(spinner).toHaveClass('custom-spinner-class');
      expect(spinner).toHaveClass('size-4');
      expect(spinner).toHaveClass('animate-spin');
    });

    it('应该支持多个自定义类名', () => {
      renderWithMounting(HTSpinner, {
        props: {
          class: 'custom-class-1 custom-class-2 custom-class-3',
        },
      });

      const spinner = screen.getByTestId('loader-icon');
      expect(spinner).toHaveClass('custom-class-1');
      expect(spinner).toHaveClass('custom-class-2');
      expect(spinner).toHaveClass('custom-class-3');
      expect(spinner).toHaveClass('size-4');
      expect(spinner).toHaveClass('animate-spin');
    });

    it('应该支持 Tailwind CSS 类名', () => {
      renderWithMounting(HTSpinner, {
        props: {
          class: 'w-8 h-8 text-blue-500',
        },
      });

      const spinner = screen.getByTestId('loader-icon');
      expect(spinner).toHaveClass('w-8');
      expect(spinner).toHaveClass('h-8');
      expect(spinner).toHaveClass('text-blue-500');
      expect(spinner).toHaveClass('size-4');
      expect(spinner).toHaveClass('animate-spin');
    });

    it('应该支持覆盖默认类名', () => {
      renderWithMounting(HTSpinner, {
        props: {
          class: 'size-8 animate-pulse',
        },
      });

      const spinner = screen.getByTestId('loader-icon');
      expect(spinner).toHaveClass('size-8');
      expect(spinner).toHaveClass('animate-pulse');
    });
  });

  describe('尺寸变体', () => {
    it('应该支持不同的尺寸类名', () => {
      const sizes = [
        { class: 'size-2', expectedSize: 'size-2' },
        { class: 'size-4', expectedSize: 'size-4' },
        { class: 'size-6', expectedSize: 'size-6' },
        { class: 'size-8', expectedSize: 'size-8' },
        { class: 'w-12 h-12', expectedSize: 'w-12 h-12' },
      ];

      sizes.forEach(({ class: sizeClass, expectedSize }) => {
        const { unmount } = renderWithMounting(HTSpinner, {
          props: {
            class: sizeClass,
          },
        });

        const spinner = screen.getByTestId('loader-icon');
        expect(spinner).toHaveClass(expectedSize);
        unmount();
      });
    });
  });

  describe('动画效果', () => {
    it('应该有旋转动画', () => {
      renderWithMounting(HTSpinner);

      const spinner = screen.getByTestId('loader-icon');
      expect(spinner).toHaveClass('animate-spin');
    });

    it('应该支持自定义动画类', () => {
      renderWithMounting(HTSpinner, {
        props: {
          class: 'animate-pulse',
        },
      });

      const spinner = screen.getByTestId('loader-icon');
      expect(spinner).toHaveClass('animate-pulse');
    });

    it('应该支持停止动画', () => {
      renderWithMounting(HTSpinner, {
        props: {
          class: 'animate-none',
        },
      });

      const spinner = screen.getByTestId('loader-icon');
      expect(spinner).toHaveClass('animate-none');
    });
  });

  describe('可访问性', () => {
    it('应该有正确的 role 属性', () => {
      renderWithMounting(HTSpinner);

      const spinner = screen.getByTestId('loader-icon');
      expect(spinner).toHaveAttribute('role', 'status');
    });

    it('应该有正确的 aria-label 属性', () => {
      renderWithMounting(HTSpinner);

      const spinner = screen.getByTestId('loader-icon');
      expect(spinner).toHaveAttribute('aria-label', 'Loading');
    });

    it('应该支持自定义 aria-label', () => {
      renderWithMounting(HTSpinner, {
        attrs: {
          'aria-label': '正在加载中...',
        },
      });

      const spinner = screen.getByTestId('loader-icon');
      expect(spinner).toHaveAttribute('aria-label', '正在加载中...');
    });

    it('应该支持其他 ARIA 属性', () => {
      renderWithMounting(HTSpinner, {
        attrs: {
          'aria-live': 'polite',
          'aria-busy': 'true',
          'aria-describedby': 'loading-description',
        },
      });

      const spinner = screen.getByTestId('loader-icon');
      expect(spinner).toHaveAttribute('aria-live', 'polite');
      expect(spinner).toHaveAttribute('aria-busy', 'true');
      expect(spinner).toHaveAttribute('aria-describedby', 'loading-description');
    });
  });

  describe('属性传递', () => {
    it('应该正确传递所有属性到图标组件', () => {
      renderWithMounting(HTSpinner, {
        attrs: {
          'data-testid': 'custom-spinner',
          'id': 'my-spinner',
          'title': 'Loading Spinner',
          'tabindex': '0',
        },
      });

      const spinner = screen.getByTestId('custom-spinner');
      expect(spinner).toHaveAttribute('id', 'my-spinner');
      expect(spinner).toHaveAttribute('title', 'Loading Spinner');
      expect(spinner).toHaveAttribute('tabindex', '0');
    });

    it('应该支持事件处理器', () => {
      const handleClick = vi.fn();
      const handleMouseEnter = vi.fn();

      renderWithMounting(HTSpinner, {
        attrs: {
          onClick: handleClick,
          onMouseenter: handleMouseEnter,
        },
      });

      const spinner = screen.getByTestId('loader-icon');

      // 由于使用的是模拟组件，这里只测试属性是否传递
      expect(spinner).toBeInTheDocument();
    });
  });

  describe('样式组合', () => {
    it('应该支持颜色和尺寸的组合', () => {
      renderWithMounting(HTSpinner, {
        props: {
          class: 'size-8 text-blue-500 bg-white border border-gray-200 rounded-full',
        },
      });

      const spinner = screen.getByTestId('loader-icon');
      expect(spinner).toHaveClass('size-8');
      expect(spinner).toHaveClass('text-blue-500');
      expect(spinner).toHaveClass('bg-white');
      expect(spinner).toHaveClass('border');
      expect(spinner).toHaveClass('border-gray-200');
      expect(spinner).toHaveClass('rounded-full');
    });

    it('应该支持定位类名', () => {
      renderWithMounting(HTSpinner, {
        props: {
          class: 'absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2',
        },
      });

      const spinner = screen.getByTestId('loader-icon');
      expect(spinner).toHaveClass('absolute');
      expect(spinner).toHaveClass('top-1/2');
      expect(spinner).toHaveClass('left-1/2');
      expect(spinner).toHaveClass('transform');
      expect(spinner).toHaveClass('-translate-x-1/2');
      expect(spinner).toHaveClass('-translate-y-1/2');
    });
  });

  describe('响应式设计', () => {
    it('应该支持响应式类名', () => {
      renderWithMounting(HTSpinner, {
        props: {
          class: 'size-4 md:size-6 lg:size-8',
        },
      });

      const spinner = screen.getByTestId('loader-icon');
      expect(spinner).toHaveClass('size-4');
      expect(spinner).toHaveClass('md:size-6');
      expect(spinner).toHaveClass('lg:size-8');
    });

    it('应该支持响应式动画', () => {
      renderWithMounting(HTSpinner, {
        props: {
          class: 'animate-spin md:animate-pulse lg:animate-bounce',
        },
      });

      const spinner = screen.getByTestId('loader-icon');
      expect(spinner).toHaveClass('animate-spin');
      expect(spinner).toHaveClass('md:animate-pulse');
      expect(spinner).toHaveClass('lg:animate-bounce');
    });
  });

  describe('边界情况', () => {
    it('应该处理空的 class 属性', () => {
      renderWithMounting(HTSpinner, {
        props: {
          class: '',
        },
      });

      const spinner = screen.getByTestId('loader-icon');
      expect(spinner).toBeInTheDocument();
      expect(spinner).toHaveClass('size-4');
      expect(spinner).toHaveClass('animate-spin');
    });

    it('应该处理 null 或 undefined 的 class 属性', () => {
      const { unmount } = renderWithMounting(HTSpinner, {
        props: {
          class: null as unknown as string,
        },
      });

      const spinner = screen.getByTestId('loader-icon');
      expect(spinner).toBeInTheDocument();
      unmount();

      renderWithMounting(HTSpinner, {
        props: {
          class: undefined as unknown as string,
        },
      });

      const spinner2 = screen.getByTestId('loader-icon');
      expect(spinner2).toBeInTheDocument();
    });

    it('应该处理重复的类名', () => {
      renderWithMounting(HTSpinner, {
        props: {
          class: 'size-4 animate-spin size-4',
        },
      });

      const spinner = screen.getByTestId('loader-icon');
      expect(spinner).toBeInTheDocument();
      expect(spinner).toHaveClass('size-4');
      expect(spinner).toHaveClass('animate-spin');
    });
  });

  describe('性能考虑', () => {
    it('应该快速渲染', () => {
      const startTime = performance.now();

      for (let i = 0; i < 100; i++) {
        const { unmount } = renderWithMounting(HTSpinner);
        unmount();
      }

      const endTime = performance.now();
      const renderTime = endTime - startTime;

      // 100次渲染应该在合理时间内完成（这里设置为1秒）
      expect(renderTime).toBeLessThan(1000);
    });

    it('应该支持多个 Spinner 同时渲染', () => {
      const spinners = [];

      for (let i = 0; i < 10; i++) {
        const { container } = renderWithMounting(HTSpinner, {
          attrs: {
            'data-testid': `spinner-${i}`,
          },
        });
        spinners.push(container);
      }

      // 验证所有 Spinner 都正确渲染
      for (let i = 0; i < 10; i++) {
        const spinner = screen.getByTestId(`spinner-${i}`);
        expect(spinner).toBeInTheDocument();
      }
    });
  });
});
