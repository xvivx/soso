import { nextTick } from 'vue';
import { fireEvent, screen } from '@testing-library/vue';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { renderWithMounting } from '../../../../test/utils';
import HTTooltip from '../Tooltip.vue';

// Mock createPopper
vi.mock('@popperjs/core', () => ({
  createPopper: vi.fn(() => ({
    update: vi.fn(),
    destroy: vi.fn(),
    setOptions: vi.fn(),
  })),
}));

describe('HTTooltip', () => {
  beforeEach(() => {
    document.body.innerHTML = '';
    vi.clearAllTimers();
    vi.useFakeTimers();
  });

  afterEach(() => {
    vi.useRealTimers();
  });

  describe('基础渲染', () => {
    it('应该正确渲染触发器', () => {
      const { container } = renderWithMounting(HTTooltip, {
        props: {
          content: 'Tooltip content',
        },
        slots: {
          default: '<button>Trigger</button>',
        },
      });

      const trigger = screen.getByText('Trigger');
      expect(trigger).toBeInTheDocument();

      const tooltip = container.querySelector('.ht-tooltip');
      expect(tooltip).toBeInTheDocument();
    });

    it('应该渲染触发器插槽内容', () => {
      renderWithMounting(HTTooltip, {
        props: {
          content: 'Tooltip content',
        },
        slots: {
          default: '<div class="custom-trigger">Custom Trigger</div>',
        },
      });

      const trigger = screen.getByText('Custom Trigger');
      expect(trigger).toBeInTheDocument();
    });
  });

  describe('内容显示', () => {
    it('应该显示文本内容', async () => {
      renderWithMounting(HTTooltip, {
        props: {
          content: 'Tooltip text content',
          visible: true,
        },
        slots: {
          default: '<button>Trigger</button>',
        },
      });

      await nextTick();
      const content = screen.getByText('Tooltip text content');
      expect(content).toBeInTheDocument();
    });

    it('应该显示插槽内容', async () => {
      renderWithMounting(HTTooltip, {
        props: {
          visible: true,
        },
        slots: {
          default: '<button>Trigger</button>',
          content: '<div class="custom-content">Custom Content</div>',
        },
      });

      await nextTick();
      const content = screen.getByText('Custom Content');
      expect(content).toBeInTheDocument();
    });
  });

  describe('位置设置', () => {
    const placements = [
      'top',
      'top-start',
      'top-end',
      'bottom',
      'bottom-start',
      'bottom-end',
      'left',
      'left-start',
      'left-end',
      'right',
      'right-start',
      'right-end',
    ] as const;

    it.each(placements)('应该支持 %s 位置', async (placement) => {
      renderWithMounting(HTTooltip, {
        props: {
          content: 'Tooltip content',
          placement,
          visible: true,
          appendToBody: false, // 禁用Teleport以便在测试中查找元素
        },
        slots: {
          default: '<button>Trigger</button>',
        },
      });

      await nextTick();
      const popper = screen.getByRole('tooltip');
      expect(popper).toBeInTheDocument();
      expect(popper).toHaveClass(`ht-tooltip__popper--${placement}`);
    });
  });

  describe('主题样式', () => {
    it('应该应用dark主题', async () => {
      renderWithMounting(HTTooltip, {
        props: {
          content: 'Dark tooltip',
          theme: 'dark',
          visible: true,
          appendToBody: false, // 禁用Teleport
        },
        slots: {
          default: '<button>Trigger</button>',
        },
      });

      await nextTick();
      const popper = screen.getByRole('tooltip');
      expect(popper).toHaveClass('ht-tooltip__popper--dark');
    });

    it('应该应用light主题', async () => {
      renderWithMounting(HTTooltip, {
        props: {
          content: 'Light tooltip',
          theme: 'light',
          visible: true,
          appendToBody: false, // 禁用Teleport
        },
        slots: {
          default: '<button>Trigger</button>',
        },
      });

      await nextTick();
      const popper = screen.getByRole('tooltip');
      expect(popper).toHaveClass('ht-tooltip__popper--light');
    });
  });

  describe('触发方式', () => {
    it('应该支持hover触发', async () => {
      renderWithMounting(HTTooltip, {
        props: {
          content: 'Hover tooltip',
          trigger: 'hover',
        },
        slots: {
          default: '<button>Hover me</button>',
        },
      });

      const trigger = screen.getByText('Hover me');
      await fireEvent.mouseEnter(trigger);
      await nextTick();

      const content = screen.getByText('Hover tooltip');
      expect(content).toBeInTheDocument();
    });

    it('应该支持click触发', async () => {
      renderWithMounting(HTTooltip, {
        props: {
          content: 'Click tooltip',
          trigger: 'click',
        },
        slots: {
          default: '<button>Click me</button>',
        },
      });

      const trigger = screen.getByText('Click me');
      await fireEvent.click(trigger);
      await nextTick();

      const content = screen.getByText('Click tooltip');
      expect(content).toBeInTheDocument();
    });

    it('应该支持focus触发', async () => {
      renderWithMounting(HTTooltip, {
        props: {
          content: 'Focus tooltip',
          trigger: 'focus',
        },
        slots: {
          default: '<input placeholder="Focus me" />',
        },
      });

      const trigger = screen.getByPlaceholderText('Focus me');
      await fireEvent.focus(trigger);
      await nextTick();

      const content = screen.getByText('Focus tooltip');
      expect(content).toBeInTheDocument();
    });

    it('应该支持manual触发', async () => {
      renderWithMounting(HTTooltip, {
        props: {
          content: 'Manual tooltip',
          trigger: 'manual',
          visible: true,
        },
        slots: {
          default: '<button>Manual trigger</button>',
        },
      });

      await nextTick();
      const content = screen.getByText('Manual tooltip');
      expect(content).toBeInTheDocument();
    });
  });

  describe('延迟显示/隐藏', () => {
    it('应该支持延迟显示', async () => {
      vi.useFakeTimers();

      const { container } = renderWithMounting(HTTooltip, {
        props: {
          content: 'Delayed tooltip',
          showDelay: 500,
          trigger: 'hover',
          appendToBody: false, // 禁用Teleport
        },
        slots: {
          default: '<button>Hover me</button>',
        },
      });

      // 找到tooltip容器元素
      const tooltipContainer = screen.getByRole('button').parentElement;
      expect(tooltipContainer).toBeTruthy();
      expect(tooltipContainer?.classList.contains('ht-tooltip')).toBe(true);

      // 找到popper元素，检查其可见性
      const popper = container.querySelector('.ht-tooltip__popper');
      expect(popper).toBeInTheDocument();

      // 初始状态下应该是隐藏的（因为defaultVisible为false）
      // 检查元素是否不可见（可能通过opacity或visibility而不是display）
      const computedStyle = window.getComputedStyle(popper!);
      const isHidden =
        computedStyle.display === 'none' ||
        computedStyle.visibility === 'hidden' ||
        computedStyle.opacity === '0' ||
        popper!.style.display === 'none';
      expect(isHidden).toBe(true);

      await fireEvent.mouseEnter(tooltipContainer!);

      // 延迟前仍然应该是隐藏的
      const computedStyleAfterEnter = window.getComputedStyle(popper!);
      const isStillHidden =
        computedStyleAfterEnter.display === 'none' ||
        computedStyleAfterEnter.visibility === 'hidden' ||
        computedStyleAfterEnter.opacity === '0' ||
        popper!.style.display === 'none';
      expect(isStillHidden).toBe(true);

      // 等待延迟时间并执行所有定时器
      vi.advanceTimersByTime(500);
      vi.runAllTimers();
      await nextTick();

      // 现在应该显示了
      const computedStyleAfterDelay = window.getComputedStyle(popper!);
      const isVisible =
        computedStyleAfterDelay.display !== 'none' &&
        computedStyleAfterDelay.visibility !== 'hidden' &&
        computedStyleAfterDelay.opacity !== '0' &&
        popper!.style.display !== 'none';
      expect(isVisible).toBe(true);

      vi.useRealTimers();
    });

    it('应该支持延迟隐藏', async () => {
      vi.useFakeTimers();

      const { emitted } = renderWithMounting(HTTooltip, {
        props: {
          content: 'Hide delayed tooltip',
          trigger: 'hover',
          hideDelay: 300,
          defaultVisible: true, // 初始显示
          appendToBody: false, // 禁用Teleport
        },
        slots: {
          default: '<button>Hover me</button>',
        },
      });

      // 找到tooltip容器元素
      const tooltipContainer = screen.getByRole('button').parentElement;
      expect(tooltipContainer).toBeTruthy();
      expect(tooltipContainer?.classList.contains('ht-tooltip')).toBe(true);

      // 等待组件初始化
      await nextTick();

      // 触发隐藏
      await fireEvent.mouseLeave(tooltipContainer!);

      // 等待延迟时间并执行所有定时器
      vi.advanceTimersByTime(300);
      vi.runAllTimers();
      await nextTick();

      // 检查是否触发了hide事件
      expect(emitted()).toHaveProperty('hide');
      expect(emitted().hide).toHaveLength(1);

      vi.useRealTimers();
    });
  });

  describe('箭头显示', () => {
    it('应该显示箭头', async () => {
      const { container } = renderWithMounting(HTTooltip, {
        props: {
          content: 'Tooltip with arrow',
          showArrow: true,
          visible: true,
          appendToBody: false, // 禁用Teleport
        },
        slots: {
          default: '<button>Trigger</button>',
        },
      });

      await nextTick();
      const arrow = container.querySelector('.ht-tooltip__arrow');
      expect(arrow).toBeInTheDocument();
    });

    it('应该隐藏箭头', async () => {
      const { container } = renderWithMounting(HTTooltip, {
        props: {
          content: 'Tooltip without arrow',
          showArrow: false,
          visible: true,
          appendToBody: false, // 禁用Teleport
        },
        slots: {
          default: '<button>Trigger</button>',
        },
      });

      await nextTick();
      const arrow = container.querySelector('.ht-tooltip__arrow');
      expect(arrow).not.toBeInTheDocument();
    });
  });

  describe('禁用状态', () => {
    it('应该在禁用时不显示tooltip', async () => {
      const { container } = renderWithMounting(HTTooltip, {
        props: {
          content: 'Disabled tooltip',
          disabled: true,
          trigger: 'hover',
          appendToBody: false, // 禁用Teleport
        },
        slots: {
          default: '<button>Hover me</button>',
        },
      });

      // 找到tooltip容器元素
      const tooltipContainer = screen.getByRole('button').parentElement;
      expect(tooltipContainer).toBeTruthy();
      expect(tooltipContainer?.classList.contains('ht-tooltip')).toBe(true);

      // 找到popper元素
      const popper = container.querySelector('.ht-tooltip__popper');
      expect(popper).toBeInTheDocument();

      // 检查初始状态下是否隐藏
      const computedStyleInitial = window.getComputedStyle(popper!);
      const isInitiallyHidden =
        computedStyleInitial.display === 'none' ||
        computedStyleInitial.visibility === 'hidden' ||
        computedStyleInitial.opacity === '0' ||
        popper!.style.display === 'none';
      expect(isInitiallyHidden).toBe(true);

      // 尝试触发显示
      await fireEvent.mouseEnter(tooltipContainer!);
      await nextTick();

      // 应该仍然隐藏
      const computedStyleAfterHover = window.getComputedStyle(popper!);
      const isStillHidden =
        computedStyleAfterHover.display === 'none' ||
        computedStyleAfterHover.visibility === 'hidden' ||
        computedStyleAfterHover.opacity === '0' ||
        popper!.style.display === 'none';
      expect(isStillHidden).toBe(true);
    });
  });

  describe('自定义样式', () => {
    it('应该应用自定义popper类名', async () => {
      const { container } = renderWithMounting(HTTooltip, {
        props: {
          content: 'Custom class tooltip',
          popperClass: 'custom-tooltip-class',
          visible: true,
          appendToBody: false, // 禁用Teleport
        },
        slots: {
          default: '<button>Trigger</button>',
        },
      });

      await nextTick();
      const popper = container.querySelector('.ht-tooltip__popper');
      expect(popper).toHaveClass('custom-tooltip-class');
    });

    it('应该应用自定义popper样式', async () => {
      const { container } = renderWithMounting(HTTooltip, {
        props: {
          content: 'Styled tooltip',
          popperStyle: { backgroundColor: 'red', color: 'white' },
          visible: true,
          appendToBody: false, // 禁用Teleport
        },
        slots: {
          default: '<button>Trigger</button>',
        },
      });

      await nextTick();
      const popper = container.querySelector('.ht-tooltip__popper');
      expect(popper).toBeInTheDocument();

      // 检查内联样式
      const style = popper?.getAttribute('style');
      expect(style).toContain('background-color: red');
      expect(style).toContain('color: white');
    });

    it('应该应用最大宽度', async () => {
      const { container } = renderWithMounting(HTTooltip, {
        props: {
          content: 'Max width tooltip with very long content that should be constrained',
          maxWidth: 200,
          visible: true,
          appendToBody: false, // 禁用Teleport
        },
        slots: {
          default: '<button>Trigger</button>',
        },
      });

      await nextTick();
      const popper = container.querySelector('.ht-tooltip__popper');
      expect(popper).toBeInTheDocument();

      // 检查内联样式中的maxWidth
      const style = popper?.getAttribute('style');
      expect(style).toContain('max-width: 200px');
    });
  });

  describe('关闭按钮', () => {
    it('应该显示关闭按钮', async () => {
      const { container } = renderWithMounting(HTTooltip, {
        props: {
          content: 'Tooltip with close button',
          showCloseButton: true,
          visible: true,
          appendToBody: false, // 禁用Teleport
        },
        slots: {
          default: '<button>Trigger</button>',
        },
      });

      await nextTick();
      const closeButton = container.querySelector('.ht-tooltip__close-button');
      expect(closeButton).toBeInTheDocument();
    });

    it('应该通过关闭按钮关闭tooltip', async () => {
      const { container, emitted } = renderWithMounting(HTTooltip, {
        props: {
          content: 'Closable tooltip',
          showCloseButton: true,
          defaultVisible: true, // 初始显示
          hideDelay: 0, // 设置为0以避免延迟
          appendToBody: false, // 禁用Teleport
        },
        slots: {
          default: '<button>Trigger</button>',
        },
      });

      await nextTick();
      const closeButton = container.querySelector('.ht-tooltip__close-button');
      expect(closeButton).toBeInTheDocument();

      await fireEvent.click(closeButton!);
      await nextTick();

      const events = emitted();
      expect(events).toHaveProperty('hide');
      expect(events.hide).toHaveLength(1);
    });
  });

  describe('事件处理', () => {
    it('应该触发show事件', async () => {
      const wrapper = renderWithMounting(HTTooltip, {
        props: {
          content: 'Show event tooltip',
          trigger: 'hover',
          appendToBody: false, // 禁用Teleport
          showDelay: 0, // 设置为0避免延迟
          hideDelay: 0, // 设置为0避免延迟
        },
        slots: {
          default: '<button>Trigger</button>',
        },
      });

      // 找到tooltip容器元素
      const tooltipContainer = screen.getByRole('button').parentElement;
      expect(tooltipContainer).toBeTruthy();
      expect(tooltipContainer?.classList.contains('ht-tooltip')).toBe(true);

      // 在tooltip容器上触发mouseenter事件
      await fireEvent.mouseEnter(tooltipContainer!);
      vi.runAllTimers(); // 运行定时器
      await nextTick();

      // 检查组件是否触发了show事件
      expect(wrapper.emitted()).toHaveProperty('show');
      expect(wrapper.emitted('show')).toHaveLength(1);
    });

    it('应该触发hide事件', async () => {
      const wrapper = renderWithMounting(HTTooltip, {
        props: {
          content: 'Hide event tooltip',
          trigger: 'hover',
          appendToBody: false, // 禁用Teleport
          showDelay: 0, // 设置为0避免延迟
          hideDelay: 0, // 设置为0避免延迟
        },
        slots: {
          default: '<button>Trigger</button>',
        },
      });

      // 找到tooltip容器元素
      const tooltipContainer = screen.getByRole('button').parentElement;
      expect(tooltipContainer).toBeTruthy();
      expect(tooltipContainer?.classList.contains('ht-tooltip')).toBe(true);

      // 先显示tooltip
      await fireEvent.mouseEnter(tooltipContainer!);
      vi.runAllTimers(); // 运行定时器
      await nextTick();

      expect(wrapper.emitted()).toHaveProperty('show');
      expect(wrapper.emitted('show')).toHaveLength(1);

      // 然后隐藏tooltip
      await fireEvent.mouseLeave(tooltipContainer!);

      // 运行所有定时器
      vi.runAllTimers();
      await nextTick();

      expect(wrapper.emitted()).toHaveProperty('hide');
      expect(wrapper.emitted('hide')).toHaveLength(1);
    });
  });

  describe('v-model支持', () => {
    it('应该支持v-model:visible', async () => {
      const handleUpdate = vi.fn();
      let currentVisible = false;

      renderWithMounting(HTTooltip, {
        props: {
          content: 'V-model tooltip',
          visible: currentVisible,
          'onUpdate:visible': (newVal: boolean) => {
            handleUpdate(newVal);
            currentVisible = newVal;
          },
          trigger: 'hover',
          appendToBody: false, // 禁用Teleport
          showDelay: 0, // 设置为0避免延迟
          hideDelay: 0, // 设置为0避免延迟
        },
        slots: {
          default: '<button>Trigger</button>',
        },
      });

      // 找到tooltip容器元素
      const tooltipContainer = screen.getByRole('button').parentElement;
      expect(tooltipContainer).toBeTruthy();
      expect(tooltipContainer?.classList.contains('ht-tooltip')).toBe(true);

      // 触发mouseEnter，应该调用update:visible事件
      await fireEvent.mouseEnter(tooltipContainer!);
      vi.runAllTimers();
      await nextTick();

      expect(handleUpdate).toHaveBeenCalledWith(true);

      // 触发mouseLeave，应该调用update:visible事件
      await fireEvent.mouseLeave(tooltipContainer!);
      vi.runAllTimers();
      await nextTick();

      expect(handleUpdate).toHaveBeenCalledWith(false);
      expect(handleUpdate).toHaveBeenCalledTimes(2);
    });
  });
});
