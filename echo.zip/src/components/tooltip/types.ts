// Tooltip 定位类型
export type TooltipPlacement =
  | 'top'
  | 'top-start'
  | 'top-end'
  | 'bottom'
  | 'bottom-start'
  | 'bottom-end'
  | 'left'
  | 'left-start'
  | 'left-end'
  | 'right'
  | 'right-start'
  | 'right-end';

// Tooltip 主题类型
export type TooltipTheme = 'dark' | 'light';

// Tooltip 触发方式
export type TooltipTrigger = 'hover' | 'click' | 'focus' | 'manual';

// Tooltip 事件定义
export interface TooltipEmits {
  /**
   * 显示时触发
   */
  'show': [];
  /**
   * 隐藏时触发
   */
  'hide': [];
  /**
   * 可见状态改变时触发
   */
  'update:visible': [visible: boolean];
}

// Tooltip 属性接口（直接定义，避免 Vue 3.5+ 编译时类型解析问题）
export interface TooltipProps {
  /**
   * 显示的内容
   */
  content?: string;
  /**
   * Tooltip 的出现位置
   */
  placement?: TooltipPlacement;
  /**
   * 是否禁用
   */
  disabled?: boolean;
  /**
   * 延迟出现，单位毫秒
   */
  showDelay?: number;
  /**
   * 延迟关闭，单位毫秒
   */
  hideDelay?: number;
  /**
   * 主题
   */
  theme?: TooltipTheme;
  /**
   * 触发方式
   */
  trigger?: TooltipTrigger;
  /**
   * 是否显示箭头
   */
  showArrow?: boolean;
  /**
   * 是否可见（用于手动控制）
   */
  visible?: boolean;
  /**
   * 默认是否可见
   */
  defaultVisible?: boolean;
  /**
   * 偏移量
   */
  offset?: number;
  /**
   * 弹出层类名
   */
  popperClass?: string;
  /**
   * 弹出层样式
   */
  popperStyle?: Record<string, any>;
  /**
   * 是否插入到 body
   */
  appendToBody?: boolean;
  /**
   * 隐藏时是否销毁
   */
  destroyOnHide?: boolean;
  /**
   * 最大宽度
   */
  maxWidth?: string | number;
  /**
   * 是否显示关闭按钮（主要用于移动端）
   */
  showCloseButton?: boolean;
}

// Tooltip 实例方法
export interface TooltipInstance {
  /**
   * 显示 tooltip
   */
  show(): void;
  /**
   * 隐藏 tooltip
   */
  hide(): void;
  /**
   * 更新 tooltip 位置
   */
  updatePopper(): void;
}
