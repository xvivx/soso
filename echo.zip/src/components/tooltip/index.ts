import HTTooltip from './Tooltip.vue';

// 导出组件
export { HTTooltip };

// 导出类型
export * from './types';

export default HTTooltip;
