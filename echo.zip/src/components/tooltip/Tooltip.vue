<template>
  <div
    ref="triggerRef"
    class="ht-tooltip"
    @mouseenter="handleMouseEnter"
    @mouseleave="handleMouseLeave"
    @click="handleClick"
    @focus="handleFocus"
    @blur="handleBlur"
  >
    <!-- 触发器内容 -->
    <slot />

    <!-- Tooltip 弹出层 -->
    <Teleport :to="props.appendToBody ? 'body' : undefined" :disabled="!props.appendToBody">
      <Transition
        name="ht-tooltip-fade"
        @before-enter="onBeforeEnter"
        @after-enter="onAfterEnter"
        @before-leave="onBeforeLeave"
        @after-leave="onAfterLeave"
      >
        <div
          v-show="computedVisible"
          ref="popperRef"
          :class="[
            'ht-tooltip__popper',
            `ht-tooltip__popper--${props.theme}`,
            `ht-tooltip__popper--${actualPlacement}`,
            props.popperClass,
          ]"
          :style="[
            props.popperStyle || {},
            { maxWidth: typeof props.maxWidth === 'number' ? `${props.maxWidth}px` : props.maxWidth },
          ]"
          role="tooltip"
          :aria-hidden="!computedVisible"
        >
          <!-- 箭头 -->
          <div v-if="props.showArrow" ref="arrowRef" class="ht-tooltip__arrow" data-popper-arrow />

          <!-- 内容 -->
          <div class="ht-tooltip__content">
            <slot name="content">{{ displayContent }}</slot>

            <!-- 关闭按钮 -->
            <button
              v-if="props.showCloseButton"
              class="ht-tooltip__close-button"
              type="button"
              @click="handleCloseClick"
              aria-label="关闭提示"
            >
              <svg class="ht-tooltip__close-icon" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path
                  d="M18 6L6 18M6 6L18 18"
                  stroke="currentColor"
                  stroke-width="2"
                  stroke-linecap="round"
                  stroke-linejoin="round"
                />
              </svg>
            </button>
          </div>
        </div>
      </Transition>
    </Teleport>
  </div>
</template>

<script setup lang="ts">
import { computed, nextTick, onMounted, onUnmounted, ref, watch } from 'vue';
import { createPopper, type Instance as PopperInstance } from '@popperjs/core';
import { useLocale } from '@/locale';
import { type TooltipEmits, type TooltipInstance, type TooltipPlacement, type TooltipProps } from './types';
import './styles/index.css';

// 组件名称
defineOptions({
  name: 'HTTooltip',
});

// 属性定义
const props = withDefaults(defineProps<TooltipProps>(), {
  content: '',
  placement: 'top',
  disabled: false,
  showDelay: 0,
  hideDelay: 0,
  theme: 'dark',
  trigger: 'hover',
  showArrow: true,
  visible: undefined,
  defaultVisible: false,
  offset: 8,
  popperClass: '',
  popperStyle: () => ({}),
  appendToBody: true,
  destroyOnHide: false,
  maxWidth: 300,
  showCloseButton: false,
});

// 事件定义
const emit = defineEmits<TooltipEmits>();

// 多语言支持
const { t } = useLocale();

// 模板引用
const triggerRef = ref<HTMLElement>();
const popperRef = ref<HTMLElement>();
const arrowRef = ref<HTMLElement>();
const popperInstance = ref<PopperInstance>();

// 状态管理
const isVisible = ref(props.defaultVisible);
const actualPlacement = ref<TooltipPlacement>(props.placement);
const showTimer = ref<number>();
const hideTimer = ref<number>();

// 计算属性
const computedVisible = computed(() => {
  if (props.disabled) return false;
  return props.visible !== undefined ? props.visible : isVisible.value;
});

const displayContent = computed(() => {
  if (props.content) {
    return props.content;
  }
  // 如果没有内容，显示多语言的默认文本
  return t('htTooltip.empty', '暂无提示');
});

// 清除定时器
const clearTimers = () => {
  if (showTimer.value) {
    clearTimeout(showTimer.value);
    showTimer.value = undefined;
  }
  if (hideTimer.value) {
    clearTimeout(hideTimer.value);
    hideTimer.value = undefined;
  }
};

// 显示 tooltip
const doShow = () => {
  if (props.disabled) return;

  clearTimers();

  if (props.showDelay > 0) {
    showTimer.value = window.setTimeout(() => {
      setVisible(true);
    }, props.showDelay);
  } else {
    setVisible(true);
  }
};

// 隐藏 tooltip
const doHide = () => {
  clearTimers();

  if (props.hideDelay > 0) {
    hideTimer.value = window.setTimeout(() => {
      setVisible(false);
    }, props.hideDelay);
  } else {
    setVisible(false);
  }
};

// 设置可见性
const setVisible = (visible: boolean) => {
  if (props.disabled) return;

  if (visible === isVisible.value) return;

  isVisible.value = visible;
  emit('update:visible', visible);

  if (visible) {
    emit('show');
    nextTick(() => {
      createPopperInstance();
    });
  } else {
    emit('hide');
    if (props.destroyOnHide) {
      destroyPopperInstance();
    }
  }
};

// 创建 Popper 实例
const createPopperInstance = async () => {
  if (!triggerRef.value || !popperRef.value) return;

  await nextTick();

  if (popperInstance.value) {
    popperInstance.value.destroy();
  }

  popperInstance.value = createPopper(triggerRef.value, popperRef.value, {
    placement: props.placement,
    modifiers: [
      {
        name: 'offset',
        options: {
          offset: [0, props.offset],
        },
      },
      {
        name: 'arrow',
        options: {
          element: arrowRef.value,
          padding: 8,
        },
      },
      {
        name: 'preventOverflow',
        options: {
          padding: 8,
        },
      },
      {
        name: 'flip',
        options: {
          fallbackPlacements: ['top', 'bottom', 'left', 'right'],
        },
      },
    ],
  });
};

// 销毁 Popper 实例
const destroyPopperInstance = () => {
  if (popperInstance.value) {
    popperInstance.value.destroy();
    popperInstance.value = undefined;
  }
};

// 更新 popper 位置
const updatePopper = () => {
  if (popperInstance.value) {
    popperInstance.value.update();
  }
};

// 事件处理器
const handleMouseEnter = () => {
  if (props.trigger === 'hover') {
    doShow();
  }
};

const handleMouseLeave = () => {
  if (props.trigger === 'hover') {
    doHide();
  }
};

const handleClick = () => {
  if (props.trigger === 'click') {
    if (computedVisible.value) {
      doHide();
    } else {
      doShow();
    }
  }
};

const handleFocus = () => {
  if (props.trigger === 'focus') {
    doShow();
  }
};

const handleBlur = () => {
  if (props.trigger === 'focus') {
    doHide();
  }
};

// 关闭按钮点击处理
const handleCloseClick = (event: Event) => {
  event.stopPropagation();
  doHide();
};

// 过渡事件处理
const onBeforeEnter = () => {
  updatePopper();
};

const onAfterEnter = () => {
  // 动画完成后的处理
};

const onBeforeLeave = () => {
  // 离开前的处理
};

const onAfterLeave = () => {
  // 离开后的处理
};

// 监听 visible 属性变化
watch(
  () => props.visible,
  (newVal) => {
    if (newVal !== undefined) {
      setVisible(newVal);
    }
  }
);

// 监听 placement 变化
watch(
  () => props.placement,
  () => {
    actualPlacement.value = props.placement;
    if (computedVisible.value) {
      nextTick(() => {
        updatePopper();
      });
    }
  }
);

// 生命周期
onMounted(() => {
  if (computedVisible.value) {
    createPopperInstance();
  }
});

onUnmounted(() => {
  clearTimers();
  destroyPopperInstance();
});

// 暴露实例方法
defineExpose<TooltipInstance>({
  show: doShow,
  hide: doHide,
  updatePopper,
});
</script>

<style scoped>
/* 基础样式 */
.ht-tooltip {
  display: inline-block;
}

.ht-tooltip__popper {
  position: absolute;
  z-index: var(--tooltip-z-index, 2000);
  padding: var(--tooltips-container-padding-vertical, 12px) var(--tooltips-container-padding-horizontal, 12px);
  border-radius: var(--tooltips-container-radius, 6px);
  font-size: var(--tooltips-content-font-body-size, 12px);
  line-height: var(--tooltip-line-height, 1.4);
  word-wrap: break-word;
  box-sizing: border-box;
}

.ht-tooltip__popper--dark {
  background-color: var(--tooltips-container-background-color-brand, #303133);
  color: var(--tooltips-content-font-body-color, white);
  border: 1px solid var(--tooltip-dark-border, transparent);
}

.ht-tooltip__popper--light {
  background-color: var(--tooltips-container-background-color-neutral, #ffffff);
  color: var(--tooltip-light-color, #606266);
  border: 1px solid var(--tooltip-light-border, #e4e7ed);
  box-shadow: var(--tooltip-light-shadow, 0 2px 12px 0 rgba(0, 0, 0, 0.1));
}

.ht-tooltip__content {
  margin: 0;
  position: relative;
  display: flex;
  align-items: flex-start;
  gap: 8px;
}

/* 关闭按钮样式 */
.ht-tooltip__close-button {
  position: absolute;
  top: -4px;
  right: -4px;
  width: var(--tooltip-close-button-size, 20px);
  height: var(--tooltip-close-button-size, 20px);
  padding: var(--tooltip-close-button-padding, 2px);
  background: transparent;
  border: none;
  border-radius: var(--tooltip-close-button-border-radius, 4px);
  color: var(--tooltip-close-button-color, currentColor);
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: background-color 0.2s ease;
  flex-shrink: 0;
}

.ht-tooltip__close-button:hover {
  background-color: var(--tooltip-close-button-hover-bg, rgba(255, 255, 255, 0.1));
}

.ht-tooltip__close-button:focus {
  outline: 2px solid rgba(255, 255, 255, 0.5);
  outline-offset: 1px;
}

.ht-tooltip__close-icon {
  width: 14px;
  height: 14px;
  stroke-width: 2;
}

/* 当有关闭按钮时，调整内容布局 */
.ht-tooltip__popper:has(.ht-tooltip__close-button) .ht-tooltip__content {
  padding-right: 24px;
}

.ht-tooltip__arrow {
  position: absolute;
  width: var(--tooltips-arrow-size-width, 12px);
  height: var(--tooltips-arrow-size-height, 6px);
}

.ht-tooltip__arrow::before {
  content: '';
  position: absolute;
  border-style: solid;
}

/* 箭头位置样式 */
.ht-tooltip__popper[data-popper-placement^='top'] .ht-tooltip__arrow {
  bottom: calc(-1 * var(--tooltips-arrow-size-height, 6px));
}

.ht-tooltip__popper[data-popper-placement^='top'] .ht-tooltip__arrow::before {
  border-left: calc(var(--tooltips-arrow-size-width, 12px) / 2) solid transparent;
  border-right: calc(var(--tooltips-arrow-size-width, 12px) / 2) solid transparent;
  border-top: var(--tooltips-arrow-size-height, 6px) solid;
}

.ht-tooltip__popper[data-popper-placement^='bottom'] .ht-tooltip__arrow {
  top: calc(-1 * var(--tooltips-arrow-size-height, 6px));
}

.ht-tooltip__popper[data-popper-placement^='bottom'] .ht-tooltip__arrow::before {
  border-left: calc(var(--tooltips-arrow-size-width, 12px) / 2) solid transparent;
  border-right: calc(var(--tooltips-arrow-size-width, 12px) / 2) solid transparent;
  border-bottom: var(--tooltips-arrow-size-height, 6px) solid;
}

.ht-tooltip__popper[data-popper-placement^='left'] .ht-tooltip__arrow {
  right: calc(-1 * var(--tooltips-arrow-size-height, 6px));
  width: var(--tooltips-arrow-size-height, 6px);
  height: var(--tooltips-arrow-size-width, 12px);
}

.ht-tooltip__popper[data-popper-placement^='left'] .ht-tooltip__arrow::before {
  border-top: calc(var(--tooltips-arrow-size-width, 12px) / 2) solid transparent;
  border-bottom: calc(var(--tooltips-arrow-size-width, 12px) / 2) solid transparent;
  border-left: var(--tooltips-arrow-size-height, 6px) solid;
}

.ht-tooltip__popper[data-popper-placement^='right'] .ht-tooltip__arrow {
  left: calc(-1 * var(--tooltips-arrow-size-height, 6px));
  width: var(--tooltips-arrow-size-height, 6px);
  height: var(--tooltips-arrow-size-width, 12px);
}

.ht-tooltip__popper[data-popper-placement^='right'] .ht-tooltip__arrow::before {
  border-top: calc(var(--tooltips-arrow-size-width, 12px) / 2) solid transparent;
  border-bottom: calc(var(--tooltips-arrow-size-width, 12px) / 2) solid transparent;
  border-right: var(--tooltips-arrow-size-height, 6px) solid;
}

/* 主题色箭头 */
.ht-tooltip__popper--dark[data-popper-placement^='top'] .ht-tooltip__arrow::before {
  border-top-color: var(--tooltips-arrow-color-brand, #303133);
}

.ht-tooltip__popper--dark[data-popper-placement^='bottom'] .ht-tooltip__arrow::before {
  border-bottom-color: var(--tooltips-arrow-color-brand, #303133);
}

.ht-tooltip__popper--dark[data-popper-placement^='left'] .ht-tooltip__arrow::before {
  border-left-color: var(--tooltips-arrow-color-brand, #303133);
}

.ht-tooltip__popper--dark[data-popper-placement^='right'] .ht-tooltip__arrow::before {
  border-right-color: var(--tooltips-arrow-color-brand, #303133);
}

.ht-tooltip__popper--light[data-popper-placement^='top'] .ht-tooltip__arrow::before {
  border-top-color: var(--tooltips-arrow-color-neutral, #ffffff);
}

.ht-tooltip__popper--light[data-popper-placement^='bottom'] .ht-tooltip__arrow::before {
  border-bottom-color: var(--tooltips-arrow-color-neutral, #ffffff);
}

.ht-tooltip__popper--light[data-popper-placement^='left'] .ht-tooltip__arrow::before {
  border-left-color: var(--tooltips-arrow-color-neutral, #ffffff);
}

.ht-tooltip__popper--light[data-popper-placement^='right'] .ht-tooltip__arrow::before {
  border-right-color: var(--tooltips-arrow-color-neutral, #ffffff);
}

/* 过渡动画 */
.ht-tooltip-dark-enter-active,
.ht-tooltip-dark-leave-active,
.ht-tooltip-light-enter-active,
.ht-tooltip-light-leave-active {
  transition:
    opacity var(--tooltip-animation-duration, 0.15s) var(--tooltip-animation-timing, cubic-bezier(0.4, 0, 0.2, 1)),
    transform var(--tooltip-animation-duration, 0.15s) var(--tooltip-animation-timing, cubic-bezier(0.4, 0, 0.2, 1));
}

.ht-tooltip-dark-enter-from,
.ht-tooltip-dark-leave-to,
.ht-tooltip-light-enter-from,
.ht-tooltip-light-leave-to {
  opacity: 0;
  transform: scale(0.8);
}
</style>
