export { default } from './PopoverRoot.vue';
export type { PopoverProps } from './types';
