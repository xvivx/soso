import { type PopoverContentProps } from 'reka-ui';

export interface PopoverProps extends PopoverContentProps {
  title?: string;
  defaultOpen?: boolean;
  open?: boolean;
  disabled?: boolean;
  trigger?: 'hover' | 'click';
  showArrow?: boolean;
  fitWidth?: boolean;
  floating?: boolean;
}
