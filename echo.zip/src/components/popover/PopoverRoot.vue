<template>
  <PopoverRoot data-slot="popover" v-bind="forwarded" :open="visible" @update:open="setOpen">
    <PopoverTrigger as-child v-on="events" class="cursor-pointer">
      <slot name="reference" :open="visible"></slot>
    </PopoverTrigger>

    <PopoverPortal v-if="desktop || floating" to="body">
      <PopoverContent
        :class="
          cn(
            'ht-popover-container min-w-30 rounded-xl py-4 shadow focus-visible:outline-none',
            fitWidth && 'ht-popover-container-fit'
          )
        "
        v-on="events"
        v-bind="props"
      >
        <PopoverArrow class="ht-popover-arrow h-1.5" v-if="showArrow" />

        <template v-if="children.length > 1">
          <div class="ht-popover-content overflow-auto px-4">
            <component v-for="child in children" :is="child" :key="child.scopeId"></component>
          </div>
        </template>
        <component v-else class="ht-popover-content overflow-auto px-4" :is="children[0]" />
      </PopoverContent>
    </PopoverPortal>
  </PopoverRoot>
</template>

<script setup lang="tsx">
import { computed, getCurrentInstance, onUnmounted, ref, useSlots, watch, type VNode } from 'vue';
import { useMediaQuery } from '@vueuse/core';
import {
  PopoverArrow,
  PopoverContent,
  PopoverPortal,
  PopoverRoot,
  PopoverTrigger,
  useForwardPropsEmits,
  type PopoverContentProps,
  type PopoverRootEmits,
} from 'reka-ui';
import Modal from '@/components/modal';
import { cn } from '@/utils';

defineSlots<{
  reference(props: { open: boolean }): VNode;
  default(props: { close: () => void }): VNode;
}>();

export interface PopoverProps extends Omit<PopoverContentProps, 'asChild'> {
  title?: string;
  defaultOpen?: boolean;
  open?: boolean;
  disabled?: boolean;
  trigger?: 'hover' | 'click';
  showArrow?: boolean;
  fitWidth?: boolean;
  floating?: boolean;
}

const desktop = useMediaQuery('(min-width: 768px)');
const props = withDefaults(defineProps<PopoverProps>(), {
  trigger: 'click',
  align: 'start',
  side: 'bottom',
  sideOffset: 8,
  fitWidth: true,
  showArrow: true,
});
const emits = defineEmits<PopoverRootEmits>();
const forwarded = useForwardPropsEmits(props, emits);
const slots = useSlots();
const instance = getCurrentInstance()!;
const controlled = 'open' in (instance.vnode.props || {});

function setOpen(value: boolean) {
  controlled ? emits('update:open', value) : (open.value = value);
}
let timer: NodeJS.Timeout;
function debounceUpdateOpen(open: boolean, immediate = false) {
  clearTimeout(timer!);
  if (open || immediate) {
    setOpen(open);
  } else {
    timer = setTimeout(setOpen, 150, false);
  }
}

const events = computed(() =>
  desktop.value && props.trigger === 'hover'
    ? {
        mouseenter: () => debounceUpdateOpen(true),
        mouseleave: () => debounceUpdateOpen(false),
        click: (event: MouseEvent) => {
          if (props.trigger === 'hover') {
            event.stopImmediatePropagation();
          }
        },
      }
    : {}
);

// 受控使用外部传的open属性
const open = ref(controlled ? props.open : props.defaultOpen);
const visible = computed(() => (controlled ? props.open : open.value));
let cleanup: () => void = () => null;
const close = () => debounceUpdateOpen(false, true);
const children = computed(() => slots.default!({ close }) || []);

watch(
  visible,
  () => {
    if (desktop.value || props.floating) return;
    if (visible.value) {
      cleanup = Modal.show({
        title: props.title,
        children: slots.default!({ close: close }),
        onClose: close,
      });
    } else {
      cleanup();
    }
  },
  { immediate: true }
);
onUnmounted(() => cleanup());
</script>

<style>
@keyframes fade-in {
  from {
    opacity: 0;
    transform: translate3d(0, 20px, 0);
  }
  to {
    opacity: 1;
    transform: translate3d(0, 0, 0);
  }
}

@keyframes fade-out {
  from {
    opacity: 1;
    transform: translate3d(0, 0, 0);
  }
  to {
    opacity: 0;
    transform: translate3d(0, 20px, 0);
  }
}

.ht-popover-container[data-state='open'] {
  animation: fade-in 150ms ease-out;
}
.ht-popover-container[data-state='closed'] {
  animation: fade-out 150ms ease-in;
}
.ht-popover-container {
  background-color: var(--popover-content-bg-color);
  z-index: var(--popover-z-index);
}
.ht-popover-container-fit {
  width: var(--reka-popover-trigger-width);
}
.ht-popover-arrow {
  fill: var(--popover-content-bg-color);
}
.ht-popover-content {
  max-width: var(--popover-content-max-width);
  max-height: var(--popover-content-max-height);
}

:root {
  --popover-z-index: 1000;
  --popover-content-bg-color: #fff;
  --popover-content-max-width: 400px;
  --popover-content-max-height: 400px;
}
</style>
