<template>
  <PopoverRoot
    data-slot="popover"
    v-bind="forwarded"
    :open="visible"
    @update:open="(value) => (controlled ? emits('update:open', value) : (open = value))"
  >
    <PopoverTrigger as-child>
      <slot name="reference" :open="visible"></slot>
    </PopoverTrigger>
  </PopoverRoot>
</template>

<script setup lang="tsx">
import { computed, Fragment, getCurrentInstance, onUnmounted, ref, useSlots, watch, type VNode } from 'vue';
import {
  PopoverRoot,
  PopoverTrigger,
  useForwardPropsEmits,
  type PopoverRootEmits,
  type PopoverRootProps,
} from 'reka-ui';
import Modal from '@/components/modal';

defineSlots<{
  reference(props: { open: boolean }): VNode;
  default(props: { close: () => void }): VNode;
}>();

const props = defineProps<PopoverRootProps & { title?: string }>();
const emits = defineEmits<PopoverRootEmits>();

const forwarded = useForwardPropsEmits(props, emits);
const slots = useSlots();
const instance = getCurrentInstance()!;
const controlled = 'open' in (instance.vnode.props || {});

// 受控使用外部传的open属性
const open = ref(controlled ? props.open : props.defaultOpen);
const visible = computed(() => (controlled ? props.open : open.value));
let cleanup: () => void = () => null;
const close = () => {
  emits('update:open', false);
  open.value = false;
};

watch(
  visible,
  () => {
    if (visible.value) {
      cleanup = Modal.show({
        title: props.title,
        children: <Fragment>{slots.default!({ close: close })}</Fragment>,
        onClose: close,
      });
    } else {
      cleanup();
    }
  },
  { immediate: true }
);
onUnmounted(() => cleanup());
</script>
