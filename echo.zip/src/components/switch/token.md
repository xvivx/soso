--switch-container-width-default
开关默认宽度
52px

--switch-container-width-small
小号开关宽度
40px

--switch-container-height-default
开关默认高度
32px

--switch-container-height-small
小号开关高度
24px

--switch-container-border-radius-default
开关默认圆角
16px

--switch-container-border-radius-small
小号开关圆角
12px

--switch-container-bg-color-off
关闭状态背景色
#E5E6EB

--switch-container-bg-color-on
开启状态背景色
#1677FF

--switch-container-bg-color-disabled
禁用状态背景色
#E5E6EB

--switch-dot-size-default
开关圆点默认尺寸
28px

--switch-dot-size-small
小号开关圆点尺寸
20px

--switch-dot-bg-color-default
圆点默认背景色
#FFFFFF
Color modes / Surface / Primary
--switch-dot-transform-off
关闭状态圆点位置
translateX(2px)

--switch-dot-transform-on
开启状态圆点位置
translateX(22px)

--switch-dot-transform-on-small
小号开启状态圆点位置
translateX(16px)

--switch-text-font-size-default
开关文本默认字号
14px

--switch-text-color-default
开关文本默认颜色
#333333

--switch-text-margin-left
文本在左侧时外边距
0 0 0 8px

--switch-text-margin-right
文本在右侧时外边距
8px 0 0 0

--switch-opacity-disabled
禁用状态透明度
0.5

--switch-transition-duration
开关切换过渡时间
0.3s
