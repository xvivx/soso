export { default as HTSwitch } from './Switch.vue';
export type { SwitchEmits, SwitchProps } from './types';
