<script setup lang="ts">
import { computed } from 'vue';
import { motion } from 'motion-v';
import { SwitchRoot } from 'reka-ui';
import { cn } from '@/utils/index';
import { useCustomFieldValue } from '@/hooks';
import type { SwitchEmits, SwitchProps } from './types';
import './styles/index.css';

const props = withDefaults(defineProps<SwitchProps>(), {
  size: 26, // Vant 默认 26px
  activeValue: true,
  inactiveValue: false,
  loading: false,
  disabled: false,
});

const emit = defineEmits<SwitchEmits>();

const model = defineModel<boolean | string | number>('modelValue', { default: false });

useCustomFieldValue(() => model.value);

// 转换为布尔值给 SwitchRoot
const checked = computed(() => model.value === props.activeValue);

function handleSwitchChange(value: boolean) {
  if (isDisabled.value) {
    return;
  }
  const newValue = value ? props.activeValue : props.inactiveValue;
  model.value = newValue;
  emit('update:modelValue', newValue as boolean);
  emit('change', newValue as boolean);
}

const isDisabled = computed(() => props.disabled || props.loading);

// 计算开关尺寸（Vant 风格）
const switchSize = computed(() => {
  const size = typeof props.size === 'number' ? `${props.size}px` : props.size;
  const sizeNum = parseInt(size);
  const dotSize = sizeNum - 4; // 圆点比容器小 4px
  const dotTranslate = sizeNum - 2; // 圆点向右移动的距离

  return {
    width: `${sizeNum * 2}px`,
    height: `${sizeNum}px`,
    fontSize: `${sizeNum}px`,
    '--switch-dot-size': `${dotSize}px`,
    '--switch-dot-translate': `${dotTranslate}px`,
  };
});

const switchStyle = computed(() => {
  const style: Record<string, string> = { ...switchSize.value };

  if (checked.value && props.activeColor) {
    style.backgroundColor = props.activeColor;
  } else if (!checked.value && props.inactiveColor) {
    style.backgroundColor = props.inactiveColor;
  }

  return style;
});

// Motion 动画配置
const thumbAnimation = computed(() => ({
  x: checked.value ? `var(--switch-dot-translate, 22px)` : '2px',
}));

const springTransition = {
  type: 'spring' as const,
  stiffness: 500,
  damping: 30,
  mass: 1,
};
</script>

<template>
  <SwitchRoot
    :model-value="checked"
    :disabled="isDisabled"
    :class="
      cn('ht-switch', {
        'ht-switch--on': checked,
        'ht-switch--off': !checked,
        'ht-switch--disabled': isDisabled,
        'ht-switch--loading': loading,
      })
    "
    :style="switchStyle"
    @update:model-value="handleSwitchChange"
  >
    <!-- background 插槽 - Vant API -->
    <slot name="background" />

    <!-- 使用 motion.div 替代 SwitchThumb 实现弹性动画 -->
    <motion.div class="ht-switch__button" :animate="thumbAnimation" :transition="springTransition">
      <!-- node 插槽 - Vant API -->
      <slot name="node">
        <!-- Loading Icon with rotation animation -->
        <motion.div
          v-if="loading"
          :animate="{ rotate: 360 }"
          :transition="{ duration: 1, repeat: Infinity, ease: 'linear' }"
        >
          <svg class="ht-switch__loading-icon" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <circle cx="12" cy="12" r="10" stroke="currentColor" stroke-width="3" fill="none" opacity="0.25" />
            <path
              d="M12 2a10 10 0 0 1 10 10"
              stroke="currentColor"
              stroke-width="3"
              fill="none"
              stroke-linecap="round"
            />
          </svg>
        </motion.div>
      </slot>
    </motion.div>

    <!-- Label Slot -->
    <span v-if="$slots.default" class="ht-switch__label">
      <slot :checked="checked" :disabled="isDisabled" />
    </span>
  </SwitchRoot>
</template>

<style>
:root {
  /* 容器尺寸 */
  --switch-container-width-default: 52px;
  --switch-container-width-small: 40px;
  --switch-container-height-default: 32px;
  --switch-container-height-small: 24px;

  /* 圆角 */
  --switch-container-border-radius-default: 16px;
  --switch-container-border-radius-small: 12px;

  /* 背景色 */
  --switch-container-bg-color-off: #e5e6eb;
  --switch-container-bg-color-on: #1677ff;
  --switch-container-bg-color-disabled: #e5e6eb;

  /* 圆点 */
  --switch-dot-size-default: 28px;
  --switch-dot-size-small: 20px;
  --switch-dot-bg-color-default: #ffffff;

  /* 位置 */
  --switch-dot-transform-off: translateX(2px);
  --switch-dot-transform-on: translateX(22px);
  --switch-dot-transform-on-small: translateX(16px);

  /* 文本 */
  --switch-text-font-size-default: 14px;
  --switch-text-color-default: #333333;
  --switch-text-margin-left: 0 0 0 8px;
  --switch-text-margin-right: 8px 0 0 0;

  /* 状态 */
  --switch-opacity-disabled: 0.5;
  --switch-transition-duration: 0.3s;
}

@layer components {
  .ht-switch {
    position: relative;
    display: inline-flex;
    align-items: center;
    /* width 和 height 通过内联样式设置 */
    border-radius: 999px; /* 完全圆角 */
    background-color: var(--switch-container-bg-color-off);
    transition: background-color var(--switch-transition-duration) ease;
    outline: none;
    border: none;
    cursor: pointer;
    flex-shrink: 0;
  }

  .ht-switch:focus-visible {
    box-shadow: 0 0 0 2px rgba(22, 119, 255, 0.2);
  }

  .ht-switch--on,
  .ht-switch[data-state='checked'] {
    background-color: var(--switch-container-bg-color-on);
  }

  .ht-switch--disabled,
  .ht-switch[data-disabled] {
    background-color: var(--switch-container-bg-color-disabled);
    opacity: var(--switch-opacity-disabled);
    cursor: not-allowed;
  }

  .ht-switch__button {
    display: flex;
    align-items: center;
    justify-content: center;
    width: var(--switch-dot-size, var(--switch-dot-size-default));
    height: var(--switch-dot-size, var(--switch-dot-size-default));
    background-color: var(--switch-dot-bg-color-default);
    border-radius: 50%;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    pointer-events: none; /* 不阻止父元素的点击事件 */
    /* motion-v 处理 transform 动画，移除 CSS transition */
  }

  .ht-switch__loading-icon {
    width: 14px;
    height: 14px;
    /* motion-v 处理旋转动画，移除 @keyframes */
  }

  .ht-switch__label {
    font-size: var(--switch-text-font-size-default);
    color: var(--switch-text-color-default);
  }
}
</style>
