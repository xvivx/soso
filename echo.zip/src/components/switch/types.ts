export interface SwitchProps {
  modelValue?: boolean | string | number;
  loading?: boolean;
  disabled?: boolean;
  size?: string | number; // Vant 使用 px 值，如 '30px' 或 30
  activeColor?: string;
  inactiveColor?: string;
  activeValue?: boolean | string | number;
  inactiveValue?: boolean | string | number;
}

export interface SwitchEmits {
  'update:modelValue': [value: boolean | string | number];
  change: [value: boolean | string | number];
  click: [event: MouseEvent];
}
