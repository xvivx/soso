import { nextTick } from 'vue';
import { fireEvent, screen } from '@testing-library/vue';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { renderWithMounting } from '../../../../test/utils';
import HTToast from '../HTToast.vue';

describe('HTToast', () => {
  beforeEach(() => {
    document.body.innerHTML = '';
    vi.clearAllTimers();
    vi.useFakeTimers();
  });

  afterEach(() => {
    vi.useRealTimers();
  });

  describe('基础渲染', () => {
    it('应该正确渲染默认Toast', () => {
      const { container } = renderWithMounting(HTToast, {
        props: {
          visible: true,
          message: 'Toast Message',
        },
      });

      const toast = container.querySelector('.ht-toast');
      expect(toast).toBeInTheDocument();
      expect(screen.getByText('Toast Message')).toBeInTheDocument();
    });

    it('应该在不可见时不渲染', () => {
      const { container } = renderWithMounting(HTToast, {
        props: {
          visible: false,
          message: 'Toast Message',
        },
      });

      const toast = container.querySelector('.ht-toast');
      expect(toast).not.toBeInTheDocument();
    });

    it('应该渲染消息内容', () => {
      renderWithMounting(HTToast, {
        props: {
          visible: true,
          message: 'Custom Toast Content',
        },
      });

      const content = screen.getByText('Custom Toast Content');
      expect(content).toBeInTheDocument();
    });
  });

  describe('类型变体', () => {
    const types = ['text', 'loading', 'success', 'fail'] as const;

    it.each(types)('应该应用 %s 类型样式', (type) => {
      const { container } = renderWithMounting(HTToast, {
        props: {
          visible: true,
          type,
          message: `${type} message`,
        },
      });

      const toast = container.querySelector('.ht-toast');
      expect(toast).toHaveClass(`ht-toast--${type}`);
    });
  });

  describe('位置设置', () => {
    const positions = ['top', 'middle', 'bottom'] as const;

    it.each(positions)('应该应用 %s 位置样式', (position) => {
      const { container } = renderWithMounting(HTToast, {
        props: {
          visible: true,
          position,
          message: `${position} toast`,
        },
      });

      const toast = container.querySelector('.ht-toast');
      expect(toast).toHaveClass(`ht-toast--${position}`);
    });
  });

  describe('自动关闭功能', () => {
    it('应该在指定时间后自动关闭', async () => {
      const handleClose = vi.fn();
      renderWithMounting(HTToast, {
        props: {
          visible: true,
          duration: 2000,
          onClose: handleClose,
          message: 'Auto close toast',
        },
      });

      // 等待自动关闭触发
      vi.advanceTimersByTime(2000);
      await nextTick();

      expect(handleClose).toHaveBeenCalled();
    });

    it('应该支持禁用自动关闭', () => {
      const handleClose = vi.fn();
      renderWithMounting(HTToast, {
        props: {
          visible: true,
          duration: 0,
          onClose: handleClose,
          message: 'No auto close toast',
        },
      });

      vi.advanceTimersByTime(5000);
      expect(handleClose).not.toHaveBeenCalled();
    });
  });

  describe('点击功能', () => {
    it('应该支持点击关闭', async () => {
      const handleClose = vi.fn();
      const { container } = renderWithMounting(HTToast, {
        props: {
          visible: true,
          closeOnClick: true,
          onClose: handleClose,
          message: 'Click to close',
        },
      });

      const toast = container.querySelector('.ht-toast');
      await fireEvent.click(toast!);

      expect(handleClose).toHaveBeenCalled();
    });

    it('应该支持禁用点击', async () => {
      const handleClose = vi.fn();
      const { container } = renderWithMounting(HTToast, {
        props: {
          visible: true,
          closeOnClick: false,
          onClose: handleClose,
          message: 'No click close',
        },
      });

      const toast = container.querySelector('.ht-toast');
      await fireEvent.click(toast!);

      expect(handleClose).not.toHaveBeenCalled();
    });
  });

  describe('遮罩层功能', () => {
    it('应该显示遮罩层', () => {
      const { container } = renderWithMounting(HTToast, {
        props: {
          visible: true,
          overlay: true,
          message: 'With overlay',
        },
      });

      const overlay = container.querySelector('.ht-toast__overlay');
      expect(overlay).toBeInTheDocument();
    });

    it('应该支持点击遮罩层关闭', async () => {
      const handleClose = vi.fn();
      const { container } = renderWithMounting(HTToast, {
        props: {
          visible: true,
          overlay: true,
          closeOnClickOverlay: true,
          onClose: handleClose,
          message: 'Click overlay to close',
        },
      });

      const overlay = container.querySelector('.ht-toast__overlay');
      await fireEvent.click(overlay!);

      expect(handleClose).toHaveBeenCalled();
    });
  });

  describe('图标功能', () => {
    it('应该显示自定义图标', () => {
      const { container } = renderWithMounting(HTToast, {
        props: {
          visible: true,
          icon: 'star',
          message: 'With custom icon',
        },
      });

      const icon = container.querySelector('.ht-toast__icon-svg');
      expect(icon).toBeInTheDocument();
    });

    it('应该显示成功图标', () => {
      const { container } = renderWithMounting(HTToast, {
        props: {
          visible: true,
          type: 'success',
          message: 'Success message',
        },
      });

      const icon = container.querySelector('.ht-toast__icon-svg');
      expect(icon).toBeInTheDocument();
    });
  });

  describe('加载状态', () => {
    it('应该显示加载动画', () => {
      const { container } = renderWithMounting(HTToast, {
        props: {
          visible: true,
          type: 'loading',
          message: 'Loading...',
        },
      });

      const loading = container.querySelector('.ht-toast__loading');
      expect(loading).toBeInTheDocument();
    });
  });

  describe('层级设置', () => {
    it('应该应用自定义z-index', () => {
      const { container } = renderWithMounting(HTToast, {
        props: {
          visible: true,
          zIndex: 9999,
          message: 'High z-index toast',
        },
      });

      const toast = container.querySelector('.ht-toast');
      expect(toast).toBeInTheDocument();
      // 检查样式属性是否包含z-index
      const style = toast?.getAttribute('style');
      expect(style).toContain('z-index: 9999');
    });
  });

  describe('事件处理', () => {
    it('应该触发opened事件', async () => {
      const handleOpened = vi.fn();
      renderWithMounting(HTToast, {
        props: {
          visible: true,
          onOpened: handleOpened,
          message: 'Opened event test',
        },
      });

      await nextTick();
      expect(handleOpened).toHaveBeenCalled();
    });

    it('应该在鼠标悬停时暂停自动关闭', async () => {
      const handleClose = vi.fn();
      const { container } = renderWithMounting(HTToast, {
        props: {
          visible: true,
          duration: 2000,
          onClose: handleClose,
          message: 'Hover to pause',
        },
      });

      const toast = container.querySelector('.ht-toast');

      // 鼠标悬停
      await fireEvent.mouseEnter(toast!);
      vi.advanceTimersByTime(2000);
      expect(handleClose).not.toHaveBeenCalled();

      // 鼠标离开
      await fireEvent.mouseLeave(toast!);
      vi.advanceTimersByTime(2000);
      expect(handleClose).toHaveBeenCalled();
    });
  });

  describe('HTML内容', () => {
    it('应该支持HTML内容', () => {
      const { container } = renderWithMounting(HTToast, {
        props: {
          visible: true,
          type: 'html',
          message: '<strong>Bold text</strong>',
        },
      });

      const strong = container.querySelector('strong');
      expect(strong).toBeInTheDocument();
      expect(strong).toHaveTextContent('Bold text');
    });
  });
});
