// 组件导出
export { default as HTToast } from './HTToast.vue';
export { default as ToastProvider } from './ToastProvider.vue';

// API 导出 - 对齐 Vant API
export {
  Toast,
  showToast,
  showLoadingToast,
  showSuccessToast,
  showFailToast,
  closeToast,
  setToastDefaultOptions,
  resetToastDefaultOptions,
  allowMultipleToast,
} from './api';

// Store 导出
export {
  useToastStore,
  toastState,
  addToast,
  clearToast,
  setDefaultOptions,
  resetDefaultOptions,
  allowMultiple,
} from './store';

// 类型导出
export type {
  ToastType,
  ToastPosition,
  ToastOptions,
  ToastInstance,
  ToastMethod,
  HTToastProps,
  HTToastEmits,
  ToastProviderProps,
  ToastState,
} from './types';

// 默认导出 Toast API
export { Toast as default } from './api';
