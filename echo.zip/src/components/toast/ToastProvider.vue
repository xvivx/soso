<script setup lang="ts">
import { computed } from 'vue';
import { Motion } from 'motion-v';
import { ToastProvider } from 'reka-ui';
import HTToast from './HTToast.vue';
import { toastState } from './store';
import type { HTToastProps, ToastProviderProps, ToastWithPosition } from './types';
import './styles/index.css';

const props = withDefaults(defineProps<ToastProviderProps>(), {
  duration: 2000,
  position: 'middle',
  swipeDirection: 'right',
  label: 'Notification',
});

// 计算所有需要渲染的 Toast 列表（包括正在退出的）
const renderToasts = computed(() => {
  return toastState.queue.filter((toast) => toast.visible || toast.exiting);
});

// 过滤 Toast props，移除不需要的属性
function getToastProps(toast: ToastWithPosition): HTToastProps {
  const { id: _id, top: _top, height: _height, onClose: _onClose, onOpened: _onOpened, ...toastProps } = toast;
  return toastProps as HTToastProps;
}

// 根据位置获取动画配置
function getAnimationConfig(position: string) {
  const baseConfig = {
    duration: 0.3,
    ease: 'easeOut',
  };

  switch (position) {
    case 'top':
      return {
        ...baseConfig,
        initial: { opacity: 0, transform: 'translateX(-50%) translateY(-100%)' },
        animate: { opacity: 1, transform: 'translateX(-50%) translateY(0%)' },
        exit: { opacity: 0, transform: 'translateX(-50%) translateY(-100%)' },
      };
    case 'bottom':
      return {
        ...baseConfig,
        initial: { opacity: 0, transform: 'translateX(-50%) translateY(100%)' },
        animate: { opacity: 1, transform: 'translateX(-50%) translateY(0%)' },
        exit: { opacity: 0, transform: 'translateX(-50%) translateY(100%)' },
      };
    case 'middle':
    default:
      return {
        ...baseConfig,
        initial: { opacity: 0, transform: 'translateX(-50%) scale(0.9)' },
        animate: { opacity: 1, transform: 'translateX(-50%) scale(1)' },
        exit: { opacity: 0, transform: 'translateX(-50%) scale(0.9)' },
      };
  }
}
</script>

<template>
  <ToastProvider :duration="props.duration" :swipe-direction="props.swipeDirection" :label="props.label">
    <!-- 使用 Motion 组件来处理 Toast 的进入和离开动画 -->
    <div class="ht-toast-wrapper">
      <Motion
        v-for="toast in renderToasts"
        :key="toast.id"
        :data-toast-id="toast.id"
        v-bind="getAnimationConfig(toast.position || 'middle')"
        :style="{
          position: 'fixed',
          top: `${toast.top || 0}px`,
          left: '50%',
          zIndex: 2000,
        }"
        :class="['ht-toast-container', `ht-toast-container--${toast.position || 'middle'}`]"
      >
        <HTToast
          v-bind="getToastProps(toast)"
          :visible="toast.visible && !toast.exiting"
          @close="toast.onClose"
          @opened="toast.onOpened"
        />
      </Motion>
    </div>
  </ToastProvider>
</template>

<style>
@reference 'tailwindcss';

:root {
  /* Toast Container CSS Variables */
  --toast-container-z-index: 2000;
}

@layer components {
  .ht-toast-container {
    @apply pointer-events-none;
    @apply w-fit max-w-[calc(100vw-40px)];
    /* 移除 transition，让 motion-v 处理动画 */
  }

  .ht-toast-container > * {
    @apply pointer-events-auto;
  }
}
</style>
