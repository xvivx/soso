<script setup lang="ts">
import { computed, onMounted, onUnmounted } from 'vue';
import { cva } from 'class-variance-authority';
import { HTIcon } from '@/components/icon';
import { HTLoading } from '@/components/loading';
import { addUnit, cn } from '@/utils/index';
import type { HTToastEmits, HTToastProps } from './types';
import './styles/index.css';

const props = withDefaults(defineProps<HTToastProps>(), {
  type: 'text',
  position: 'middle',
  duration: 2000,
  forbidClick: false,
  closeOnClick: false,
  closeOnClickOverlay: false,
  overlay: false,
  wordBreak: 'break-all',
  zIndex: 2000,
  visible: true,
});

const emit = defineEmits<HTToastEmits>();

let timer: number | null = null;

// 自动关闭
function startTimer() {
  if (props.duration > 0) {
    timer = window.setTimeout(() => {
      handleClose();
    }, props.duration);
  }
}

function clearTimer() {
  if (timer) {
    window.clearTimeout(timer);
    timer = null;
  }
}

onMounted(() => {
  startTimer();
});

onUnmounted(() => {
  clearTimer();
});

const toastVariants = cva('ht-toast', {
  variants: {
    type: {
      text: 'ht-toast--text',
      html: 'ht-toast--html',
      success: 'ht-toast--success',
      fail: 'ht-toast--fail',
      loading: 'ht-toast--loading',
    },
    position: {
      top: 'ht-toast--top',
      middle: 'ht-toast--middle',
      bottom: 'ht-toast--bottom',
    },
    wordBreak: {
      'break-all': 'ht-toast--break-all',
      'break-word': 'ht-toast--break-word',
      'normal': 'ht-toast--normal',
    },
    overlay: {
      true: 'ht-toast--overlay',
    },
    forbidClick: {
      true: 'ht-toast--forbid-click',
    },
  },
  defaultVariants: {
    type: 'text',
    position: 'middle',
    wordBreak: 'break-all',
  },
});

const toastClass = computed(() =>
  cn(
    toastVariants({
      type: props.type,
      position: props.position,
      wordBreak: props.wordBreak,
      overlay: props.overlay,
      forbidClick: props.forbidClick,
    }),
    props.className
  )
);

const toastStyle = computed(() => ({
  zIndex: props.zIndex,
}));

// 计算图标
const iconName = computed(() => {
  if (props.icon) return props.icon;

  switch (props.type) {
    case 'success':
      return 'check-circle';
    case 'fail':
      return 'x-circle';
    case 'loading':
      return null; // 使用 Loading 组件
    default:
      return null;
  }
});

// 计算图标大小
const iconSize = computed(() => addUnit(props.iconSize || 20));

// 处理点击事件
function handleClick() {
  if (props.closeOnClick) {
    handleClose();
  }
}

// 处理关闭事件
function handleClose() {
  clearTimer();
  emit('close');
  emit('update:visible', false);
}
</script>

<template>
  <div :class="toastClass" :style="toastStyle" @click="handleClick" @mouseenter="clearTimer" @mouseleave="startTimer">
    <!-- 遮罩层 -->
    <div
      v-if="overlay"
      class="ht-toast__overlay"
      :class="overlayClass"
      :style="overlayStyle"
      @click="closeOnClickOverlay && handleClose()"
    />

    <!-- Toast 内容 -->
    <div class="ht-toast__content">
      <!-- 图标或加载动画 -->
      <div v-if="type === 'loading' || iconName || image" class="ht-toast__icon">
        <HTLoading
          v-if="type === 'loading'"
          vertical
          :type="loadingType || 'circular'"
          :size="iconSize"
          :text="message"
          class="ht-toast__loading"
        />
        <img v-else-if="image" :src="image" :alt="message" class="ht-toast__image" />
        <HTIcon
          v-else-if="iconName"
          :name="iconName"
          :prefix="iconPrefix"
          :size="iconSize"
          class="ht-toast__icon-svg"
        />
      </div>

      <!-- 消息内容 -->
      <div v-if="type !== 'loading' && message" class="ht-toast__message">
        <div v-if="type === 'html'" v-html="message" />
        <template v-else>
          {{ message }}
        </template>
      </div>
    </div>

    <!-- 关闭按钮 (可选) -->
    <button v-if="closeOnClick" class="ht-toast__close" @click.stop="handleClose">
      <HTIcon name="x" :size="16" />
    </button>
  </div>
</template>
