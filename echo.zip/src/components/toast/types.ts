// Vant Toast API 兼容类型
export type ToastType = 'text' | 'loading' | 'success' | 'fail' | 'html';
export type ToastPosition = 'top' | 'middle' | 'bottom';
export type ToastWordBreak = 'break-all' | 'break-word' | 'normal';
export type LoadingType = 'circular' | 'spinner';

// Toast 选项接口 - 兼容 Vant API
export interface ToastOptions {
  type?: ToastType;
  message?: string;
  position?: ToastPosition;
  duration?: number;
  className?: string;
  icon?: string;
  iconPrefix?: string;
  iconSize?: number | string;
  image?: string;
  loadingType?: LoadingType;
  forbidClick?: boolean;
  closeOnClick?: boolean;
  closeOnClickOverlay?: boolean;
  overlay?: boolean;
  overlayClass?: string;
  overlayStyle?: Record<string, any>;
  transition?: string;
  teleport?: string | Element | any;
  wordBreak?: ToastWordBreak;
  zIndex?: number;
  onOpened?: () => void;
  onClose?: () => void;
  // shadcn/vue 扩展属性
  variant?: 'default' | 'destructive' | 'success' | 'warning';
  // reka-ui 兼容属性
  as?: string | object;
  asChild?: boolean;
}

// Toast 实例接口
export interface ToastInstance {
  id: string | number;
  message: string;
  close: () => void;
  clear: () => void;
}

// Toast 方法接口
export interface ToastMethod {
  (options: string | ToastOptions): ToastInstance;
  text: (message: string, options?: Omit<ToastOptions, 'type'>) => ToastInstance;
  loading: (message?: string, options?: Omit<ToastOptions, 'type'>) => ToastInstance;
  success: (message: string, options?: Omit<ToastOptions, 'type'>) => ToastInstance;
  fail: (message: string, options?: Omit<ToastOptions, 'type'>) => ToastInstance;
  html: (message: string, options?: Omit<ToastOptions, 'type'>) => ToastInstance;
  clear: (all?: boolean) => void;
  setDefaultOptions: (options: ToastOptions) => void;
  resetDefaultOptions: () => void;
  allowMultiple: (allow?: boolean) => void;
}

// HTToast 组件 Props
export interface HTToastProps extends ToastOptions {
  modelValue?: boolean;
  visible?: boolean;
}

// HTToast 组件 Emits
export interface HTToastEmits {
  'update:modelValue': [value: boolean];
  'update:visible': [value: boolean];
  opened: [];
  close: [];
}

// Toast Provider Props
export interface ToastProviderProps {
  duration?: number;
  position?: ToastPosition;
  className?: string;
  // reka-ui Toast Provider props
  disableSwipe?: boolean;
  swipeDirection?: 'right' | 'left' | 'up' | 'down';
  swipeThreshold?: number;
  label?: string;
}

// Toast 状态管理
export interface ToastState {
  queue: Array<ToastWithPosition>;
  defaultOptions: ToastOptions;
  allowMultiple: boolean;
}

// Toast 带位置信息的扩展类型
export interface ToastWithPosition extends ToastOptions {
  id: string | number;
  visible: boolean;
  exiting?: boolean; // 标记是否正在退出
  top?: number; // 计算出的 top 位置
  height?: number; // Toast 的实际高度
}
