import { nextTick, reactive, readonly } from 'vue';
import type { ToastInstance, ToastOptions, ToastState, ToastWithPosition } from './types';

// 默认配置
const defaultToastOptions: ToastOptions = {
  type: 'text',
  message: '',
  position: 'middle',
  duration: 2000,
  className: '',
  forbidClick: false,
  closeOnClick: false,
  closeOnClickOverlay: false,
  overlay: false,
  wordBreak: 'break-all',
  zIndex: 2000,
};

// Toast 高度和间距配置
const TOAST_CONFIG = {
  height: 48, // 默认 Toast 高度
  gap: 16, // Toast 之间的间距
  padding: 20, // 容器边距
};

// 响应式状态
const state = reactive<ToastState>({
  queue: [],
  defaultOptions: { ...defaultToastOptions },
  allowMultiple: true, // 改为默认允许多个，实现 Element Message 效果
});

// 计算 Toast 位置
function calculateToastPositions() {
  const positionGroups: Record<string, ToastWithPosition[]> = {
    top: [],
    middle: [],
    bottom: [],
  };

  // 按位置分组，排除正在退出的 toast
  state.queue.forEach((toast) => {
    if (!toast.exiting) {
      // 只计算非退出状态的 toast
      const position = toast.position || 'middle';
      if (positionGroups[position]) {
        positionGroups[position].push(toast);
      }
    }
  });

  // 为每个位置组计算 top 值
  Object.keys(positionGroups).forEach((position) => {
    const toasts = positionGroups[position];
    if (!toasts || toasts.length === 0) return;

    // 首先尝试获取实际高度
    toasts.forEach((toast) => {
      if (!toast.height) {
        const element = document.querySelector(`[data-toast-id="${toast.id}"]`) as HTMLElement;
        if (element) {
          // 获取元素的实际高度，包括内边距和边框
          const rect = element.getBoundingClientRect();
          toast.height = rect.height;

          // 如果高度仍然为 0，说明元素可能还在渲染中，使用默认高度
          if (toast.height === 0) {
            toast.height = TOAST_CONFIG.height;
          }
        } else {
          toast.height = TOAST_CONFIG.height; // 回退到默认高度
        }
      }
    });

    let currentTop = TOAST_CONFIG.padding;

    toasts.forEach((toast, index) => {
      const height = toast.height || TOAST_CONFIG.height;

      if (position === 'top') {
        toast.top = currentTop;
        // 根据 Toast 的实际高度动态调整间距
        const dynamicGap = height > TOAST_CONFIG.height ? TOAST_CONFIG.gap * 1.2 : TOAST_CONFIG.gap;
        currentTop += height + dynamicGap;
      } else if (position === 'middle') {
        // 中间位置需要特殊处理，从中心点向上下展开
        const totalHeight = toasts.reduce((sum, t, i) => {
          const toastHeight = t.height || TOAST_CONFIG.height;
          const gap = i > 0 ? (toastHeight > TOAST_CONFIG.height ? TOAST_CONFIG.gap * 1.2 : TOAST_CONFIG.gap) : 0;
          return sum + toastHeight + gap;
        }, 0);
        const startTop = (window.innerHeight - totalHeight) / 2;

        let offset = 0;
        for (let i = 0; i < index; i++) {
          const prevToast = toasts[i];
          if (prevToast) {
            const prevHeight = prevToast.height || TOAST_CONFIG.height;
            const dynamicGap = prevHeight > TOAST_CONFIG.height ? TOAST_CONFIG.gap * 1.2 : TOAST_CONFIG.gap;
            offset += prevHeight + dynamicGap;
          }
        }
        toast.top = startTop + offset;
      } else if (position === 'bottom') {
        // 底部位置从下往上计算
        const totalHeight = toasts.reduce((sum, t, i) => {
          const toastHeight = t.height || TOAST_CONFIG.height;
          const gap = i > 0 ? (toastHeight > TOAST_CONFIG.height ? TOAST_CONFIG.gap * 1.2 : TOAST_CONFIG.gap) : 0;
          return sum + toastHeight + gap;
        }, 0);
        const startTop = window.innerHeight - totalHeight - TOAST_CONFIG.padding;

        let offset = 0;
        for (let i = 0; i < index; i++) {
          const prevToast = toasts[i];
          if (prevToast) {
            const prevHeight = prevToast.height || TOAST_CONFIG.height;
            const dynamicGap = prevHeight > TOAST_CONFIG.height ? TOAST_CONFIG.gap * 1.2 : TOAST_CONFIG.gap;
            offset += prevHeight + dynamicGap;
          }
        }
        toast.top = startTop + offset;
      }
    });
  });
}

// ID 生成器
let toastId = 0;
function generateId(): string {
  return `toast_${++toastId}`;
}

// 合并选项
function mergeOptions(options: string | ToastOptions): ToastOptions {
  const baseOptions = typeof options === 'string' ? { message: options } : options;
  return { ...state.defaultOptions, ...baseOptions };
}

// 定时器管理
const timers = new Map<string | number, ReturnType<typeof setTimeout>>();

function clearTimer(id: string | number) {
  const timer = timers.get(id);
  if (timer) {
    clearTimeout(timer);
    timers.delete(id);
  }
}

function removeFromQueue(id: string | number) {
  const index = state.queue.findIndex((toast) => toast.id === id);
  if (index > -1) {
    const toast = state.queue[index];
    if (toast) {
      // 标记为正在退出，但不立即移除
      toast.exiting = true;
      toast.visible = false;

      // 延迟移除，等待退出动画完成
      setTimeout(() => {
        const currentIndex = state.queue.findIndex((t) => t.id === id);
        if (currentIndex > -1) {
          state.queue.splice(currentIndex, 1);
          // 在退出动画完成后重新计算位置
          calculateToastPositions();
        }
      }, 300); // 与动画持续时间保持一致
    }
  }
  clearTimer(id);
}

// 添加 Toast
export function addToast(options: string | ToastOptions): ToastInstance {
  const mergedOptions = mergeOptions(options);
  const id = generateId();

  // 如果不允许多个 Toast，清除现有的
  if (!state.allowMultiple) {
    clearToast();
  }

  // 创建 Toast 对象（初始时不可见）
  const toastOptions: ToastWithPosition = {
    ...mergedOptions,
    id,
    visible: false, // 初始时不可见，等位置计算完成后再显示
    height: TOAST_CONFIG.height, // 默认高度，后续可以通过 DOM 获取实际高度
    onClose: () => {
      removeFromQueue(id);
      mergedOptions.onClose?.();
    },
    onOpened: () => {
      mergedOptions.onOpened?.();
    },
  };

  // 添加到队列
  state.queue.push(toastOptions);

  // 立即计算位置（使用估算高度）
  calculateToastPositions();

  // 设置为可见以触发动画
  const toast = state.queue.find((t) => t.id === id);
  if (toast) {
    toast.visible = true;
  }

  // 在下一个 tick 中获取实际高度并重新计算（仅一次）
  nextTick(() => {
    const element = document.querySelector(`[data-toast-id="${id}"]`) as HTMLElement;
    if (element) {
      const actualHeight = element.getBoundingClientRect().height;
      if (actualHeight > 0 && Math.abs(actualHeight - (toastOptions.height || TOAST_CONFIG.height)) > 5) {
        toastOptions.height = actualHeight;
        calculateToastPositions();
      }
    }
  });

  // 设置自动关闭
  if (mergedOptions.duration && mergedOptions.duration > 0) {
    const timer = setTimeout(() => {
      removeFromQueue(id);
      mergedOptions.onClose?.();
    }, mergedOptions.duration);
    timers.set(id, timer);
  }

  // 调用打开回调
  mergedOptions.onOpened?.();

  // 返回 Toast 实例
  const instance: ToastInstance = {
    id,
    message: mergedOptions.message || '',
    close: () => removeFromQueue(id),
    clear: () => clearToast(),
  };

  return instance;
}

// 清除 Toast
export function clearToast(all = true) {
  if (all) {
    // 清除所有定时器
    timers.forEach((timer) => clearTimeout(timer));
    timers.clear();
    // 清空队列
    state.queue.length = 0;
  } else {
    // 只清除最后一个
    const lastToast = state.queue[state.queue.length - 1];
    if (lastToast) {
      removeFromQueue(lastToast.id);
    }
  }
}

// 设置默认选项
export function setDefaultOptions(options: ToastOptions) {
  Object.assign(state.defaultOptions, options);
}

// 重置默认选项
export function resetDefaultOptions() {
  Object.assign(state.defaultOptions, defaultToastOptions);
}

// 允许多个 Toast
export function allowMultiple(allow = true) {
  state.allowMultiple = allow;
}

// 导出 hook
export function useToastStore() {
  return {
    state: readonly(state),
    addToast,
    clearToast,
    setDefaultOptions,
    resetDefaultOptions,
    allowMultiple,
  };
}

// 导出只读状态
export const toastState = readonly(state);
