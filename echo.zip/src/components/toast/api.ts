import { addToast, allowMultiple, clearToast, resetDefaultOptions, setDefaultOptions } from './store';
import type { ToastInstance, ToastMethod, ToastOptions } from './types';

// 创建 Toast 方法
function createToastMethod(): ToastMethod {
  const toast = ((options: string | ToastOptions): ToastInstance => {
    return addToast(options);
  }) as ToastMethod;

  // 文本 Toast
  toast.text = (message: string, options?: Omit<ToastOptions, 'type'>): ToastInstance => {
    return addToast({ ...options, type: 'text', message });
  };

  // 加载 Toast <mcreference link="https://develop365.gitlab.io/vant/en-US/toast/" index="1">1</mcreference>
  toast.loading = (message = 'Loading...', options?: Omit<ToastOptions, 'type'>): ToastInstance => {
    return addToast({
      ...options,
      type: 'loading',
      message,
      duration: 0, // 加载状态默认不自动关闭
      forbidClick: true, // 加载时禁止点击
    });
  };

  // 成功 Toast <mcreference link="https://develop365.gitlab.io/vant/en-US/toast/" index="1">1</mcreference>
  toast.success = (message: string, options?: Omit<ToastOptions, 'type'>): ToastInstance => {
    return addToast({ ...options, type: 'success', message });
  };

  // 失败 Toast <mcreference link="https://develop365.gitlab.io/vant/en-US/toast/" index="1">1</mcreference>
  toast.fail = (message: string, options?: Omit<ToastOptions, 'type'>): ToastInstance => {
    return addToast({ ...options, type: 'fail', message });
  };

  // HTML Toast <mcreference link="https://develop365.gitlab.io/vant/en-US/toast/" index="1">1</mcreference>
  toast.html = (message: string, options?: Omit<ToastOptions, 'type'>): ToastInstance => {
    return addToast({ ...options, type: 'html', message });
  };

  // 清除 Toast <mcreference link="https://develop365.gitlab.io/vant/en-US/toast/" index="1">1</mcreference>
  toast.clear = (all = true): void => {
    clearToast(all);
  };

  // 设置默认选项 <mcreference link="https://develop365.gitlab.io/vant/en-US/toast/" index="1">1</mcreference>
  toast.setDefaultOptions = (options: ToastOptions): void => {
    setDefaultOptions(options);
  };

  // 重置默认选项 <mcreference link="https://develop365.gitlab.io/vant/en-US/toast/" index="1">1</mcreference>
  toast.resetDefaultOptions = (): void => {
    resetDefaultOptions();
  };

  // 允许多个 Toast <mcreference link="https://develop365.gitlab.io/vant/en-US/toast/" index="1">1</mcreference>
  toast.allowMultiple = (allow = true): void => {
    allowMultiple(allow);
  };

  return toast;
}

// 导出 Toast 实例
export const Toast = createToastMethod();

// 导出快捷方法 - 兼容 Vant API <mcreference link="https://develop365.gitlab.io/vant/en-US/toast/" index="1">1</mcreference>
export const showToast = Toast;
export const showLoadingToast = Toast.loading;
export const showSuccessToast = Toast.success;
export const showFailToast = Toast.fail;
export const closeToast = Toast.clear;
export const setToastDefaultOptions = Toast.setDefaultOptions;
export const resetToastDefaultOptions = Toast.resetDefaultOptions;
export const allowMultipleToast = Toast.allowMultiple;

// 默认导出
export default Toast;
