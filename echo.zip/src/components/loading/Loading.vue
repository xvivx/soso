<script setup lang="ts">
import { computed } from 'vue';
import { cva } from 'class-variance-authority';
import { useLocale } from '@/locale';
import { cn } from '@/utils';
import type { ExtendedLoadingProps, InternalLoadingSize } from './types';
// Import component-specific styles
import './styles/index.css';

defineOptions({
  name: 'HTLoading',
});

type Props = ExtendedLoadingProps;

// 兼容 Vant API 的默认值
const props = withDefaults(defineProps<Props>(), {
  type: 'circular',
  size: '30px',
  color: '',
  textSize: '',
  textColor: '',
  vertical: false,
  text: '',
  textAlign: 'center',
});

// 获取国际化函数
const { t } = useLocale();

// 计算本地化文本,优先使用 prop,其次使用 locale 配置
const computedText = computed(() => {
  if (props.text) return props.text;
  return t('htLoading.loading', '加载中...');
});

// 工具函数：将 Vant 兼容的尺寸转换为内部尺寸
const convertSize = (size: string | number): InternalLoadingSize => {
  const sizeStr = typeof size === 'number' ? `${size}px` : size;
  const num = parseInt(sizeStr);

  if (num <= 16) return 'small';
  if (num >= 32) return 'large';
  return 'default';
};

// 工具函数：将尺寸转换为像素值
const sizeToPixels = (size: string | number): number => {
  if (typeof size === 'number') return size;
  return parseInt(size) || 30;
};

// 工具函数：根据颜色值返回颜色类型
const getColorType = (color: string): string => {
  if (!color) return 'primary';

  // 检查是否为已知的语义化颜色
  const colorMap: Record<string, string> = {
    '#1677ff': 'primary',
    '#1989fa': 'primary',
    '#4096ff': 'primary',
    '#52c41a': 'success',
    '#07c160': 'success',
    '#16b364': 'success',
    '#faad14': 'warning',
    '#ff976a': 'warning',
    '#f04438': 'warning',
    '#ee0a24': 'danger',
    '#ff4d4f': 'danger',
    '#f5222d': 'danger',
    '#8c8c8c': 'gray',
    '#999': 'gray',
    '#666': 'gray',
  };

  return colorMap[color.toLowerCase()] || 'custom';
};

// CVA variants for loading component
const variants = cva('ht-loading inline-flex items-center', {
  variants: {
    size: {
      small: 'ht-loading--gap-small',
      default: 'ht-loading--gap-default',
      large: 'ht-loading--gap-large',
    },
    vertical: {
      true: 'ht-loading--vertical',
      false: 'ht-loading--horizontal',
    },
    textAlign: {
      left: 'ht-loading--text-left',
      center: 'ht-loading--text-center',
      right: 'ht-loading--text-right',
    },
  },
  defaultVariants: {
    size: 'default',
    vertical: false,
    textAlign: 'center',
  },
});

// 计算内部尺寸
const internalSize = computed<InternalLoadingSize>(() => {
  return convertSize(props.size || '30px');
});

// 计算图标尺寸（像素值）
const spinnerSize = computed(() => {
  return sizeToPixels(props.size || '30px');
});

// 计算文本尺寸（像素值）
const textSize = computed(() => {
  if (props.textSize) {
    return sizeToPixels(props.textSize);
  }
  // 基于spinner尺寸自动调整文本大小
  const baseSize = spinnerSize.value;
  return Math.max(baseSize * 0.6, 12);
});

// 计算图标颜色
const spinnerColor = computed(() => {
  if (props.color) return props.color;

  // 使用组件专用的 token
  return 'var(--loading-spinner-color-default)';
});

// 计算文本颜色
const textColor = computed(() => {
  if (props.textColor) return props.textColor;
  if (props.color) return props.color;
  return 'var(--loading-text-color-default)';
});

// 计算容器样式
const containerStyle = computed(() => {
  const style: Record<string, string> = {};

  // 设置自定义颜色
  if (props.color && !props.textColor) {
    style.color = props.color;
  }

  return style;
});

// 计算容器类
const containerClass = computed(() => {
  return cn(
    variants({
      size: internalSize.value,
      vertical: props.vertical,
      textAlign: props.textAlign,
    }),
    'ht-loading',
    props.class
  );
});

// 计算图标样式
const iconStyle = computed(() => {
  return {
    width: `${spinnerSize.value}px`,
    height: `${spinnerSize.value}px`,
    color: spinnerColor.value,
  };
});

// 计算文本样式
const textStyle = computed(() => {
  const style: Record<string, string> = {
    fontSize: `${textSize.value}px`,
    color: textColor.value,
  };

  // 边距由 CSS 中的布局类处理，不需要内联样式
  return style;
});
</script>

<template>
  <div
    :class="containerClass"
    :style="containerStyle"
    :data-size="internalSize"
    :data-color="getColorType(props.color)"
    role="status"
    aria-live="polite"
    aria-busy="true"
    :aria-label="computedText || 'Loading'"
  >
    <!-- Loading Icon -->
    <div class="ht-loading__icon flex-shrink-0">
      <!-- Default slot for custom icon -->
      <slot name="icon">
        <!-- Circular type - Vant 兼容 -->
        <svg v-if="type === 'circular'" class="ht-loading__circular" viewBox="25 25 50 50" :style="iconStyle">
          <circle cx="50" cy="50" r="20" fill="none" :stroke="spinnerColor" />
        </svg>

        <!-- Spinner type - Vant 兼容（12条线） -->
        <span v-else-if="type === 'spinner'" class="ht-loading__spinner" :style="iconStyle" data-testid="loader-icon">
          <i v-for="index in 12" :key="index" class="ht-loading__line" :data-index="index" />
        </span>
      </slot>
    </div>

    <!-- Loading Text -->
    <div v-if="computedText || $slots.default" class="ht-loading__text flex-shrink-0" :style="textStyle">
      <slot>{{ computedText }}</slot>
    </div>
  </div>
</template>
