// 兼容 Vant API 的类型定义
export type LoadingType = 'circular' | 'spinner';
export type LoadingSize = string | number | null | undefined;
export type LoadingColor = string;

// Vant 兼容的 Props 接口
export interface LoadingProps {
  /**
   * 加载类型 - 兼容 Vant API
   * @default 'circular'
   */
  type?: LoadingType;

  /**
   * 加载图标大小 - 兼容 Vant API (支持数字或字符串)
   * @default '30px'
   */
  size?: LoadingSize;

  /**
   * 自定义颜色 - 兼容 Vant API
   */
  color?: LoadingColor;

  /**
   * 加载文本大小 - 兼容 Vant API
   */
  textSize?: LoadingSize;

  /**
   * 文本颜色 - 兼容 Vant API
   */
  textColor?: LoadingColor;

  /**
   * 是否垂直排列 - 兼容 Vant API
   * @default false
   */
  vertical?: boolean;

  /**
   * 自定义类名
   */
  class?: string;
}

// 内部使用的类型
export type InternalLoadingSize = 'small' | 'default' | 'large';
export type InternalLoadingColor = 'primary' | 'gray';
export type TextAlign = 'left' | 'center' | 'right';

// 扩展接口用于内部实现
export interface ExtendedLoadingProps extends LoadingProps {
  /**
   * 加载文本 (内部扩展)
   */
  text?: string;

  /**
   * 文本对齐方式 (内部扩展)
   * @default 'center'
   */
  textAlign?: TextAlign;
}
