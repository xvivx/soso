# HTLoading 加载组件

基于 shadcn-vue 实现，完全兼容 Vant Loading 组件 API 的加载动画组件。

## 特性

- ✅ 完全兼容 Vant Loading API
- ✅ 支持两种加载动画类型：circular（圆形）和 spinner（旋转器）
- ✅ 响应式设计，支持多种尺寸
- ✅ 支持自定义颜色和文本样式
- ✅ 支持垂直和水平布局
- ✅ 完整的无障碍支持
- ✅ 深色模式支持
- ✅ 使用项目设计 token，确保主题一致性

## API

### Props

| 参数      | 说明         | 类型                            | 默认值       | Vant 兼容 |
| --------- | ------------ | ------------------------------- | ------------ | --------- |
| type      | 加载类型     | `'circular' \| 'spinner'`       | `'circular'` | ✅        |
| size      | 加载图标大小 | `string \| number`              | `'30px'`     | ✅        |
| color     | 自定义颜色   | `string`                        | `''`         | ✅        |
| textSize  | 文本大小     | `string \| number`              | `''`         | ✅        |
| textColor | 文本颜色     | `string`                        | `''`         | ✅        |
| vertical  | 是否垂直排列 | `boolean`                       | `false`      | ✅        |
| text      | 加载文本     | `string`                        | `''`         | ✅        |
| textAlign | 文本对齐方式 | `'left' \| 'center' \| 'right'` | `'center'`   | ✅        |
| class     | 自定义类名   | `string`                        | `''`         | ✅        |

### Slots

| 名称    | 说明                         | 参数 |
| ------- | ---------------------------- | ---- |
| default | 默认内容，用于自定义加载文本 | -    |
| icon    | 自定义图标插槽               | -    |

## 使用示例

### 基础用法

```vue
<template>
  <!-- 默认 circular 类型 -->
  <HTLoading />

  <!-- spinner 类型 -->
  <HTLoading type="spinner" />

  <!-- 带文本 -->
  <HTLoading text="加载中..." />

  <!-- 垂直布局 -->
  <HTLoading text="加载中..." vertical />
</template>
```

### 自定义样式

```vue
<template>
  <!-- 自定义尺寸 -->
  <HTLoading size="48px" text="大号加载" />

  <!-- 自定义颜色 -->
  <HTLoading color="#ff4d4f" text="危险加载" />

  <!-- 自定义文本样式 -->
  <HTLoading text="自定义文本" textSize="18px" textColor="#1677ff" color="#52c41a" />
</template>
```

### 完整 Vant 兼容用法

```vue
<template>
  <HTLoading
    type="circular"
    size="30px"
    color="#1677ff"
    textSize="14px"
    textColor="#333"
    vertical="{false}"
    text="加载中..."
    textAlign="center"
    class="custom-loading"
  />
</template>
```

### 自定义图标

```vue
<template>
  <HTLoading text="自定义图标加载">
    <template #icon>
      <div class="h-6 w-6 animate-spin rounded-full border-b-2 border-blue-500"></div>
    </template>
  </HTLoading>
</template>
```

## 设计 Token

组件使用项目的设计 token 系统，确保与整体设计风格保持一致：

### 尺寸 Token

```css
:root {
  --loading-spinner-size-default: var(--dimensions-sizing-icon-md, 24px);
  --loading-spinner-size-small: var(--dimensions-sizing-icon-sm, 16px);
  --loading-spinner-size-large: var(--dimensions-sizing-icon-lg, 32px);
}
```

### 颜色 Token

```css
:root {
  --loading-spinner-color-default: var(--color-brand-fill, #1677ff);
  --loading-text-color-default: var(--color-content-tertiary, #8c8c8c);
}
```

### 动画 Token

```css
:root {
  --loading-spinner-animation-duration: 0.8s;
}
```

## 无障碍支持

- **ARIA 属性**：自动添加 `role="status"`、`aria-live="polite"`、`aria-busy="true"`
- **屏幕阅读器**：支持自定义 `aria-label`
- **减少动画**：支持 `prefers-reduced-motion` 媒体查询
- **高对比度**：支持 `prefers-contrast: high` 媒体查询

## 响应式设计

组件支持响应式设计，在小屏幕设备上会自动调整大小：

```css
@media (max-width: 768px) {
  .ht-loading {
    --loading-spinner-size: min(var(--loading-spinner-size-default, 24px), 20px);
    --loading-text-font-size: min(var(--loading-text-font-size-default, 12px), 11px);
  }
}
```

## 深色模式支持

组件自动适配深色模式：

```css
@media (prefers-color-scheme: dark) {
  .ht-loading {
    --loading-spinner-color-default: var(--color-brand-fill, #4096ff);
    --loading-text-color-default: var(--color-content-secondary, rgba(255, 255, 255, 0.6));
  }
}
```

## 与 Vant 的差异

虽然完全兼容 Vant API，但有以下改进：

1. **更好的 TypeScript 支持**：完整的类型定义
2. **设计 Token 集成**：使用项目统一的设计系统
3. **无障碍增强**：更好的屏幕阅读器支持
4. **响应式优化**：移动端自动适配
5. **深色模式**：自动主题切换支持

## 最佳实践

1. **尺寸选择**：根据使用场景选择合适的尺寸
   - 按钮内：使用 16px
   - 表单内：使用 20px
   - 页面级：使用 30px 或更大

2. **文本描述**：提供清晰的加载状态描述

   ```vue
   <HTLoading text="正在上传文件，请稍候..." />
   ```

3. **颜色使用**：遵循设计系统的颜色规范

   ```vue
   <!-- 主色用于正常操作 -->
   <HTLoading color="var(--color-brand-fill)" />

   <!-- 危险色用于删除等操作 -->
   <HTLoading color="var(--color-feedback-warning-content)" />
   ```

4. **无障碍考虑**：为复杂加载场景提供更详细的描述
   ```vue
   <HTLoading text="处理中" :aria-label="'正在处理 ' + itemCount + ' 个项目'" />
   ```
