export { default as HTLoading } from './Loading.vue';
export type {
  LoadingProps,
  LoadingType,
  LoadingSize,
  LoadingColor,
  TextAlign,
  InternalLoadingSize,
  InternalLoadingColor,
  ExtendedLoadingProps,
} from './types';
