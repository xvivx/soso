import { nextTick } from 'vue';
import { mount } from '@vue/test-utils';
import { describe, expect, it } from 'vitest';
import HTLoading from '../Loading.vue';

describe('HTLoading', () => {
  describe('基础功能', () => {
    it('应该正确渲染默认的 circular 加载器', () => {
      const wrapper = mount(HTLoading);

      expect(wrapper.find('.ht-loading').exists()).toBe(true);
      expect(wrapper.find('.ht-loading__circular').exists()).toBe(true);
      expect(wrapper.find('svg').exists()).toBe(true);
    });

    it('应该响应 type 属性变化', async () => {
      const wrapper = mount(HTLoading, {
        props: { type: 'spinner' },
      });

      expect(wrapper.find('.ht-loading__circular').exists()).toBe(false);
      // 检查是否存在 spinner 元素
      expect(wrapper.find('.ht-loading__spinner').exists()).toBe(true);
    });

    it('应该显示加载文本', () => {
      const wrapper = mount(HTLoading, {
        props: { text: '加载中...' },
      });

      expect(wrapper.text()).toContain('加载中...');
      expect(wrapper.find('.ht-loading__text').exists()).toBe(true);
    });

    it('应该支持插槽内容', () => {
      const wrapper = mount(HTLoading, {
        slots: {
          default: '自定义加载文本',
        },
      });

      expect(wrapper.text()).toContain('自定义加载文本');
    });

    it('应该支持自定义图标插槽', () => {
      const wrapper = mount(HTLoading, {
        slots: {
          icon: '<div class="custom-icon">⚡</div>',
        },
      });

      expect(wrapper.find('.custom-icon').exists()).toBe(true);
      expect(wrapper.text()).toContain('⚡');
    });
  });

  describe('Props 测试', () => {
    it('应该正确应用 size 属性', () => {
      const wrapper = mount(HTLoading, {
        props: { size: '48px' },
      });

      const svg = wrapper.find('svg.ht-loading__circular');
      expect(svg.attributes('style')).toContain('width: 48px');
      expect(svg.attributes('style')).toContain('height: 48px');
    });

    it('应该支持数字形式的 size', () => {
      const wrapper = mount(HTLoading, {
        props: { size: 24 },
      });

      const svg = wrapper.find('svg.ht-loading__circular');
      expect(svg.attributes('style')).toContain('width: 24px');
      expect(svg.attributes('style')).toContain('height: 24px');
    });

    it('应该正确应用 color 属性', () => {
      const wrapper = mount(HTLoading, {
        props: { color: '#ff0000' },
      });

      const circle = wrapper.find('circle');
      expect(circle.attributes('stroke')).toBe('#ff0000');
    });

    it('应该正确应用 vertical 属性', () => {
      const wrapper = mount(HTLoading, {
        props: { vertical: true, text: '测试' },
      });

      expect(wrapper.find('.ht-loading').classes()).toContain('ht-loading--vertical');
    });

    it('应该正确应用 textAlign 属性', () => {
      const wrapper = mount(HTLoading, {
        props: { textAlign: 'right', text: '测试' },
      });

      expect(wrapper.find('.ht-loading').classes()).toContain('ht-loading--text-right');
    });

    it('应该正确应用 textSize 属性', () => {
      const wrapper = mount(HTLoading, {
        props: { textSize: '18px', text: '测试' },
      });

      const text = wrapper.find('.ht-loading__text');
      expect(text.attributes('style')).toContain('font-size: 18px');
    });

    it('应该正确应用 textColor 属性', () => {
      const wrapper = mount(HTLoading, {
        props: { textColor: '#00ff00', text: '测试' },
      });

      const text = wrapper.find('.ht-loading__text');
      expect(text.attributes('style')).toContain('color: rgb(0, 255, 0)'); // CSS 会转换颜色格式
    });

    it('应该正确应用自定义 class', () => {
      const wrapper = mount(HTLoading, {
        props: { class: 'custom-loading-class' },
      });

      expect(wrapper.find('.ht-loading').classes()).toContain('custom-loading-class');
    });
  });

  describe('Vant 兼容性测试', () => {
    it('应该支持 Vant 的默认 API', () => {
      const wrapper = mount(HTLoading, {
        props: {
          type: 'circular',
          size: '30px',
          color: '#1989fa',
          textSize: '14px',
          textColor: '#333333',
          vertical: false,
          text: '加载中',
          textAlign: 'center',
        },
      });

      expect(wrapper.find('.ht-loading__circular').exists()).toBe(true);
      expect(wrapper.text()).toContain('加载中');
      expect(wrapper.find('.ht-loading').classes()).toContain('ht-loading--horizontal');
    });

    it('应该支持 Vant 的尺寸规范', () => {
      const testSizes = ['16px', '20px', '24px', '30px', '40px'];

      testSizes.forEach((size) => {
        const wrapper = mount(HTLoading, {
          props: { size },
        });

        const svg = wrapper.find('svg.ht-loading__circular');
        const expectedSize = parseInt(size);
        expect(svg.attributes('style')).toContain(`width: ${expectedSize}px`);
        expect(svg.attributes('style')).toContain(`height: ${expectedSize}px`);
      });
    });

    it('应该支持 Vant 的颜色规范', () => {
      const vantColors = {
        primary: '#1989fa',
        success: '#07c160',
        warning: '#ff976a',
        danger: '#ee0a24',
      };

      Object.entries(vantColors).forEach(([, color]) => {
        const wrapper = mount(HTLoading, {
          props: { color },
        });

        const circle = wrapper.find('circle');
        expect(circle.attributes('stroke')).toBe(color);
      });
    });
  });

  describe('响应式和动态行为', () => {
    it('应该响应 props 变化', async () => {
      const wrapper = mount(HTLoading, {
        props: { size: '20px', color: '#ff0000' },
      });

      let svg = wrapper.find('svg.ht-loading__circular');
      let circle = wrapper.find('circle');
      expect(svg.attributes('style')).toContain('width: 20px');
      expect(circle.attributes('stroke')).toBe('#ff0000');

      await wrapper.setProps({ size: '40px', color: '#00ff00' });
      await nextTick();

      svg = wrapper.find('svg.ht-loading__circular');
      circle = wrapper.find('circle');
      expect(svg.attributes('style')).toContain('width: 40px');
      expect(circle.attributes('stroke')).toBe('#00ff00');
    });

    it('应该响应文本变化', async () => {
      const wrapper = mount(HTLoading, {
        props: { text: '初始文本' },
      });

      expect(wrapper.text()).toContain('初始文本');

      await wrapper.setProps({ text: '更新文本' });
      await nextTick();

      expect(wrapper.text()).toContain('更新文本');
    });

    it('应该响应布局变化', async () => {
      const wrapper = mount(HTLoading, {
        props: { vertical: false, text: '测试' },
      });

      expect(wrapper.find('.ht-loading').classes()).toContain('ht-loading--horizontal');

      await wrapper.setProps({ vertical: true });
      await nextTick();

      expect(wrapper.find('.ht-loading').classes()).toContain('ht-loading--vertical');
    });
  });

  describe('样式计算', () => {
    it('应该正确计算内部尺寸分类', () => {
      const testCases = [
        { input: '12px', expected: 'small' },
        { input: '16px', expected: 'small' },
        { input: '20px', expected: 'default' },
        { input: '30px', expected: 'default' },
        { input: '40px', expected: 'large' },
        { input: 15, expected: 'small' },
        { input: 25, expected: 'default' },
        { input: 35, expected: 'large' },
      ];

      testCases.forEach(({ input, expected }) => {
        const wrapper = mount(HTLoading, {
          props: { size: input },
        });

        // 检查 gap 类是否正确应用
        if (expected === 'small') {
          expect(wrapper.find('.ht-loading').classes()).toContain('ht-loading--gap-small');
        } else if (expected === 'default') {
          expect(wrapper.find('.ht-loading').classes()).toContain('ht-loading--gap-default');
        } else if (expected === 'large') {
          expect(wrapper.find('.ht-loading').classes()).toContain('ht-loading--gap-large');
        }
      });
    });

    it('应该正确计算文本大小', () => {
      const wrapper = mount(HTLoading, {
        props: { size: '30px', textSize: '16px', text: '测试' },
      });

      const text = wrapper.find('.ht-loading__text');
      expect(text.attributes('style')).toContain('font-size: 16px');
    });

    it('应该在没有自定义 textSize 时自动计算', () => {
      const wrapper = mount(HTLoading, {
        props: { size: '30px', text: '测试' },
      });

      const text = wrapper.find('.ht-loading__text');
      // 30px * 0.6 = 18px，但最小值为 12px
      expect(text.attributes('style')).toContain('font-size: 18px');
    });
  });

  describe('无障碍测试', () => {
    it('应该有正确的 ARIA 属性', () => {
      const wrapper = mount(HTLoading, {
        props: { text: '加载中' },
      });

      const container = wrapper.find('.ht-loading');
      expect(container.attributes('role')).toBe('status');
      expect(container.attributes('aria-live')).toBe('polite');
      expect(container.attributes('aria-busy')).toBe('true');
      expect(container.attributes('aria-label')).toBe('加载中');
    });

    it('应该支持自定义 aria-label', async () => {
      const wrapper = mount(HTLoading, {
        props: { text: 'Loading' },
        attrs: { 'aria-label': 'Custom loading message' },
      });

      expect(wrapper.find('.ht-loading').attributes('aria-label')).toBe('Custom loading message');
    });

    it('应该在没有文本时提供默认 aria-label', () => {
      const wrapper = mount(HTLoading);

      // 根据实际的组件实现，默认文本是 "加载中..." 而不是 "Loading"
      expect(wrapper.find('.ht-loading').attributes('aria-label')).toBe('加载中...');
    });
  });

  describe('错误处理', () => {
    it('应该处理无效的尺寸值', () => {
      const wrapper = mount(HTLoading, {
        props: { size: 'invalid' },
      });

      // 应该回退到默认值 30px
      const svg = wrapper.find('svg.ht-loading__circular');
      expect(svg.attributes('style')).toContain('width: 30px');
    });

    it('应该处理空的 size 值', () => {
      const wrapper = mount(HTLoading, {
        props: { size: '' },
      });

      // 应该回退到默认值 30px
      const svg = wrapper.find('svg.ht-loading__circular');
      expect(svg.attributes('style')).toContain('width: 30px');
    });

    it('应该处理 null 或 undefined 的 props', () => {
      const wrapper = mount(HTLoading, {
        props: {
          size: null,
          color: undefined,
          textSize: null,
          textColor: undefined,
        },
      });

      expect(wrapper.find('.ht-loading').exists()).toBe(true);
      // 默认情况下应该使用默认尺寸
      const svg = wrapper.find('svg.ht-loading__circular');
      expect(svg.attributes('style')).toContain('width: 30px');
    });
  });

  describe('样式类应用', () => {
    it('应该正确应用所有相关的 CVA 类', () => {
      const wrapper = mount(HTLoading, {
        props: {
          size: '40px',
          vertical: true,
          textAlign: 'right',
          text: '测试',
          class: 'extra-class',
        },
      });

      const container = wrapper.find('.ht-loading');
      expect(container.classes()).toContain('ht-loading');
      expect(container.classes()).toContain('inline-flex');
      expect(container.classes()).toContain('items-center');
      expect(container.classes()).toContain('ht-loading--gap-large'); // large size
      expect(container.classes()).toContain('ht-loading--vertical'); // vertical
      expect(container.classes()).toContain('ht-loading--text-right'); // right align
      expect(container.classes()).toContain('extra-class');
    });
  });
});
