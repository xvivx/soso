<script setup lang="ts">
import { computed, useSlots, type CSSProperties } from 'vue';
import { addUnit } from '@/utils/index';
import type { EmptyProps } from './types';

const props = withDefaults(defineProps<EmptyProps>(), {
  description: '',
});

const slots = useSlots();
const hasDefaultSlot = !!slots.default;
const hasDescriptionSlot = !!slots.description;

const imgSizeStyle = computed<CSSProperties>(() => {
  const style: CSSProperties = {};
  const val = props.imageSize;
  if (Array.isArray(val)) {
    const [w, h] = val;
    style.width = addUnit(w);
    style.height = addUnit(h);
  } else {
    const size = addUnit(val);
    style.width = size;
    style.height = size;
  }
  return style;
});
</script>

<template>
  <div class="ht-empty flex flex-col items-center text-center">
    <div
      class="ht-empty__icon inline-flex items-center justify-center [&_img]:block [&_img]:h-full [&_img]:w-full [&_svg]:block [&_svg]:h-full [&_svg]:w-full"
      :style="imgSizeStyle"
    >
      <slot name="image">
        <template v-if="props.image">
          <img :src="props.image" alt="empty" />
        </template>
        <template v-else>
          <svg
            t="1761059161502"
            class="icon"
            viewBox="0 0 1024 1024"
            version="1.1"
            xmlns="http://www.w3.org/2000/svg"
            p-id="8492"
            width="200"
            height="200"
          >
            <path
              d="M855.6 427.2H168.5c-12.7 0-24.4 6.9-30.6 18L4.4 684.7C1.5 689.9 0 695.8 0 701.8v287.1c0 19.4 15.7 35.1 35.1 35.1H989c19.4 0 35.1-15.7 35.1-35.1V701.8c0-6-1.5-11.8-4.4-17.1L886.2 445.2c-6.2-11.1-17.9-18-30.6-18zM673.4 695.6c-16.5 0-30.8 11.5-34.3 27.7-12.7 58.5-64.8 102.3-127.2 102.3s-114.5-43.8-127.2-102.3c-3.5-16.1-17.8-27.7-34.3-27.7H119c-26.4 0-43.3-28-31.1-51.4l81.7-155.8c6.1-11.6 18-18.8 31.1-18.8h622.4c13 0 25 7.2 31.1 18.8l81.7 155.8c12.2 23.4-4.7 51.4-31.1 51.4H673.4zM819.9 209.5c-1-1.8-2.1-3.7-3.2-5.5-9.8-16.6-31.1-22.2-47.8-12.6L648.5 261c-17 9.8-22.7 31.6-12.6 48.4 0.9 1.4 1.7 2.9 2.5 4.4 9.5 17 31.2 22.8 48 13L807 257.3c16.7-9.7 22.4-31 12.9-47.8zM375.4 261.1L255 191.6c-16.7-9.6-38-4-47.8 12.6-1.1 1.8-2.1 3.6-3.2 5.5-9.5 16.8-3.8 38.1 12.9 47.8L337.3 327c16.9 9.7 38.6 4 48-13.1 0.8-1.5 1.7-2.9 2.5-4.4 10.2-16.8 4.5-38.6-12.4-48.4zM512 239.3h2.5c19.5 0.3 35.5-15.5 35.5-35.1v-139c0-19.3-15.6-34.9-34.8-35.1h-6.4C489.6 30.3 474 46 474 65.2v139c0 19.5 15.9 35.4 35.5 35.1h2.5z"
              p-id="8493"
              fill="#8a8a8a"
            ></path>
          </svg>
        </template>
      </slot>
    </div>

    <div class="ht-empty__description" v-if="hasDescriptionSlot || props.description">
      <slot name="description">{{ props.description }}</slot>
    </div>

    <div class="ht-empty__footer" v-if="hasDefaultSlot">
      <slot />
    </div>
  </div>
</template>

<style>
:root {
  /** 容器 */
  --empty-container-padding-default: 32px 16px; /** 容器默认内边距 */
  --empty-container-bg-color-default: #ffffff; /** 容器默认背景色 */
  /** 图标 */
  --empty-icon-size-default: 100px; /** 空状态图标默认尺寸 */
  --empty-icon-color-default: #e5e6eb; /** 空状态图标默认颜色 */
  /** 文本 */
  --empty-text-font-size-default: 14px; /** 空状态文本默认字号 */
  --empty-text-color-default: #8c8c8c; /** 空状态文本默认颜色 */
  --empty-text-margin-default: 16px 0 0; /** 空状态文本默认外边距 */
  /** 底部 */
  --empty-footer-margin-default: 24px 0 0; /** 空状态底部默认外边距 */
}

@layer components {
  .ht-empty {
    background-color: var(--empty-container-bg-color-default);
    padding: var(--empty-container-padding-default);
  }

  .ht-empty__icon {
    color: var(--empty-icon-color-default);
    width: var(--empty-icon-size-default);
    height: var(--empty-icon-size-default);
  }

  .ht-empty__description {
    margin: var(--empty-text-margin-default);
    color: var(--empty-text-color-default);
    font-size: var(--empty-text-font-size-default);
  }

  .ht-empty__footer {
    margin: var(--empty-footer-margin-default);
  }
}
</style>
