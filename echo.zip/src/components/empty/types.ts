export interface EmptyProps {
  image?: string;
  imageSize?: number | string | (number | string)[];
  title?: string;
  description?: string;
  buttonText?: string;
}
