export interface EmptyProps {
  image?: string;
  imageSize?: number | string | (number | string)[];
  description?: string;
}
