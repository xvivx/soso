import { screen } from '@testing-library/vue';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import { click, renderWithMounting } from '../../../../test/utils';
import HTEmpty from '../Empty.vue';

describe('HTEmpty', () => {
  beforeEach(() => {
    document.body.innerHTML = '';
  });

  describe('基础渲染', () => {
    it('应该渲染默认空状态', () => {
      const { container } = renderWithMounting(HTEmpty);

      const empty = container.querySelector('.ht-empty');
      expect(empty).toBeTruthy();
    });

    it('应该渲染默认图标', () => {
      const { container } = renderWithMounting(HTEmpty);

      const iconWrapper = container.querySelector('.ht-empty__icon');
      expect(iconWrapper).toBeTruthy();

      // 默认内容为 img 或 svg，任选其一存在即通过
      const img = container.querySelector('.ht-empty__icon img');
      const svg = container.querySelector('.ht-empty__icon svg');
      expect(img || svg).toBeTruthy();
    });

    it('应该根据 props 渲染 title', () => {
      renderWithMounting(HTEmpty, {
        props: {
          title: '暂无数据',
        },
      });

      expect(screen.getByText('暂无数据')).toBeTruthy();
    });

    it('应该根据 props 渲染 description', () => {
      renderWithMounting(HTEmpty, {
        props: {
          description: '当前没有任何内容',
        },
      });

      expect(screen.getByText('当前没有任何内容')).toBeTruthy();
    });
  });

  describe('插槽', () => {
    it('应该优先渲染 title 插槽内容', () => {
      renderWithMounting(HTEmpty, {
        props: {
          title: 'props 标题',
        },
        slots: {
          title: 'slot 标题',
        },
      });

      expect(screen.getByText('slot 标题')).toBeTruthy();
      expect(screen.queryByText('props 标题')).toBeNull();
    });

    it('应该优先渲染 description 插槽内容', () => {
      renderWithMounting(HTEmpty, {
        props: {
          description: 'props 描述',
        },
        slots: {
          description: 'slot 描述',
        },
      });

      expect(screen.getByText('slot 描述')).toBeTruthy();
      expect(screen.queryByText('props 描述')).toBeNull();
    });

    it('应该支持自定义 image 插槽', () => {
      renderWithMounting(HTEmpty, {
        slots: {
          image: '<div data-testid="custom-image">Custom Image</div>',
        },
      });

      expect(screen.getByTestId('custom-image')).toBeTruthy();
    });

    it('应该支持自定义 button 插槽', () => {
      renderWithMounting(HTEmpty, {
        props: {
          buttonText: '刷新',
        },
        slots: {
          button: '<button data-testid="custom-btn">自定义按钮</button>',
        },
      });

      expect(screen.getByTestId('custom-btn')).toBeTruthy();
      expect(screen.queryByText('刷新')).toBeNull();
    });

    it('默认插槽应作为 footer 渲染', () => {
      renderWithMounting(HTEmpty, {
        slots: {
          default: '<div data-testid="footer">Footer Content</div>',
        },
      });

      expect(screen.getByTestId('footer')).toBeTruthy();
    });
  });

  describe('按钮功能', () => {
    it('buttonText 应渲染按钮', () => {
      renderWithMounting(HTEmpty, {
        props: {
          buttonText: '刷新页面',
        },
      });

      const btn = screen.getByRole('button', { name: '刷新页面' });
      expect(btn).toBeTruthy();
    });

    it('点击按钮应触发 clickButton 事件', async () => {
      const handle = vi.fn();

      renderWithMounting(HTEmpty, {
        props: {
          buttonText: '刷新页面',
          onClickButton: handle,
        },
      });

      const btn = screen.getByRole('button', { name: '刷新页面' });
      await click(btn);

      expect(handle).toHaveBeenCalledTimes(1);
    });

    it('没有 buttonText 时不应渲染按钮', () => {
      const { container } = renderWithMounting(HTEmpty);

      const button = container.querySelector('button');
      expect(button).toBeNull();
    });
  });

  describe('图片尺寸', () => {
    it('imageSize 支持数字', () => {
      const { container } = renderWithMounting(HTEmpty, {
        props: {
          imageSize: 40,
        },
      });

      const icon = container.querySelector('.ht-empty__icon')!;
      const style = icon.getAttribute('style') || '';
      expect(style).toContain('40px');
    });

    it('imageSize 支持字符串', () => {
      const { container } = renderWithMounting(HTEmpty, {
        props: {
          imageSize: '100px',
        },
      });

      const icon = container.querySelector('.ht-empty__icon')!;
      const style = icon.getAttribute('style') || '';
      expect(style).toContain('100px');
    });

    it('imageSize 支持数组并单独设置宽高', () => {
      const { container } = renderWithMounting(HTEmpty, {
        props: {
          imageSize: [40, 50],
        },
      });

      const icon = container.querySelector('.ht-empty__icon')!;
      const style = icon.getAttribute('style') || '';
      expect(style).toContain('40px');
      expect(style).toContain('50px');
    });

    it('imageSize 数组支持字符串值', () => {
      const { container } = renderWithMounting(HTEmpty, {
        props: {
          imageSize: ['50px', '60px'],
        },
      });

      const icon = container.querySelector('.ht-empty__icon')!;
      const style = icon.getAttribute('style') || '';
      expect(style).toContain('50px');
      expect(style).toContain('60px');
    });
  });

  describe('自定义图片', () => {
    it('应该支持自定义图片 URL', () => {
      const { container } = renderWithMounting(HTEmpty, {
        props: {
          image: 'https://example.com/empty.png',
        },
      });

      const img = container.querySelector('.ht-empty__icon img') as HTMLImageElement;
      expect(img).toBeTruthy();
      expect(img.src).toContain('example.com/empty.png');
    });
  });

  describe('边界情况', () => {
    it('应该处理没有任何内容的情况', () => {
      const { container } = renderWithMounting(HTEmpty);

      const empty = container.querySelector('.ht-empty');
      expect(empty).toBeTruthy();
    });

    it('应该处理长文本 title', () => {
      const longTitle = 'A'.repeat(1000);
      renderWithMounting(HTEmpty, {
        props: {
          title: longTitle,
        },
      });

      expect(screen.getByText(longTitle)).toBeTruthy();
    });

    it('应该处理长文本 description', () => {
      const longDesc = 'B'.repeat(1000);
      renderWithMounting(HTEmpty, {
        props: {
          description: longDesc,
        },
      });

      expect(screen.getByText(longDesc)).toBeTruthy();
    });

    it('应该处理特殊字符', () => {
      const specialChars = '!@#$%^&*()_+-=[]{}|;:,.<>?';
      renderWithMounting(HTEmpty, {
        props: {
          title: specialChars,
          description: specialChars,
        },
      });

      const titles = screen.getAllByText(specialChars);
      expect(titles.length).toBeGreaterThanOrEqual(1);
    });
  });
});
