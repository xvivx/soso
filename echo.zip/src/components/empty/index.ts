export { default as HTEmpty } from './Empty.vue';
export type { EmptyProps } from './types';
