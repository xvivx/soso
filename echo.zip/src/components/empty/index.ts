import HTEmpty from './Empty.vue';

export { HTEmpty };
export default HTEmpty;
export type { EmptyProps } from './types';
