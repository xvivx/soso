import { nextTick } from 'vue';
import { mount } from '@vue/test-utils';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import HTPullRefresh from '../index.vue';
import type { HTPullRefreshInstance } from '../types';

describe('HTPullRefresh', () => {
  let wrapper: any;

  beforeEach(() => {
    wrapper = mount(HTPullRefresh, {
      slots: {
        default: '<div class="test-content">Test Content</div>',
      },
    });
  });

  afterEach(() => {
    wrapper?.unmount();
  });

  describe('基础功能', () => {
    it('应该正确渲染组件', () => {
      expect(wrapper.find('.ht-pull-refresh').exists()).toBe(true);
      expect(wrapper.find('.test-content').exists()).toBe(true);
    });

    it('应该正确应用自定义类名', () => {
      wrapper = mount(HTPullRefresh, {
        props: { className: 'custom-class' },
        slots: { default: '<div>Content</div>' },
      });

      expect(wrapper.find('.ht-pull-refresh').classes()).toContain('custom-class');
    });

    it('应该正确应用自定义样式', () => {
      const customStyle = 'background: red;';
      wrapper = mount(HTPullRefresh, {
        props: { style: customStyle },
        slots: { default: '<div>Content</div>' },
      });

      expect(wrapper.find('.ht-pull-refresh').attributes('style')).toContain(customStyle);
    });
  });

  describe('Props 测试', () => {
    it('应该正确处理disabled属性', () => {
      wrapper = mount(HTPullRefresh, {
        props: { disabled: true },
        slots: { default: '<div>Content</div>' },
      });

      expect(wrapper.find('.ht-pull-refresh--disabled').exists()).toBe(true);
    });

    it('应该使用自定义提示文字', () => {
      const customProps = {
        pullingText: '自定义下拉文字',
        loosingText: '自定义释放文字',
        loadingText: '自定义加载文字',
        successText: '自定义成功文字',
        errorText: '自定义错误文字',
      };

      wrapper = mount(HTPullRefresh, {
        props: customProps,
        slots: { default: '<div>Content</div>' },
      });

      expect(wrapper.vm.pullingText).toBe(customProps.pullingText);
      expect(wrapper.vm.loosingText).toBe(customProps.loosingText);
      expect(wrapper.vm.loadingText).toBe(customProps.loadingText);
      expect(wrapper.vm.successText).toBe(customProps.successText);
      expect(wrapper.vm.errorText).toBe(customProps.errorText);
    });

    it('应该使用默认配置值', () => {
      const wrapper = mount(HTPullRefresh, {
        slots: { default: '<div>Content</div>' },
      });

      const vm = wrapper.vm as any;
      expect(vm.disabled).toBe(false);
      expect(vm.pullDistance).toBe(50);
      expect(vm.successDuration).toBe(500);
      expect(vm.animationDuration).toBe(300);
    });
  });

  describe('状态管理', () => {
    it('应该有正确的初始状态', () => {
      const vm = wrapper.vm as any;
      expect(vm.status).toBe('normal');
      expect(vm.translateY).toBe(0);
      expect(vm.distance).toBe(0);
      expect(vm.isPulling).toBe(false);
    });

    it('应该正确触发status-change事件', async () => {
      const statusChangeSpy = vi.fn();
      wrapper = mount(HTPullRefresh, {
        props: { 'onStatusChange': statusChangeSpy },
        slots: { default: '<div>Content</div>' },
      });

      const vm = wrapper.vm as any;
      // setStatus 现在的签名是 (distance: number, isLoading?: boolean)
      vm.setStatus(30); // 设置距离为 30，小于 pullDistance 50，状态为 pulling

      await nextTick();
      expect(statusChangeSpy).toHaveBeenCalledWith('pulling');
      expect(vm.status).toBe('pulling');
      expect(vm.distance).toBe(30);
    });
  });

  describe('事件测试', () => {
    it('应该正确触发refresh事件', async () => {
      const refreshSpy = vi.fn();
      wrapper = mount(HTPullRefresh, {
        props: { 'onRefresh': refreshSpy },
        slots: { default: '<div>Content</div>' },
      });

      const vm = wrapper.vm as any;
      vm.triggerRefresh();

      await nextTick();
      expect(refreshSpy).toHaveBeenCalled();
      expect(vm.status).toBe('loading');
    });

    it('禁用状态下不应该触发refresh事件', async () => {
      const refreshSpy = vi.fn();
      wrapper = mount(HTPullRefresh, {
        props: {
          disabled: true,
          'onRefresh': refreshSpy,
        },
        slots: { default: '<div>Content</div>' },
      });

      const vm = wrapper.vm as any;
      vm.triggerRefresh();

      await nextTick();
      expect(refreshSpy).not.toHaveBeenCalled();
    });
  });

  describe('插槽测试', () => {
    it('应该渲染默认插槽内容', () => {
      wrapper = mount(HTPullRefresh, {
        slots: {
          default: '<div class="custom-content">Custom Content</div>',
        },
      });

      expect(wrapper.find('.custom-content').exists()).toBe(true);
      expect(wrapper.text()).toContain('Custom Content');
    });

    it('应该渲染状态插槽内容', async () => {
      wrapper = mount(HTPullRefresh, {
        slots: {
          default: '<div>Content</div>',
          loading: '<div class="custom-loading">自定义加载</div>',
          success: '<div class="custom-success">自定义成功</div>',
        },
      });

      // 强制设置状态为loading来测试插槽
      const vm = wrapper.vm as any;
      // setStatus(distance: number, isLoading?: boolean)
      vm.setStatus(50, true); // 设置为 loading 状态

      await nextTick();

      // 注意：由于组件的条件渲染逻辑，可能需要触发特定状态才能看到插槽
      expect(wrapper.find('.custom-loading').exists()).toBe(true);
    });
  });

  describe('方法测试', () => {
    it('triggerRefresh方法应该正确工作', async () => {
      const refreshSpy = vi.fn();
      wrapper = mount(HTPullRefresh, {
        props: { 'onRefresh': refreshSpy },
        slots: { default: '<div>Content</div>' },
      });

      const vm = wrapper.vm as HTPullRefreshInstance;
      vm.triggerRefresh();

      await nextTick();
      expect(vm.getStatus()).toBe('loading');
      expect(refreshSpy).toHaveBeenCalled();
    });

    it('complete方法应该正确处理成功状态', async () => {
      const vm = wrapper.vm as HTPullRefreshInstance;

      // 先设置为loading状态
      vm.triggerRefresh();

      // 调用complete
      vm.complete(true);

      await nextTick();
      expect(vm.getStatus()).toBe('success');
    });

    it('complete方法应该正确处理失败状态', async () => {
      const vm = wrapper.vm as HTPullRefreshInstance;

      // 先设置为loading状态
      vm.triggerRefresh();

      // 调用complete(false)表示失败
      vm.complete(false);

      await nextTick();
      expect(vm.getStatus()).toBe('error');
    });

    it('getStatus方法应该返回正确的状态', async () => {
      const vm = wrapper.vm as HTPullRefreshInstance;

      expect(vm.getStatus()).toBe('normal');

      vm.triggerRefresh();
      expect(vm.getStatus()).toBe('loading');
    });

    it('getDistance方法应该返回正确的距离', async () => {
      const vm = wrapper.vm as any; // 使用any来访问内部状态

      expect(vm.getDistance()).toBe(0);

      // 手动设置distance来测试getDistance方法
      vm.distance = 50;
      expect(vm.getDistance()).toBe(50);
    });

    it('禁用状态下triggerRefresh不应该生效', async () => {
      const refreshSpy = vi.fn();
      wrapper = mount(HTPullRefresh, {
        props: {
          disabled: true,
          'onRefresh': refreshSpy,
        },
        slots: { default: '<div>Content</div>' },
      });

      const vm = wrapper.vm as HTPullRefreshInstance;
      vm.triggerRefresh();

      await nextTick();
      expect(refreshSpy).not.toHaveBeenCalled();
      expect(vm.getStatus()).toBe('normal');
    });
  });

  describe('边界情况测试', () => {
    it('重复设置相同状态应该不触发事件', async () => {
      const statusChangeSpy = vi.fn();
      wrapper = mount(HTPullRefresh, {
        props: { 'onStatusChange': statusChangeSpy },
        slots: { default: '<div>Content</div>' },
      });

      const vm = wrapper.vm as any;
      // 设置为相同状态，两次都设置为 0 （normal）
      vm.setStatus(0);
      statusChangeSpy.mockClear(); // 清除之前的调用
      vm.setStatus(0); // 重复设置相同状态

      await nextTick();
      expect(statusChangeSpy).not.toHaveBeenCalled();
    });

    it('在非loading状态下调用complete应该不生效', async () => {
      const vm = wrapper.vm as any;

      // 设置为normal状态（distance=0）
      vm.setStatus(0);

      // 调用complete应该不生效
      vm.complete(true);

      await nextTick();
      expect(vm.status).toBe('normal');
    });
  });

  describe('可访问性测试', () => {
    it('应该支持触摸事件', () => {
      const vm = wrapper.vm as any;

      // 检查触摸相关的响应式状态是否存在
      expect(typeof vm.startY).toBe('number');
      expect(typeof vm.isTouchable).toBe('boolean');
    });

    it('禁用状态下应该正确隐藏头部', () => {
      wrapper = mount(HTPullRefresh, {
        props: { disabled: true },
        slots: { default: '<div>Content</div>' },
      });

      expect(wrapper.find('.ht-pull-refresh--disabled').exists()).toBe(true);
    });
  });

  describe('响应式测试', () => {
    it('应该正确响应props变化', async () => {
      wrapper = mount(HTPullRefresh, {
        props: { disabled: false },
        slots: { default: '<div>Content</div>' },
      });

      expect(wrapper.find('.ht-pull-refresh--disabled').exists()).toBe(false);

      await wrapper.setProps({ disabled: true });
      expect(wrapper.find('.ht-pull-refresh--disabled').exists()).toBe(true);
    });

    it('应该正确响应pullDistance变化', async () => {
      wrapper = mount(HTPullRefresh, {
        props: { pullDistance: 80 },
        slots: { default: '<div>Content</div>' },
      });

      const vm = wrapper.vm as any; // 使用any来访问内部状态

      // 验证props值正确传递
      expect(vm.pullDistance).toBe(80);

      // triggerRefresh 应该使用 headHeight 而不是 pullDistance
      vm.triggerRefresh();
      await nextTick();

      // 验证translateY使用了 headHeight （默认 50）
      expect(vm.translateY).toBe(50);
    });
  });

  describe('Token系统测试', () => {
    it('应该应用正确的CSS token', () => {
      wrapper = mount(HTPullRefresh, {
        slots: { default: '<div>Content</div>' },
      });

      // 检查组件是否应用了正确的类名
      expect(wrapper.find('.ht-pull-refresh').exists()).toBe(true);
      expect(wrapper.find('.ht-pull-refresh__head').exists()).toBe(true);
      expect(wrapper.find('.ht-pull-refresh__track').exists()).toBe(true);
      expect(wrapper.find('.ht-pull-refresh__content').exists()).toBe(true);
    });

    it('应该应用状态相关的样式类', async () => {
      wrapper = mount(HTPullRefresh, {
        slots: { default: '<div>Content</div>' },
      });

      const vm = wrapper.vm as HTPullRefreshInstance;

      // 测试loading状态
      vm.triggerRefresh();
      await nextTick();

      const loadingIcon = wrapper.find('.ht-pull-refresh__icon--loading');
      expect(loadingIcon.exists()).toBe(true);
    });
  });

  describe('生命周期测试', () => {
    it('应该在组件销毁时清理状态', () => {
      const vm = wrapper.vm as any;

      // 设置一些状态
      vm.triggerRefresh();
      expect(vm.getStatus()).toBe('loading');

      // 销毁组件
      wrapper.unmount();

      // 验证状态已清理（在实际应用中这些变量会被清理）
      expect(wrapper.exists()).toBe(false);
    });
  });

  describe('性能测试', () => {
    it('应该正确处理频繁的状态变化', async () => {
      const vm = wrapper.vm as HTPullRefreshInstance;
      const statusChangeSpy = vi.fn();

      wrapper = mount(HTPullRefresh, {
        props: { 'onStatusChange': statusChangeSpy },
        slots: { default: '<div>Content</div>' },
      });

      // 快速连续的状态变化
      vm.triggerRefresh();
      vm.complete(true);
      vm.triggerRefresh();
      vm.complete(false);

      await nextTick();

      // 最终状态应该是error
      expect(vm.getStatus()).toBe('error');
    });
  });
});
