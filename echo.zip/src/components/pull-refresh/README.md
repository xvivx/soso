# HTPullRefresh 下拉刷新组件

基于 shadcn-vue 和项目 token 系统实现，完全兼容 Vant PullRefresh 组件 API 的下拉刷新组件。

## 特性

- 🎯 **Vant 兼容**：完全兼容 Vant PullRefresh 的 API 和行为
- 🎨 **Token 系统**：基于项目三级 token 规范，支持主题定制
- 📱 **触摸优化**：支持触摸手势，提供流畅的下拉体验
- 🎭 **状态丰富**：支持 normal、pulling、loosing、loading、success、error 六种状态
- 🔧 **高度可定制**：支持自定义图标、文案、插槽等
- ♿ **无障碍**：符合无障碍访问标准
- 🧪 **测试覆盖**：完整的单元测试覆盖

## 基础用法

```vue
<template>
  <HTPullRefresh @refresh="onRefresh">
    <div>
      <!-- 你的内容 -->
      <p>下拉刷新次数: {{ count }}</p>
    </div>
  </HTPullRefresh>
</template>

<script setup>
import { ref } from 'vue';
import { HTPullRefresh } from '@/components';

const count = ref(0);

const onRefresh = () => {
  setTimeout(() => {
    count.value++;
  }, 1000);
};
</script>
```

## 自定义提示文字

```vue
<template>
  <HTPullRefresh
    pulling-text="下拉获取新数据"
    loosing-text="松开手指更新"
    loading-text="正在加载中..."
    success-text="更新成功！"
    error-text="更新失败，请重试"
    @refresh="onRefresh"
  >
    <div>内容区域</div>
  </HTPullRefresh>
</template>
```

## 自定义插槽

```vue
<template>
  <HTPullRefresh @refresh="onRefresh">
    <!-- 自定义加载状态 -->
    <template #loading>
      <div class="custom-loading">
        <div class="spinner"></div>
        <span>正在获取最新数据...</span>
      </div>
    </template>

    <!-- 自定义下拉状态 -->
    <template #pulling>
      <div class="custom-pulling">
        <span>👆 继续下拉</span>
      </div>
    </template>

    <!-- 自定义释放状态 -->
    <template #loosing>
      <div class="custom-loosing">
        <span>🎯 释放立即刷新</span>
      </div>
    </template>

    <div>内容区域</div>
  </HTPullRefresh>
</template>
```

## 完整列表刷新示例

```vue
<template>
  <HTPullRefresh
    :success-text="updateTime"
    @refresh="onRefreshList"
  >
    <div class="list">
      <div v-for="item in list" :key="item.id" class="list-item">
        {{ item.text }}
      </div>
    </div>
  </HTPullRefresh>
</template>

<script setup>
import { ref } from 'vue';

const list = ref([
  { id: 1, text: '列表项 1' },
  { id: 2, text: '列表项 2' },
  // ...
]);

const updateTime = ref('上次更新时间: ' + new Date().toLocaleTimeString());

const onRefreshList = async () => {
  // 模拟异步数据获取
  await new Promise(resolve => setTimeout(resolve, 1500));

  // 更新数据
  list.value = list.value.map(item => ({
    ...item,
    text: '更新后的' + item.text
  }));

  // 更新时间
  updateTime.value = '上次更新时间: ' + new Date().toLocaleTimeString();
};
</script>
```

## API

### Props

| 参数 | 说明 | 类型 | 默认值 | Vant 兼容 |
|------|------|------|--------|-----------|
| disabled | 是否禁用下拉刷新 | `boolean` | `false` | ✅ |
| success-text | 成功提示文字 | `string` | `'刷新成功'` | ✅ |
| error-text | 失败提示文字 | `string` | `'刷新失败'` | ✅ |
| loading-text | 加载提示文字 | `string` | `'加载中...'` | ✅ |
| pulling-text | 下拉提示文字 | `string` | `'下拉刷新'` | ✅ |
| loosing-text | 释放提示文字 | `string` | `'释放刷新'` | ✅ |
| pull-distance | 触发下拉刷新的距离 | `number` | `50` | ✅ |
| success-duration | 成功提示展示时长(ms) | `number` | `500` | ✅ |
| animation-duration | 动画时长(ms) | `number` | `300` | ✅ |
| className | 自定义类名 | `string` | - | ❌ |
| style | 自定义样式 | `string \| Record<string, any>` | - | ❌ |

### Events

| 事件名 | 说明 | 回调参数 | Vant 兼容 |
|--------|------|----------|-----------|
| refresh | 下拉刷新触发时调用 | - | ✅ |
| status-change | 状态改变时调用 | `(status: PullRefreshStatus)` | ✅ |

### Slots

| 插槽名 | 说明 | Vant 兼容 |
|--------|------|-----------|
| default | 内容区域 | ✅ |
| normal | 自定义默认状态提示 | ✅ |
| pulling | 自定义下拉中状态提示 | ✅ |
| loosing | 自定义释放状态提示 | ✅ |
| loading | 自定义加载中状态提示 | ✅ |
| success | 自定义成功状态提示 | ✅ |
| error | 自定义失败状态提示 | ✅ |

### Methods

通过 ref 可以调用组件方法：

| 方法名 | 说明 | 参数 | Vant 兼容 |
|--------|------|------|-----------|
| triggerRefresh | 手动触发刷新 | - | ✅ |
| complete | 完成刷新 | `(success?: boolean)` | ✅ |

## 类型定义

```typescript
export type PullRefreshStatus = 'normal' | 'pulling' | 'loosing' | 'loading' | 'success' | 'error';

export interface HTPullRefreshProps {
  disabled?: boolean;
  successText?: string;
  errorText?: string;
  loadingText?: string;
  pullingText?: string;
  loosingText?: string;
  pullDistance?: number;
  successDuration?: number;
  animationDuration?: number;
  className?: string;
  style?: string | Record<string, any>;
}

export interface HTPullRefreshEmits {
  refresh: [];
  'status-change': [status: PullRefreshStatus];
}
```

## 主题定制

基于项目的三级 token 系统，你可以通过修改 CSS 变量来自定义样式：

```css
:root {
  /* 基础容器 Token */
  --pull-refresh-container-height-default: auto;

  /* 头部区域 Token */
  --pull-refresh-header-padding-default: 16px 0;
  --pull-refresh-header__icon-size-default: 20px;
  --pull-refresh-header__icon-color-default: #8C8C8C;
  --pull-refresh-header__icon-color-active: #1677FF;
  --pull-refresh-header__icon-color-error: #FF4D4F;
  --pull-refresh-header__icon-margin-default: 8px;

  /* 文本样式 Token */
  --pull-refresh-header__text-font-size-default: 12px;
  --pull-refresh-header__text-color-default: #8C8C8C;
  --pull-refresh-header__text-color-active: #1677FF;

  /* 加载状态 Token */
  --pull-refresh-loading-size-default: 20px;
  --pull-refresh-loading-color-default: #1677FF;

  /* 内容区域 Token */
  --pull-refresh-content-margin-default: 0;

  /* 动画过渡 Token */
  --pull-refresh-transition-duration: 0.3s;
}
```

## 使用注意事项

1. **滚动容器**：组件会自动检测滚动容器，确保在列表顶部才能触发下拉刷新
2. **触摸事件**：组件会阻止触摸事件的默认行为和冒泡
3. **异步处理**：`refresh` 事件应该是异步的，完成后组件会自动回弹
4. **性能优化**：建议在 `refresh` 事件中进行防抖处理
5. **移动端适配**：组件专门针对移动端触摸手势优化

## 迁移指南

### 从 Vant PullRefresh 迁移

```vue
<!-- Vant 用法 -->
<van-pull-refresh v-model="isLoading" @refresh="onRefresh">
  <div>内容</div>
</van-pull-refresh>

<!-- HTPullRefresh 用法 -->
<HTPullRefresh @refresh="onRefresh">
  <div>内容</div>
</HTPullRefresh>

<script>
// Vant 需要手动控制 loading 状态
const isLoading = ref(false);

const onRefresh = async () => {
  isLoading.value = true;
  try {
    await fetchData();
  } finally {
    isLoading.value = false;
  }
};

// HTPullRefresh 会自动管理状态
const onRefresh = async () => {
  await fetchData();
  // 组件会自动处理完成状态
};
</script>
```

## 示例

查看 `/src/docs/pull-refresh.vue` 获取更多使用示例。

## 测试

组件包含完整的单元测试，运行以下命令进行测试：

```bash
npm run test:unit pull-refresh
```

## 贡献

欢迎提交 Issue 和 PR 来改进这个组件。