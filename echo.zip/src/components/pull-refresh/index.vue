<template>
  <div
    ref="rootRef"
    :class="cn('ht-pull-refresh', { 'ht-pull-refresh--disabled': disabled }, className)"
    :style="style"
    @touchstart.passive="onTouchStart"
    @touchmove="onTouchMove"
    @touchend="onTouchEnd"
    @touchcancel="onTouchEnd"
  >
    <!-- 下拉刷新头部 -->
    <div
      ref="headRef"
      :class="
        cn('ht-pull-refresh__head', {
          'ht-pull-refresh__head--visible': status !== 'normal' || isPulling,
        })
      "
    >
      <!-- 自定义状态插槽 -->
      <slot v-if="status === 'normal' && !isPulling" name="normal">
        <div class="ht-pull-refresh__icon">
          <svg viewBox="0 0 24 24" fill="currentColor">
            <path
              d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"
            />
          </svg>
        </div>
        <span class="ht-pull-refresh__text">{{ pullingText }}</span>
      </slot>

      <slot v-else-if="status === 'pulling'" name="pulling">
        <div class="ht-pull-refresh__icon ht-pull-refresh__icon--pulling">
          <svg viewBox="0 0 24 24" fill="currentColor">
            <path d="M7.41 8.59L12 13.17l4.59-4.58L18 10l-6 6-6-6 1.41-1.41z" />
          </svg>
        </div>
        <span class="ht-pull-refresh__text">{{ pullingText }}</span>
      </slot>

      <slot v-else-if="status === 'loosing'" name="loosing">
        <div class="ht-pull-refresh__icon ht-pull-refresh__icon--loosing">
          <svg viewBox="0 0 24 24" fill="currentColor">
            <path
              d="M12 4V1L8 5l4 4V6c3.31 0 6 2.69 6 6s-2.69 6-6 6-6-2.69-6-6H4c0 4.42 3.58 8 8 8s8-3.58 8-8-3.58-8-8-8z"
            />
          </svg>
        </div>
        <span class="ht-pull-refresh__text ht-pull-refresh__text--primary">{{ loosingText }}</span>
      </slot>

      <slot v-else-if="status === 'loading'" name="loading">
        <div class="ht-pull-refresh__icon ht-pull-refresh__icon--loading">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <circle cx="12" cy="12" r="10" stroke-dasharray="31.416" stroke-dashoffset="31.416" />
          </svg>
        </div>
        <span class="ht-pull-refresh__text">{{ loadingText }}</span>
      </slot>

      <slot v-else-if="status === 'success'" name="success">
        <div class="ht-pull-refresh__icon ht-pull-refresh__icon--success">
          <svg viewBox="0 0 24 24" fill="currentColor">
            <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41L9 16.17z" />
          </svg>
        </div>
        <span class="ht-pull-refresh__text ht-pull-refresh__text--success">{{ successText }}</span>
      </slot>

      <slot v-else-if="status === 'error'" name="error">
        <div class="ht-pull-refresh__icon ht-pull-refresh__icon--error">
          <svg viewBox="0 0 24 24" fill="currentColor">
            <path
              d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12 19 6.41z"
            />
          </svg>
        </div>
        <span class="ht-pull-refresh__text ht-pull-refresh__text--error">{{ errorText }}</span>
      </slot>
    </div>

    <!-- 内容区域 -->
    <div
      ref="trackRef"
      class="ht-pull-refresh__track"
      :style="{
        transform: translateY ? `translate3d(0, ${translateY}px, 0)` : '',
        transitionDuration: `${duration}ms`,
      }"
    >
      <div class="ht-pull-refresh__content">
        <slot />
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { computed, nextTick, onBeforeUnmount, onMounted, ref, watch } from 'vue';
import { cn } from '@/utils';
import './styles/index.css';
import {
  DEFAULT_ANIMATION_DURATION,
  DEFAULT_HEAD_HEIGHT,
  DEFAULT_PULL_DISTANCE,
  DEFAULT_PULL_REFRESH_TEXTS,
  DEFAULT_SUCCESS_DURATION,
  PULL_REFRESH_STATUS,
} from './constants';
import type { HTPullRefreshEmits, HTPullRefreshProps, PullRefreshStatus } from './types';

// Props 定义
const props = withDefaults(defineProps<HTPullRefreshProps>(), {
  modelValue: false,
  disabled: false,
  successText: DEFAULT_PULL_REFRESH_TEXTS.success,
  errorText: DEFAULT_PULL_REFRESH_TEXTS.error,
  loadingText: DEFAULT_PULL_REFRESH_TEXTS.loading,
  pullingText: DEFAULT_PULL_REFRESH_TEXTS.pulling,
  loosingText: DEFAULT_PULL_REFRESH_TEXTS.loosing,
  headHeight: DEFAULT_HEAD_HEIGHT,
  pullDistance: DEFAULT_PULL_DISTANCE,
  successDuration: DEFAULT_SUCCESS_DURATION,
  animationDuration: DEFAULT_ANIMATION_DURATION,
});

// Events 定义
const emit = defineEmits<HTPullRefreshEmits>();

// 响应式状态
const rootRef = ref<HTMLElement>();
const headRef = ref<HTMLElement>();
const trackRef = ref<HTMLElement>();
const status = ref<PullRefreshStatus>(PULL_REFRESH_STATUS.NORMAL);
const translateY = ref(0);
const distance = ref(0);
const duration = ref(0);
const isPulling = ref(false);
const reachTop = ref(false);

// 触摸状态
let startY = 0;
let startX = 0;
let deltaX = 0;
let deltaY = 0;
let isTouchable = false;

// 获取数值类型的 prop 值
const getNumericProp = (value: number | string | undefined, defaultValue: number): number => {
  if (value === undefined) return defaultValue;
  return typeof value === 'string' ? parseFloat(value) : value;
};

// 计算属性：头部高度
const headHeightValue = computed(() => getNumericProp(props.headHeight, DEFAULT_HEAD_HEIGHT));

// 计算属性：下拉距离
const pullDistanceValue = computed(() => {
  const pullDist = getNumericProp(props.pullDistance, 0);
  return pullDist || headHeightValue.value;
});

// 阻尼函数，参考 vant 实现
const ease = (distance: number): number => {
  const pullDistance = pullDistanceValue.value;

  if (distance > pullDistance) {
    if (distance < pullDistance * 2) {
      distance = pullDistance + (distance - pullDistance) / 2;
    } else {
      distance = pullDistance * 1.5 + (distance - pullDistance * 2) / 4;
    }
  }

  return Math.round(distance);
};

// 计算属性
const isTouchableComputed = computed(() => {
  return (
    !props.disabled &&
    status.value !== PULL_REFRESH_STATUS.LOADING &&
    status.value !== PULL_REFRESH_STATUS.SUCCESS &&
    status.value !== PULL_REFRESH_STATUS.ERROR
  );
});

// 获取滚动容器
const getScrollParent = (node: HTMLElement | null): HTMLElement | Window => {
  if (!node) return window;

  const getStyle = computed(() => {
    return window.getComputedStyle(node);
  });

  const scrollParent = computed(() => {
    const { position, overflowY, overflowX } = getStyle.value;
    const isScrollable = /(auto|scroll)/.test(overflowY + overflowX);

    if (isScrollable && position !== 'absolute') {
      return node;
    }

    return getScrollParent(node.parentElement || null);
  });

  return scrollParent.value;
};

// 检查是否在顶部
const checkIsReachTop = (el: HTMLElement | Window): boolean => {
  if (el === window) {
    return window.scrollY === 0;
  }
  return (el as HTMLElement).scrollTop === 0;
};

// 设置状态
const setStatus = (newDistance: number, isLoading?: boolean) => {
  distance.value = newDistance;

  let newStatus: PullRefreshStatus;
  if (isLoading) {
    newStatus = PULL_REFRESH_STATUS.LOADING;
  } else if (newDistance === 0) {
    newStatus = PULL_REFRESH_STATUS.NORMAL;
  } else if (newDistance < pullDistanceValue.value) {
    newStatus = PULL_REFRESH_STATUS.PULLING;
  } else {
    newStatus = PULL_REFRESH_STATUS.LOOSING;
  }

  if (status.value !== newStatus) {
    status.value = newStatus;
    emit('status-change', newStatus);
  }

  emit('change', {
    status: status.value,
    distance: newDistance,
  });
};

// 检查是否是垂直滚动
const isVertical = (): boolean => {
  return Math.abs(deltaY) > Math.abs(deltaX);
};

// 触摸开始
const onTouchStart = (event: TouchEvent) => {
  if (!isTouchableComputed.value || !rootRef.value) return;

  const touch = event.touches?.[0];
  if (!touch) return;

  reachTop.value = checkIsReachTop(getScrollParent(rootRef.value));
  if (!reachTop.value) return;

  isTouchable = true;
  startY = touch.clientY;
  startX = touch.clientX;
  deltaX = 0;
  deltaY = 0;
  duration.value = 0;
};

// 触摸移动
const onTouchMove = (event: TouchEvent) => {
  if (!isTouchable) return;

  const touch = event.touches?.[0];
  if (!touch) return;

  // 检查是否在顶部
  if (!reachTop.value && rootRef.value) {
    reachTop.value = checkIsReachTop(getScrollParent(rootRef.value));
  }

  const currentY = touch.clientY;
  const currentX = touch.clientX;
  deltaY = currentY - startY;
  deltaX = currentX - startX;

  // 如果是向上滚动，则不处理
  if (deltaY <= 0) return;

  // 只处理垂直方向的下拉
  if (reachTop.value && deltaY >= 0 && isVertical()) {
    // 阻止默认行为
    event.preventDefault();

    isPulling.value = true;

    // 使用阻尼函数计算距离
    const easedDistance = ease(deltaY);
    translateY.value = easedDistance;

    // 更新状态
    setStatus(easedDistance);
  }
};

// 触摸结束
const onTouchEnd = () => {
  if (!isTouchable) return;
  if (!reachTop.value || !deltaY) return;

  isTouchable = false;
  isPulling.value = false;
  duration.value = props.animationDuration;

  // 根据状态决定是否触发刷新
  if (status.value === PULL_REFRESH_STATUS.LOOSING) {
    setStatus(headHeightValue.value, true);
    translateY.value = headHeightValue.value;
    emit('update:modelValue', true);

    // 确保 value 变化可以被 watch 到
    nextTick(() => {
      emit('refresh');
    });
  } else {
    setStatus(0);
    translateY.value = 0;
  }
};

// 显示成功提示
const showSuccessTip = () => {
  status.value = PULL_REFRESH_STATUS.SUCCESS;

  setTimeout(() => {
    setStatus(0);
    translateY.value = 0;
  }, props.successDuration);
};

// 完成刷新
const onComplete = (success: boolean = true) => {
  if (status.value !== PULL_REFRESH_STATUS.LOADING) return;

  if (success) {
    status.value = PULL_REFRESH_STATUS.SUCCESS;
    setTimeout(() => {
      setStatus(0);
      translateY.value = 0;
    }, props.successDuration);
  } else {
    status.value = PULL_REFRESH_STATUS.ERROR;
    setTimeout(() => {
      setStatus(0);
      translateY.value = 0;
    }, props.successDuration);
  }
};

// 暴露方法给父组件
defineExpose({
  /**
   * 手动触发刷新
   * 用于编程式触发下拉刷新操作
   */
  triggerRefresh: () => {
    if (props.disabled) return;

    setStatus(headHeightValue.value, true);
    translateY.value = headHeightValue.value;
    emit('update:modelValue', true);
    nextTick(() => {
      emit('refresh');
    });
  },

  /**
   * 完成刷新操作
   * @param success - 是否刷新成功，默认为 true
   */
  complete: onComplete,

  /**
   * 获取当前状态
   * 用于外部组件检查当前刷新状态
   */
  getStatus: () => status.value,

  /**
   * 获取当前下拉距离
   * 用于调试或自定义交互
   */
  getDistance: () => distance.value,
});

// watch modelValue 变化
watch(
  () => props.modelValue,
  (value) => {
    duration.value = props.animationDuration;

    if (value) {
      setStatus(headHeightValue.value, true);
      translateY.value = headHeightValue.value;
    } else if (props.successText) {
      showSuccessTip();
    } else {
      setStatus(0);
      translateY.value = 0;
    }
  }
);

// 生命周期
onMounted(() => {
  // 初始化时检查是否在顶部
  if (rootRef.value) {
    reachTop.value = checkIsReachTop(getScrollParent(rootRef.value));
  }
});

onBeforeUnmount(() => {
  // 清理状态，防止内存泄漏
  isTouchable = false;
  isPulling.value = false;
  status.value = PULL_REFRESH_STATUS.NORMAL;
  translateY.value = 0;
  distance.value = 0;
  deltaX = 0;
  deltaY = 0;
});
</script>
