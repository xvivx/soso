import type { PullRefreshStatus } from './types';

/**
 * 下拉刷新默认文案
 * 遵循 H5组件三级token.md 规范
 */
export const DEFAULT_PULL_REFRESH_TEXTS = {
  pulling: '下拉刷新',
  loosing: '释放刷新',
  loading: '加载中...',
  success: '刷新成功',
  error: '刷新失败',
} as const;

/**
 * 默认头部高度
 * 控制下拉刷新头部区域的高度
 */
export const DEFAULT_HEAD_HEIGHT = 50;

/**
 * 默认触发下拉刷新的距离
 * 基于 token 系统和最佳实践设定
 */
export const DEFAULT_PULL_DISTANCE = 50;

/**
 * 成功状态显示时长（毫秒）
 * 确保用户能清楚看到刷新结果
 */
export const DEFAULT_SUCCESS_DURATION = 500;

/**
 * 动画过渡时长（毫秒）
 * 与 token 系统中的 --pull-refresh-transition-duration 保持一致
 */
export const DEFAULT_ANIMATION_DURATION = 300;

/**
 * 下拉刷新状态枚举
 * 包含完整的生命周期状态
 */
export const PULL_REFRESH_STATUS = {
  NORMAL: 'normal' as PullRefreshStatus,
  PULLING: 'pulling' as PullRefreshStatus,
  LOOSING: 'loosing' as PullRefreshStatus,
  LOADING: 'loading' as PullRefreshStatus,
  SUCCESS: 'success' as PullRefreshStatus,
  ERROR: 'error' as PullRefreshStatus,
} as const;

/**
 * 下拉刷新触摸事件类型
 * 用于触摸事件处理的状态管理
 */
export const TOUCH_EVENT_TYPE = {
  START: 'touchstart',
  MOVE: 'touchmove',
  END: 'touchend',
  CANCEL: 'touchcancel',
} as const;

/**
 * 阻尼效果系数
 * 用于下拉时的阻力计算，提供更好的用户体验
 */
export const DAMPING_COEFFICIENT = 0.85;

/**
 * 状态值类型映射
 * 用于类型安全和状态验证
 */
export const STATUS_TYPE_MAP = {
  [PULL_REFRESH_STATUS.NORMAL]: 'idle',
  [PULL_REFRESH_STATUS.PULLING]: 'pulling',
  [PULL_REFRESH_STATUS.LOOSING]: 'ready',
  [PULL_REFRESH_STATUS.LOADING]: 'refreshing',
  [PULL_REFRESH_STATUS.SUCCESS]: 'success',
  [PULL_REFRESH_STATUS.ERROR]: 'error',
} as const;
