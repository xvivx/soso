/**
 * HTPullRefresh 组件 Props 接口
 * 基于 Vant PullRefresh 组件，完全兼容其 API
 */
export interface HTPullRefreshProps {
  /**
   * 是否处于加载中状态
   * 支持 v-model 双向绑定
   * @default false
   */
  modelValue?: boolean;

  /**
   * 顶部内容高度
   * 控制下拉刷新头部区域的高度
   * @default 50
   */
  headHeight?: number | string;

  /**
   * 是否禁用下拉刷新
   * @default false
   */
  disabled?: boolean;

  /**
   * 下拉刷新成功提示文字
   * @default '刷新成功'
   */
  successText?: string;

  /**
   * 下拉刷新失败提示文字
   * @default '刷新失败'
   */
  errorText?: string;

  /**
   * 加载中状态提示文字
   * @default '加载中...'
   */
  loadingText?: string;

  /**
   * 下拉状态提示文字
   * @default '下拉刷新'
   */
  pullingText?: string;

  /**
   * 释放即可刷新时提示文字
   * @default '释放刷新'
   */
  loosingText?: string;

  /**
   * 触发下拉刷新的距离（像素）
   * 当下拉距离超过此值时，释放会触发刷新
   * @default 50
   */
  pullDistance?: number;

  /**
   * 成功提示的展示时长（毫秒）
   * 刷新成功后显示成功状态的持续时间
   * @default 500
   */
  successDuration?: number;

  /**
   * 动画时长（毫秒）
   * 下拉和回弹动画的持续时间
   * @default 300
   */
  animationDuration?: number;

  /**
   * 自定义类名
   * 用于扩展组件样式
   */
  className?: string;

  /**
   * 自定义样式
   * 支持字符串或对象形式的样式定义
   */
  style?: string | Record<string, string | number>;

  /**
   * 是否禁用头部回弹动画
   * 设置为 true 时，头部不会自动回弹
   * @default false
   */
  disablePullAnimation?: boolean;

  /**
   * 自定义下拉刷新的阻尼系数
   * 用于控制下拉时的阻力感
   * @default 0.85
   */
  dampingFactor?: number;
}

/**
 * HTPullRefresh 组件事件接口
 */
export interface HTPullRefreshEmits {
  /**
   * 下拉刷新触发时调用
   * 当用户下拉超过阈值并释放时触发
   */
  refresh: [];

  /**
   * 下拉状态改变时调用
   * @param data - 包含状态和距离的对象
   */
  change: [data: { status: PullRefreshStatus; distance: number }];

  /**
   * 更新 modelValue，用于 v-model 双向绑定
   * @param value - 新的 modelValue
   */
  'update:modelValue': [value: boolean];

  /**
   * 下拉状态改变时调用
   * @param status - 当前状态
   */
  'status-change': [status: PullRefreshStatus];

  /**
   * 开始下拉时调用
   */
  'pull-start': [];

  /**
   * 下拉移动时调用
   * @param distance - 当前下拉距离
   */
  'pull-move': [distance: number];

  /**
   * 下拉结束但未触发刷新时调用
   */
  'pull-end': [];
}

/**
 * 下拉刷新状态类型
 * 包含完整的生命周期状态
 */
export type PullRefreshStatus = 'normal' | 'pulling' | 'loosing' | 'loading' | 'success' | 'error';

/**
 * 下拉刷新组件实例接口
 * 包含组件暴露的方法和属性
 */
export interface HTPullRefreshInstance {
  /**
   * 手动触发刷新
   */
  triggerRefresh: () => void;

  /**
   * 完成刷新操作
   * @param success - 是否刷新成功
   */
  complete: (success?: boolean) => void;

  /**
   * 获取当前状态
   */
  getStatus: () => PullRefreshStatus;

  /**
   * 获取当前下拉距离
   */
  getDistance: () => number;
}

/**
 * HTPullRefresh 组件插槽接口
 */
export interface HTPullRefreshSlots {
  /**
   * 自定义下拉刷新中的内容
   */
  default: unknown;

  /**
   * 自定义默认状态提示内容
   */
  normal?: unknown;

  /**
   * 自定义下拉中状态提示内容
   */
  pulling?: unknown;

  /**
   * 自定义释放状态提示内容
   */
  loosing?: unknown;

  /**
   * 自定义加载中状态提示内容
   */
  loading?: unknown;

  /**
   * 自定义成功状态提示内容
   */
  success?: unknown;

  /**
   * 自定义失败状态提示内容
   */
  error?: unknown;
}

/**
 * 触摸事件状态接口
 * 用于组件内部触摸状态管理
 */
export interface TouchState {
  startY: number;
  isTouchable: boolean;
  isPulling: boolean;
  reachTop: boolean;
}

/**
 * 组件内部状态接口
 * 定义组件的核心响应式状态
 */
export interface PullRefreshState {
  status: PullRefreshStatus;
  translateY: number;
  distance: number;
  duration: number;
}
