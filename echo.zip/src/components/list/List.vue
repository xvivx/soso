<script setup lang="ts">
import { computed, nextTick, onBeforeUnmount, onMounted, ref, watch } from 'vue';
import { addUnit } from '@/utils/index';
import { useLocale } from '@/locale';
import HTIcon from '../icon/Icon.vue';
import type { ListProps } from './types';

const props = withDefaults(defineProps<ListProps>(), {
  loading: false,
  error: false,
  finished: false,
  offset: 300,
  errorText: '',
  loadingText: '',
  finishedText: '',
  immediateCheck: true,
});

// 获取国际化函数
const { t } = useLocale();

// 计算本地化文本,优先使用 prop,其次使用 locale 配置
const computedErrorText = computed(() => {
  if (props.errorText) return props.errorText;
  return t('htList.errorText', '加载失败,点击重试');
});

const computedLoadingText = computed(() => {
  if (props.loadingText) return props.loadingText;
  return t('htList.loadingText', '加载中...');
});

const computedFinishedText = computed(() => {
  if (props.finishedText) return props.finishedText;
  return t('htList.finishedText', '没有更多了');
});

const loadingModel = defineModel<boolean>('loading');
const errorModel = defineModel<boolean>('error');

const emit = defineEmits<{
  (e: 'load'): void;
}>();

const htListRef = ref<HTMLElement | null>(null);
const sentinelRef = ref<HTMLElement | null>(null);
const observer = ref<IntersectionObserver | null>(null);

const offsetPx = computed(() => addUnit(props.offset) || '0px');

function createObserver() {
  cleanupObserver();

  const options: IntersectionObserverInit = {
    root: null,
    rootMargin: `0px 0px ${offsetPx.value} 0px`,
    threshold: 0,
  };

  observer.value = new IntersectionObserver((entries) => {
    for (const entry of entries) {
      if (entry.isIntersecting) {
        if (!loadingModel.value && !props.finished && !errorModel.value) {
          loadingModel.value = true;
          emit('load');
        }
      }
    }
  }, options);

  if (sentinelRef.value) observer.value.observe(sentinelRef.value);
}

function cleanupObserver() {
  if (observer.value) {
    observer.value.disconnect();
    observer.value = null;
  }
}

watch(
  [
    () => props.offset,
    () => props.immediateCheck,
    () => props.finished,
    () => loadingModel.value,
    () => errorModel.value,
  ],
  () => {
    nextTick(() => createObserver());
  }
);

onMounted(() => {
  nextTick(() => {
    if (props.immediateCheck) createObserver();
  });
});

onBeforeUnmount(() => {
  cleanupObserver();
});

function onErrorClick() {
  loadingModel.value = true;
  emit('load');
}
</script>

<template>
  <div ref="htListRef" class="ht-list w-full">
    <slot />
    <div ref="sentinelRef" class="h-px w-full" />
    <div class="ht-list__bottom text-center">
      <template v-if="loadingModel">
        <slot name="loading">
          <div class="inline-flex cursor-pointer items-center gap-2">
            <HTIcon class="ht-list__icon">
              <svg class="h-full w-full animate-spin" viewBox="25 25 50 50" xmlns="http://www.w3.org/2000/svg">
                <circle
                  cx="50"
                  cy="50"
                  r="20"
                  fill="none"
                  stroke="currentColor"
                  stroke-width="3"
                  stroke-linecap="round"
                  stroke-dasharray="90 150"
                  stroke-dashoffset="0"
                ></circle>
              </svg>
            </HTIcon>
            <span class="ht-list__text">{{ computedLoadingText }}</span>
          </div>
        </slot>
      </template>

      <template v-else-if="errorModel">
        <slot name="error">
          <div class="inline-flex cursor-pointer items-center gap-2" role="button" @click="onErrorClick">
            <span class="ht-list__text">{{ computedErrorText }}</span>
          </div>
        </slot>
      </template>

      <template v-else-if="finished">
        <slot name="finished">
          <div class="inline-flex items-center gap-2">
            <span class="ht-list__text">{{ computedFinishedText }}</span>
          </div>
        </slot>
      </template>
    </div>
  </div>
</template>
<style>
:root {
  --list-loading-padding-default: 16px 0; /** 加载区默认内边距 */
  --list-loading-icon-size-default: 16px; /** 加载图标默认尺寸 */
  --list-loading-icon-color-default: #8c8c8c; /** 加载图标默认颜色 */
  --list-loading-text-font-size-default: 14px; /** 加载文本默认字号 */
  --list-loading-text-color-default: #8c8c8c; /** 加载文本默认颜色 */
}

@layer components {
  .ht-list__bottom {
    padding: var(--list-loading-padding-default);
    color: var(--list-loading-text-color-default);
  }

  .ht-list__icon {
    width: var(--list-loading-icon-size-default);
    height: var(--list-loading-icon-size-default);
    font-size: var(--list-loading-icon-size-default);
    display: inline-block;
  }

  .ht-list__text {
    color: var(--list-loading-text-color-default);
    font-size: var(--list-loading-text-font-size-default);
  }
}
</style>
