import type { ComponentPublicInstance } from 'vue';

export interface ListProps {
  finished?: boolean;
  offset?: number | string;
  errorText?: string;
  loadingText?: string;
  finishedText?: string;
  immediateCheck?: boolean;
}

export type ListInstance = ComponentPublicInstance<ListProps>;
