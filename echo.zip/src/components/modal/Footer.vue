<template>
  <div class="ht-modal-footer sticky bottom-0 bg-inherit">
    <slot></slot>
  </div>
</template>

<script setup lang="ts"></script>

<style>
.ht-modal-footer {
  --button-text-font-size-default: var(--modal-footer-button-font-size);
  padding: var(--modal-footer-padding);
}

:root {
  /* 确认弹窗底部操作按钮的边距 */
  --modal-footer-padding: 16px 0;
  /* 确认弹窗底部操作按钮的字体大小 */
  --modal-footer-button-font-size: 16px;
}
</style>
