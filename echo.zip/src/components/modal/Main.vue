<template>
  {{ null }}
</template>
<script setup lang="ts">
import { h, onUnmounted, useSlots, watch } from 'vue';
import { createRender } from '@/components/portal-render/store';
import Content from './Content.vue';

type Props = {
  show: boolean;
  closable?: boolean;
  drawer?: boolean;
  center?: boolean;
};

const props = withDefaults(defineProps<Props>(), {
  closable: true,
});

const emits = defineEmits<{
  'update:show': [show: boolean];
  close: [];
}>();

let cleanup: () => void = () => null;
const slots = useSlots();
watch(
  () => props.show,
  () => {
    if (props.show) {
      const onClose = () => {
        emits('update:show', false);
        emits('close');
      };
      cleanup = createRender(h(Content, { onClose }, slots), {
        ...props,
        onClose,
      });
    } else {
      cleanup();
    }
  },
  { immediate: true }
);
onUnmounted(() => cleanup());
</script>
