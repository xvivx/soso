import { type VNode } from 'vue';
import HTButton from '../button';
import { createRender, render } from '../portal-render/store';
import Content from './Content.vue';
import Footer from './Footer.vue';
import HTModal from './Main.vue';

type Options = {
  title?: VNode | string;
  children: VNode | string | VNode[];
  closable?: boolean;
  onClose?: () => void;
  drawer?: boolean;
  center?: boolean;
  confirm?: {
    cancelText?: string;
    confirmText?: string;
    onCancel?: (event: MouseEvent) => void;
    onConfirm: (event: MouseEvent) => void;
  };
};

const show = (options: Options) => {
  const { onClose = () => close(), title, children, confirm, ...rests } = options;
  const close = createRender(
    <Content onClose={onClose}>
      {{
        title: title ? () => title : null,
        default: () => [
          children,
          confirm &&
            (() => {
              const { cancelText = 'Cancel', onCancel, confirmText = 'Confirm', onConfirm } = confirm;
              return (
                <Footer class="flex items-center justify-between gap-4">
                  {cancelText && (
                    <HTButton class="flex-1" type="default" onClick={onCancel || onClose}>
                      {cancelText}
                    </HTButton>
                  )}
                  <HTButton class="flex-1" type="primary" onClick={onConfirm}>
                    {confirmText}
                  </HTButton>
                </Footer>
              );
            })(),
        ],
      }}
    </Content>,
    {
      onClose,
      ...rests,
    }
  );

  return close;
};

export default Object.assign(HTModal, {
  show,
  Footer,
  close: () => render.close(),
  closeAll: () => render.closeAllOverlays(),
});
