export type ModalProps = {
  show: boolean;
  closable?: boolean;
  drawer?: boolean;
  center?: boolean;
};
