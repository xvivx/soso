export default defineProps<{
  className?: string;
  title?: VNode;
  closable?: boolean;
  onClose: (visible: false) => void;
  size?: 'sm' | 'md' | 'lg';
}>();
