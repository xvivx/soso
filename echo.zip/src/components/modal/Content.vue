<template>
  <div class="ht-modal relative">
    <div v-if="$slots.title" class="ht-modal-title sticky top-0 flex items-center justify-between gap-2 bg-inherit">
      <slot name="title"></slot>
      <button
        class="ht-modal-close-icon flex-center shrink-0 self-start transition-all active:translate-y-px"
        @click="$emit('close')"
      >
        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
          <path
            fill-rule="evenodd"
            clip-rule="evenodd"
            d="M14.6613 16.0999L15.5452 16.9838L17.3129 15.2161L16.429 14.3322L11.9818 9.88489L16.1686 5.69809L17.0524 4.81421L15.2847 3.04644L14.4008 3.93033L10.214 8.11712L5.87138 3.77451L4.98749 2.89062L3.21973 4.65839L4.10361 5.54228L8.44622 9.88489L4.06943 14.2617L3.18555 15.1456L4.95331 16.9133L5.8372 16.0294L10.214 11.6527L14.6613 16.0999Z"
            fill="currentColor"
          />
        </svg>
      </button>
    </div>

    <slot></slot>
  </div>
</template>
<script setup lang="ts">
defineEmits<{ close: [] }>();
</script>

<style>
.ht-modal {
  background-color: var(--modal-bg-color);
  font-size: var(--modal-font-size);
  color: var(--modal-text-color);
  padding: var(--modal-padding);
}

.ht-modal-title {
  padding-bottom: var(--modal-title-padding-bottom);
  color: var(--modal-title-color);
  font-size: var(--modal-title-font-size);
  font-weight: bold;
}

.ht-modal-close-icon {
  width: var(--modal-close-icon-size);
  height: var(--modal-close-icon-size);
  color: var(--modal-close-icon-color);
}

@media (hover: hover) {
  .ht-modal-close-icon:hover {
    color: var(--modal-close-icon-hover-color);
  }
}

:root {
  /* 弹窗背景色 */
  --modal-bg-color: #fff;
  /* 弹窗文字颜色 */
  --modal-text-color: #333;
  /* 弹窗文字大小 */
  --modal-font-size: 14px;
  /* 弹窗内容区的边距 */
  --modal-padding: 0 16px;
  /* 弹窗标题文字颜色 */
  --modal-title-color: #000;
  /* 弹窗标题字体大小 */
  --modal-title-font-size: 18px;
  /* 弹窗标题距离内容区的间距 */
  --modal-title-padding-bottom: 16px;
  /* 弹窗关闭icon的大小 */
  --modal-close-icon-size: 36px;
  /* 弹窗关闭icon的颜色 */
  --modal-close-icon-color: #999;
  /* 弹窗关闭icon悬浮颜色 */
  --modal-close-icon-hover-color: #000;
}
</style>
