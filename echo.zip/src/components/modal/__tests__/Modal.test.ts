import { nextTick } from 'vue';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import { createRender } from '@/components/portal-render/store';
import HTModal from '..';
import { cleanupPortalContainer, renderWithMounting } from '../../../../test/utils';

// 模拟 portal-render store
vi.mock('@/components/portal-render/store', () => {
  const mockCleanup = vi.fn();
  const mockCreateRender = vi.fn(() => mockCleanup);
  const mockRender = {
    close: vi.fn(),
    closeAllOverlays: vi.fn(),
    delete: vi.fn(),
  };

  return {
    createRender: mockCreateRender,
    render: mockRender,
    useRender: vi.fn(() => mockRender),
  };
});

describe('HTModal', () => {
  let mockCleanup: ReturnType<typeof vi.fn>;

  beforeEach(() => {
    vi.clearAllMocks();
    mockCleanup = vi.fn();
    vi.mocked(createRender).mockImplementation(() => mockCleanup);
    document.body.innerHTML = '';
  });

  afterEach(() => {
    cleanupPortalContainer();
  });

  describe('基础渲染', () => {
    it('应该隐藏时不渲染内容', () => {
      renderWithMounting(HTModal, {
        props: {
          show: false,
        },
      });

      // 当 show 为 false 时，不应该调用 createRender
      expect(vi.mocked(createRender)).toHaveBeenCalledTimes(0);
    });

    it('应该支持默认 closable 为 true', () => {
      renderWithMounting(HTModal, {
        props: {
          show: true,
        },
      });

      expect(vi.mocked(createRender)).toHaveBeenCalledWith(
        expect.any(Object),
        expect.objectContaining({
          closable: true,
        })
      );
    });

    it('应该支持自定义 closable 属性', () => {
      renderWithMounting(HTModal, {
        props: {
          show: true,
          closable: false,
        },
      });

      expect(vi.mocked(createRender)).toHaveBeenCalledWith(
        expect.any(Object),
        expect.objectContaining({
          closable: false,
        })
      );
    });
  });

  describe('事件处理', () => {
    it('应该在 show 变化时触发正确的渲染逻辑', async () => {
      const { rerender } = renderWithMounting(HTModal, {
        props: {
          show: false,
        },
      });

      expect(vi.mocked(createRender)).toHaveBeenCalledTimes(0);

      await rerender({ show: true });
      expect(vi.mocked(createRender)).toHaveBeenCalledTimes(1);

      await rerender({ show: false });
      expect(mockCleanup).toHaveBeenCalledTimes(1);
    });

    it('应该触发 update:show 事件', async () => {
      const mockOnClose = vi.fn();
      vi.mocked(createRender).mockImplementation((node, options) => {
        const cleanup = vi.fn();
        // 模拟调用 onClose
        options?.onClose?.();
        return cleanup;
      });

      renderWithMounting(HTModal, {
        props: {
          show: true,
          'onUpdate:show': mockOnClose,
        },
      });

      await nextTick();
      expect(mockOnClose).toHaveBeenCalledWith(false);
    });

    it('应该触发 close 事件', () => {
      const mockOnClose = vi.fn();
      vi.mocked(createRender).mockImplementation((node, options) => {
        // 立即调用 onClose
        options?.onClose?.();
        return vi.fn();
      });

      renderWithMounting(HTModal, {
        props: {
          show: true,
          onClose: mockOnClose,
        },
      });

      expect(mockOnClose).toHaveBeenCalledTimes(1);
    });
  });

  describe('生命周期管理', () => {
    it('应该在组件卸载时清理资源', () => {
      const { unmount } = renderWithMounting(HTModal, {
        props: {
          show: true,
        },
      });

      expect(vi.mocked(createRender)).toHaveBeenCalledTimes(1);
      expect(mockCleanup).toHaveBeenCalledTimes(0);

      unmount();
      expect(mockCleanup).toHaveBeenCalledTimes(1);
    });

    it('应该在隐藏时清理渲染', async () => {
      const { rerender } = renderWithMounting(HTModal, {
        props: {
          show: true,
        },
      });

      expect(vi.mocked(createRender)).toHaveBeenCalledTimes(1);
      expect(mockCleanup).toHaveBeenCalledTimes(0);

      await rerender({ show: false });
      expect(mockCleanup).toHaveBeenCalledTimes(1);
    });

    it('应该正确处理多次显示/隐藏', async () => {
      const { rerender } = renderWithMounting(HTModal, {
        props: {
          show: false,
        },
      });

      // 显示
      await rerender({ show: true });
      expect(vi.mocked(createRender)).toHaveBeenCalledTimes(1);

      // 隐藏
      await rerender({ show: false });
      expect(mockCleanup).toHaveBeenCalledTimes(1);

      // 再次显示
      await rerender({ show: true });
      expect(vi.mocked(createRender)).toHaveBeenCalledTimes(2);
    });
  });

  describe('错误处理', () => {
    it('应该处理 createRender 抛出的错误', () => {
      const error = new Error('Render error');
      vi.mocked(createRender).mockImplementation(() => {
        throw error;
      });

      expect(() => {
        renderWithMounting(HTModal, {
          props: {
            show: true,
          },
        });
      }).toThrow('Render error');
    });
  });
});
