import { h } from 'vue';
import { mount } from '@vue/test-utils';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import RadioGroup from '../../radio-group/RadioGroup.vue';
import HTRadio from '../Radio.vue';

describe('HTRadio', () => {
  beforeEach(() => {
    document.body.innerHTML = '';
  });

  function mountWithGroup(props = {}, slots = {}) {
    return mount(RadioGroup, {
      props: { modelValue: null },
      slots: {
        default: () => h(HTRadio, { ...(props as any) }, slots),
      },
      global: { components: { HTRadio } },
    });
  }

  it('应该正确渲染单选框', () => {
    const wrapper = mountWithGroup({ name: 'option-1', label: '单选项' }, { default: '单选项' });
    const radio = wrapper.find('.ht-radio');
    expect(radio.exists()).toBe(true);
    expect(radio.text()).toContain('单选项');
  });

  it('应该渲染图标', () => {
    const wrapper = mountWithGroup({ name: 'option-1' }, { default: '图标项' });
    const icon = wrapper.find('.ht-radio__icon');
    expect(icon.exists()).toBe(true);
  });

  it('应该支持 round 形状', () => {
    const wrapper = mountWithGroup({ name: 'option-1', shape: 'round' }, { default: '圆形项' });
    const round = wrapper.find('.ht-radio__round');
    expect(round.exists()).toBe(true);
  });

  it('应该支持 dot 形状', () => {
    const wrapper = mountWithGroup({ name: 'option-1', shape: 'dot' }, { default: '点形项' });
    const ring = wrapper.find('.ht-radio__ring');
    expect(ring.exists()).toBe(true);
  });

  it('应该响应点击事件', async () => {
    const handleClick = vi.fn();
    const wrapper = mount(RadioGroup, {
      props: { modelValue: null },
      slots: {
        default: () => h(HTRadio, { name: 'option-1', onClick: handleClick }, { default: '可点击项' }),
      },
      global: { components: { HTRadio } },
    });
    const radio = wrapper.find('.ht-radio');
    await radio.trigger('click');
    expect(handleClick).toHaveBeenCalled();
  });

  it('禁用时不应触发点击事件', async () => {
    const handleClick = vi.fn();
    const wrapper = mount(RadioGroup, {
      props: { modelValue: null },
      slots: {
        default: () => h(HTRadio, { name: 'option-1', disabled: true, onClick: handleClick }, { default: '禁用项' }),
      },
      global: { components: { HTRadio } },
    });
    const radio = wrapper.find('.ht-radio');
    await radio.trigger('click');
    expect(handleClick).not.toHaveBeenCalled();
  });

  it('应该正确显示禁用样式', () => {
    const wrapper = mountWithGroup({ name: 'option-1', disabled: true }, { default: '禁用项' });
    const radio = wrapper.find('.ht-radio');
    expect(radio.attributes('data-disabled')).toBe('');
    expect(radio.classes()).toContain('cursor-not-allowed');
  });

  it('应该支持 secondary 变体', () => {
    const wrapper = mountWithGroup({ name: 'option-1', variant: 'secondary' }, { default: '次色项' });
    const radio = wrapper.find('.ht-radio--secondary');
    expect(radio.exists()).toBe(true);
  });

  it('应该支持 small 尺寸', () => {
    const wrapper = mountWithGroup({ name: 'option-1', iconSize: 'small' }, { default: '小尺寸项' });
    const radio = wrapper.find('.ht-radio--small');
    expect(radio.exists()).toBe(true);
  });

  it('应该支持自定义图标插槽', () => {
    const wrapper = mountWithGroup(
      { name: 'option-1' },
      { icon: h('div', { 'data-testid': 'custom-icon' }, 'Custom'), default: '自定义图标项' }
    );
    const customIcon = wrapper.find('[data-testid="custom-icon"]');
    expect(customIcon.exists()).toBe(true);
  });

  it('应该支持默认插槽', () => {
    const wrapper = mountWithGroup(
      { name: 'option-1' },
      { default: h('span', { 'data-testid': 'custom-label' }, 'Custom Label') }
    );
    const customLabel = wrapper.find('[data-testid="custom-label"]');
    expect(customLabel.exists()).toBe(true);
  });
});
