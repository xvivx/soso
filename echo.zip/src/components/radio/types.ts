import type { IconSize, RadioLabelPosition } from '@/components/radioGroup/types';

export interface RadioProps {
  name: string | number;
  disabled?: boolean;
  iconSize?: IconSize;
  checkedColor?: string;
  labelPosition?: RadioLabelPosition;
}
