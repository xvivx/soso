import type { IconSize, RadioLabelPosition, RadioShape, RadioVariant } from '@/components/radioGroup/types';

export interface RadioProps {
  name: string | number;
  disabled?: boolean;
  iconSize?: IconSize;
  checkedColor?: string;
  labelPosition?: RadioLabelPosition;
  shape?: RadioShape;
  variant?: RadioVariant;
}
