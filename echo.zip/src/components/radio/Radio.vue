<script setup lang="ts">
import { computed } from 'vue';
import { RadioGroupItem } from 'reka-ui';
import HTIcon from '@/components/icon/Icon.vue';
import { addUnit, cn, RADIO_GROUP_KEY } from '@/utils/index';
import { useParent } from '@/hooks';
import type { RadioProps } from './types';

const props = withDefaults(defineProps<RadioProps>(), {
  disabled: false,
});

const emit = defineEmits<{ (e: 'click', ev: MouseEvent): void }>();

const { parent: radioGroup } = useParent(RADIO_GROUP_KEY);
const radioGroupDisabled = computed(() => radioGroup?.props.disabled);
const radioGroupIconSize = computed(() => radioGroup?.props.iconSize);
const radioGroupCheckedColor = computed(() => radioGroup?.props.checkedColor);
const radioGroupLabelPosition = computed(() => radioGroup?.props.labelPosition);
const radioGroupShape = computed(() => radioGroup?.props.shape);
const radioGroupVariant = computed(() => radioGroup?.props.variant);
const radioGroupModel = computed(() => radioGroup?.props.modelValue);

const isDisabled = computed(() => !!props.disabled || !!radioGroupDisabled.value);
const isChecked = computed(() => (radioGroupModel.value ? radioGroupModel.value === props.name : false));

const iconSize = computed(() => props.iconSize ?? radioGroupIconSize.value);
const resolvedIconSize = computed(() => {
  if (iconSize.value === 'small') return undefined; // 使用 CSS 变量
  return addUnit(iconSize.value);
});

const variant = computed(() => props.variant ?? radioGroupVariant.value ?? 'primary');
const checkedColor = computed(() => props.checkedColor ?? radioGroupCheckedColor.value);

const labelPosition = computed(() => props.labelPosition ?? radioGroupLabelPosition.value ?? 'right');
const shape = computed(() => props.shape ?? radioGroupShape.value ?? 'round');

function onClick(e: MouseEvent) {
  if (isDisabled.value) {
    e.preventDefault();
    e.stopPropagation();
    return;
  }
  emit('click', e);
}
</script>

<template>
  <RadioGroupItem
    :value="props.name"
    :disabled="isDisabled"
    :class="
      cn('ht-radio inline-flex items-center', {
        'cursor-not-allowed': isDisabled,
        'cursor-pointer': !isDisabled,
        'ht-radio--small': iconSize === 'small',
        'ht-radio--primary': variant !== 'secondary',
        'ht-radio--secondary': variant === 'secondary',
      })
    "
    :style="{
      '--radio-custom-checked-color': checkedColor,
    }"
    @click="onClick"
  >
    <span :class="cn('ht-radio__inner inline-flex items-center', { 'flex-row-reverse': labelPosition === 'left' })">
      <span
        class="ht-radio__icon inline-flex items-center justify-center [&_img]:block [&_img]:h-full [&_img]:w-full [&_img]:object-contain"
        :style="{ width: resolvedIconSize, height: resolvedIconSize }"
      >
        <slot name="icon" :checked="isChecked" :disabled="isDisabled">
          <!-- round 形状：显示勾选 icon -->
          <span
            v-if="shape === 'round'"
            :class="
              cn(
                'ht-radio__round relative box-border flex h-full w-full items-center justify-center rounded-full border-solid bg-transparent transition-all duration-200'
              )
            "
          >
            <HTIcon v-if="isChecked" class="ht-radio__check-icon">
              <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path
                  d="M20 6L9 17L4 12"
                  stroke="currentColor"
                  stroke-width="2"
                  stroke-linecap="round"
                  stroke-linejoin="round"
                />
              </svg>
            </HTIcon>
          </span>
          <!-- dot 形状：显示实心圆点 -->
          <span
            v-else
            :class="
              cn(
                'ht-radio__ring relative box-border h-full w-full rounded-full border-solid bg-transparent after:absolute after:top-1/2 after:left-1/2 after:block after:rounded-full'
              )
            "
          ></span>
        </slot>
      </span>

      <span class="ht-radio__label inline-block">
        <slot :checked="isChecked" :disabled="isDisabled" />
      </span>
    </span>
  </RadioGroupItem>
</template>

<style>
:root {
  --radio-container-gap-default: var(--dimensions-spacing-stack-sm); /** 单选框与文本默认间距 */
  --radio-opacity-disabled: var(--color-surface-transparent); /** 单选框禁用时透明度 */

  /** icon部分 - 默认尺寸 */
  --radio-ring-size-default: var(--size-1); /** 单选框内层圆环默认尺寸 */
  --radio-outer-size-default: var(--dimensions-sizing-icon-2xl); /** 单选框外层圆环默认尺寸 */
  --radio-outer-border-width-default: var(--dimensions-border-width-thick); /** 单选框外层圆环默认边框宽度 */

  /** icon部分 - small尺寸 */
  --radio-ring-size-small: var(--size-1); /** 单选框内层圆环小尺寸 */
  --radio-outer-size-small: var(--dimensions-sizing-container-md); /** 单选框外层圆环小尺寸 */
  --radio-outer-border-width-small: var(--dimensions-border-width-thick); /** 单选框外层圆环小尺寸边框宽度 */

  /** icon颜色 */
  --radio-outer-border-color-default: var(--color-border-default); /** 单选框未选中时icon的颜色 */
  --radio-outer-border-color-disabled: var(--color-border-disabled); /** 单选框禁用态时外层圆环的颜色 */
  --radio-icon-bg-color-disabled: var(--color-surface-disabled); /** 单选框禁用态时icon的背景色 */
  --radio-dot-color-disabled: var(--color-border-disabled); /** 单选框禁用态时内层圆点的颜色 */

  /** variant颜色 - primary */
  --radio-icon-color-primary-checked: var(--color-content-primary); /** 单选框primary选中时icon的颜色 */

  /** variant颜色 - secondary */
  --radio-icon-color-secondary-checked: var(--color-feedback-success-background); /** 单选框secondary选中时icon的颜色 */

  /** 当前使用的 checked 颜色（可被 variant 类覆盖） */
  --radio-icon-color-checked: var(--radio-icon-color-primary-checked);

  /** 文本部分 */
  --radio-text-font-size-default: var(--typography-body-l-size); /** 单选框文本默认字号 */
  --radio-text-font-size-small: var(--typography-body-m-size); /** 单选框文本小字号 */
  --radio-text-color-default: var(--color-content-primary); /** 单选框文本默认颜色 */
  --radio-text-color-disabled: var(--color-content-disabled); /** 单选框禁用时文本颜色 */
}
@layer components {
  .ht-radio {
    color: var(--radio-text-color-default);
    font-size: var(--radio-text-font-size-default);
  }

  .ht-radio__inner {
    gap: var(--radio-container-gap-default);
  }

  .ht-radio__icon {
    width: var(--radio-outer-size-default);
    height: var(--radio-outer-size-default);
  }

  .ht-radio--small .ht-radio__icon {
    width: var(--radio-outer-size-small);
    height: var(--radio-outer-size-small);
  }

  .ht-radio--small .ht-radio__label {
    font-size: var(--radio-text-font-size-small);
  }

  .ht-radio--small .ht-radio__round,
  .ht-radio--small .ht-radio__ring {
    border-width: var(--radio-outer-border-width-small);
  }

  .ht-radio--small .ht-radio__ring::after {
    width: calc(100% - var(--radio-ring-size-small) * 2);
    height: calc(100% - var(--radio-ring-size-small) * 2);
  }

  .ht-radio--small .ht-radio__check-icon {
    font-size: calc(var(--radio-outer-size-small) - var(--radio-ring-size-small) * 2);
  }

  .ht-radio--small .ht-radio__label {
    line-height: var(--radio-outer-size-small);
  }

  /* round 形状：圆形外框 + 内部勾选 icon */
  .ht-radio__round {
    border-width: var(--radio-outer-border-width-default);
    border-color: var(--radio-outer-border-color-default);
  }

  /* primary variant */
  .ht-radio--primary {
    --radio-icon-color-checked: var(--radio-custom-checked-color, var(--radio-icon-color-primary-checked));
  }

  .ht-radio--primary[data-state='checked'] .ht-radio__round {
    border-color: var(--radio-icon-color-checked);
    background-color: var(--radio-icon-color-checked);
  }

  .ht-radio--primary[data-state='checked'] .ht-radio__ring {
    border-color: var(--radio-icon-color-checked);
  }

  .ht-radio--primary[data-state='checked'] .ht-radio__ring::after {
    background-color: var(--radio-icon-color-checked);
  }

  /* secondary variant */
  .ht-radio--secondary {
    --radio-icon-color-checked: var(--radio-custom-checked-color, var(--radio-icon-color-secondary-checked));
  }

  .ht-radio--secondary[data-state='checked'] .ht-radio__round {
    border-color: var(--radio-icon-color-checked);
    background-color: var(--radio-icon-color-checked);
  }

  .ht-radio--secondary[data-state='checked'] .ht-radio__ring {
    border-color: var(--radio-icon-color-checked);
  }

  .ht-radio--secondary[data-state='checked'] .ht-radio__ring::after {
    background-color: var(--radio-icon-color-checked);
  }

  .ht-radio__check-icon {
    font-size: calc(var(--radio-outer-size-default) - var(--radio-ring-size-default) * 2);
    color: #ffffff;
  }

  /* dot 形状：圆形外框 + 圆形内部标记 */
  .ht-radio__ring {
    border-width: var(--radio-outer-border-width-default);
    border-color: var(--radio-outer-border-color-default);
    transition:
      border-color 0.18s ease,
      background-color 0.18s ease,
      transform 0.18s cubic-bezier(0.2, 0.8, 0.2, 1);
  }

  .ht-radio__ring::after {
    content: '';
    width: calc(100% - var(--radio-ring-size-default) * 2);
    height: calc(100% - var(--radio-ring-size-default) * 2);
    transform: translate(-50%, -50%) scale(0.001);
    transition:
      transform 0.12s ease,
      background-color 0.18s ease;
  }

  .ht-radio[data-state='checked'] .ht-radio__ring::after {
    transform: translate(-50%, -50%) scale(1);
  }

  .ht-radio[data-disabled] {
    opacity: var(--radio-opacity-disabled);
    color: var(--radio-text-color-disabled);
  }

  .ht-radio[data-disabled] .ht-radio__round {
    border-color: var(--radio-outer-border-color-disabled);
    background-color: var(--radio-icon-bg-color-disabled);
  }

  .ht-radio[data-disabled] .ht-radio__check-icon {
    color: var(--radio-dot-color-disabled);
  }

  .ht-radio[data-disabled] .ht-radio__ring {
    border-color: var(--radio-outer-border-color-disabled);
  }

  .ht-radio[data-disabled] .ht-radio__ring::after {
    background-color: var(--radio-dot-color-disabled);
  }

  .ht-radio__label {
    line-height: var(--radio-outer-size-default);
  }
}
</style>
