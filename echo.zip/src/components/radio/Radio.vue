<script setup lang="ts">
import { computed } from 'vue';
import { RadioGroupItem } from 'reka-ui';
import { addUnit, cn, RADIO_GROUP_KEY } from '@/utils/index';
import { useParent } from '@/hooks';
import type { RadioProps } from './types';

const props = withDefaults(defineProps<RadioProps>(), {
  disabled: false,
});

const emit = defineEmits<{ (e: 'click', ev: MouseEvent): void }>();

const { parent: radioGroup } = useParent(RADIO_GROUP_KEY);

const radioGroupDisabled = computed(() => radioGroup?.props.disabled);
const radioGroupIconSize = computed(() => radioGroup?.props.iconSize);
const radioGroupCheckedColor = computed(() => radioGroup?.props.checkedColor);
const radioGroupLabelPosition = computed(() => radioGroup?.props.labelPosition);
const radioGroupModel = computed(() => radioGroup?.props.modelValue);

const isDisabled = computed(() => !!props.disabled || !!radioGroupDisabled.value);
const isChecked = computed(() => (radioGroupModel.value ? radioGroupModel.value === props.name : false));

const resolvedIconSize = computed(() => addUnit(props.iconSize ?? radioGroupIconSize.value));
const resolvedCheckedColor = computed(() => props.checkedColor ?? radioGroupCheckedColor.value);
const labelPosition = computed(() => props.labelPosition ?? radioGroupLabelPosition.value ?? 'right');

function onClick(e: MouseEvent) {
  if (isDisabled.value) {
    e.preventDefault();
    e.stopPropagation();
    return;
  }
  emit('click', e);
}
</script>

<template>
  <RadioGroupItem
    :value="props.name"
    :disabled="isDisabled"
    :class="
      cn('ht-radio inline-flex items-center', {
        'cursor-not-allowed': isDisabled,
        'cursor-pointer': !isDisabled,
      })
    "
    @click="onClick"
    :style="{
      '--radio-color-checked': resolvedCheckedColor,
    }"
  >
    <span :class="cn('ht-radio__inner inline-flex items-center', { 'flex-row-reverse': labelPosition === 'left' })">
      <span
        class="ht-radio__icon inline-flex items-center justify-center [&_img]:block [&_img]:h-full [&_img]:w-full [&_img]:object-contain [&_svg]:block [&_svg]:h-full [&_svg]:w-full"
        :style="{ width: resolvedIconSize, height: resolvedIconSize }"
      >
        <slot name="icon" :checked="isChecked" :disabled="isDisabled">
          <span
            class="ht-radio__ring relative box-border h-full w-full rounded-full border-solid bg-transparent after:absolute after:top-1/2 after:left-1/2 after:block after:rounded-full"
          ></span>
        </slot>
      </span>

      <span class="ht-radio__label inline-block">
        <slot :checked="isChecked" :disabled="isDisabled" />
      </span>
    </span>
  </RadioGroupItem>
</template>

<style>
:root {
  --radio-container-gap-default: 8px; /** 单选框与文本默认间距 */
  --radio-opacity-disabled: 0.6; /** 单选框禁用时透明度 */

  /** icon部分 */
  --radio-ring-size-default: 8px; /** 单选框内层圆环默认尺寸 */
  --radio-outer-size-default: 20px; /** 单选框外层圆环默认尺寸 */
  --radio-outer-border-width-default: 2px; /** 单选框外层圆环默认边框宽度 */
  --radio-icon-color-default: #c9cdd4; /** 单选框未选中时icon的颜色 */
  --radio-icon-color-checked: #1677ff; /** 单选框选中时icon的颜色 */
  --radio-icon-color-disabled: #8c8c8c; /** 单选框禁用态时icon的颜色 */

  /** 文本部分 */
  --radio-text-font-size-default: 14px; /** 单选框文本默认字号 */
  --radio-text-color-default: #333333; /** 单选框文本默认颜色 */
  --radio-text-color-disabled: #8c8c8c; /** 单选框禁用时文本颜色 */
}
@layer components {
  .ht-radio {
    color: var(--radio-text-color-default);
    font-size: var(--radio-text-font-size-default);
  }

  .ht-radio__inner {
    gap: var(--radio-container-gap-default);
  }

  .ht-radio__icon {
    width: var(--radio-outer-size-default);
    height: var(--radio-outer-size-default);
  }

  .ht-radio__ring {
    border-width: var(--radio-outer-border-width-default);
    border-color: var(--radio-icon-color-default);
    transition:
      border-color 0.18s ease,
      background-color 0.18s ease,
      transform 0.18s cubic-bezier(0.2, 0.8, 0.2, 1);
  }

  .ht-radio__ring::after {
    content: '';
    width: calc(100% - var(--radio-ring-size-default));
    height: calc(100% - var(--radio-ring-size-default));
    transform: translate(-50%, -50%) scale(0.001);
    transition:
      transform 0.12s ease,
      background-color 0.18s ease;
  }

  .ht-radio[data-state='checked'] .ht-radio__ring {
    border-color: var(--radio-color-checked, var(--radio-icon-color-checked));
  }

  .ht-radio[data-state='checked'] .ht-radio__ring::after {
    transform: translate(-50%, -50%) scale(1);
    background-color: var(--radio-color-checked, var(--radio-icon-color-checked));
  }

  .ht-radio[data-disabled] {
    opacity: var(--radio-opacity-disabled);
    color: var(--radio-text-color-disabled);
  }

  .ht-radio[data-disabled] .ht-radio__ring {
    border-color: var(--radio-icon-color-disabled);
  }

  .ht-radio[data-disabled] .ht-radio__ring::after {
    background-color: var(--radio-icon-color-disabled);
  }

  .ht-radio__label {
    line-height: var(--radio-outer-size-default);
  }
}
</style>
