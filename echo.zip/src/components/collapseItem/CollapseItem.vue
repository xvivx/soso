<script setup lang="ts">
import { ref } from 'vue';
import { cva } from 'class-variance-authority';
import { AccordionContent, AccordionHeader, AccordionItem, AccordionTrigger } from 'reka-ui';
import HTIcon from '@/components/icon/Icon.vue';
import { COLLAPSE_KEY } from '@/utils/index';
import { useParent } from '@/hooks';
import type { CollapseItemProps } from './types';

const variants = cva('ht-collapse-item border-b', {
  variants: {
    size: {
      large: 'ht-collapse-item-large',
      default: 'ht-collapse-item-default',
    },
  },
  defaultVariants: {
    size: 'default',
  },
});

const props = withDefaults(defineProps<CollapseItemProps>(), {
  disabled: false,
});

useParent(COLLAPSE_KEY);

const accordionItemRef = ref<typeof AccordionItem>();
function toggle(expand?: boolean) {
  const accordionItemEl = accordionItemRef.value?.$el;
  if (!accordionItemEl) return;
  const trigger = accordionItemEl.querySelector('.ht-collapse-trigger');
  if (!trigger) return;

  const state = trigger.getAttribute('data-state');
  if (typeof expand === 'boolean') {
    if ((expand && state !== 'open') || (!expand && state !== 'closed')) {
      trigger.click();
    }
  } else {
    trigger.click();
  }
}

defineExpose({ toggle });
</script>

<template>
  <AccordionItem ref="accordionItemRef" :value="name" :class="variants({ size })">
    <AccordionHeader as-child>
      <AccordionTrigger
        class="ht-collapse-trigger group flex w-full cursor-pointer items-center justify-between"
        :disabled="disabled"
        :data-disabled="disabled"
        aria-disabled="disabled"
      >
        <div class="flex flex-1">
          <template v-if="icon">
            <HTIcon :name="icon" class="mr-1.5" />
          </template>
          <div :class="['ht-collapse-trigger__title', titleClass]" :data-disabled="disabled">
            <slot name="title">{{ props.title }}</slot>
          </div>
        </div>
        <div
          class="inline-flex transition-transform duration-200 ease-in-out group-data-[state=closed]:rotate-0 group-data-[state=open]:-rotate-180"
        >
          <slot name="icon-right">
            <HTIcon>
              <svg
                xmlns="http://www.w3.org/2000/svg"
                xmlns:xlink="http://www.w3.org/1999/xlink"
                t="1760884392814"
                class="icon"
                viewBox="0 0 1024 1024"
                version="1.1"
                p-id="2931"
                width="200"
                height="200"
              >
                <path
                  d="M512.197498 752.238526 158.499897 398.540925c-18.73776-18.73776-18.73776-49.092092 0-67.828828s49.092092-18.73776 67.828828 0l285.868773 285.868773 285.868773-285.868773c18.73776-18.73776 49.092092-18.73776 67.828828 0s18.73776 49.092092 0 67.828828L512.197498 752.238526z"
                  fill="currentColor"
                  p-id="2932"
                />
              </svg>
            </HTIcon>
          </slot>
        </div>
      </AccordionTrigger>
    </AccordionHeader>
    <AccordionContent
      class="ht-collapse-content data-[state=closed]:animate-accordion-up data-[state=open]:animate-accordion-down overflow-hidden text-sm"
    >
      <div class="ht-collapse-content__inner">
        <slot />
      </div>
    </AccordionContent>
  </AccordionItem>
</template>

<style>
:root {
  /** 头部 */
  --collapse-item-header-height-default: 48px; /** 头部默认高度 */
  --collapse-item-header-padding-default: 16px 20px; /** 头部默认内边距 */
  --collapse-item-header-bg-color-default: #ffffff; /** 头部默认背景色 */
  --collapse-item-header-bg-color-active: #f5f5f5; /** 头部 active 背景色 */
  --collapse-item-header-title-font-size-default: 14px; /** 头部标题默认字号 */
  --collapse-item-header-title-font-size-large: 16px; /** 头部标题大号字号 */
  --collapse-item-header-title-color-default: #333333; /** 头部标题默认颜色 */
  --collapse-item-header-title-color-disabled: #8c8c8c; /** 头部标题禁用颜色 */
  --collapse-item-header-arrow-size-default: 16px; /** 头部箭头默认尺寸 */
  --collapse-item-header-arrow-color-default: #8c8c8c; /** 头部箭头默认颜色 */

  /** 内容区 */
  --collapse-item-content-padding-default: 0 20px 16px; /** 内容区默认内边距 */
  --collapse-item-content-font-size-default: 14px; /** 内容区默认字号 */
  --collapse-item-content-color-default: #666666; /** 内容区默认颜色 */
  --collapse-item-content-transition-duration: 0.3s; /** 内容展开/折叠过渡时间 */

  /** 其他 */
  --collapse-item-border-color-default: #ececed; /** 项之间默认边框色 */
  --collapse-item-opacity-disabled: 0.5; /** 项禁用时透明度 */
}
@layer components {
  .ht-collapse-item {
    border-bottom-color: var(--collapse-item-border-color-default);
  }

  .ht-collapse-trigger {
    padding: var(--collapse-item-header-padding-default);
    height: var(--collapse-item-header-height-default);
    background-color: var(--collapse-item-header-bg-color-default);
  }

  .ht-collapse-trigger:active {
    background: var(--collapse-item-header-bg-color-active);
  }

  .ht-collapse-trigger__title {
    font-size: var(--collapse-item-header-title-font-size-default);
    color: var(--collapse-item-header-title-color-default);
  }

  .ht-collapse-item-large .ht-collapse-trigger__title {
    font-size: var(--collapse-item-header-title-font-size-large);
  }

  .ht-collapse-trigger[data-disabled='true'] {
    color: var(--collapse-item-header-title-color-disabled);
    opacity: var(--collapse-item-opacity-disabled);
    cursor: not-allowed;
  }

  .ht-collapse-trigger .ht-icon {
    width: var(--collapse-item-header-arrow-size-default);
    height: var(--collapse-item-header-arrow-size-default);
    color: var(--collapse-item-header-arrow-color-default);
  }

  .ht-collapse-content {
    font-size: var(--collapse-item-content-font-size-default);
    color: var(--collapse-item-content-color-default);
    transition-duration: var(--collapse-item-content-transition-duration);
  }

  .ht-collapse-content__inner {
    padding: var(--collapse-item-content-padding-default);
  }
}
</style>
