import HTCollapseItem from './CollapseItem.vue';

export { HTCollapseItem };
export default HTCollapseItem;
export type { CollapseItemProps, CollapseItemInstance } from './types';
