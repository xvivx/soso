import type { ComponentPublicInstance } from 'vue';

export interface CollapseItemProps {
  name: string;
  icon?: string;
  size?: 'default' | 'large';
  title?: string;
  disabled?: boolean;
  titleClass?: string;
}

export type CollapseItemExpose = {
  toggle: (newValue?: boolean) => void;
};

export type CollapseItemInstance = ComponentPublicInstance<CollapseItemProps, CollapseItemExpose>;
