/* HTButton 常量定义 */

import { cva } from 'class-variance-authority';

// CVA 变体定义
export const buttonVariants = cva(
  'ht-button inline-flex items-center justify-center font-medium transition-all duration-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50',
  {
    variants: {
      type: {
        default: 'btn-default',
        primary: 'btn-primary',
        success: 'btn-success',
        warning: 'btn-warning',
        danger: 'btn-danger',
        info: 'btn-info',
      },
      size: {
        large: 'btn-large',
        normal: 'btn-normal',
        small: 'btn-small',
        mini: 'btn-mini',
      },
      plain: {
        true: 'btn-plain',
        false: '',
      },
      block: {
        true: 'w-full',
        false: '',
      },
      round: {
        true: 'btn-round',
        false: '',
      },
      square: {
        true: 'btn-square',
        false: '',
      },
      hairline: {
        true: 'btn-hairline',
        false: '',
      },
      loading: {
        true: 'cursor-wait',
        false: '',
      },
      variant: {
        default: '',
        destructive: '',
        outline: '',
        secondary: '',
        ghost: '',
        link: '',
      },
    },
    defaultVariants: {
      type: 'default',
      size: 'normal',
      plain: false,
      block: false,
      round: false,
      square: false,
      hairline: false,
      loading: false,
      variant: 'default',
    },
  }
);

// 按钮类型映射
export const BUTTON_TYPE_MAP = {
  default: 'default',
  primary: 'primary',
  success: 'success',
  warning: 'warning',
  danger: 'danger',
  info: 'info',
} as const;

// 按钮尺寸映射
export const BUTTON_SIZE_MAP = {
  large: 'large',
  normal: 'normal',
  small: 'small',
  mini: 'mini',
} as const;

// 加载类型映射
export const LOADING_TYPE_MAP = {
  spinner: 'spinner',
  circular: 'circular',
} as const;

// 图标位置映射
export const ICON_POSITION_MAP = {
  left: 'left',
  right: 'right',
} as const;

// 原生按钮类型映射
export const NATIVE_TYPE_MAP = {
  button: 'button',
  submit: 'submit',
  reset: 'reset',
} as const;

// 支持的按钮类型列表
export const SUPPORTED_BUTTON_TYPES: readonly string[] = Object.values(BUTTON_TYPE_MAP);

// 支持的按钮尺寸列表
export const SUPPORTED_BUTTON_SIZES: readonly string[] = Object.values(BUTTON_SIZE_MAP);

// 支持的加载类型列表
export const SUPPORTED_LOADING_TYPES: readonly string[] = Object.values(LOADING_TYPE_MAP);

// 支持的图标位置列表
export const SUPPORTED_ICON_POSITIONS: readonly string[] = Object.values(ICON_POSITION_MAP);

// 支持的原生类型列表
export const SUPPORTED_NATIVE_TYPES: readonly string[] = Object.values(NATIVE_TYPE_MAP);

// 按钮状态常量
export const BUTTON_STATE = {
  LOADING: 'loading',
  DISABLED: 'disabled',
  ACTIVE: 'active',
  HOVER: 'hover',
  FOCUS: 'focus',
} as const;

// 动画持续时间常量（毫秒）
export const ANIMATION_DURATION = {
  FAST: 200,
  NORMAL: 300,
  SLOW: 500,
  LOADING_ROTATE: 800,
  LOADING_DASH: 1500,
  LOADING_SPIN: 1200,
  LOADING_DOT: 1400,
} as const;

// 默认加载尺寸
export const DEFAULT_LOADING_SIZE = 20;

// 最小加载尺寸
export const MIN_LOADING_SIZE = 12;

// 最大加载尺寸
export const MAX_LOADING_SIZE = 48;
