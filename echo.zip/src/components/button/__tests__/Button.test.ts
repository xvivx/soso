import { fireEvent, screen } from '@testing-library/vue';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import { click, renderWithMounting } from '../../../../test/utils';
import HTButton from '../Button.vue';

// Mock window.location
Object.defineProperty(window, 'location', {
  value: {
    href: '',
    replace: vi.fn(),
  },
  writable: true,
});

describe('HTButton', () => {
  beforeEach(() => {
    // 清理 DOM
    document.body.innerHTML = '';
    // 重置 window.location mock
    window.location.href = '';
  });

  describe('基础渲染', () => {
    it('应该正确渲染默认按钮', () => {
      renderWithMounting(HTButton, {
        slots: {
          default: 'Click me',
        },
      });

      const button = screen.getByRole('button', { name: 'Click me' });
      expect(button).toBeInTheDocument();
      expect(button).toHaveClass('ht-button');
      expect(button).toHaveClass('btn-default');
      expect(button).toHaveClass('btn-normal');
    });

    it('应该支持自定义标签', () => {
      const { container } = renderWithMounting(HTButton, {
        props: {
          tag: 'a',
        },
        slots: {
          default: 'Link Button',
        },
      });

      const link = container.querySelector('a');
      expect(link).toBeInTheDocument();
      expect(link?.tagName).toBe('A');
      expect(link).toHaveClass('ht-button');
    });

    it('应该支持自定义 class', () => {
      renderWithMounting(HTButton, {
        attrs: {
          class: 'custom-class',
        },
        slots: {
          default: 'Button',
        },
      });

      const button = screen.getByRole('button');
      expect(button).toHaveClass('custom-class');
    });

    it('应该渲染插槽内容', () => {
      renderWithMounting(HTButton, {
        slots: {
          default: 'Button Content',
        },
      });

      const button = screen.getByText('Button Content');
      expect(button).toBeInTheDocument();
    });
  });

  describe('主题变体', () => {
    const types = ['primary', 'success', 'warning', 'danger'] as const;

    it.each(types)('应该应用 %s 类型', (type) => {
      renderWithMounting(HTButton, {
        props: {
          type,
        },
        slots: {
          default: `${type} Button`,
        },
      });

      const button = screen.getByRole('button');
      expect(button).toHaveClass(`btn-${type}`);
    });
  });

  describe('尺寸变体', () => {
    const sizes = ['normal', 'large', 'small', 'mini'] as const;

    it.each(sizes)('应该应用 %s 尺寸', (size) => {
      renderWithMounting(HTButton, {
        props: {
          size,
        },
        slots: {
          default: `${size} Button`,
        },
      });

      const button = screen.getByRole('button');
      expect(button).toHaveClass(`btn-${size}`);
    });
  });

  describe('样式修饰符', () => {
    it('应该应用 plain 样式', () => {
      renderWithMounting(HTButton, {
        props: {
          plain: true,
        },
        slots: {
          default: 'Plain Button',
        },
      });

      const button = screen.getByRole('button');
      expect(button).toHaveClass('btn-plain');
    });

    it('应该应用 block 样式', () => {
      renderWithMounting(HTButton, {
        props: {
          block: true,
        },
        slots: {
          default: 'Block Button',
        },
      });

      const button = screen.getByRole('button');
      expect(button).toHaveClass('w-full');
    });

    it('应该应用 round 样式', () => {
      renderWithMounting(HTButton, {
        props: {
          round: true,
        },
        slots: {
          default: 'Round Button',
        },
      });

      const button = screen.getByRole('button');
      expect(button).toHaveClass('btn-round');
    });
  });

  describe('组合样式', () => {
    it('应该支持组合多个样式修饰符', () => {
      renderWithMounting(HTButton, {
        props: {
          type: 'success',
          size: 'large',
          plain: true,
          block: true,
          round: true,
        },
        slots: {
          default: 'Combined Button',
        },
      });

      const button = screen.getByRole('button');
      expect(button).toHaveClass('ht-button');
      expect(button).toHaveClass('btn-success');
      expect(button).toHaveClass('btn-large');
      expect(button).toHaveClass('btn-plain');
      expect(button).toHaveClass('w-full');
      expect(button).toHaveClass('btn-round');
    });
  });

  describe('交互行为', () => {
    it('应该响应点击事件', async () => {
      const handleClick = vi.fn();

      renderWithMounting(HTButton, {
        props: {
          onClick: handleClick,
        },
        slots: {
          default: 'Click Me',
        },
      });

      const button = screen.getByRole('button');
      await click(button);

      expect(handleClick).toHaveBeenCalledTimes(1);
    });

    it('应该响应多个点击事件', async () => {
      const handleClick = vi.fn();

      renderWithMounting(HTButton, {
        props: {
          onClick: handleClick,
        },
        slots: {
          default: 'Click Me',
        },
      });

      const button = screen.getByRole('button');
      await click(button);
      await click(button);
      await click(button);

      expect(handleClick).toHaveBeenCalledTimes(3);
    });

    it('应该支持传递事件处理器', async () => {
      const handleMouseEnter = vi.fn();
      const handleMouseLeave = vi.fn();

      renderWithMounting(HTButton, {
        props: {
          onMouseenter: handleMouseEnter,
          onMouseleave: handleMouseLeave,
        },
        slots: {
          default: 'Hover Button',
        },
      });

      const button = screen.getByRole('button');

      await fireEvent.mouseEnter(button);
      expect(handleMouseEnter).toHaveBeenCalledTimes(1);

      await fireEvent.mouseLeave(button);
      expect(handleMouseLeave).toHaveBeenCalledTimes(1);
    });
  });

  describe('可访问性', () => {
    it('应该有正确的 role 属性', () => {
      renderWithMounting(HTButton, {
        slots: {
          default: 'Accessible Button',
        },
      });

      const button = screen.getByRole('button');
      expect(button).toBeInTheDocument();
    });

    it('应该支持 disabled 属性', () => {
      renderWithMounting(HTButton, {
        attrs: {
          disabled: true,
        },
        slots: {
          default: 'Disabled Button',
        },
      });

      const button = screen.getByRole('button');
      expect(button).toBeDisabled();
      expect(button).toHaveClass('disabled:pointer-events-none');
    });

    it('应该支持 aria 属性', () => {
      renderWithMounting(HTButton, {
        attrs: {
          'aria-label': 'Custom Label',
          'aria-describedby': 'button-description',
        },
        slots: {
          default: 'Aria Button',
        },
      });

      const button = screen.getByRole('button');
      expect(button).toHaveAttribute('aria-label', 'Custom Label');
      expect(button).toHaveAttribute('aria-describedby', 'button-description');
    });
  });

  describe('复杂插槽内容', () => {
    it('应该支持图标和文本组合', () => {
      renderWithMounting(HTButton, {
        slots: {
          default: ['<span data-testid="icon">🚀</span>', ' Button with Icon'],
        },
      });

      const button = screen.getByRole('button');
      const icon = button.querySelector('[data-testid="icon"]');
      expect(icon).toBeInTheDocument();
      expect(button).toHaveTextContent('Button with Icon');
    });

    it('应该支持 HTML 内容', () => {
      renderWithMounting(HTButton, {
        slots: {
          default: '<strong>Bold</strong> and <em>italic</em> text',
        },
      });

      const button = screen.getByRole('button');
      expect(button).toContainHTML('<strong>Bold</strong>');
      expect(button).toContainHTML('<em>italic</em>');
    });
  });

  describe('CSS 变量和样式', () => {
    it('应该有正确的 CSS 类名', () => {
      renderWithMounting(HTButton, {
        props: {
          type: 'primary',
          size: 'large',
        },
        slots: {
          default: 'Styled Button',
        },
      });

      const button = screen.getByRole('button');

      // 检查基础类名
      expect(button).toHaveClass('ht-button');
      expect(button).toHaveClass('btn-primary');
      expect(button).toHaveClass('btn-large');

      // 检查过渡效果
      expect(button).toHaveClass('transition-all');
    });

    it('应该继承 CSS 变量', () => {
      renderWithMounting(HTButton, {
        props: {
          type: 'primary',
        },
        slots: {
          default: 'CSS Variable Button',
        },
      });

      const button = screen.getByRole('button');

      // 注意：在测试环境中，CSS 变量的计算可能不同
      // 这里主要检查类名是否正确应用
      expect(button).toHaveClass('btn-primary');
    });
  });

  describe('边界情况', () => {
    it('应该处理空内容', () => {
      renderWithMounting(HTButton);

      const button = screen.getByRole('button');
      expect(button).toBeInTheDocument();
      expect(button.textContent).toBe('');
    });

    it('应该处理长文本内容', () => {
      const longText = 'A'.repeat(1000);
      renderWithMounting(HTButton, {
        slots: {
          default: longText,
        },
      });

      const button = screen.getByRole('button');
      expect(button).toHaveTextContent(longText);
    });

    it('应该处理特殊字符', () => {
      const specialChars = '!@#$%^&*()_+-=[]{}|;:,.<>?';
      renderWithMounting(HTButton, {
        slots: {
          default: specialChars,
        },
      });

      const button = screen.getByRole('button');
      expect(button).toHaveTextContent(specialChars);
    });
  });

  describe('URL 导航功能', () => {
    it('应该支持 URL 导航 with url prop', async () => {
      const testUrl = 'https://example.com';
      renderWithMounting(HTButton, {
        props: {
          url: testUrl,
        },
        slots: {
          default: 'External Link',
        },
      });

      const button = screen.getByRole('button');
      await click(button);

      expect(window.location.href).toBe(testUrl);
    });

    it('应该支持 URL 导航 with replace prop', async () => {
      const testUrl = 'https://example.com';
      renderWithMounting(HTButton, {
        props: {
          url: testUrl,
          replace: true,
        },
        slots: {
          default: 'Replace Link',
        },
      });

      const button = screen.getByRole('button');
      await click(button);

      expect(window.location.replace).toHaveBeenCalledWith(testUrl);
    });

    it('应该在禁用状态下不执行导航', async () => {
      renderWithMounting(HTButton, {
        props: {
          url: 'https://example.com',
          disabled: true,
        },
        slots: {
          default: 'Disabled Navigation',
        },
      });

      const button = screen.getByRole('button');
      await click(button);

      expect(window.location.href).toBe('');
    });

    it('应该在加载状态下不执行导航', async () => {
      renderWithMounting(HTButton, {
        props: {
          url: 'https://example.com',
          loading: true,
        },
        slots: {
          default: 'Loading Navigation',
        },
      });

      const button = screen.getByRole('button');
      await click(button);

      expect(window.location.href).toBe('');
    });
  });

  describe('加载状态', () => {
    it('应该显示加载状态', () => {
      renderWithMounting(HTButton, {
        props: {
          loading: true,
          loadingText: 'Loading...',
        },
        slots: {
          default: 'Button',
        },
      });

      const button = screen.getByRole('button');
      expect(button).toBeInTheDocument();

      const loadingText = screen.getByText('Loading...');
      expect(loadingText).toBeInTheDocument();
    });

    it('应该支持自定义加载类型', () => {
      renderWithMounting(HTButton, {
        props: {
          loading: true,
          loadingType: 'spinner',
        },
        slots: {
          default: 'Button',
        },
      });

      const button = screen.getByRole('button');
      expect(button).toBeInTheDocument();

      const spinner = button.querySelector('.ht-loading-icon--spinner');
      expect(spinner).toBeInTheDocument();
    });

    it('应该支持自定义加载尺寸', () => {
      renderWithMounting(HTButton, {
        props: {
          loading: true,
          loadingSize: 24,
        },
        slots: {
          default: 'Button',
        },
      });

      const button = screen.getByRole('button');
      expect(button).toBeInTheDocument();

      const loadingIcon = button.querySelector('.ht-loading-icon');
      // 检查内联样式
      expect(loadingIcon?.style.fontSize).toBe('24px');
    });
  });

  describe('图标功能', () => {
    it('应该支持图标名称', () => {
      renderWithMounting(HTButton, {
        props: {
          icon: 'home',
          iconPrefix: 'ht-icon',
        },
        slots: {
          default: 'Home',
        },
      });

      const button = screen.getByRole('button');
      const icon = button.querySelector('.ht-icon-home');
      expect(icon).toBeInTheDocument();
    });

    it('应该支持图标 URL', () => {
      const iconUrl = 'https://example.com/icon.png';
      renderWithMounting(HTButton, {
        props: {
          icon: iconUrl,
        },
        slots: {
          default: 'URL Icon',
        },
      });

      const button = screen.getByRole('button');
      const iconImg = button.querySelector('.ht-button__icon-img');
      expect(iconImg).toHaveAttribute('src', iconUrl);
    });

    it('应该支持图标位置在右侧', () => {
      renderWithMounting(HTButton, {
        props: {
          icon: 'home',
          iconPosition: 'right',
        },
        slots: {
          default: 'Right Icon',
        },
      });

      const button = screen.getByRole('button');
      const rightIcon = button.querySelector('.ht-button__icon--right');
      expect(rightIcon).toBeInTheDocument();

      const leftIcon = button.querySelector('.ht-button__icon--left');
      expect(leftIcon).not.toBeInTheDocument();
    });
  });

  describe('无障碍功能', () => {
    it('应该设置 aria-disabled 属性当按钮被禁用时', () => {
      renderWithMounting(HTButton, {
        props: {
          disabled: true,
        },
        slots: {
          default: 'Disabled Button',
        },
      });

      const button = screen.getByRole('button');
      expect(button).toHaveAttribute('aria-disabled', 'true');
    });

    it('应该设置 aria-busy 属性当按钮处于加载状态时', () => {
      renderWithMounting(HTButton, {
        props: {
          loading: true,
        },
        slots: {
          default: 'Loading Button',
        },
      });

      const button = screen.getByRole('button');
      expect(button).toHaveAttribute('aria-busy', 'true');
    });

    it('应该同时设置 aria-disabled 和 aria-busy 当按钮被禁用且处于加载状态时', () => {
      renderWithMounting(HTButton, {
        props: {
          disabled: true,
          loading: true,
        },
        slots: {
          default: 'Disabled Loading Button',
        },
      });

      const button = screen.getByRole('button');
      expect(button).toHaveAttribute('aria-disabled', 'true');
      expect(button).toHaveAttribute('aria-busy', 'true');
    });
  });
});
