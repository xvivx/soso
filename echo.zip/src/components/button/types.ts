/* HTButton 类型定义 */

// 兼容 Vant API 的类型定义
export type ButtonType = 'default' | 'primary' | 'success' | 'warning' | 'danger';
export type ButtonSize = 'large' | 'normal' | 'small' | 'mini';
export type IconPosition = 'left' | 'right';
export type LoadingType = 'spinner' | 'circular';
export type NativeType = 'button' | 'submit' | 'reset';

// shadcn-vue 扩展类型
export type ButtonVariant = 'default' | 'destructive' | 'outline' | 'secondary' | 'ghost' | 'link';

// Props 接口
export interface HTButtonProps {
  // Vant 兼容 API
  type?: ButtonType;
  size?: ButtonSize;
  text?: string;
  color?: string;
  icon?: string;
  iconPrefix?: string;
  iconPosition?: IconPosition;
  plain?: boolean;
  block?: boolean;
  round?: boolean;
  square?: boolean;
  loading?: boolean;
  disabled?: boolean;
  hairline?: boolean;
  loadingText?: string;
  loadingType?: LoadingType;
  loadingSize?: number | string;
  tag?: keyof HTMLElementTagNameMap;
  nativeType?: NativeType;
  url?: string;
  replace?: boolean;

  // shadcn-vue 扩展属性
  variant?: ButtonVariant;
  className?: string;
  asChild?: boolean;

  // reka-ui 兼容属性
  as?: keyof HTMLElementTagNameMap | 'button' | 'a' | 'div' | 'span';
}

// Events 接口
export interface HTButtonEmits {
  click: [event: MouseEvent];
  touchstart: [event: TouchEvent];
  // reka-ui 扩展事件
  keydown: [event: KeyboardEvent];
  keyup: [event: KeyboardEvent];
  focus: [event: FocusEvent];
  blur: [event: FocusEvent];
}

// Slots 接口
export interface HTButtonSlots {
  default: () => unknown;
  icon?: () => unknown;
  loading?: () => unknown;
}

// 按钮样式变体配置
export interface ButtonVariants {
  type: ButtonType;
  size: ButtonSize;
  plain: boolean;
  block: boolean;
  round: boolean;
  square: boolean;
  hairline: boolean;
  loading: boolean;
}

// 默认属性配置
export const DEFAULT_BUTTON_PROPS: Partial<HTButtonProps> = {
  type: 'default',
  size: 'normal',
  iconPrefix: 'ht-icon',
  iconPosition: 'left',
  plain: false,
  block: false,
  round: false,
  square: false,
  loading: false,
  disabled: false,
  hairline: false,
  loadingType: 'circular',
  loadingSize: 20,
  tag: 'button',
  nativeType: 'button',
  replace: false,
  variant: 'default',
  asChild: false,
  as: 'button',
};
