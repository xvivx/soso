<script setup lang="ts">
import { computed } from 'vue';
import { Primitive } from 'reka-ui';
import { cn } from '@/utils';
import { buttonVariants } from './constants';
import { type HTButtonEmits, type HTButtonProps } from './types';
// 导入样式
import './styles/index.css';

// Props 接口继承自 HTButtonProps
type Props = HTButtonProps;

const props = withDefaults(defineProps<Props>(), {
  type: 'default',
  size: 'normal',
  iconPrefix: 'ht-icon',
  iconPosition: 'left',
  plain: false,
  block: false,
  round: false,
  square: false,
  loading: false,
  disabled: false,
  hairline: false,
  loadingType: 'circular',
  loadingSize: 20,
  tag: 'button',
  nativeType: 'button',
  replace: false,
  variant: 'default',
  asChild: false,
});

const emit = defineEmits<HTButtonEmits>();

// 计算按钮样式
const buttonClasses = computed(() => {
  return cn(
    buttonVariants({
      type: props.type,
      size: props.size,
      plain: props.plain,
      block: props.block,
      round: props.round,
      square: props.square,
      hairline: props.hairline,
      loading: props.loading,
    }),
    props.className
  );
});

// 计算自定义颜色样式
const customStyles = computed(() => {
  const styles: Record<string, string> = {};

  if (props.color) {
    // 支持渐变色
    if (props.color.includes('gradient')) {
      styles.background = props.color;
      styles.border = 'none';
    } else {
      styles.background = props.color;
      styles.borderColor = props.color;
    }
  }

  return styles;
});

// 处理点击事件
const handleClick = (event: MouseEvent) => {
  if (props.disabled || props.loading) {
    event.preventDefault();
    return;
  }

  // 处理导航逻辑
  navigate(event);

  emit('click', event);
};

// 处理触摸开始事件
const handleTouchstart = (event: TouchEvent) => {
  emit('touchstart', event);
};

// 处理键盘按下事件
const handleKeydown = (event: KeyboardEvent) => {
  emit('keydown', event);
};

// 处理键盘释放事件
const handleKeyup = (event: KeyboardEvent) => {
  emit('keyup', event);
};

// 处理获得焦点事件
const handleFocus = (event: FocusEvent) => {
  emit('focus', event);
};

// 处理失去焦点事件
const handleBlur = (event: FocusEvent) => {
  emit('blur', event);
};

// 判断是否显示加载状态
const showLoading = computed(() => props.loading);

// 判断按钮是否被禁用
const isDisabled = computed(() => props.disabled);

// 生成图标类名
const iconClass = computed(() => {
  if (!props.icon) return '';

  return props.icon.startsWith('http') ? '' : `${props.iconPrefix}-${props.icon}`;
});

// 生成加载图标尺寸
const computedLoadingSize = computed(() => {
  return typeof props.loadingSize === 'number' ? `${props.loadingSize}px` : props.loadingSize;
});

// 导航逻辑
const navigate = (event: MouseEvent) => {
  // 如果有 url 属性，使用浏览器导航
  if (props.url) {
    event.preventDefault();
    if (props.replace) {
      window.location.replace(props.url);
    } else {
      window.location.href = props.url;
    }
    return;
  }
};
</script>

<template>
  <Primitive
    :as="tag"
    :as-child="asChild"
    :class="buttonClasses"
    :style="customStyles"
    :disabled="isDisabled"
    :type="tag === 'button' ? nativeType : undefined"
    :href="url || undefined"
    :aria-disabled="isDisabled || undefined"
    :aria-busy="loading || undefined"
    v-bind="$attrs"
    @click="handleClick"
    @touchstart="handleTouchstart"
    @keydown="handleKeydown"
    @keyup="handleKeyup"
    @focus="handleFocus"
    @blur="handleBlur"
  >
    <!-- 加载状态图标 -->
    <div v-if="showLoading" class="ht-button__loading">
      <slot name="loading">
        <!-- 默认加载图标 - 使用 CSS 动画实现 -->
        <div
          class="ht-loading-icon"
          :class="`ht-loading-icon--${loadingType}`"
          :style="{ fontSize: computedLoadingSize }"
        >
          <svg viewBox="25 25 50 50" class="ht-loading-icon__circular">
            <circle cx="50" cy="50" r="20" fill="none" />
          </svg>
          <div v-if="loadingType === 'spinner'" class="ht-loading-icon__spinner">
            <div class="ht-loading-icon__dot"></div>
            <div class="ht-loading-icon__dot"></div>
            <div class="ht-loading-icon__dot"></div>
            <div class="ht-loading-icon__dot"></div>
          </div>
        </div>
      </slot>
      <span v-if="loadingText" class="ht-button__loading-text">
        {{ loadingText }}
      </span>
    </div>

    <!-- 按钮内容 -->
    <div v-else class="ht-button__content">
      <!-- 左侧图标 -->
      <div v-if="icon && iconPosition === 'left'" class="ht-button__icon ht-button__icon--left">
        <slot name="icon">
          <img v-if="icon.startsWith('http')" :src="icon" :alt="text || 'icon'" class="ht-button__icon-img" />
          <i v-else :class="iconClass" />
        </slot>
      </div>

      <!-- 按钮文本 -->
      <span v-if="text || $slots.default" class="ht-button__text">
        <slot>{{ text }}</slot>
      </span>

      <!-- 右侧图标 -->
      <div v-if="icon && iconPosition === 'right'" class="ht-button__icon ht-button__icon--right">
        <slot name="icon">
          <img v-if="icon.startsWith('http')" :src="icon" :alt="text || 'icon'" class="ht-button__icon-img" />
          <i v-else :class="iconClass" />
        </slot>
      </div>
    </div>
  </Primitive>
</template>
