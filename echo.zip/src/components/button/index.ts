/* HTButton 组件导出 */

import HTButton from './Button.vue';
import type {
  ButtonSize,
  ButtonType,
  ButtonVariant,
  HTButtonEmits,
  HTButtonProps,
  HTButtonSlots,
  IconPosition,
  NativeType,
} from './types';

// 导出组件
export { HTButton };
export default HTButton;

// 导出类型
export type {
  HTButtonProps,
  HTButtonEmits,
  HTButtonSlots,
  ButtonType,
  ButtonSize,
  IconPosition,
  NativeType,
  ButtonVariant,
};

// 导出常量
export {
  buttonVariants,
  BUTTON_TYPE_MAP,
  BUTTON_SIZE_MAP,
  LOADING_TYPE_MAP,
  ICON_POSITION_MAP,
  NATIVE_TYPE_MAP,
  SUPPORTED_BUTTON_TYPES,
  SUPPORTED_BUTTON_SIZES,
  SUPPORTED_LOADING_TYPES,
  SUPPORTED_ICON_POSITIONS,
  SUPPORTED_NATIVE_TYPES,
  BUTTON_STATE,
  ANIMATION_DURATION,
  DEFAULT_LOADING_SIZE,
  MIN_LOADING_SIZE,
  MAX_LOADING_SIZE,
} from './constants';

export { DEFAULT_BUTTON_PROPS } from './types';
