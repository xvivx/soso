export type DatePickerType = 'date' | 'time' | 'datetime' | 'year-month';

export interface DatePickerProps {
  modelValue?: Date;
  type?: DatePickerType;
  minDate?: Date;
  maxDate?: Date;
  title?: string;
  confirmText?: string;
  cancelText?: string;
  showToolbar?: boolean;
  filter?: (type: string, values: string[]) => string[];
  formatter?: (type: string, value: string) => string;
}

export interface DatePickerEmits {
  'update:modelValue': [value: Date];
  confirm: [value: Date];
  cancel: [];
  change: [value: Date];
}

export interface PickerColumn {
  type: 'year' | 'month' | 'day';
  values: string[];
  selectedIndex: number;
}
