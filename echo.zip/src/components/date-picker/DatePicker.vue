<script setup lang="ts">
import { computed, nextTick, onMounted, ref, watch } from 'vue';
import { cn } from '@/utils/index';
import type { DatePickerEmits, DatePickerProps } from './types';
import './styles/index.css';

const props = withDefaults(defineProps<DatePickerProps>(), {
  type: 'date',
  showToolbar: true,
  confirmText: '确认',
  cancelText: '取消',
});

const emit = defineEmits<DatePickerEmits>();

// 当前选中的年月日
const currentDate = ref(props.modelValue || new Date());
const selectedYear = ref(currentDate.value.getFullYear());
const selectedMonth = ref(currentDate.value.getMonth() + 1);
const selectedDay = ref(currentDate.value.getDate());

// 滚动容器引用
const yearRef = ref<HTMLDivElement>();
const monthRef = ref<HTMLDivElement>();
const dayRef = ref<HTMLDivElement>();

// 计算可选的年份范围
const years = computed(() => {
  const minYear = props.minDate?.getFullYear() || new Date().getFullYear() - 10;
  const maxYear = props.maxDate?.getFullYear() || new Date().getFullYear() + 10;
  const result: number[] = [];
  for (let i = minYear; i <= maxYear; i++) {
    result.push(i);
  }
  return result;
});

// 计算可选的月份范围
const months = computed(() => {
  const result: number[] = [];
  let minMonth = 1;
  let maxMonth = 12;

  if (props.minDate && selectedYear.value === props.minDate.getFullYear()) {
    minMonth = props.minDate.getMonth() + 1;
  }

  if (props.maxDate && selectedYear.value === props.maxDate.getFullYear()) {
    maxMonth = props.maxDate.getMonth() + 1;
  }

  for (let i = minMonth; i <= maxMonth; i++) {
    result.push(i);
  }
  return result;
});

// 计算可选的日期范围
const days = computed(() => {
  const result: number[] = [];
  let minDay = 1;
  let maxDay = new Date(selectedYear.value, selectedMonth.value, 0).getDate();

  if (
    props.minDate &&
    selectedYear.value === props.minDate.getFullYear() &&
    selectedMonth.value === props.minDate.getMonth() + 1
  ) {
    minDay = props.minDate.getDate();
  }

  if (
    props.maxDate &&
    selectedYear.value === props.maxDate.getFullYear() &&
    selectedMonth.value === props.maxDate.getMonth() + 1
  ) {
    maxDay = props.maxDate.getDate();
  }

  for (let i = minDay; i <= maxDay; i++) {
    result.push(i);
  }
  return result;
});

// 格式化显示
const formatValue = (type: string, value: number) => {
  if (props.formatter) {
    return props.formatter(type, value.toString());
  }
  if (type === 'year') return `${value}年`;
  if (type === 'month') return `${value}月`;
  if (type === 'day') return `${value}日`;
  return value.toString();
};

// 监听选中值变化
watch([selectedYear, selectedMonth, selectedDay], () => {
  if (!months.value.includes(selectedMonth.value)) {
    selectedMonth.value = months.value[0] || 1;
  }
  if (!days.value.includes(selectedDay.value)) {
    selectedDay.value = days.value[0] || 1;
  }

  const newDate = new Date(selectedYear.value, selectedMonth.value - 1, selectedDay.value);
  emit('change', newDate);
});

// 确认
function handleConfirm() {
  const date = new Date(selectedYear.value, selectedMonth.value - 1, selectedDay.value);
  emit('update:modelValue', date);
  emit('confirm', date);
}

// 取消
function handleCancel() {
  emit('cancel');
}

// 滚动到选中项
function scrollToSelected() {
  nextTick(() => {
    const itemHeight = 36; // 每项高度

    if (yearRef.value) {
      const yearIndex = years.value.indexOf(selectedYear.value);
      yearRef.value.scrollTop = yearIndex * itemHeight;
    }

    if (monthRef.value) {
      const monthIndex = months.value.indexOf(selectedMonth.value);
      monthRef.value.scrollTop = monthIndex * itemHeight;
    }

    if (dayRef.value) {
      const dayIndex = days.value.indexOf(selectedDay.value);
      dayRef.value.scrollTop = dayIndex * itemHeight;
    }
  });
}

// 处理滚动
function handleScroll(type: 'year' | 'month' | 'day', event: Event) {
  const target = event.target as HTMLDivElement;
  const itemHeight = 36;
  const scrollTop = target.scrollTop;
  const index = Math.round(scrollTop / itemHeight);

  if (type === 'year') {
    selectedYear.value = years.value[index] || selectedYear.value;
  } else if (type === 'month') {
    selectedMonth.value = months.value[index] || selectedMonth.value;
  } else if (type === 'day') {
    selectedDay.value = days.value[index] || selectedDay.value;
  }
}

onMounted(() => {
  scrollToSelected();
});

watch([years, months, days], () => {
  scrollToSelected();
});
</script>

<template>
  <div class="ht-date-picker">
    <!-- Toolbar -->
    <div v-if="showToolbar" class="ht-date-picker__toolbar">
      <button class="ht-date-picker__cancel" @click="handleCancel">
        {{ cancelText }}
      </button>
      <div v-if="title" class="ht-date-picker__title">{{ title }}</div>
      <button class="ht-date-picker__confirm" @click="handleConfirm">
        {{ confirmText }}
      </button>
    </div>

    <!-- Columns Container -->
    <div class="ht-date-picker__body">
      <!-- Mask -->
      <div class="ht-date-picker__mask">
        <div class="ht-date-picker__mask-top" />
        <div class="ht-date-picker__highlight" />
        <div class="ht-date-picker__mask-bottom" />
      </div>

      <!-- Columns -->
      <div class="ht-date-picker__columns">
        <!-- 年 -->
        <div ref="yearRef" class="ht-date-picker__column" @scroll="handleScroll('year', $event)">
          <div class="ht-date-picker__column-items">
            <div
              v-for="year in years"
              :key="year"
              :class="
                cn('ht-date-picker__item', {
                  'ht-date-picker__item--selected': year === selectedYear,
                })
              "
            >
              {{ formatValue('year', year) }}
            </div>
          </div>
        </div>

        <!-- 月 -->
        <div ref="monthRef" class="ht-date-picker__column" @scroll="handleScroll('month', $event)">
          <div class="ht-date-picker__column-items">
            <div
              v-for="month in months"
              :key="month"
              :class="
                cn('ht-date-picker__item', {
                  'ht-date-picker__item--selected': month === selectedMonth,
                })
              "
            >
              {{ formatValue('month', month) }}
            </div>
          </div>
        </div>

        <!-- 日 -->
        <div ref="dayRef" class="ht-date-picker__column" @scroll="handleScroll('day', $event)">
          <div class="ht-date-picker__column-items">
            <div
              v-for="day in days"
              :key="day"
              :class="
                cn('ht-date-picker__item', {
                  'ht-date-picker__item--selected': day === selectedDay,
                })
              "
            >
              {{ formatValue('day', day) }}
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
