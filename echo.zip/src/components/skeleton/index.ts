import HTSkeleton from './Skeleton.vue';

export default HTSkeleton;
export type { SkeletonProps, SkeletonAvatarShape } from './types';
