--skeleton-container-padding-default
容器默认内边距
16px
Dimensions / Spacing / Inset /MD
--skeleton-container-bg-color-default
容器默认背景色
#FFFFFF
Color modes / Surface / Primary


--skeleton-avatar-avatar-size-default
头像占位默认尺寸
40px
Dimensions / Sizing /Icon /4xI
--skeleton-avatar-avatar-size-small
头像占位小号尺寸
32px
Dimensions / Sizing /Icon /3xI
--skeleton-avatar-avatar-size-large
头像占位大号尺寸
48px
Dimensions / Sizing /Icon /6xI
--skeleton-avatar-avatar-border-radius-default
头像占位默认圆角
50%
Dimensions / Radius / Circle
--skeleton-avatar-avatar-border-radius-square

头像占位方形圆角
8px
Dimensions / Radius /MD
--skeleton-avatar-avatar-bg-color-default
头像占位默认背景色
#F2F3F5
Color modes / Content / Tertiary
--skeleton-avatar-avatar-animation-duration
头像占位动画时长
1.5s
数值对齐

--skeleton-avatar-avatar-animation-timing-function
头像占位动画曲线
ease-in-out
数值对齐



--skeleton-image-image-width-default
图片占位默认宽度
120px
数值对齐

--skeleton-image-image-height-default
图片占位默认高度
80px
数值对齐

--skeleton-image-image-border-radius-default
图片占位默认圆角
8px
Dimensions / Radius /MD
--skeleton-image-image-bg-color-default
图片占位默认背景色
#F2F3F5
Color modes / Content / Tertiary
--skeleton-image-image-animation-duration
图片占位动画时长
1.5s
数值对齐


--skeleton-paragraph-paragraph-margin-default
段落占位默认外边距
8px 0 0
数值对齐

--skeleton-paragraph-line-height-default
段落行占位默认高度
16px

--skeleton-paragraph-line-margin-default
段落行之间默认间距
8px 0 0
数值对齐

--skeleton-paragraph-line-border-radius-default
段落行默认圆角
4px

--skeleton-paragraph-line-bg-color-default
段落行默认背景色
#F2F3F5

--skeleton-paragraph-line-width-first
第一段行默认宽度
100%
数值对齐
百分比&固定值
--skeleton-paragraph-line-width-second
第二段行默认宽度
80%

--skeleton-paragraph-line-width-third
第三段行默认宽度
60%

--skeleton-paragraph-line-animation-duration
段落行动画时长
1.5s
数值对齐
