export type SkeletonAvatarShape = 'round' | 'square';

export interface SkeletonProps {
  row?: number;
  rowWidth?: string | number | (string | number)[];
  title?: boolean;
  titleWidth?: string | number;
  avatar?: boolean;
  avatarSize?: string | number;
  avatarShape?: SkeletonAvatarShape;
  loading?: boolean;
  animate?: boolean;
}
