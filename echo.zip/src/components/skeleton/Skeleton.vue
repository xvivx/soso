<script setup lang="ts">
import { computed, useSlots } from 'vue';
import { addUnit, cn } from '@/utils/index';
import type { SkeletonProps } from './types';
import './styles/index.css';

const props = withDefaults(defineProps<SkeletonProps>(), {
  row: 3,
  title: false,
  avatar: false,
  avatarShape: 'round',
  loading: true,
  animate: true,
});

const slots = useSlots();

const avatarSizeStyle = computed(() => {
  return addUnit(props.avatarSize || 40);
});

const titleWidthStyle = computed(() => {
  return addUnit(props.titleWidth || '40%');
});

const getRowWidth = (index: number): string => {
  if (Array.isArray(props.rowWidth)) {
    return addUnit(props.rowWidth[index] || '100%') || '';
  }
  if (props.rowWidth) {
    return addUnit(props.rowWidth) || '';
  }
  // 默认宽度：第一行100%，第二行80%，第三行60%，后续100%
  if (index === 0) return '100%';
  if (index === 1) return '80%';
  if (index === 2) return '60%';
  return '100%';
};
</script>

<template>
  <div
    v-if="loading"
    :class="
      cn('ht-skeleton', {
        'ht-skeleton--animate': animate,
      })
    "
  >
    <!-- 自定义 slot -->
    <slot v-if="slots.default" />

    <!-- 默认骨架屏 -->
    <div v-else class="ht-skeleton__content">
      <!-- 头像 -->
      <div
        v-if="avatar"
        :class="
          cn('ht-skeleton__avatar', {
            'ht-skeleton__avatar--round': avatarShape === 'round',
            'ht-skeleton__avatar--square': avatarShape === 'square',
          })
        "
        :style="{ width: avatarSizeStyle, height: avatarSizeStyle }"
      />

      <!-- 内容区 -->
      <div class="ht-skeleton__body">
        <!-- 标题 -->
        <div v-if="title" class="ht-skeleton__title" :style="{ width: titleWidthStyle }" />

        <!-- 段落 -->
        <div v-if="row" class="ht-skeleton__paragraph">
          <div v-for="index in row" :key="index" class="ht-skeleton__row" :style="{ width: getRowWidth(index - 1) }" />
        </div>
      </div>
    </div>
  </div>

  <!-- 加载完成后显示真实内容 -->
  <slot v-else name="template" />
</template>

<style scoped>
.ht-skeleton__content {
  display: flex;
  gap: 16px;
  padding: var(--skeleton-container-padding-default, 16px);
  background-color: var(--skeleton-container-bg-color-default, #ffffff);
}

.ht-skeleton__body {
  flex: 1;
  display: flex;
  flex-direction: column;
}
</style>
