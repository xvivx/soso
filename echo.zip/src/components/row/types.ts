import type { HTMLAttributes } from 'vue';

export interface RowProps {
  class?: HTMLAttributes['class'];
  tag?: string;
  gutter?: number | string;
  justify?: 'start' | 'end' | 'center' | 'space-around' | 'space-between';
  align?: 'top' | 'middle' | 'bottom';
  wrap?: boolean;
}
