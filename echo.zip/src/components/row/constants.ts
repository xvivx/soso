import { cva } from 'class-variance-authority';

export const rowVariants = cva('row', {
  variants: {
    justify: {
      start: 'row-justify-start',
      end: 'row-justify-end',
      center: 'row-justify-center',
      'space-around': 'row-justify-space-around',
      'space-between': 'row-justify-space-between',
    },
    align: {
      top: 'row-align-top',
      middle: 'row-align-middle',
      bottom: 'row-align-bottom',
    },
  },
  defaultVariants: {
    justify: 'start',
    align: 'top',
  },
});
