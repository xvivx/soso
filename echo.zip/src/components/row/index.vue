<script setup lang="ts">
import { computed, provide } from 'vue';
import { cn } from '@/utils';
import { rowVariants } from './constants';
import type { RowProps } from './types';

const props = withDefaults(defineProps<RowProps>(), {
  tag: 'div',
  gutter: 0,
  wrap: true,
});

const emit = defineEmits(['click']);

const classes = computed(() =>
  cn(rowVariants({ justify: props.justify, align: props.align }), { 'ht-row--nowrap': !props.wrap }, props.class)
);

const styles = computed(() => {
  const gutter = Number(props.gutter);
  if (!gutter) {
    return {};
  }

  const margin = `-${gutter / 2}px`;
  return {
    marginLeft: margin,
    marginRight: margin,
  };
});

function handleClick(event: MouseEvent) {
  emit('click', event);
}

provide(
  'row-gutter',
  computed(() => Number(props.gutter))
);
</script>

<template>
  <component :is="props.tag" :class="classes" :style="styles" @click="handleClick">
    <slot />
  </component>
</template>

<style>
@import './style/index.css';
</style>
