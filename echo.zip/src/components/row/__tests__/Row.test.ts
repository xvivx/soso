import { fireEvent, render, screen } from '@testing-library/vue';
import { describe, expect, it, vi } from 'vitest';
import HTRow from '../index.vue';

describe('HTRow', () => {
  it('应该正确渲染默认行', () => {
    const { container } = render(HTRow, {
      slots: {
        default: 'Row Content',
      },
    });

    const row = container.querySelector('.row');
    expect(row).toBeTruthy();
    expect(screen.getByText('Row Content')).toBeTruthy();
  });

  it('应该支持自定义标签', () => {
    const { container } = render(HTRow, {
      props: {
        tag: 'section',
      },
      slots: {
        default: 'Section Row',
      },
    });

    const section = container.querySelector('section');
    expect(section).toBeTruthy();
    expect(section?.tagName).toBe('SECTION');
    expect(section?.classList.contains('row')).toBe(true);
  });

  it('应该支持插槽内容', () => {
    render(HTRow, {
      slots: {
        default: '<div class="col">Column 1</div><div class="col">Column 2</div>',
      },
    });

    expect(screen.getByText('Column 1')).toBeTruthy();
    expect(screen.getByText('Column 2')).toBeTruthy();
  });

  it('应该支持水平对齐方式', () => {
    const justifyValues = ['start', 'end', 'center', 'space-around', 'space-between'] as const;

    justifyValues.forEach((justify) => {
      const { container } = render(HTRow, {
        props: {
          justify,
        },
        slots: {
          default: 'Content',
        },
      });

      const row = container.querySelector('.row');
      expect(row?.classList.contains(`row-justify-${justify}`)).toBe(true);
    });
  });

  it('应该支持垂直对齐方式', () => {
    const alignValues = ['top', 'middle', 'bottom'] as const;

    alignValues.forEach((align) => {
      const { container } = render(HTRow, {
        props: {
          align,
        },
        slots: {
          default: 'Content',
        },
      });

      const row = container.querySelector('.row');
      expect(row?.classList.contains(`row-align-${align}`)).toBe(true);
    });
  });

  it('应该支持间距设置', () => {
    const { container } = render(HTRow, {
      props: {
        gutter: 20,
      },
      slots: {
        default: 'Content',
      },
    });

    const row = container.querySelector('.row');
    const styles = row?.getAttribute('style');
    expect(styles).toContain('margin-left: -10px');
    expect(styles).toContain('margin-right: -10px');
  });

  it('间距为0时不应该有margin样式', () => {
    const { container } = render(HTRow, {
      props: {
        gutter: 0,
      },
      slots: {
        default: 'Content',
      },
    });

    const row = container.querySelector('.row');
    const styles = row?.getAttribute('style');
    expect(styles).toBeFalsy();
  });

  it('应该支持换行控制', () => {
    const { container } = render(HTRow, {
      props: {
        wrap: false,
      },
      slots: {
        default: 'Content',
      },
    });

    const row = container.querySelector('.row');
    expect(row?.classList.contains('ht-row--nowrap')).toBe(true);
  });

  it('默认应该支持换行', () => {
    const { container } = render(HTRow, {
      slots: {
        default: 'Content',
      },
    });

    const row = container.querySelector('.row');
    expect(row?.classList.contains('ht-row--nowrap')).toBe(false);
  });

  it('应该支持自定义类名', () => {
    const { container } = render(HTRow, {
      props: {
        class: 'custom-row-class',
      },
      slots: {
        default: 'Content',
      },
    });

    const row = container.querySelector('.row');
    expect(row?.classList.contains('custom-row-class')).toBe(true);
  });

  it('应该支持点击事件', async () => {
    const clickHandler = vi.fn();
    const { container } = render(HTRow, {
      props: {
        onClick: clickHandler,
      },
      slots: {
        default: 'Clickable Row',
      },
    });

    const row = container.querySelector('.row');
    expect(row).toBeTruthy();

    if (row) {
      await fireEvent.click(row);
      expect(clickHandler).toHaveBeenCalledTimes(1);
    }
  });

  it('应该正确处理复杂组合', () => {
    const { container } = render(HTRow, {
      props: {
        tag: 'section',
        justify: 'center',
        align: 'middle',
        gutter: 16,
        wrap: false,
        class: 'complex-row',
      },
      slots: {
        default: `
          <div class="col-1">Column 1</div>
          <div class="col-2">Column 2</div>
          <div class="col-3">Column 3</div>
        `,
      },
    });

    const row = container.querySelector('section');
    expect(row?.tagName).toBe('SECTION');
    expect(row?.classList.contains('row')).toBe(true);
    expect(row?.classList.contains('row-justify-center')).toBe(true);
    expect(row?.classList.contains('row-align-middle')).toBe(true);
    expect(row?.classList.contains('ht-row--nowrap')).toBe(true);
    expect(row?.classList.contains('complex-row')).toBe(true);

    const styles = row?.getAttribute('style');
    expect(styles).toContain('margin-left: -8px');
    expect(styles).toContain('margin-right: -8px');

    expect(screen.getByText('Column 1')).toBeTruthy();
    expect(screen.getByText('Column 2')).toBeTruthy();
    expect(screen.getByText('Column 3')).toBeTruthy();
  });

  it('应该提供gutter上下文给子组件', () => {
    // 这个测试验证Row组件是否正确提供了gutter上下文
    // 在实际使用中，Col组件会消费这个上下文
    const { container } = render(HTRow, {
      props: {
        gutter: 24,
      },
      slots: {
        default: '<div class="test-child">Child Content</div>',
      },
    });

    const row = container.querySelector('.row');
    expect(row).toBeTruthy();
    expect(screen.getByText('Child Content')).toBeTruthy();
  });

  it('应该正确处理字符串类型的gutter', () => {
    const { container } = render(HTRow, {
      props: {
        gutter: '20',
      },
      slots: {
        default: 'Content',
      },
    });

    const row = container.querySelector('.row');
    const styles = row?.getAttribute('style');
    expect(styles).toContain('margin-left: -10px');
    expect(styles).toContain('margin-right: -10px');
  });

  it('应该正确处理默认值', () => {
    const { container } = render(HTRow, {
      slots: {
        default: 'Default Row',
      },
    });

    const row = container.querySelector('.row');
    expect(row?.classList.contains('row-justify-start')).toBe(true);
    expect(row?.classList.contains('row-align-top')).toBe(true);
    expect(row?.classList.contains('ht-row--nowrap')).toBe(false);
  });
});
