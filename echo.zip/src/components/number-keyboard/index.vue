<script setup lang="ts">
import { onBeforeUnmount, onMounted } from 'vue';

const props = defineProps({
  hideOnClickOutside: {
    type: Boolean,
    default: false,
  },
  modelValue: String,
  show: {
    type: Boolean,
    default: true,
  },
  title: String,
  theme: {
    type: String,
    default: 'default', // 支持 default/custom
  },
  extraKey: {
    type: Array as () => string[],
    default: () => [],
  },
  closeButtonText: String,
  deleteButtonText: String,
  hideDelete: Boolean,
  hideClose: Boolean,
  maxlength: Number,
  randomKeyOrder: Boolean,
  transition: {
    type: Boolean,
    default: true,
  },
});

let keyboardEl: HTMLElement | null = null;

function handleClickOutside(e: MouseEvent) {
  if (!props.show || !props.hideOnClickOutside) return;
  if (keyboardEl && !keyboardEl.contains(e.target as Node)) {
    onClose();
  }
}

onMounted(() => {
  keyboardEl = document.querySelector('.ht-number-keyboard');
  document.addEventListener('mousedown', handleClickOutside);
});

onBeforeUnmount(() => {
  document.removeEventListener('mousedown', handleClickOutside);
});

const emit = defineEmits(['update:modelValue', 'input', 'delete', 'close', 'blur', 'show']);

// const keys = ref<string[]>([]);

function shuffle(arr: string[]) {
  return arr.sort(() => Math.random() - 0.5);
}

function getKeys() {
  // 只展示数字，不展示小数点
  let baseKeys = ['1', '2', '3', '4', '5', '6', '7', '8', '9'];
  if (props.randomKeyOrder) baseKeys = shuffle([...baseKeys]);
  // 过滤掉小数点
  const extraKeys = (props.extraKey || []).filter((k) => k !== '.');
  // Vant布局：前面三行数字和自定义键，最后一行收起、0、删除
  const keys = [...baseKeys, ...extraKeys];
  while (keys.length < 9) keys.push('');
  return keys;
}

function onKeyPress(key: string) {
  if (props.maxlength && (props.modelValue?.length ?? 0) >= props.maxlength) return;
  emit('input', key);
  emit('update:modelValue', (props.modelValue ?? '') + key);
}

function onDelete() {
  emit('delete');
  emit('update:modelValue', (props.modelValue ?? '').slice(0, -1));
}

function onClose() {
  emit('close');
}

// function onBlur() {
//   emit('blur');
// }

// function onShow() {
//   emit('show');
// }
</script>

<template>
  <transition name="ht-keyboard-slide" v-if="props.transition">
    <div v-show="props.show" class="ht-number-keyboard">
      <div v-if="props.title" class="ht-number-keyboard__title">{{ props.title }}</div>
      <div class="ht-number-keyboard__keys">
        <!-- 前面三行数字和自定义键 -->
        <template v-for="row in 3" :key="row">
          <template v-for="col in 3" :key="col">
            <button
              v-if="getKeys()[(row - 1) * 3 + (col - 1)] !== ''"
              class="ht-number-keyboard__key"
              @click="
                () => getKeys()[(row - 1) * 3 + (col - 1)] && onKeyPress(getKeys()[(row - 1) * 3 + (col - 1)] as string)
              "
            >
              {{ getKeys()[(row - 1) * 3 + (col - 1)] }}
            </button>
            <button v-else class="ht-number-keyboard__key" style="visibility: hidden; pointer-events: none" />
          </template>
        </template>
        <!-- 最后一行：收起、0、删除 -->
        <button v-show="!props.hideClose" class="ht-number-keyboard__key ht-number-keyboard__close" @click="onClose">
          {{ props.closeButtonText || '收起' }}
        </button>
        <button class="ht-number-keyboard__key" @click="onKeyPress('0')">0</button>
        <button v-show="!props.hideDelete" class="ht-number-keyboard__key ht-number-keyboard__delete" @click="onDelete">
          {{ props.deleteButtonText || '删除' }}
        </button>
      </div>
    </div>
  </transition>
  <div v-else v-show="props.show" class="ht-number-keyboard">
    <div v-if="props.title" class="ht-number-keyboard__title">{{ props.title }}</div>
    <div class="ht-number-keyboard__keys">
      <!-- 前面三行数字和自定义键 -->
      <template v-for="row in 3" :key="row">
        <template v-for="col in 3" :key="col">
          <button
            v-if="getKeys()[(row - 1) * 3 + (col - 1)] !== ''"
            class="ht-number-keyboard__key"
            @click="
              () => getKeys()[(row - 1) * 3 + (col - 1)] && onKeyPress(getKeys()[(row - 1) * 3 + (col - 1)] as string)
            "
          >
            {{ getKeys()[(row - 1) * 3 + (col - 1)] }}
          </button>
          <button v-else class="ht-number-keyboard__key" style="visibility: hidden; pointer-events: none" />
        </template>
      </template>
      <!-- 最后一行：收起、0、删除 -->
      <button v-show="!props.hideClose" class="ht-number-keyboard__key ht-number-keyboard__close" @click="onClose">
        {{ props.closeButtonText || '收起' }}
      </button>
      <button class="ht-number-keyboard__key" @click="onKeyPress('0')">0</button>
      <button v-show="!props.hideDelete" class="ht-number-keyboard__key ht-number-keyboard__delete" @click="onDelete">
        {{ props.deleteButtonText || '删除' }}
      </button>
    </div>
  </div>
</template>

<style scoped>
/* Vant风格数字键盘样式优化 */
.ht-number-keyboard {
  position: fixed;
  left: 0;
  right: 0;
  bottom: 0;
  background: #f7f8fa;
  box-shadow: 0 -2px 8px rgba(0, 0, 0, 0.08);
  z-index: 1000;
  padding: 0.32rem 0 0.16rem 0;
  border-top-left-radius: 16px;
  border-top-right-radius: 16px;
  font-family: -apple-system, BlinkMacSystemFont, 'Helvetica Neue', Arial, sans-serif;
}
.ht-number-keyboard__title {
  text-align: center;
  font-size: 0.48rem;
  color: #323233;
  margin-bottom: 0.16rem;
  font-weight: 500;
}
/* 每行三个按钮布局 */
.ht-number-keyboard__keys {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 0.12rem;
  padding: 0 0.16rem;
}
.ht-number-keyboard__key {
  width: 100%;
  min-width: 0;
  height: 48px;
  margin: 0.08rem 0;
  background: #fff;
  border-radius: 12px;
  border: none;
  font-size: 1.1rem;
  color: #323233;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.04);
  cursor: pointer;
  transition: background 0.2s;
  outline: none;
  user-select: none;
  font-weight: 500;
}
.ht-number-keyboard__key:active {
  background: #f2f3f5;
}
.ht-number-keyboard__delete {
  color: #ee0a24;
  font-weight: 500;
}
.ht-number-keyboard__close {
  color: #969799;
  font-weight: 500;
}
.ht-keyboard-slide-enter-active,
.ht-keyboard-slide-leave-active {
  transition: transform 0.3s cubic-bezier(0.25, 1, 0.5, 1);
}
.ht-keyboard-slide-enter-from,
.ht-keyboard-slide-leave-to {
  transform: translateY(100%);
}
</style>
