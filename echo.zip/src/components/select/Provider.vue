<template>
  <slot></slot>
</template>
<script setup lang="ts" generic="ValueType = string">
import { provide } from 'vue';
import type { Context } from './types';

const props = defineProps<Context<ValueType>>();
provide('ht-select-context', props);
</script>
