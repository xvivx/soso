import Select from './index.vue';
import Option from './Option.vue';

export const HTOption = Option;

const HTSelect = Object.assign(Select, { Option });
export default HTSelect;
