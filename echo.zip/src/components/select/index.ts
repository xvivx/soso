import Select from './index.vue';
import Option from './Option.vue';

export type { SelectProps } from './types';

export const HTOption = Option;

const HTSelect = Object.assign(Select, { Option });
export default HTSelect;
