<template>
  <div
    :class="
      cn(
        'ht-select-option flex cursor-pointer items-center justify-between gap-4 overflow-hidden rounded transition-all',
        ctx.value === option.value && 'ht-select-option-selected',
        option.class
      )
    "
    @click="ctx.select(option.value)"
  >
    <div class="flex-1 truncate leading-5">
      <slot :selected="ctx.value === option.value">
        {{ option.label }}
      </slot>
    </div>

    <div v-if="ctx.value === option.value" class="ht-select-selected-dot rounded-full"></div>
  </div>
</template>
<script setup lang="ts" generic="ValueType, OptionType extends BaseOption<ValueType, OptionType>">
import { inject } from 'vue';
import { cn } from '@/utils';
import type { BaseOption, Context } from './types';

defineProps<{ option: OptionType }>();
const ctx = inject<Context<ValueType>>('ht-select-context')!;
</script>
