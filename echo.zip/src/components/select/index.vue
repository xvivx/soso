<template>
  <HTPopover :title="placeholder" :show-arrow="false" fit-width>
    <template #reference="{ open }">
      <div
        :class="
          cn('ht-select flex items-center justify-between', selected && 'ht-select-selected', $attrs.class as string)
        "
      >
        <div class="flex-1 truncate">
          <slot name="reference" :open="open" :selected="selected">
            {{ selected ? selected.label : props.placeholder }}
          </slot>
        </div>

        <svg
          :class="cn('ht-select-icon transition-all', open ? '-rotate-90' : 'rotate-90')"
          xmlns="http://www.w3.org/2000/svg"
          width="14"
          height="14"
          viewBox="0 0 14 14"
          fill="none"
        >
          <path d="M8.18205 7L5 10.1113L5.90897 11L10 7L5.90897 3L5 3.88875L8.18205 7Z" fill="currentColor" />
        </svg>
      </div>
    </template>

    <template #default="{ close }">
      <div class="ht-select-portal-content">
        <Provider
          :value="value"
          :select="
            (value) => {
              emits('update:value', value!);
              close();
            }
          "
        >
          <slot>
            <Option v-for="option in options" :option="option" :key="String(option.value)">{{ option.label }}</Option>
          </slot>
        </Provider>
      </div>
    </template>
  </HTPopover>
</template>
<script setup lang="ts" generic="ValueType, OptionType extends BaseOption<ValueType, OptionType>">
import { computed } from 'vue';
import { HTPopover } from '@/components';
import { useCustomFieldValue } from '@/hooks';
import { cn } from '@/utils';
import Option from './Option.vue';
import Provider from './Provider.vue';
import type { BaseOption, SelectProps } from './types';

const props = defineProps<SelectProps<ValueType, OptionType>>();
const emits = defineEmits<{
  'update:value': [ValueType];
}>();

useCustomFieldValue(() => props.value);

const options = computed(() => {
  return props.options.reduce(
    (current, next) => (next.children ? current.concat(next.children) : current.concat(next)),
    [] as Omit<OptionType, 'children'>[]
  );
});
const selected = computed(() => options.value.find((option) => option.value === props.value));
</script>

<style>
.ht-select {
  color: var(--select-placeholder-color);
  border-radius: var(--select-radius);
  border-color: var(--select-border-color);
  height: var(--select-height);
  gap: var(--select-gap);
  padding: var(--select-padding);
  border-width: var(--select-border-width);
  background-color: var(--select-bg-color);
  font-size: var(--select-font-size);
}

.ht-select-selected {
  color: var(--select-selected-color);
}

.ht-select-icon {
  width: var(--select-icon-size);
  height: var(--select-icon-size);
}

.ht-select-option + .ht-select-option {
  margin-top: var(--select-option-margin);
}

.ht-select-option {
  padding: var(--select-option-padding);
  font-size: var(--select-option-font-size);
  color: var(--select-option-font-color);
}
@media (hover: hover) {
  .ht-select-option:hover {
    background-color: var(--select-option-hover-bg-color);
  }
}

.ht-select-option-selected {
  background-color: var(--select-option-selected-bg-color);
  color: var(--select-option-selected-font-color);
}

.ht-select-selected-dot {
  border-width: var(--select-selected-dot-border-width);
  border-color: var(--select-selected-dot-color);
  width: var(--select-selected-dot-size);
  height: var(--select-selected-dot-size);
}
.ht-select-portal-content {
  background-color: var(-select-portal-content-bg-color);
}

:root {
  /* 选择器的背景颜色 */
  --select-bg-color: #fefefe;
  /* 选择器的高度 */
  --select-height: 40px;
  /* 选择器的触发元素和右侧icon之间的距离 */
  --select-gap: 8px;
  /* 选择器的圆角大小 */
  --select-radius: 6px;
  /* 选择器的边距 */
  --select-padding: 0 12px;
  /* 选择器的边框颜色 */
  --select-border-color: #ccc;
  /* 选择器的边框宽度 */
  --select-border-width: 1px;
  /* 选择器字体大小 */
  --select-font-size: 14px;
  /* 选择器的占位字体颜色 */
  --select-placeholder-color: #b3bec1;
  /* 选择器选中时的字体颜色 */
  --select-selected-color: #000;
  /* 选择器icon的大小 */
  --select-icon-size: 14px;
  /* 选择器下拉背景色 */
  --select-portal-content-bg-color: #fff;
  /* 选择器选项被选中时的背景颜色 */
  --select-option-selected-bg-color: #b3bec1;
  /* 选择器选项被选中时的字体颜色 */
  --select-option-selected-font-color: #000;
  /* 选择器选中时圆点的大小 */
  --select-selected-dot-size: 20px;
  /* 选择器选中时圆点的颜色 */
  --select-selected-dot-color: var(--color-up);
  /* 选择器选中时圆点的边框宽度 */
  --select-selected-dot-border-width: 6px;
  /* 选择器选项的字体大小 */
  --select-option-font-size: 14px;
  /* 选择器选项的字体颜色 */
  --select-option-font-color: #4e4c4c;
  /* 选择器选项间的边距 */
  --select-option-margin: 6px;
  /* 选择器选项的内边距 */
  --select-option-padding: 10px 12px;
  /* 选择器选项悬浮时的背景颜色 */
  --select-option-hover-bg-color: #ccc;
}
</style>
