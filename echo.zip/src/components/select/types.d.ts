export interface SelectProps<ValueType, OptionType extends BaseOption<ValueType, OptionType>> {
  value?: ValueType;
  options?: OptionType[];
  placeholder?: string;
}

type Single<ValueType> = {
  label: string;
  value: ValueType;
  class?: string;
};

type Group<ValueType, OptionType extends Single<ValueType>> = {
  label: string;
  class?: string;
  children: OptionType[];
};

export type BaseOption<ValueType, OptionType> = {
  value: ValueType;
  label: string | number;
  children?: Omit<OptionType, 'children'>[];
  class?: string;
};

export type Context<ValueType> = {
  value: ValueType;
  select: (value: ValueType) => void;
};
