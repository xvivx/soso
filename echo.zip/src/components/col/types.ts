import type { HTMLAttributes } from 'vue';

export interface ColProps {
  span?: number;
  offset?: number;
  class?: HTMLAttributes['class'];
  tag?: string;
}
