<script setup lang="ts">
import { computed, inject } from 'vue';
import { cn } from '@/utils';
import { colVariants } from './constants';
import type { ColProps } from './types';

const props = withDefaults(defineProps<ColProps>(), {
  tag: 'div',
  span: 24,
});

const gutter = inject(
  'row-gutter',
  computed(() => 0)
);

const classes = computed(() => {
  const variantProps = { span: props.span, offset: props.offset };
  return cn(colVariants(variantProps), props.class);
});

const styles = computed(() => {
  const gutterValue = gutter.value;
  if (!gutterValue) {
    return {};
  }

  const padding = `${gutterValue / 2}px`;
  return {
    paddingLeft: padding,
    paddingRight: padding,
  };
});
</script>

<template>
  <component :is="props.tag" :class="classes" :style="styles">
    <slot />
  </component>
</template>

<style>
@import './style/index.css';
</style>
