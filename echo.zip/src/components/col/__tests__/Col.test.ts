import { render, screen } from '@testing-library/vue';
import { describe, expect, it } from 'vitest';
import HTRow from '../../row/index.vue';
import HTCol from '../index.vue';

describe('HTCol', () => {
  it('应该正确渲染默认列', () => {
    const { container } = render(HTCol, {
      slots: {
        default: 'Col Content',
      },
    });

    const col = container.querySelector('.col');
    expect(col).toBeTruthy();
    expect(col?.classList.contains('col-24')).toBe(true); // 默认span为24
    expect(screen.getByText('Col Content')).toBeTruthy();
  });

  it('应该支持自定义标签', () => {
    const { container } = render(HTCol, {
      props: {
        tag: 'section',
      },
      slots: {
        default: 'Section Col',
      },
    });

    const section = container.querySelector('section');
    expect(section).toBeTruthy();
    expect(section?.tagName).toBe('SECTION');
    expect(section?.classList.contains('col')).toBe(true);
  });

  it('应该支持插槽内容', () => {
    render(HTCol, {
      slots: {
        default: '<div class="content">Column Content</div>',
      },
    });

    expect(screen.getByText('Column Content')).toBeTruthy();
  });

  it('应该支持不同的span值', () => {
    const spanValues = [1, 6, 12, 18, 24];

    spanValues.forEach((span) => {
      const { container } = render(HTCol, {
        props: {
          span,
        },
        slots: {
          default: `Span ${span}`,
        },
      });

      const col = container.querySelector('.col');
      expect(col?.classList.contains(`col-${span}`)).toBe(true);
    });
  });

  it('应该支持offset偏移', () => {
    const offsetValues = [1, 3, 6, 12];

    offsetValues.forEach((offset) => {
      const { container } = render(HTCol, {
        props: {
          offset,
        },
        slots: {
          default: `Offset ${offset}`,
        },
      });

      const col = container.querySelector('.col');
      expect(col?.classList.contains(`col-offset-${offset}`)).toBe(true);
    });
  });

  it('应该支持同时设置span和offset', () => {
    const { container } = render(HTCol, {
      props: {
        span: 12,
        offset: 6,
      },
      slots: {
        default: 'Span 12 Offset 6',
      },
    });

    const col = container.querySelector('.col');
    expect(col?.classList.contains('col-12')).toBe(true);
    expect(col?.classList.contains('col-offset-6')).toBe(true);
  });

  it('应该支持自定义类名', () => {
    const { container } = render(HTCol, {
      props: {
        class: 'custom-col-class',
      },
      slots: {
        default: 'Custom Col',
      },
    });

    const col = container.querySelector('.col');
    expect(col?.classList.contains('custom-col-class')).toBe(true);
  });

  it('应该正确处理默认值', () => {
    const { container } = render(HTCol, {
      slots: {
        default: 'Default Col',
      },
    });

    const col = container.querySelector('.col');
    expect(col?.classList.contains('col-24')).toBe(true); // 默认span为24
    expect(col?.classList.contains('col-offset-1')).toBe(false); // 默认没有offset
  });

  it('应该在Row组件中正确接收gutter', () => {
    const { container } = render(HTRow, {
      props: {
        gutter: 20,
      },
      slots: {
        default: `
          <HTCol :span="12">
            <div>Column 1</div>
          </HTCol>
          <HTCol :span="12">
            <div>Column 2</div>
          </HTCol>
        `,
      },
      global: {
        components: {
          HTCol,
        },
      },
    });

    const cols = container.querySelectorAll('.col');
    expect(cols).toHaveLength(2);

    // 检查每个col是否有正确的padding
    cols.forEach((col) => {
      const styles = col.getAttribute('style');
      expect(styles).toContain('padding-left: 10px');
      expect(styles).toContain('padding-right: 10px');
    });
  });

  it('应该在没有gutter时不添加padding', () => {
    const { container } = render(HTRow, {
      props: {
        gutter: 0,
      },
      slots: {
        default: `
          <HTCol :span="24">
            <div>No Gutter Column</div>
          </HTCol>
        `,
      },
      global: {
        components: {
          HTCol,
        },
      },
    });

    const col = container.querySelector('.col');
    const styles = col?.getAttribute('style');
    expect(styles).toBeFalsy();
  });

  it('应该正确处理复杂组合', () => {
    const { container } = render(HTCol, {
      props: {
        tag: 'article',
        span: 8,
        offset: 4,
        class: 'complex-col',
      },
      slots: {
        default: 'Complex Column',
      },
    });

    const col = container.querySelector('article');
    expect(col?.tagName).toBe('ARTICLE');
    expect(col?.classList.contains('col')).toBe(true);
    expect(col?.classList.contains('col-8')).toBe(true);
    expect(col?.classList.contains('col-offset-4')).toBe(true);
    expect(col?.classList.contains('complex-col')).toBe(true);
    expect(screen.getByText('Complex Column')).toBeTruthy();
  });

  it('应该支持边界值span', () => {
    // 测试最小值
    const { container: container1 } = render(HTCol, {
      props: {
        span: 1,
      },
      slots: {
        default: 'Min Span',
      },
    });

    const col1 = container1.querySelector('.col');
    expect(col1?.classList.contains('col-1')).toBe(true);

    // 测试最大值
    const { container: container2 } = render(HTCol, {
      props: {
        span: 24,
      },
      slots: {
        default: 'Max Span',
      },
    });

    const col2 = container2.querySelector('.col');
    expect(col2?.classList.contains('col-24')).toBe(true);
  });

  it('应该支持边界值offset', () => {
    // 测试最小值
    const { container: container1 } = render(HTCol, {
      props: {
        offset: 1,
      },
      slots: {
        default: 'Min Offset',
      },
    });

    const col1 = container1.querySelector('.col');
    expect(col1?.classList.contains('col-offset-1')).toBe(true);

    // 测试最大值
    const { container: container2 } = render(HTCol, {
      props: {
        offset: 24,
      },
      slots: {
        default: 'Max Offset',
      },
    });

    const col2 = container2.querySelector('.col');
    expect(col2?.classList.contains('col-offset-24')).toBe(true);
  });

  it('应该在Row组件中正确处理多个Col', () => {
    const { container } = render(HTRow, {
      props: {
        gutter: 16,
      },
      slots: {
        default: `
          <HTCol :span="6">
            <div>Col 1</div>
          </HTCol>
          <HTCol :span="6" :offset="3">
            <div>Col 2</div>
          </HTCol>
          <HTCol :span="9">
            <div>Col 3</div>
          </HTCol>
        `,
      },
      global: {
        components: {
          HTCol,
        },
      },
    });

    const cols = container.querySelectorAll('.col');
    expect(cols).toHaveLength(3);

    // 检查第一个col
    expect(cols[0].classList.contains('col-6')).toBe(true);
    expect(cols[0].getAttribute('style')).toContain('padding-left: 8px');

    // 检查第二个col
    expect(cols[1].classList.contains('col-6')).toBe(true);
    expect(cols[1].classList.contains('col-offset-3')).toBe(true);

    // 检查第三个col
    expect(cols[2].classList.contains('col-9')).toBe(true);

    expect(screen.getByText('Col 1')).toBeTruthy();
    expect(screen.getByText('Col 2')).toBeTruthy();
    expect(screen.getByText('Col 3')).toBeTruthy();
  });

  it('应该正确处理字符串类型的gutter', () => {
    const { container } = render(HTRow, {
      props: {
        gutter: '24',
      },
      slots: {
        default: `
          <HTCol :span="12">
            <div>String Gutter Col</div>
          </HTCol>
        `,
      },
      global: {
        components: {
          HTCol,
        },
      },
    });

    const col = container.querySelector('.col');
    const styles = col?.getAttribute('style');
    expect(styles).toContain('padding-left: 12px');
    expect(styles).toContain('padding-right: 12px');
  });
});
