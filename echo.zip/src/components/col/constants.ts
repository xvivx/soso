import { cva } from 'class-variance-authority';

const spanClasses = Array.from({ length: 24 }, (_, i) => `col-${i + 1}`);
const offsetClasses = Array.from({ length: 24 }, (_, i) => `col-offset-${i + 1}`);

export const colVariants = cva('col', {
  variants: {
    span: {
      ...Object.fromEntries(spanClasses.map((_, i) => [i + 1, `col-${i + 1}`])),
    },
    offset: {
      ...Object.fromEntries(offsetClasses.map((_, i) => [i + 1, `col-offset-${i + 1}`])),
    },
  },
  defaultVariants: {
    span: 24,
  },
});
