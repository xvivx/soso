import type { AcceptableValue } from 'reka-ui';

export type IconSize = number | string;

export type RadioLabelPosition = 'left' | 'right';
export type RadioGroupDirection = 'vertical' | 'horizontal';
export interface RadioGroupProps {
  modelValue: AcceptableValue;
  disabled?: boolean;
  direction?: RadioGroupDirection;
  labelPosition?: RadioLabelPosition;
  iconSize?: IconSize;
  checkedColor?: string;
}

export type RadioGroupProvide = {
  props: RadioGroupProps;
};
