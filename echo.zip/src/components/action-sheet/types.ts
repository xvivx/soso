export interface ActionSheetAction {
  name: string;
  subname?: string;
  color?: string;
  disabled?: boolean;
  loading?: boolean;
  className?: string;
  callback?: () => void;
}

export interface ActionSheetProps {
  modelValue?: boolean;
  actions?: ActionSheetAction[];
  title?: string;
  cancelText?: string;
  description?: string;
  closeOnClickAction?: boolean;
  closeOnClickOverlay?: boolean;
  round?: boolean;
  safeAreaInsetBottom?: boolean;
}

export interface ActionSheetEmits {
  'update:modelValue': [value: boolean];
  select: [action: ActionSheetAction, index: number];
  cancel: [];
  open: [];
  close: [];
  'click-overlay': [];
}
