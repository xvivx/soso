<template>
  {{ null }}
</template>

<script setup lang="ts">
import { h, onUnmounted, watch } from 'vue';
import { createRender } from '@/components/portal-render/store';
import ActionSheetContent from './ActionSheetContent.vue';
import type { ActionSheetEmits, ActionSheetProps } from './types';

defineOptions({
  name: 'HTActionSheet',
});

const props = withDefaults(defineProps<ActionSheetProps>(), {
  closeOnClickAction: true,
  closeOnClickOverlay: true,
  round: true,
  safeAreaInsetBottom: true,
});

const emit = defineEmits<ActionSheetEmits>();

let cleanup: () => void = () => null;

watch(
  () => props.modelValue,
  (newValue) => {
    console.log('[ActionSheet] modelValue changed:', newValue);
    console.log('[ActionSheet] props:', props);

    if (props.modelValue) {
      const onClose = () => {
        console.log('[ActionSheet] onClose called');
        emit('update:modelValue', false);
        emit('close');
      };

      const handleSelect = (action: any, index: number) => {
        console.log('[ActionSheet] handleSelect:', action, index);
        emit('select', action, index);
        if (props.closeOnClickAction) {
          onClose();
        }
      };

      const handleCancel = () => {
        console.log('[ActionSheet] handleCancel');
        emit('cancel');
        onClose();
      };

      console.log('[ActionSheet] Creating render with ActionSheetContent');
      cleanup = createRender(
        h(ActionSheetContent, {
          actions: props.actions,
          title: props.title,
          description: props.description,
          cancelText: props.cancelText,
          round: props.round,
          safeAreaInsetBottom: props.safeAreaInsetBottom,
          onSelect: handleSelect,
          onCancel: handleCancel,
        }),
        {
          closable: props.closeOnClickOverlay,
          onClose,
        }
      );
      console.log('[ActionSheet] Render created, cleanup function:', typeof cleanup);

      emit('open');
    } else {
      console.log('[ActionSheet] Calling cleanup');
      cleanup();
    }
  },
  { immediate: true }
);

onUnmounted(() => cleanup());
</script>
