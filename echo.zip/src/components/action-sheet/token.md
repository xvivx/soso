--action-sheet-container-z-index-default
面板默认层级
1999

--action-sheet-container-bg-color-default
面板默认背景色
#FFFFFF
Color modes / Surface / Primary
--action-sheet-container-border-radius-top
面板顶部默认圆角
16px

--action-sheet-container-max-height-default
面板最大高度
80vh

--action-sheet-mask-bg-color-default
遮罩默认背景色
rgba(0,0,0,0.5)

--action-sheet-mask-transition-duration
遮罩过渡时间
0.3s

--action-sheet-option-height-default
选项默认高度
56px

--action-sheet-option-padding-default
选项默认内边距
0 16px

--action-sheet-option-font-size-default
选项默认字号
16px

--action-sheet-option-color-default

选项默认颜色
#333333
Color modes / Content / Primary
--action-sheet-option-color-primary
选项主色（如“删除”）
#FF4D4F

--action-sheet-option-bg-color-hover
选项 hover 背景色
#F5F5F5

--action-sheet-cancel-button-height-default
取消按钮默认高度
56px

--action-sheet-cancel-button-margin-default
取消按钮默认外边距
8px 0 0

--action-sheet-cancel-button-bg-color-default
取消按钮默认背景色
#F5F5F5

--action-sheet-cancel-button-font-size-default
取消按钮默认字号
16px

--action-sheet-container-transform-hidden
面板隐藏时位移（向下）
translateY(100%)
数值对齐

--action-sheet-container-transition-duration
面板过渡时间
0.3s
数值对齐
