<script lang="ts">
export default {
  name: 'ActionSheetContent',
};
</script>

<script setup lang="ts">
import { onMounted, onUnmounted } from 'vue';
import { cn } from '@/utils/index';
import type { ActionSheetAction } from './types';
import './styles/index.css';

export interface ActionSheetContentProps {
  actions?: ActionSheetAction[];
  title?: string;
  description?: string;
  cancelText?: string;
  round?: boolean;
  safeAreaInsetBottom?: boolean;
}

const props = withDefaults(defineProps<ActionSheetContentProps>(), {
  round: true,
  safeAreaInsetBottom: true,
});

console.log('[ActionSheetContent] Component created with props:', props);

onMounted(() => {
  console.log('[ActionSheetContent] Component mounted');
});

onUnmounted(() => {
  console.log('[ActionSheetContent] Component unmounted');
});

const emit = defineEmits<{
  select: [action: ActionSheetAction, index: number];
  cancel: [];
}>();

function handleActionClick(action: ActionSheetAction, index: number) {
  if (action.disabled || action.loading) {
    return;
  }

  emit('select', action, index);

  if (action.callback) {
    action.callback();
  }
}

function handleCancel() {
  emit('cancel');
}
</script>

<template>
  <div
    :class="
      cn('ht-action-sheet', {
        'ht-action-sheet--round': props.round,
      })
    "
  >
    <!-- Header -->
    <div v-if="props.title || props.description" class="ht-action-sheet__header">
      <h3 v-if="props.title" class="ht-action-sheet__title">{{ props.title }}</h3>
      <p v-if="props.description" class="ht-action-sheet__description">{{ props.description }}</p>
    </div>

    <!-- Actions -->
    <div v-if="props.actions && props.actions.length > 0" class="ht-action-sheet__content">
      <button
        v-for="(action, index) in props.actions"
        :key="action.name || index"
        :class="
          cn(
            'ht-action-sheet__item',
            {
              'ht-action-sheet__item--disabled': action.disabled,
              'ht-action-sheet__item--loading': action.loading,
            },
            action.className
          )
        "
        :style="action.color ? { color: action.color } : undefined"
        :disabled="action.disabled"
        @click="handleActionClick(action, index)"
      >
        <span v-if="action.loading" class="ht-action-sheet__loading">Loading...</span>
        <div v-else class="ht-action-sheet__item-content">
          <span class="ht-action-sheet__name">{{ action.name }}</span>
          <span v-if="action.subname" class="ht-action-sheet__subname">{{ action.subname }}</span>
        </div>
      </button>
    </div>

    <!-- Cancel Button -->
    <button v-if="props.cancelText" class="ht-action-sheet__cancel" @click="handleCancel">
      {{ props.cancelText }}
    </button>

    <!-- Safe Area -->
    <div v-if="props.safeAreaInsetBottom" class="ht-action-sheet__safe-area" />
  </div>
</template>
