export interface IconProps {
  name?: string;
  color?: string;
  size?: number | string;
  classPrefix?: string;
  tag?: keyof HTMLElementTagNameMap;
}
