import { fireEvent } from '@testing-library/vue';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import { renderWithMounting } from '../../../../test/utils';
import HTIcon from '../Icon.vue';

describe('HTIcon', () => {
  beforeEach(() => {
    document.body.innerHTML = '';
  });

  describe('基础渲染', () => {
    it('应该正确渲染图标', () => {
      const { container } = renderWithMounting(HTIcon, {
        props: {
          name: 'search-line',
        },
      });

      const icon = container.querySelector('.ht-icon');
      expect(icon).toBeTruthy();
      expect(icon?.classList.contains('ht-icon-search-line')).toBe(true);
    });

    it('应该使用默认的 i 标签', () => {
      const { container } = renderWithMounting(HTIcon, {
        props: {
          name: 'search-line',
        },
      });

      const icon = container.querySelector('i');
      expect(icon).toBeTruthy();
      expect(icon?.tagName).toBe('I');
    });

    it('应该支持自定义标签', () => {
      const { container } = renderWithMounting(HTIcon, {
        props: {
          name: 'search-line',
          tag: 'span',
        },
      });

      const icon = container.querySelector('span');
      expect(icon).toBeTruthy();
      expect(icon?.tagName).toBe('SPAN');
      expect(icon?.classList.contains('ht-icon')).toBe(true);
    });
  });

  describe('图标名称', () => {
    it('应该根据 name 属性生成对应的类名', () => {
      const { container } = renderWithMounting(HTIcon, {
        props: {
          name: 'check-line-sm',
        },
      });

      const icon = container.querySelector('.ht-icon');
      expect(icon?.classList.contains('ht-icon-check-line-sm')).toBe(true);
    });

    it('没有 name 时不应该生成图标类名', () => {
      const { container } = renderWithMounting(HTIcon);

      const icon = container.querySelector('.ht-icon');
      expect(icon).toBeTruthy();
      // 检查没有 ht-icon-* 类名（除了基础的 ht-icon）
      const classList = Array.from(icon?.classList || []);
      const hasIconClass = classList.some((cls) => cls.startsWith('ht-icon-') && cls !== 'ht-icon');
      expect(hasIconClass).toBe(false);
    });
  });

  describe('图标尺寸', () => {
    it('应该支持 small 预定义尺寸', () => {
      const { container } = renderWithMounting(HTIcon, {
        props: {
          name: 'search-line',
          size: 'small',
        },
      });

      const icon = container.querySelector('.ht-icon');
      expect(icon?.classList.contains('ht-icon--small')).toBe(true);
    });

    it('应该支持 large 预定义尺寸', () => {
      const { container } = renderWithMounting(HTIcon, {
        props: {
          name: 'search-line',
          size: 'large',
        },
      });

      const icon = container.querySelector('.ht-icon');
      expect(icon?.classList.contains('ht-icon--large')).toBe(true);
    });

    it('应该支持数字尺寸（像素）', () => {
      const { container } = renderWithMounting(HTIcon, {
        props: {
          name: 'search-line',
          size: 32,
        },
      });

      const icon = container.querySelector('.ht-icon') as HTMLElement;
      expect(icon?.style.fontSize).toBe('32px');
    });

    it('应该支持字符串尺寸（带单位）', () => {
      const { container } = renderWithMounting(HTIcon, {
        props: {
          name: 'search-line',
          size: '2rem',
        },
      });

      const icon = container.querySelector('.ht-icon') as HTMLElement;
      expect(icon?.style.fontSize).toBe('2rem');
    });

    it('应该支持字符串尺寸（不带单位）', () => {
      const { container } = renderWithMounting(HTIcon, {
        props: {
          name: 'search-line',
          size: '48',
        },
      });

      const icon = container.querySelector('.ht-icon') as HTMLElement;
      expect(icon?.style.fontSize).toBe('48px');
    });

    it('自定义尺寸时不应该有预定义尺寸类', () => {
      const { container } = renderWithMounting(HTIcon, {
        props: {
          name: 'search-line',
          size: 32,
        },
      });

      const icon = container.querySelector('.ht-icon');
      expect(icon?.classList.contains('ht-icon--small')).toBe(false);
      expect(icon?.classList.contains('ht-icon--large')).toBe(false);
    });
  });

  describe('图标颜色', () => {
    it('应该支持自定义颜色', () => {
      const { container } = renderWithMounting(HTIcon, {
        props: {
          name: 'search-line',
          color: '#ff0000',
        },
      });

      const icon = container.querySelector('.ht-icon') as HTMLElement;
      expect(icon?.style.color).toBe('rgb(255, 0, 0)');
    });

    it('应该支持 CSS 颜色名称', () => {
      const { container } = renderWithMounting(HTIcon, {
        props: {
          name: 'search-line',
          color: 'red',
        },
      });

      const icon = container.querySelector('.ht-icon') as HTMLElement;
      expect(icon?.style.color).toBe('red');
    });

    it('应该支持 rgb 颜色', () => {
      const { container } = renderWithMounting(HTIcon, {
        props: {
          name: 'search-line',
          color: 'rgb(0, 128, 255)',
        },
      });

      const icon = container.querySelector('.ht-icon') as HTMLElement;
      expect(icon?.style.color).toBe('rgb(0, 128, 255)');
    });

    it('应该支持 rgba 颜色', () => {
      const { container } = renderWithMounting(HTIcon, {
        props: {
          name: 'search-line',
          color: 'rgba(0, 128, 255, 0.5)',
        },
      });

      const icon = container.querySelector('.ht-icon') as HTMLElement;
      expect(icon?.style.color).toBe('rgba(0, 128, 255, 0.5)');
    });
  });

  describe('自定义类前缀', () => {
    it('应该支持自定义 classPrefix 用于图标名称', () => {
      const { container } = renderWithMounting(HTIcon, {
        props: {
          name: 'search-line',
          classPrefix: 'custom-icon',
        },
      });

      const icon = container.querySelector('.ht-icon');
      // classPrefix 用于图标字体库的类名
      expect(icon?.classList.contains('custom-icon-search-line')).toBe(true);
      // 基础类名仍然是 ht-icon
      expect(icon?.classList.contains('ht-icon')).toBe(true);
    });

    it('自定义前缀不影响尺寸类（尺寸类使用固定的 ht-icon 前缀）', () => {
      const { container } = renderWithMounting(HTIcon, {
        props: {
          name: 'search-line',
          size: 'small',
          classPrefix: 'custom-icon',
        },
      });

      const icon = container.querySelector('.ht-icon');
      expect(icon?.classList.contains('custom-icon-search-line')).toBe(true);
      expect(icon?.classList.contains('ht-icon--small')).toBe(true);
      expect(icon?.classList.contains('custom-icon--small')).toBe(false);
    });
  });

  describe('图片图标', () => {
    it('应该识别图片路径（带斜杠）', () => {
      const { container } = renderWithMounting(HTIcon, {
        props: {
          name: '/path/to/icon.png',
        },
      });

      const img = container.querySelector('img');
      expect(img).toBeTruthy();
      expect(img?.getAttribute('src')).toBe('/path/to/icon.png');
    });

    it('图片图标应该支持尺寸设置', () => {
      const { container } = renderWithMounting(HTIcon, {
        props: {
          name: '/path/to/icon.png',
          size: 48,
        },
      });

      const icon = container.querySelector('.ht-icon') as HTMLElement;
      expect(icon?.style.fontSize).toBe('48px');
    });
  });

  describe('插槽', () => {
    it('应该支持默认插槽', () => {
      const { container } = renderWithMounting(HTIcon, {
        slots: {
          default: '<svg><circle r="10" /></svg>',
        },
      });

      const icon = container.querySelector('.ht-icon');
      const svg = icon?.querySelector('svg');
      expect(svg).toBeTruthy();
    });

    it('插槽内容优先于 name 属性', () => {
      const { container } = renderWithMounting(HTIcon, {
        props: {
          name: 'search-line',
        },
        slots: {
          default: '<span class="custom-content">Custom</span>',
        },
      });

      const customContent = container.querySelector('.custom-content');
      expect(customContent).toBeTruthy();

      // 有插槽时，不应该生成图标字体类名（因为插槽内容优先）
      const icon = container.querySelector('.ht-icon');
      expect(icon?.classList.contains('ht-icon-search-line')).toBe(false);
      // 但基础类名应该保留
      expect(icon?.classList.contains('ht-icon')).toBe(true);
    });

    it('插槽中的 SVG 应该继承尺寸', () => {
      const { container } = renderWithMounting(HTIcon, {
        props: {
          size: 32,
        },
        slots: {
          default: '<svg class="test-svg"><circle r="10" /></svg>',
        },
      });

      const icon = container.querySelector('.ht-icon') as HTMLElement;
      expect(icon?.style.fontSize).toBe('32px');
      // SVG 应该有 1em 的宽高样式类
      expect(icon?.classList.contains('[&_svg]:h-[1em]')).toBe(true);
      expect(icon?.classList.contains('[&_svg]:w-[1em]')).toBe(true);
    });
  });

  describe('事件', () => {
    it('应该触发 click 事件并传递原生事件对象', async () => {
      const onClick = vi.fn();
      const { container } = renderWithMounting(HTIcon, {
        props: {
          name: 'search-line',
          onClick,
        },
      });

      const icon = container.querySelector('.ht-icon');
      await fireEvent.click(icon!);

      expect(onClick).toHaveBeenCalledTimes(1);
      expect(onClick).toHaveBeenCalledWith(expect.any(MouseEvent));
    });

    it('应该支持多次点击', async () => {
      const onClick = vi.fn();
      const { container } = renderWithMounting(HTIcon, {
        props: {
          name: 'search-line',
          onClick,
        },
      });

      const icon = container.querySelector('.ht-icon');
      await fireEvent.click(icon!);
      await fireEvent.click(icon!);
      await fireEvent.click(icon!);

      expect(onClick).toHaveBeenCalledTimes(3);
    });
  });

  describe('边界情况', () => {
    it('应该处理空的 name 属性', () => {
      const { container } = renderWithMounting(HTIcon, {
        props: {
          name: '',
        },
      });

      const icon = container.querySelector('.ht-icon');
      expect(icon).toBeTruthy();
      // 空 name 不应该生成无效的图标类名（如 ht-icon-）
      const classList = Array.from(icon?.classList || []);
      const hasInvalidIconClass = classList.some((cls) => cls === 'ht-icon-' || cls.startsWith('ht-icon--'));
      expect(hasInvalidIconClass).toBe(false);
    });

    it('应该处理 size 为 0', () => {
      const { container } = renderWithMounting(HTIcon, {
        props: {
          name: 'search-line',
          size: 0,
        },
      });

      const icon = container.querySelector('.ht-icon') as HTMLElement;
      expect(icon?.style.fontSize).toBe('0px');
    });
  });
});
