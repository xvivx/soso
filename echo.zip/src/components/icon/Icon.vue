<script setup lang="ts">
import { computed, useSlots } from 'vue';
import { addUnit, cn } from '@/utils/index';
import type { IconProps } from './types';

const props = withDefaults(defineProps<IconProps>(), {
  classPrefix: 'ht-icon',
  tag: 'i',
});

const isImageIcon = computed(() => props.name?.includes('/'));

const iconClass = computed(() => (props.name ? `${props.classPrefix}-${props.name}` : ''));

const predefinedSizeOptions = ['small', 'large'] as const;
const isPredefinedSize = computed(() =>
  predefinedSizeOptions.includes(props.size as unknown as (typeof predefinedSizeOptions)[number])
);
const sizeClass = computed(() => {
  if (isPredefinedSize.value) {
    return `ht-icon--${props.size}`;
  }
  return '';
});

const sizeWithUnit = computed(() => addUnit(props.size));
const rootStyle = computed(() => {
  const style: Record<string, string> = {};
  if (sizeWithUnit.value && !isPredefinedSize.value) {
    style.fontSize = sizeWithUnit.value;
  }
  if (props.color) style.color = props.color;
  return style;
});

const slots = useSlots();
const hasSlot = computed(() => !!slots.default);

const emit = defineEmits<{
  (e: 'click', event: MouseEvent): void;
}>();

function onClick(e: MouseEvent) {
  emit('click', e);
}
</script>

<template>
  <component
    :is="tag"
    @click="onClick"
    :class="
      cn(
        'ht-icon',
        'inline-flex items-center justify-center align-middle not-italic',
        !isImageIcon && !hasSlot && iconClass,
        sizeClass,
        '[&_svg]:h-[1em] [&_svg]:w-[1em]'
      )
    "
    :style="rootStyle"
  >
    <template v-if="hasSlot">
      <slot />
    </template>
    <img v-else-if="isImageIcon" :src="name" class="block h-[1em] w-[1em] object-contain" />
  </component>
</template>

<style>
@import './style/icon.css';
:root {
  --icon-size-default: 24px; /** 图标默认尺寸 */
  --icon-size-small: 12px; /** 图标小号尺寸 */
  --icon-size-large: 24px; /** 图标大号尺寸 */
  --icon-color-default: #333333; /** 图标默认颜色 */
}
@layer components {
  .ht-icon {
    color: var(--icon-color-default);
    font-size: var(--icon-size-default);
  }

  .ht-icon--small {
    font-size: var(--icon-size-small);
  }

  .ht-icon--large {
    font-size: var(--icon-size-large);
  }
}
</style>
