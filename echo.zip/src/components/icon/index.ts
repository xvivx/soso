import HTIcon from './Icon.vue';

export { HTIcon };
export default HTIcon;
export type { IconProps } from './types';
