export { default as HTIcon } from './Icon.vue';
export type { IconProps } from './types';
