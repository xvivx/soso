import { cva } from 'class-variance-authority';

export const dividerVariants = cva('ht-divider relative flex items-center', {
  variants: {
    vertical: {
      true: 'ht-divider--vertical inline-block h-4 w-px mx-2',
      false: 'ht-divider--horizontal w-full my-4',
    },
    dashed: {
      true: 'ht-divider--dashed',
      false: '',
    },
    hairline: {
      true: 'ht-divider--hairline',
      false: '',
    },
    contentPosition: {
      left: 'ht-divider--content-left',
      center: 'ht-divider--content-center',
      right: 'ht-divider--content-right',
    },
  },
  defaultVariants: {
    vertical: false,
    dashed: false,
    hairline: true,
    contentPosition: 'center',
  },
});

export const dividerLineVariants = cva('ht-divider__line flex-1 border-0 bg-border', {
  variants: {
    vertical: {
      true: 'h-full w-px',
      false: 'h-px w-full',
    },
    dashed: {
      true: 'border-dashed bg-transparent',
      false: '',
    },
    hairline: {
      true: '',
      false: 'h-0.5',
    },
  },
  defaultVariants: {
    vertical: false,
    dashed: false,
    hairline: true,
  },
});

export const dividerContentVariants = cva('ht-divider__content px-4 text-muted-foreground whitespace-nowrap', {
  variants: {
    vertical: {
      true: 'hidden',
      false: 'block',
    },
  },
  defaultVariants: {
    vertical: false,
  },
});
