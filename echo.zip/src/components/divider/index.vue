<script setup lang="ts">
import { computed, useSlots } from 'vue';
import { cn } from '@/utils';
import { dividerContentVariants, dividerLineVariants, dividerVariants } from './constants';
import type { DividerProps } from './types';
import './style/index.css';

const props = withDefaults(defineProps<DividerProps>(), {
  dashed: false,
  hairline: true,
  contentPosition: 'center',
  vertical: false,
});

const slots = useSlots();

const hasContent = computed(() => {
  return !props.vertical && !!slots.default;
});

const classes = computed(() => {
  return cn(
    dividerVariants({
      vertical: props.vertical,
      dashed: props.dashed,
      hairline: props.hairline,
      contentPosition: hasContent.value ? props.contentPosition : undefined,
    }),
    props.class
  );
});

const lineClasses = computed(() => {
  return dividerLineVariants({
    vertical: props.vertical,
    dashed: props.dashed,
    hairline: props.hairline,
  });
});

const contentClasses = computed(() => {
  return dividerContentVariants({
    vertical: props.vertical,
  });
});
</script>

<template>
  <div :class="classes">
    <!-- 垂直分割线 -->
    <div v-if="vertical" :class="lineClasses" />

    <!-- 水平分割线 -->
    <template v-else>
      <!-- 左侧线条 -->
      <div v-if="!hasContent || contentPosition === 'right' || contentPosition === 'center'" :class="lineClasses" />

      <!-- 内容区域 -->
      <div v-if="hasContent" :class="contentClasses">
        <slot />
      </div>

      <!-- 右侧线条 -->
      <div v-if="!hasContent || contentPosition === 'left' || contentPosition === 'center'" :class="lineClasses" />
    </template>
  </div>
</template>
