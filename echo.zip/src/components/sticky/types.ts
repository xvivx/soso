import type { ExtractPropTypes, PropType } from 'vue';

export const stickyProps = {
  // 吸顶距离
  offsetTop: {
    type: [Number, String] as PropType<number | string>,
    default: 0,
  },
  // 吸底距离
  offsetBottom: {
    type: [Number, String] as PropType<number | string>,
    default: 0,
  },
  // 是否使用css sticky定位
  cssMode: {
    type: Boolean as PropType<boolean>,
    default: false,
  },
  // 容器选择器
  container: {
    type: [String, Object] as PropType<string | HTMLElement>,
    default: '',
  },
  // 定位方式
  position: {
    type: String as PropType<'top' | 'bottom'>,
    default: 'top',
    validator: (value: string) => ['top', 'bottom'].includes(value),
  },
  // z-index
  zIndex: {
    type: [Number, String] as PropType<number | string>,
    default: 99,
  },
} as const;

export type StickyProps = ExtractPropTypes<typeof stickyProps>;

export type StickyPosition = 'top' | 'bottom';

export interface StickyExpose {
  // 更新吸顶状态
  updateSticky: () => void;
}
