<template>
  <div ref="root" :class="classes" :style="rootStyle">
    <div v-if="fixed" class="sticky-placeholder" :style="{ height: `${height}px` }" />
    <div :class="{ 'sticky--fixed': fixed && !props.cssMode }" :style="stickyStyle">
      <slot />
    </div>
  </div>
</template>

<script setup lang="ts">
import { computed, onBeforeUnmount, onMounted, ref, watch, type CSSProperties } from 'vue';
import { useEventListener } from '@vueuse/core';
import { getElementTop, getScrollTop, unitToPx } from '@/utils';
import { stickyProps } from './types';

const props = defineProps(stickyProps);

const root = ref<HTMLElement>();
const height = ref(0);
const fixed = ref(false);
const scrollParent = ref<Window | HTMLElement>();

// 计算根元素的样式
const rootStyle = computed<CSSProperties>(() => {
  if (props.cssMode) {
    return {
      position: 'sticky' as const,
      top: props.position === 'top' ? unitToPx(props.offsetTop) : undefined,
      bottom: props.position === 'bottom' ? unitToPx(props.offsetBottom) : undefined,
      zIndex: props.zIndex,
    };
  }
  return {};
});

// 计算吸顶元素的样式
const stickyStyle = computed<CSSProperties>(() => {
  if (fixed.value && !props.cssMode) {
    return {
      top: props.position === 'top' ? unitToPx(props.offsetTop) : undefined,
      bottom: props.position === 'bottom' ? unitToPx(props.offsetBottom) : undefined,
      zIndex: props.zIndex,
      width: root.value ? `${root.value.offsetWidth}px` : undefined,
    };
  }
  return {};
});

// 计算class
const classes = computed(() => {
  return ['sticky', { 'sticky--css-mode': props.cssMode }];
});

// 获取滚动容器
const getContainer = () => {
  if (props.container) {
    if (typeof props.container === 'string') {
      return document.querySelector(props.container) as HTMLElement;
    }
    return props.container;
  }
  return window;
};

// 检查是否需要固定
const checkPosition = () => {
  if (!root.value || props.cssMode) {
    return;
  }

  height.value = root.value.offsetHeight;

  const container = getContainer();
  const scrollTop = getScrollTop(container);
  const rootTop = getElementTop(root.value, container);

  if (props.position === 'top') {
    const offsetTop = parseFloat(unitToPx(props.offsetTop));
    fixed.value = scrollTop + offsetTop > rootTop;
  } else {
    const offsetBottom = parseFloat(unitToPx(props.offsetBottom));
    const bottomTop = rootTop + height.value - window.innerHeight;
    fixed.value = scrollTop + window.innerHeight - offsetBottom < bottomTop;
  }
};

// 更新吸顶状态
const updateSticky = () => {
  checkPosition();
};

// 监听滚动事件
const onScroll = () => {
  checkPosition();
};

// 监听属性变化
watch(
  () => [props.position, props.container, props.offsetTop, props.offsetBottom],
  () => {
    checkPosition();
  }
);

// 生命周期钩子
onMounted(() => {
  scrollParent.value = getContainer();
  useEventListener(scrollParent, 'scroll', onScroll, { passive: true });
  checkPosition();
});

onBeforeUnmount(() => {
  if (scrollParent.value && !props.cssMode) {
    scrollParent.value.removeEventListener('scroll', onScroll);
  }
});

// 暴露方法
defineExpose({
  updateSticky,
});
</script>

<style>
@import './style/index.css';
</style>
