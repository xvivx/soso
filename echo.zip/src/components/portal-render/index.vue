<template>
  <Teleport to="body">
    <AnimatePresence :key="desktop ? 'desktop' : 'mobile'">
      <template v-for="(overlay, index) in store[1]" :key="overlay.key">
        <motion.div
          class="ht-overlay no-scrollbar fixed inset-0 overflow-scroll overscroll-contain bg-black/60"
          :initial="{ opacity: 0 }"
          :animate="{ opacity: 1 }"
          :exit="{ opacity: 0 }"
          :style="{ zIndex: `calc(var(--overly-z-index) + ${2 * index})` }"
          :transition="{ duration }"
          @click="overlay.closable !== false && render.close()"
        >
        </motion.div>

        <div
          :class="variants.layout({ variant: variantKey(overlay) })"
          :style="{ zIndex: `calc(var(--overly-z-index) + ${2 * index + 1})` }"
        >
          <motion.div
            :class="variants.content({ variant: variantKey(overlay) })"
            :variants="variants.animation[variantKey(overlay)]"
            initial="hidden"
            animate="visible"
            exit="hidden"
            :transition="{ duration }"
            v-on="
              // 移动端底部弹窗交互逻辑
              variantKey(overlay) === 'bottom'
                ? {
                    touchstart: onTouchStart,
                    touchmove: onTouchMove,
                    touchend: onTouchEnd,
                  }
                : {}
            "
          >
            <div v-if="variantKey(overlay) === 'bottom'" class="flex-center relative h-6 touch-none">
              <svg xmlns="http://www.w3.org/2000/svg" width="37" height="4" viewBox="0 0 37 4">
                <rect x="0.5" width="36" height="4" rx="2" class="fill-primary" fill-opacity="0.3" />
              </svg>
            </div>

            <component
              :is="overlay.node"
              :class="
                cn(
                  'ht-portal-content relative overflow-y-auto',
                  overlay.drawer ? 'ht-drawer-content w-100 max-w-[70vw] px-4' : 'min-h-24',
                  overlay.node.props && overlay.node.props.class
                )
              "
            />
          </motion.div>
        </div>
      </template>
    </AnimatePresence>
  </Teleport>
</template>
<script setup lang="ts">
import { computed, onUnmounted } from 'vue';
import { useMediaQuery } from '@vueuse/core';
import { cva } from 'class-variance-authority';
import { animate, AnimatePresence, motion, useMotionValue } from 'motion-v';
import { cn } from '@/utils';
import { render, useRender, type OverlayVmNode } from './store';

const desktop = useMediaQuery('(min-width: 768px)');
const duration = 0.3;
const [_, vmNodes] = useRender();
const store = computed(
  () =>
    [
      vmNodes.value.filter((node) => node.type === 'message'),
      vmNodes.value.filter((node) => node.type === 'overlay'),
    ] as const
);
const variants = {
  animation: {
    bottom: {
      hidden: { y: '100%' },
      visible: { y: 0 },
    },
    center: {
      hidden: { scale: 0.25 },
      visible: { scale: 1 },
    },
    right: {
      hidden: { x: '100%' },
      visible: { x: 0 },
    },
    message: {
      hidden: { x: '100%' },
      visible: { x: 0 },
    },
  },
  layout: cva('ht-portal-wrapper no-scrollbar pointer-events-none fixed inset-0 overflow-scroll overscroll-contain', {
    variants: {
      variant: {
        right: 'flex flex-row justify-end',
        center: 'flex-center',
        bottom: 'flex flex-col justify-end',
      },
    },
  }),
  content: cva('ht-portal-container pointer-events-auto touch-none', {
    variants: {
      variant: {
        right: 'h-full rounded-none py-4',
        center: 'mx-6 rounded-2xl py-4 rounded-2xl',
        bottom: 'rounded-t-2xl pb-4',
      },
    },
  }),
};
const variantKey = (overlay: OverlayVmNode) => {
  return overlay.drawer ? 'right' : overlay.center || desktop.value ? 'center' : 'bottom';
};

const domRefs: {
  content?: HTMLDivElement;
  overlay?: HTMLDivElement;
} = {};
let start = 0;
let maxMoveDistance = 0;
const offset = useMotionValue(0);

function onTouchStart(event: TouchEvent) {
  if (domRefs.content) return;

  let target = event.target as HTMLDivElement;
  while (!target.classList.contains('ht-portal-container')) {
    if (target.scrollTop > 5) return;
    target = target.parentElement as HTMLDivElement;
  }

  maxMoveDistance = target.clientHeight;
  domRefs.content = target;
  domRefs.overlay = domRefs.content.parentElement!.previousSibling as HTMLDivElement;
  start = event.touches[0]!.clientY;
  offset.jump(0);
}

function onTouchMove(event: TouchEvent) {
  if (!domRefs.content) return;

  const distance = event.touches[0]!.clientY - start;
  if (distance > 0) {
    event.preventDefault();
    event.stopPropagation();
    offset.set(distance);
  } else {
    offset.jump(0);
    clear();
  }
}

async function onTouchEnd() {
  if (!domRefs.content || offset.get() === 0) return clear();

  const progress = offset.get() / maxMoveDistance;
  const shouldClose = offset.getVelocity() > 1200 || progress > 0.6;
  await animate(offset, shouldClose ? maxMoveDistance : 0, { duration });
  if (shouldClose) {
    domRefs.overlay!.classList.add('hidden');
    render.close();
  }

  clear();
}

offset.on('change', (value) => {
  animate(domRefs.content!, { y: value }, { type: false });
  animate(domRefs.overlay!, { opacity: 1 - value / maxMoveDistance }, { type: false });
});

function clear() {
  delete domRefs.content;
  delete domRefs.overlay;
}
onUnmounted(clear);
</script>

<style>
@reference 'tailwindcss';

.ht-overlay {
  background-color: var(--overlay-bg-color);
}

.ht-portal-content {
  max-height: var(--portal-content-max-height);

  @variant md {
    max-width: var(--portal-content-max-width);
  }
}

.ht-drawer-content {
  max-height: 100%;
}

.ht-portal-container {
  background-color: var(--portal-container-bg-color);
  box-shadow: 0 1px var(--portal-container-bg-color);
}

.ht-portal-wrapper::after,
.ht-overlay::after {
  content: '';
  position: absolute;
  inset: 0;
  bottom: -1px;
  z-index: -100;
}

:root {
  --overly-z-index: 1000;
  --overlay-bg-color: rgba(0, 0, 0, 0.6);
  --portal-container-bg-color: #fff;
  --portal-content-max-height: 80vh;
  --portal-content-max-width: 800px;
}
</style>
