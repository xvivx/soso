<template>
  <Teleport to="body">
    <AnimatePresence>
      <template v-for="(overlay, index) in store[1]" :key="overlay.key">
        <motion.div
          class="ht-overlay no-scrollbar fixed inset-0 touch-none overflow-auto bg-black/60"
          :initial="{ opacity: 0 }"
          :animate="{ opacity: 1 }"
          :exit="{ opacity: 0 }"
          :style="{ zIndex: `calc(var(--overly-z-index) + ${2 * index})` }"
          :transition="{ duration }"
          @click="overlay.closable !== false && render.close()"
        >
        </motion.div>
        <div
          :class="
            cn(
              'ht-portal-wrapper no-scrollbar pointer-events-none fixed inset-0 flex justify-end overflow-scroll overscroll-contain',
              overlay.drawer ? 'flex-row' : 'translate-y-px flex-col'
            )
          "
          :style="{ zIndex: `calc(var(--overly-z-index) + ${2 * index + 1})` }"
        >
          <motion.div
            :class="
              cn(
                'ht-portal-container pointer-events-auto transform-gpu touch-none',
                overlay.drawer ? 'h-full py-4' : 'rounded-t-2xl pb-4'
              )
            "
            :variants="overlay.drawer ? animations.drawer : animations.mobile"
            initial="hidden"
            animate="visible"
            exit="hidden"
            data-ht-portal-container
            :transition="{ duration }"
            @touchstart="(event) => !overlay.drawer && onTouchStart(event)"
            @touchmove="(event) => !overlay.drawer && onTouchMove(event)"
            @touchend="() => !overlay.drawer && onTouchEnd()"
          >
            <div v-if="!overlay.drawer" class="relative h-6 touch-none">
              <svg
                class="pointer-events-none absolute top-2 left-1/2 -translate-x-1/2"
                xmlns="http://www.w3.org/2000/svg"
                width="37"
                height="4"
                viewBox="0 0 37 4"
              >
                <rect x="0.5" width="36" height="4" rx="2" class="fill-primary" fill-opacity="0.3" />
              </svg>
            </div>

            <component
              :is="overlay.node"
              :class="
                cn(
                  'ht-portal-content relative overflow-y-auto bg-inherit',
                  overlay.drawer ? 'ht-drawer-content h-full w-100 max-w-[70vw] px-4' : 'min-h-24',
                  overlay.node.props && overlay.node.props.class
                )
              "
            />
          </motion.div>
        </div>
      </template>
    </AnimatePresence>
  </Teleport>
</template>
<script setup lang="ts">
import { computed, onUnmounted } from 'vue';
import { animate, AnimatePresence, motion, useMotionValue } from 'motion-v';
import { cn } from '@/utils';
import { render, useRender } from './store';

const duration = 0.2;
const [_, vmNodes] = useRender();
const store = computed(
  () =>
    [
      vmNodes.value.filter((node) => node.type === 'message'),
      vmNodes.value.filter((node) => node.type === 'overlay'),
    ] as const
);

const animations = {
  mobile: {
    hidden: { y: '100%' },
    visible: { y: 0 },
  },
  desktop: {
    hidden: { scale: 0.25 },
    visible: { scale: 1, y: 0 },
  },
  drawer: {
    hidden: { x: '100%' },
    visible: { x: 0 },
  },
  message: {
    hidden: { x: '100%' },
    visible: { x: 0 },
  },
};

const doms: {
  content?: HTMLDivElement;
  overlay?: HTMLDivElement;
} = {};

let start = 0;
let maxMoveDistance = 0;
const offset = useMotionValue(0);
function onTouchStart(event: TouchEvent) {
  let target = event.target as HTMLDivElement;
  while (!target.hasAttribute('data-ht-portal-container')) {
    if (target.scrollTop > 0) return clear();
    target = target.parentElement as HTMLDivElement;
  }

  maxMoveDistance = target.clientHeight;
  doms.content = target;
  doms.overlay = doms.content.parentElement!.previousSibling as HTMLDivElement;
  start = event.touches[0]!.clientY;
  offset.jump(0);
}

function onTouchMove(event: TouchEvent) {
  const distance = event.touches[0]!.clientY - start;
  offset.set(distance);
  if (distance > 0) {
    move(distance);
  } else {
    move(0);
    clear();
  }
}

async function onTouchEnd() {
  if (!doms.content || offset.get() === 0) return clear();

  const progress = offset.get() / maxMoveDistance;
  const shouldClose = offset.getVelocity() > 1200 || progress > 0.6;
  await Promise.all(move(shouldClose ? maxMoveDistance : 0, duration));

  if (shouldClose) {
    doms.overlay!.classList.add('hidden');
    render.close();
  }

  clear();
}

function move(distance: number, duration = 0) {
  return [
    doms.content &&
      animate(
        doms.content,
        { y: distance },
        {
          type: 'tween',
          ease: 'easeInOut',
          duration,
        }
      ),
    doms.overlay &&
      animate(
        doms.overlay,
        {
          opacity: 1 - distance / doms.content!.clientHeight,
        },
        { duration }
      ),
  ];
}

function clear() {
  delete doms.content;
  delete doms.overlay;
}
onUnmounted(clear);
</script>

<style>
.ht-overlay {
  background-color: var(--overlay-bg-color);
}

.ht-portal-content {
  max-height: var(--portal-content-max-height);
}

.ht-drawer-content {
  max-height: 100%;
}

.ht-portal-container {
  background-color: var(--portal-container-bg-color);
}

.ht-portal-wrapper::after {
  content: '';
  position: absolute;
  inset: 0;
  bottom: -1px;
  z-index: -100;
}

:root {
  --overly-z-index: 1000;
  --overlay-bg-color: rgba(0, 0, 0, 0.6);
  --portal-container-bg-color: #fff;
  --portal-content-max-height: 80vh;
}
</style>
