import { h, onMounted, ref, type Ref, type VNode } from 'vue';
import { debounce } from 'lodash-es';

type MessageVmNode = {
  key: PropertyKey;
  node: VNode;
  type: 'message';
};

export type OverlayVmNode = {
  key: PropertyKey;
  type: 'overlay';
  node: VNode;
  /** 点击背景是否可以关闭 */
  closable?: boolean;
  onClose?: () => void;
  drawer?: boolean;
};

type VmNode = MessageVmNode | OverlayVmNode;

let store: VmNode[] = [];
const listeners: Array<(state: VmNode[]) => void> = [];
function dispatch(action: Action) {
  console.log('[dispatch] Action:', action, 'Current store:', store);
  store = reducer(store, action);
  console.log('[dispatch] New store:', store);
  console.log('[dispatch] Notifying', listeners.length, 'listeners');
  listeners.forEach((listener) => {
    listener(store);
  });
}

export function useRender() {
  const state = ref(store);

  onMounted(() => {
    const debounceUpdate = debounce((vmNodes: VmNode[]) => {
      state.value = vmNodes;
    }, 100);
    listeners.push(debounceUpdate);
    return () => {
      const index = listeners.indexOf(debounceUpdate);
      if (index > -1) {
        listeners.splice(index, 1);
      }
    };
  });

  return [render, state] as [typeof render, Ref<typeof store>];
}

type Action =
  | {
      type: 'ADD';
      payload: VmNode;
    }
  | {
      type: 'DELETE';
      payload: PropertyKey;
    }
  | {
      type: 'CLOSE_ALL_OVERLAYS';
    };

function reducer(state: VmNode[], action: Action) {
  switch (action.type) {
    case 'ADD': {
      const node = action.payload;
      const index = state.findIndex((item) => item.key === node.key);

      if (index > -1) {
        // 更新节点
        const copy = [...state];
        return (copy.splice(index, 1, node), copy);
      } else {
        // 插入节点
        return state.concat(node);
      }
    }

    case 'DELETE': {
      return state.filter((item) => item.key !== action.payload);
    }

    case 'CLOSE_ALL_OVERLAYS': {
      return state.filter((it) => it.type === 'message');
    }

    default: {
      return state;
    }
  }
}

type RenderOption = {
  /** 是否允许点击背景关闭 */
  closable?: boolean;
  /** 如果点击背景可以关闭, 在点击背景时会优先执行该回调,
   ** 用Modal.open({...})调用时, 如果不想点击背景关闭传入 closable: false即可
   ** 用组件调用时<Modal onClose={() => {...}} /> onClose必须传入*/
  onClose?: () => void;
  drawer?: boolean;
};
/**
 * 用于在函数中渲染组件, 返回销毁方法
 * @param node 要渲染的组件
 */
export function createRender(node: VNode | VNode[], type?: 'message'): () => void;
export function createRender(node: VNode | VNode[], option?: RenderOption): () => void;
export function createRender(node: VNode | VNode[], option?: 'message' | RenderOption) {
  console.log('[createRender] Called with node:', node, 'option:', option);

  let element: VNode;

  if (!Array.isArray(node)) {
    element = node;
  } else if (node.length === 1 && node[0] && typeof node[0].type === 'string') {
    // 获取slots时会得到数组, 如果只有一个元素而且是dom标签就由它承接classname
    element = node[0];
  } else {
    // 给数组的node一个dom容器承接classname
    element = h('div', null, node);
  }

  const key = element.key || Math.random().toString(32);

  console.log('[createRender] Generated key:', key, 'element:', element);

  let payload: VmNode;

  if (option === 'message') {
    payload = {
      key,
      node: element,
      type: 'message',
    };
  } else {
    payload = {
      key,
      node: element,
      type: 'overlay',
      ...option,
    };
  }

  console.log('[createRender] Dispatching ADD with payload:', payload);
  console.log('[createRender] Store before dispatch:', store);

  dispatch({
    type: 'ADD',
    payload,
  });

  console.log('[createRender] Store after dispatch:', store);
  console.log('[createRender] Listeners count:', listeners.length);

  return () => dispatch({ type: 'DELETE', payload: key });
}

class Render {
  /** 删除指定节点 */
  delete(key: PropertyKey) {
    // 正在批量删除或者删除还未进到store中的元素拦截dispatch
    if (this.batching || store.findIndex((it) => it.key === key) === -1) return;
    dispatch({ type: 'DELETE', payload: key });
  }
  /** 是否正在调用close方法, 可能的场景是onClose中调用了该方法, 引发死循环 */
  private closing = false;
  /** 关闭当前显示的overlay元素, 类似pop操作 */
  close() {
    if (this.batching || this.closing) return;
    const lastOverlay = store.filter((it) => it.type === 'overlay').slice(-1)[0];
    if (!lastOverlay) return;

    'onClose' in lastOverlay && lastOverlay.onClose && lastOverlay.onClose();
    this.closing = true;
    dispatch({ type: 'DELETE', payload: lastOverlay.key });
    this.closing = false;
  }
  /** 是否正在调用closeAllOverlays, 可能的场景是在onClose中调用该方法, 引发死循环 */
  private batching = false;
  /** 清空除message外的所有节点, 一般用于在最后一个弹窗结束所有流程 */
  closeAllOverlays() {
    if (this.batching) return;
    this.batching = true;
    store.forEach((it) => 'onClose' in it && it.onClose && it.onClose());
    dispatch({ type: 'CLOSE_ALL_OVERLAYS' });
    this.batching = false;
  }
}

export const render = new Render();
