import HTCollapse from './Collapse.vue';

export { HTCollapse };
export default HTCollapse;
export type { CollapseProps, CollapseInstance, CollapseToggleAllOptions } from './types';
