export { default as HTCollapse } from './Collapse.vue';
export type { CollapseProps, CollapseInstance, CollapseToggleAllOptions } from './types';
