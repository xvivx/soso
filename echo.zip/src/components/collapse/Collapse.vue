<script setup lang="ts">
import { watch } from 'vue';
import { AccordionRoot } from 'reka-ui';
import { cn, COLLAPSE_KEY } from '@/utils/index';
import { useChildren } from '@/hooks';
import type { CollapseModelValue, CollapseProps, CollapseToggleAllOptions } from './types';

const props = withDefaults(defineProps<CollapseProps>(), {
  accordion: false,
  collapsible: true,
});
const model = defineModel<CollapseModelValue>('modelValue');
const emits = defineEmits<{
  (e: 'change', val: CollapseModelValue): void;
}>();
const { linkChildren, children } = useChildren(COLLAPSE_KEY);

watch(
  () => model.value,
  (val) => {
    emits('change', val as CollapseModelValue);
  },
  { immediate: false }
);

watch(
  [() => model.value, () => props.accordion],
  () => {
    validateModelValue();
  },
  { immediate: true }
);

function validateModelValue() {
  const { accordion } = props;
  if (accordion && Array.isArray(model.value)) {
    console.error('"v-model" should not be Array in accordion mode');
    return false;
  }
  if (!accordion && !Array.isArray(model.value)) {
    console.error('"v-model" should be Array in non-accordion mode');
    return false;
  }
  return true;
}

const toggleAll = (options: boolean | CollapseToggleAllOptions = {}) => {
  if (props.accordion) {
    return;
  }

  if (typeof options === 'boolean') {
    options = { expanded: options };
  }

  const { expanded, skipDisabled } = options!;
  const expandedChildren = children.filter((item: any) => {
    if (item.disabled && skipDisabled) {
      return item.$el.getAttribute('data-state') === 'open';
    }
    return expanded ?? item.$el.getAttribute('data-state') === 'closed';
  });
  const names = expandedChildren.map((item) => item.name);
  model.value = names;
};

defineExpose({ toggleAll });
linkChildren();
</script>

<template>
  <AccordionRoot
    data-slot="accordion"
    v-model="model"
    :type="accordion ? 'single' : 'multiple'"
    :collapsible="collapsible"
    :class="cn('ht-collapse overflow-hidden')"
  >
    <slot />
  </AccordionRoot>
</template>
