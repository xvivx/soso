import type { ComponentPublicInstance } from 'vue';

export type CollapseToggleAllOptions =
  | boolean
  | {
      expanded?: boolean;
      skipDisabled?: boolean;
    };

export type CollapseModelValue = string | string[];

export interface CollapseProps {
  modelValue: CollapseModelValue;
  accordion?: boolean;
  collapsible?: boolean;
}

export type CollapseInstance = ComponentPublicInstance<{
  toggleAll: (options?: boolean | CollapseToggleAllOptions) => void;
}>;
