<template>
  <div class="loading-demo space-y-8 p-6">
    <h1 class="mb-6 text-2xl font-bold">HTLoading 加载组件</h1>

    <!-- 基础用法 -->
    <section class="space-y-4">
      <h2 class="text-xl font-semibold">基础用法</h2>
      <div class="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-4">
        <div class="rounded-lg border p-4">
          <h3 class="mb-2 text-sm font-medium">Circular (默认)</h3>
          <HTLoading />
        </div>
        <div class="rounded-lg border p-4">
          <h3 class="mb-2 text-sm font-medium">Spinner</h3>
          <HTLoading type="spinner" />
        </div>
        <div class="rounded-lg border p-4">
          <h3 class="mb-2 text-sm font-medium">带文本</h3>
          <HTLoading text="加载中..." />
        </div>
        <div class="rounded-lg border p-4">
          <h3 class="mb-2 text-sm font-medium">垂直布局</h3>
          <HTLoading text="加载中..." vertical />
        </div>
      </div>
    </section>

    <!-- 尺寸变化 -->
    <section class="space-y-4">
      <h2 class="text-xl font-semibold">尺寸变化</h2>
      <div class="grid grid-cols-1 gap-4 md:grid-cols-3">
        <div class="rounded-lg border p-4">
          <h3 class="mb-2 text-sm font-medium">小号 (16px)</h3>
          <HTLoading size="16px" text="小号加载" />
        </div>
        <div class="rounded-lg border p-4">
          <h3 class="mb-2 text-sm font-medium">默认 (30px)</h3>
          <HTLoading size="30px" text="默认加载" />
        </div>
        <div class="rounded-lg border p-4">
          <h3 class="mb-2 text-sm font-medium">大号 (48px)</h3>
          <HTLoading size="48px" text="大号加载" />
        </div>
      </div>
    </section>

    <!-- 颜色变化 -->
    <section class="space-y-4">
      <h2 class="text-xl font-semibold">颜色变化</h2>
      <div class="grid grid-cols-1 gap-4 md:grid-cols-3">
        <div class="rounded-lg border p-4">
          <h3 class="mb-2 text-sm font-medium">主色 (默认)</h3>
          <HTLoading color="#1677ff" text="主色加载" />
        </div>
        <div class="rounded-lg border p-4">
          <h3 class="mb-2 text-sm font-medium">成功色</h3>
          <HTLoading color="#52c41a" text="成功加载" />
        </div>
        <div class="rounded-lg border p-4">
          <h3 class="mb-2 text-sm font-medium">警告色</h3>
          <HTLoading color="#faad14" text="警告加载" />
        </div>
      </div>
    </section>

    <!-- 文本样式 -->
    <section class="space-y-4">
      <h2 class="text-xl font-semibold">文本样式</h2>
      <div class="grid grid-cols-1 gap-4 md:grid-cols-2">
        <div class="rounded-lg border p-4">
          <h3 class="mb-2 text-sm font-medium">自定义文本颜色</h3>
          <HTLoading text="自定义颜色文本" textColor="#ff4d4f" color="#1677ff" />
        </div>
        <div class="rounded-lg border p-4">
          <h3 class="mb-2 text-sm font-medium">自定义文本大小</h3>
          <HTLoading text="大号文本" textSize="18px" size="30px" />
        </div>
      </div>
    </section>

    <!-- 对齐方式 -->
    <section class="space-y-4">
      <h2 class="text-xl font-semibold">对齐方式</h2>
      <div class="grid grid-cols-1 gap-4 md:grid-cols-3">
        <div class="rounded-lg border p-4">
          <h3 class="mb-2 text-sm font-medium">左对齐</h3>
          <HTLoading text="左对齐加载" textAlign="left" />
        </div>
        <div class="rounded-lg border p-4">
          <h3 class="mb-2 text-sm font-medium">居中对齐</h3>
          <HTLoading text="居中对齐加载" textAlign="center" />
        </div>
        <div class="rounded-lg border p-4">
          <h3 class="mb-2 text-sm font-medium">右对齐</h3>
          <HTLoading text="右对齐加载" textAlign="right" />
        </div>
      </div>
    </section>

    <!-- 自定义图标 -->
    <section class="space-y-4">
      <h2 class="text-xl font-semibold">自定义图标</h2>
      <div class="rounded-lg border p-4">
        <h3 class="mb-2 text-sm font-medium">自定义图标插槽</h3>
        <HTLoading text="自定义图标">
          <template #icon>
            <div class="h-6 w-6 animate-spin rounded-full border-b-2 border-blue-500"></div>
          </template>
        </HTLoading>
      </div>
    </section>

    <!-- Vant API 兼容性演示 -->
    <section class="space-y-4">
      <h2 class="text-xl font-semibold">Vant API 兼容性</h2>
      <div class="rounded-lg border bg-gray-50 p-4">
        <h3 class="mb-2 text-sm font-medium">完全兼容 Vant Loading API</h3>
        <pre class="overflow-x-auto rounded border bg-white p-2 text-xs"><code>{{ vantApiExample }}</code></pre>
      </div>
    </section>

    <!-- 响应式测试 -->
    <section class="space-y-4">
      <h2 class="text-xl font-semibold">响应式测试</h2>
      <div class="rounded-lg border p-4">
        <p class="mb-2 text-sm text-gray-600">调整浏览器大小查看响应式效果</p>
        <HTLoading text="响应式加载组件" size="40px" vertical />
      </div>
    </section>

    <!-- 无障碍演示 -->
    <section class="space-y-4">
      <h2 class="text-xl font-semibold">无障碍支持</h2>
      <div class="rounded-lg border p-4">
        <p class="mb-2 text-sm text-gray-600">屏幕阅读器会读出"加载中"状态</p>
        <HTLoading text="支持无障碍访问" aria-label="正在加载内容" />
        <p class="mt-2 text-xs text-gray-500">支持减少动画模式和高对比度模式</p>
      </div>
    </section>
  </div>
</template>

<script setup lang="ts">
import { HTLoading } from '@/components/loading';

// Vant API 示例代码
const vantApiExample = `// Vant 兼容的 API
<HTLoading
  type="circular"        // 'circular' | 'spinner'
  size="30px"            // string | number
  color="#1677ff"        // 自定义颜色
  textSize="14px"        // 文本大小
  textColor="#333"       // 文本颜色
  vertical={false}       // 垂直布局
  text="加载中..."       // 加载文本
  textAlign="center"     // 文本对齐
  class="custom-class"   // 自定义类名
/>

// 完全兼容 Vant 的 props 命名和默认值`;
</script>

<style scoped>
.loading-demo {
  max-width: 1200px;
  margin: 0 auto;
}

.grid {
  display: grid;
}

.grid-cols-1 {
  grid-template-columns: repeat(1, minmax(0, 1fr));
}

@media (min-width: 768px) {
  .md\:grid-cols-2 {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }

  .md\:grid-cols-3 {
    grid-template-columns: repeat(3, minmax(0, 1fr));
  }
}

@media (min-width: 1024px) {
  .lg\:grid-cols-4 {
    grid-template-columns: repeat(4, minmax(0, 1fr));
  }
}

.gap-4 {
  gap: 1rem;
}

.p-4 {
  padding: 1rem;
}

.p-6 {
  padding: 1.5rem;
}

.border {
  border-width: 1px;
  border-color: #e5e7eb;
}

.border-rounded-lg {
  border-radius: 0.5rem;
}

.rounded-lg {
  border-radius: 0.5rem;
}

.space-y-4 > :not([hidden]) ~ :not([hidden]) {
  margin-top: 1rem;
}

.space-y-8 > :not([hidden]) ~ :not([hidden]) {
  margin-top: 2rem;
}

.text-2xl {
  font-size: 1.5rem;
  line-height: 2rem;
}

.text-xl {
  font-size: 1.25rem;
  line-height: 1.75rem;
}

.text-sm {
  font-size: 0.875rem;
  line-height: 1.25rem;
}

.text-xs {
  font-size: 0.75rem;
  line-height: 1rem;
}

.font-bold {
  font-weight: 700;
}

.font-semibold {
  font-weight: 600;
}

.font-medium {
  font-weight: 500;
}

.mb-2 {
  margin-bottom: 0.5rem;
}

.mb-6 {
  margin-bottom: 1.5rem;
}

.mt-2 {
  margin-top: 0.5rem;
}

.bg-gray-50 {
  background-color: #f9fafb;
}

.bg-white {
  background-color: #ffffff;
}

.text-gray-600 {
  color: #4b5563;
}

.text-gray-500 {
  color: #6b7280;
}

.overflow-x-auto {
  overflow-x: auto;
}

.animate-spin {
  animation: spin 1s linear infinite;
}

@keyframes spin {
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
}

.h-6 {
  height: 1.5rem;
}

.w-6 {
  width: 1.5rem;
}

.border-b-2 {
  border-bottom-width: 2px;
}

.border-blue-500 {
  border-color: #3b82f6;
}

.rounded-full {
  border-radius: 9999px;
}
</style>
