<template>
  <div class="p-4">
    <Suspense>
      <template #default>
        <router-view />
      </template>
      <template #fallback>
        <div class="text-primary p-4">Loading...</div>
      </template>
    </Suspense>
  </div>
</template>

<script setup lang="ts"></script>
