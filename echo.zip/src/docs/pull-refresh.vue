<script setup lang="ts">
import { ref } from 'vue';
import { HTPullRefresh } from '@/components';
import type { HTPullRefreshInstance } from '@/components/pull-refresh/types';

// 基础用法
const count = ref(0);
const basicLoading = ref(false);
const onRefresh = () => {
  setTimeout(() => {
    count.value++;
    basicLoading.value = false;
  }, 1000);
};

// 成功提示
const successLoading = ref(false);
const successText = ref('上次更新时间 ' + new Date().toLocaleTimeString());
const onRefreshSuccess = () => {
  setTimeout(() => {
    successText.value = '上次更新时间 ' + new Date().toLocaleTimeString();
    successLoading.value = false;
  }, 1000);
};

// 失败提示
const errorLoading = ref(false);
const errorPullRef = ref<HTPullRefreshInstance>();
const onRefreshError = () => {
  setTimeout(() => {
    // 模拟失败
    errorPullRef.value?.complete(false);
    errorLoading.value = false;
  }, 1000);
};

// v-model 用法
const vmodelLoading = ref(false);
const vmodelCount = ref(0);
const onVmodelRefresh = () => {
  setTimeout(() => {
    vmodelCount.value++;
    vmodelLoading.value = false;
  }, 1500);
};

// 自定义提示
const customLoading = ref(false);
const customLoadingText = ref('正在获取最新数据...');
const customPullingText = ref('下拉获取新数据');
const customLoosingText = ref('松开手指更新');
const onCustomRefresh = () => {
  setTimeout(() => {
    customLoading.value = false;
  }, 1000);
};

// 自定义头部高度
const headHeightLoading = ref(false);
const onHeadHeightRefresh = () => {
  setTimeout(() => {
    headHeightLoading.value = false;
  }, 1000);
};

// 列表数据
const list = ref(
  Array(10)
    .fill('')
    .map((_, index) => `列表项 ${index + 1}`)
);
const listLoading = ref(false);
const onRefreshList = () => {
  setTimeout(() => {
    list.value = Array(10)
      .fill('')
      .map((_, index) => `更新后的列表项 ${index + 1} - ${new Date().toLocaleTimeString()}`);
    listLoading.value = false;
  }, 1500);
};

// 自定义插槽
const slotLoading = ref(false);
const onSlotRefresh = () => {
  setTimeout(() => {
    slotLoading.value = false;
  }, 1000);
};

// 手动触发
const manualPullRef = ref<HTPullRefreshInstance>();
const manualLoading = ref(false);
const manualCount = ref(0);
const onManualRefresh = () => {
  setTimeout(() => {
    manualCount.value++;
    manualLoading.value = false;
  }, 1000);
};
const triggerManualRefresh = () => {
  manualPullRef.value?.triggerRefresh();
};

// 状态监听
const statusChangeLoading = ref(false);
const statusHistory = ref<string[]>([]);
const onStatusChange = (status: string) => {
  statusHistory.value.unshift(`${status} - ${new Date().toLocaleTimeString()}`);
  if (statusHistory.value.length > 5) {
    statusHistory.value = statusHistory.value.slice(0, 5);
  }
};
const onStatusRefresh = () => {
  setTimeout(() => {
    statusChangeLoading.value = false;
  }, 1000);
};
</script>

<template>
  <div class="demo-page">
    <h1>HTPullRefresh 下拉刷新</h1>
    <p class="demo-description">下拉刷新组件，支持自定义提示文字、插槽和多种配置选项</p>

    <div class="demo-section">
      <h2>基础用法</h2>
      <p class="section-desc">使用 v-model 控制加载状态</p>
      <div class="demo-block">
        <HTPullRefresh v-model="basicLoading" @refresh="onRefresh">
          <div class="demo-content">
            <p>刷新次数: {{ count }}</p>
            <p>下拉此区域进行刷新</p>
          </div>
        </HTPullRefresh>
      </div>
    </div>

    <div class="demo-section">
      <h2>成功提示</h2>
      <p class="section-desc">自定义成功提示文字</p>
      <div class="demo-block">
        <HTPullRefresh v-model="successLoading" :success-text="successText" @refresh="onRefreshSuccess">
          <div class="demo-content">
            <p>{{ successText }}</p>
            <p>下拉刷新查看更新时间</p>
          </div>
        </HTPullRefresh>
      </div>
    </div>

    <div class="demo-section">
      <h2>失败提示</h2>
      <p class="section-desc">使用 ref 手动控制失败状态</p>
      <div class="demo-block">
        <HTPullRefresh
          ref="errorPullRef"
          v-model="errorLoading"
          error-text="加载失败，请重试"
          @refresh="onRefreshError"
        >
          <div class="demo-content error">
            <p>模拟加载失败场景</p>
            <p>下拉会显示失败提示</p>
          </div>
        </HTPullRefresh>
      </div>
    </div>

    <div class="demo-section">
      <h2>v-model 双向绑定</h2>
      <p class="section-desc">通过 v-model 控制加载状态</p>
      <div class="demo-block">
        <HTPullRefresh v-model="vmodelLoading" @refresh="onVmodelRefresh">
          <div class="demo-content">
            <p>当前状态: {{ vmodelLoading ? '加载中' : '空闲' }}</p>
            <p>刷新次数: {{ vmodelCount }}</p>
            <p>v-model 值会自动同步</p>
          </div>
        </HTPullRefresh>
      </div>
    </div>

    <div class="demo-section">
      <h2>自定义提示文字</h2>
      <p class="section-desc">自定义所有状态的提示文字</p>
      <div class="demo-block">
        <HTPullRefresh
          v-model="customLoading"
          :pulling-text="customPullingText"
          :loosing-text="customLoosingText"
          :loading-text="customLoadingText"
          success-text="更新完成 ✓"
          @refresh="onCustomRefresh"
        >
          <div class="demo-content">
            <p>已自定义所有提示文字</p>
            <p>试试下拉效果</p>
          </div>
        </HTPullRefresh>
      </div>
    </div>

    <div class="demo-section">
      <h2>自定义头部高度</h2>
      <p class="section-desc">通过 headHeight 属性自定义头部高度</p>
      <div class="demo-block">
        <HTPullRefresh v-model="headHeightLoading" :head-height="80" :pull-distance="80" @refresh="onHeadHeightRefresh">
          <div class="demo-content">
            <p>头部高度: 80px</p>
            <p>触发距离: 80px</p>
          </div>
        </HTPullRefresh>
      </div>
    </div>

    <div class="demo-section">
      <h2>列表刷新</h2>
      <p class="section-desc">常见的列表刷新场景</p>
      <div class="demo-block">
        <HTPullRefresh v-model="listLoading" @refresh="onRefreshList">
          <div class="demo-list">
            <div v-for="item in list" :key="item" class="list-item">
              {{ item }}
            </div>
          </div>
        </HTPullRefresh>
      </div>
    </div>

    <div class="demo-section">
      <h2>自定义插槽</h2>
      <p class="section-desc">通过插槽自定义不同状态的显示内容</p>
      <div class="demo-block">
        <HTPullRefresh v-model="slotLoading" @refresh="onSlotRefresh">
          <!-- 自定义加载状态 -->
          <template #loading>
            <div class="custom-loading">
              <div class="loading-spinner"></div>
              <span>自定义加载中...</span>
            </div>
          </template>

          <!-- 自定义下拉状态 -->
          <template #pulling>
            <div class="custom-pulling">
              <span>👆 继续下拉</span>
            </div>
          </template>

          <!-- 自定义释放状态 -->
          <template #loosing>
            <div class="custom-loosing">
              <span>🎯 释放刷新</span>
            </div>
          </template>

          <!-- 自定义成功状态 -->
          <template #success>
            <div class="custom-success">
              <span>✓ 刷新成功</span>
            </div>
          </template>

          <div class="demo-content">
            <p>使用自定义插槽的状态提示</p>
            <p>下拉查看自定义效果</p>
          </div>
        </HTPullRefresh>
      </div>
    </div>

    <div class="demo-section">
      <h2>手动触发刷新</h2>
      <p class="section-desc">通过 ref 调用组件方法手动触发刷新</p>
      <div class="demo-block">
        <HTPullRefresh ref="manualPullRef" v-model="manualLoading" @refresh="onManualRefresh">
          <div class="demo-content">
            <p>刷新次数: {{ manualCount }}</p>
            <button class="manual-button" @click="triggerManualRefresh">手动触发刷新</button>
          </div>
        </HTPullRefresh>
      </div>
    </div>

    <div class="demo-section">
      <h2>状态监听</h2>
      <p class="section-desc">监听下拉刷新的状态变化</p>
      <div class="demo-block">
        <HTPullRefresh v-model="statusChangeLoading" @refresh="onStatusRefresh" @status-change="onStatusChange">
          <div class="demo-content">
            <p>下拉查看状态变化</p>
            <div class="status-list">
              <div v-for="(status, index) in statusHistory" :key="index" class="status-item">
                {{ status }}
              </div>
            </div>
          </div>
        </HTPullRefresh>
      </div>
    </div>

    <div class="demo-section">
      <h2>禁用状态</h2>
      <p class="section-desc">禁用下拉刷新功能</p>
      <div class="demo-block">
        <HTPullRefresh disabled @refresh="onRefresh">
          <div class="demo-content disabled">
            <p>此组件已禁用下拉刷新</p>
            <p>下拉不会有任何效果</p>
          </div>
        </HTPullRefresh>
      </div>
    </div>
  </div>
</template>

<style scoped>
.demo-page {
  padding: 20px;
  max-width: 800px;
  margin: 0 auto;
}

.demo-description {
  color: #666;
  margin-bottom: 32px;
  font-size: 14px;
}

.demo-section {
  margin-bottom: 48px;
}

.demo-section h2 {
  margin-bottom: 8px;
  color: #333;
  font-size: 18px;
  font-weight: 600;
}

.section-desc {
  color: #666;
  font-size: 14px;
  margin-bottom: 16px;
}

.demo-block {
  border: 1px solid #e5e7eb;
  border-radius: 8px;
  overflow: hidden;
  height: 300px;
  position: relative;
}

.demo-content {
  padding: 20px;
  height: 100%;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
}

.demo-content.error {
  background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
}

.demo-content.disabled {
  background: linear-gradient(135deg, #a8edea 0%, #fed6e3 100%);
}

.demo-content p {
  margin: 8px 0;
  text-align: center;
}

.demo-list {
  padding: 16px;
  background: #f9fafb;
}

.list-item {
  padding: 12px 16px;
  margin-bottom: 8px;
  border-radius: 4px;
  background: white;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
}

.list-item:last-child {
  margin-bottom: 0;
}

/* 手动触发按钮 */
.manual-button {
  margin-top: 16px;
  padding: 8px 24px;
  background: white;
  color: #667eea;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-size: 14px;
  font-weight: 500;
  transition: all 0.3s;
}

.manual-button:hover {
  background: #f0f0f0;
}

.manual-button:active {
  transform: scale(0.95);
}

/* 状态列表 */
.status-list {
  margin-top: 16px;
  width: 100%;
  max-width: 300px;
}

.status-item {
  padding: 8px 12px;
  margin-bottom: 4px;
  background: rgba(255, 255, 255, 0.2);
  border-radius: 4px;
  font-size: 12px;
  text-align: left;
}

/* 自定义样式 */
.custom-loading,
.custom-pulling,
.custom-loosing,
.custom-success {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  font-size: 14px;
  color: #666;
}

.custom-success {
  color: #52c41a;
  font-weight: 500;
}

.loading-spinner {
  width: 20px;
  height: 20px;
  border: 2px solid #ddd;
  border-top: 2px solid #1890ff;
  border-radius: 50%;
  animation: spin 1s linear infinite;
}

@keyframes spin {
  0% {
    transform: rotate(0deg);
  }
  100% {
    transform: rotate(360deg);
  }
}
</style>
