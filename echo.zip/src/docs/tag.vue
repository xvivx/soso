<template>
  <div class="tag-demo space-y-8 p-6">
    <h1 class="mb-6 text-2xl font-bold">HTTag 标签组件</h1>

    <!-- 基础用法 -->
    <section class="space-y-4">
      <h2 class="text-xl font-semibold">基础用法</h2>
      <div class="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3">
        <div class="rounded-lg border p-4">
          <h3 class="mb-2 text-sm font-medium">默认标签</h3>
          <div class="flex flex-wrap gap-2">
            <HTTag>默认标签</HTTag>
            <HTTag type="primary">主要标签</HTTag>
            <HTTag type="success">成功标签</HTTag>
          </div>
        </div>
        <div class="rounded-lg border p-4">
          <h3 class="mb-2 text-sm font-medium">带图标标签</h3>
          <div class="flex flex-wrap gap-2">
            <HTTag type="primary">
              <HTIcon name="check-circle" />
              验证通过
            </HTTag>
            <HTTag type="warning">
              <HTIcon name="warning" />
              需要关注
            </HTTag>
          </div>
        </div>
        <div class="rounded-lg border p-4">
          <h3 class="mb-2 text-sm font-medium">多种类型</h3>
          <div class="flex flex-wrap gap-2">
            <HTTag type="default">默认</HTTag>
            <HTTag type="primary">主要</HTTag>
            <HTTag type="success">成功</HTTag>
            <HTTag type="warning">警告</HTTag>
            <HTTag type="danger">危险</HTTag>
            <HTTag type="info">信息</HTTag>
          </div>
        </div>
      </div>
    </section>

    <!-- 样式变体 -->
    <section class="space-y-4">
      <h2 class="text-xl font-semibold">样式变体</h2>
      <div class="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-4">
        <div class="rounded-lg border p-4">
          <h3 class="mb-2 text-sm font-medium">朴素样式</h3>
          <div class="flex flex-wrap gap-2">
            <HTTag plain>朴素</HTTag>
            <HTTag type="primary" plain>主要</HTTag>
            <HTTag type="success" plain>成功</HTTag>
          </div>
        </div>
        <div class="rounded-lg border p-4">
          <h3 class="mb-2 text-sm font-medium">圆角样式</h3>
          <div class="flex flex-wrap gap-2">
            <HTTag round>圆角</HTTag>
            <HTTag round type="primary">主要</HTTag>
            <HTTag round type="success">成功</HTTag>
          </div>
        </div>
        <div class="rounded-lg border p-4">
          <h3 class="mb-2 text-sm font-medium">标记样式</h3>
          <div class="flex flex-wrap gap-2">
            <HTTag mark>标记</HTTag>
            <HTTag mark type="primary">主要</HTTag>
            <HTTag mark type="success">成功</HTTag>
          </div>
        </div>
        <div class="rounded-lg border p-4">
          <h3 class="mb-2 text-sm font-medium">组合样式</h3>
          <div class="flex flex-wrap gap-2">
            <HTTag round plain>圆角朴素</HTTag>
            <HTTag mark plain>标记朴素</HTTag>
            <HTTag size="small" round>小号圆角</HTTag>
          </div>
        </div>
      </div>
    </section>

    <!-- 尺寸变体 -->
    <section class="space-y-4">
      <h2 class="text-xl font-semibold">尺寸变体</h2>
      <div class="grid grid-cols-1 gap-4 md:grid-cols-3">
        <div class="rounded-lg border p-4">
          <h3 class="mb-2 text-sm font-medium">小号标签</h3>
          <div class="flex flex-wrap gap-2">
            <HTTag size="small" type="primary">小号</HTTag>
            <HTTag size="small" round>圆角</HTTag>
            <HTTag size="small" mark>标记</HTTag>
          </div>
        </div>
        <div class="rounded-lg border p-4">
          <h3 class="mb-2 text-sm font-medium">默认标签</h3>
          <div class="flex flex-wrap gap-2">
            <HTTag type="primary">默认</HTTag>
            <HTTag round>圆角</HTTag>
            <HTTag mark>标记</HTTag>
          </div>
        </div>
        <div class="rounded-lg border p-4">
          <h3 class="mb-2 text-sm font-medium">大号标签</h3>
          <div class="flex flex-wrap gap-2">
            <HTTag size="large" type="primary">大号</HTTag>
            <HTTag size="large" round>圆角</HTTag>
            <HTTag size="large" mark>标记</HTTag>
          </div>
        </div>
      </div>
    </section>

    <!-- 高级特性 -->
    <section class="space-y-4">
      <h2 class="text-xl font-semibold">高级特性</h2>
      <div class="grid grid-cols-1 gap-4 md:grid-cols-2">
        <div class="rounded-lg border p-4">
          <h3 class="mb-2 text-sm font-medium">可关闭标签</h3>
          <div class="flex flex-wrap gap-2">
            <HTTag v-for="tag in closableTags" :key="tag.name" :type="tag.type" closeable @close="removeTag(tag)">
              {{ tag.name }}
            </HTTag>
            <HTTag closeable @close="addTag">
              <HTIcon name="plus" />
              添加
            </HTTag>
          </div>
        </div>
        <div class="rounded-lg border p-4">
          <h3 class="mb-2 text-sm font-medium">自定义颜色</h3>
          <div class="flex flex-wrap gap-2">
            <HTTag color="#7232dd">自定义颜色</HTTag>
            <HTTag color="#7232dd" plain>朴素自定义</HTTag>
            <HTTag color="#ffe1e1" text-color="#ad0000">自定义文本</HTTag>
            <HTTag color="linear-gradient(45deg, #ff6b6b, #feca57)" text-color="white" round> 渐变背景 </HTTag>
          </div>
        </div>
        <div class="rounded-lg border p-4">
          <h3 class="mb-2 text-sm font-medium">动态控制</h3>
          <div class="space-y-3">
            <div class="flex items-center gap-4">
              <label class="flex items-center gap-2 text-sm">
                <input type="checkbox" v-model="dynamicTag.show" class="rounded" />
                显示标签
              </label>
              <label class="flex items-center gap-2 text-sm">
                <input type="checkbox" v-model="dynamicTag.round" class="rounded" />
                圆角
              </label>
            </div>
            <HTTag v-if="dynamicTag.show" :type="dynamicTag.type" :round="dynamicTag.round" :plain="dynamicTag.plain">
              动态标签
            </HTTag>
          </div>
        </div>
        <div class="rounded-lg border p-4">
          <h3 class="mb-2 text-sm font-medium">计数器标签</h3>
          <div class="space-y-3">
            <div class="flex items-center gap-3">
              <HTTag type="primary">数量: {{ counter }}</HTTag>
              <div class="flex gap-2">
                <button
                  @click="incrementCounter"
                  class="rounded bg-green-500 px-2 py-1 text-xs text-white hover:bg-green-600"
                >
                  +
                </button>
                <button
                  @click="decrementCounter"
                  class="rounded bg-orange-500 px-2 py-1 text-xs text-white hover:bg-orange-600"
                >
                  -
                </button>
                <button
                  @click="resetCounter"
                  class="rounded bg-gray-500 px-2 py-1 text-xs text-white hover:bg-gray-600"
                >
                  重置
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- Vant API 兼容性演示 -->
    <section class="space-y-4">
      <h2 class="text-xl font-semibold">Vant API 兼容性</h2>
      <div class="rounded-lg border bg-gray-50 p-4">
        <h3 class="mb-2 text-sm font-medium">完全兼容 Vant Tag API</h3>
        <pre class="overflow-x-auto rounded border bg-white p-2 text-xs"><code>{{ vantApiExample }}</code></pre>
        <div class="mt-3 flex flex-wrap gap-2">
          <HTTag type="primary" size="large" round closeable @close="handleClose"> Vant 风格标签 </HTTag>
          <HTTag type="success" plain round> 朴素圆角 </HTTag>
          <HTTag color="#7232dd" round closeable @close="handleClose"> 自定义颜色 </HTTag>
        </div>
      </div>
    </section>

    <!-- 响应式测试 -->
    <section class="space-y-4">
      <h2 class="text-xl font-semibold">响应式测试</h2>
      <div class="rounded-lg border p-4">
        <p class="mb-2 text-sm text-gray-600">调整浏览器大小查看响应式效果</p>
        <div class="grid grid-cols-2 gap-2 sm:grid-cols-4 md:grid-cols-6 lg:grid-cols-8">
          <HTTag v-for="i in 8" :key="i" :type="getType(i)"> 响应式{{ i }} </HTTag>
        </div>
      </div>
    </section>

    <!-- 无障碍演示 -->
    <section class="space-y-4">
      <h2 class="text-xl font-semibold">无障碍支持</h2>
      <div class="rounded-lg border p-4">
        <p class="mb-2 text-sm text-gray-600">屏幕阅读器支持说明</p>
        <div class="space-y-3">
          <HTTag :aria-label="accessibilityLabel" type="primary" round closeable @close="handleClose">
            无障碍标签
          </HTTag>
          <div class="flex flex-wrap gap-2">
            <HTTag v-for="tag in accessibilityTags" :key="tag.label" :aria-label="tag.ariaLabel" :type="tag.type" round>
              {{ tag.label }}
            </HTTag>
          </div>
        </div>
        <p class="mt-2 text-xs text-gray-500">支持键盘导航和屏幕阅读器</p>
      </div>
    </section>
  </div>
</template>

<script setup lang="ts">
import { reactive, ref } from 'vue';
import { HTIcon, HTTag } from '@/components';
import type { TagType } from '@/components/tag/types';

// 可关闭标签数据
const closableTags = reactive([
  { name: 'Vue.js', type: 'success' as TagType },
  { name: 'React', type: 'primary' as TagType },
  { name: 'Angular', type: 'warning' as TagType },
]);

const removeTag = (tag: { name: string; type: TagType }) => {
  const index = closableTags.indexOf(tag);
  if (index > -1) {
    closableTags.splice(index, 1);
  }
};

const addTag = () => {
  const frameworks = ['Next.js', 'Nuxt.js', 'Svelte'];
  const colors: TagType[] = ['primary', 'success', 'warning', 'info'];
  if (closableTags.length < 6) {
    closableTags.push({
      name: frameworks[Math.floor(Math.random() * frameworks.length)]!,
      type: colors[Math.floor(Math.random() * colors.length)]!,
    });
  }
};

// 动态控制
const dynamicTag = reactive({
  show: true,
  type: 'primary' as TagType,
  round: false,
  plain: false,
});

// 计数器
const counter = ref(0);

const incrementCounter = () => counter.value++;
const decrementCounter = () => (counter.value > 0 ? counter.value-- : 0);
const resetCounter = () => (counter.value = 0);

// 响应式类型获取
const getType = (index: number): TagType => {
  const types: TagType[] = ['primary', 'success', 'warning', 'danger', 'info'];
  return types[index % types.length]!;
};

// 无障碍
const accessibilityLabel = ref('这是一个可关闭的标签，可以通过点击关闭按钮来移除');

const accessibilityTags = [
  { label: '状态正常', ariaLabel: '系统状态正常', type: 'success' },
  { label: '需要关注', ariaLabel: '需要关注的警告信息', type: 'warning' },
  { label: '错误状态', ariaLabel: '系统出现错误', type: 'danger' },
];

// 事件处理
const handleClose = (event: MouseEvent) => {
  console.log('标签关闭事件:', event);
};

// Vant API 示例代码
const vantApiExample = `// Vant 兼容的 API
<HTTag
  type="primary"
  size="large"
  round
  plain
  closeable
  color="#1677ff"
  text-color="#ffffff"
  @close="handleClose"
>
  标签内容
</HTTag>

// 完全兼容 Vant 的 props 命名和默认值
// type: default | primary | success | warning | danger | info
// size: small | default | large
// plain: boolean (朴素样式)
// round: boolean (圆角样式)
// mark: boolean (标记样式)
// closeable: boolean (可关闭)
// color: string (自定义颜色)
// show: boolean (显示/隐藏)`;
</script>

<style scoped>
.tag-demo {
  max-width: 1200px;
  margin: 0 auto;
}

/* 使用 Tailwind CSS 为主，配合少量原生 CSS */
input[type='checkbox'] {
  margin: 0;
}

button {
  transition: all 0.2s ease;
}

button:hover {
  transform: translateY(-1px);
}

/* 自定义动画 */
.tag-demo .ht-tag {
  transition: all 0.2s ease;
}

.tag-demo .ht-tag:hover {
  transform: translateY(-1px);
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
}
</style>
