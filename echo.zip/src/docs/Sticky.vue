<template>
  <div class="space-y-4 p-4">
    <HTSticky :offsetTop="0" :zIndex="99">
      <div class="rounded p-2" style="background: var(--color-surface-secondary); color: var(--color-content-primary)">
        我是吸顶 Header（滚动时固定在顶部）
      </div>
    </HTSticky>

    <div class="space-y-2">
      <div v-for="i in 30" :key="i" class="rounded border p-2">内容块 {{ i }}</div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { HTSticky } from '@/components';
</script>
