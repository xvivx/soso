<template>
  <div class="image-demo space-y-8 p-6">
    <h1 class="mb-6 text-2xl font-bold">HTImage 图片组件</h1>

    <p class="mb-6 leading-relaxed text-gray-600">
      基于 shadcn-vue 实现，完全兼容 Vant Image 组件 API
      的图片组件。支持多种填充模式、懒加载、错误处理、自定义状态等功能。
    </p>

    <!-- 基础用法 -->
    <section class="space-y-4">
      <h2 class="text-xl font-semibold">基础用法</h2>
      <div class="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-4">
        <div class="rounded-lg border p-4">
          <h3 class="mb-2 text-sm font-medium">基础图片</h3>
          <HTImage src="https://picsum.photos/200/200" width="200" height="200" alt="基础图片" />
        </div>
        <div class="rounded-lg border p-4">
          <h3 class="mb-2 text-sm font-medium">带文本</h3>
          <HTImage src="https://picsum.photos/150/150" width="150" height="150" alt="带文本图片" />
        </div>
        <div class="rounded-lg border p-4">
          <h3 class="mb-2 text-sm font-medium">响应式</h3>
          <HTImage src="https://picsum.photos/180/120" width="100%" height="auto" alt="响应式图片" />
        </div>
        <div class="rounded-lg border p-4">
          <h3 class="mb-2 text-sm font-medium">正方形</h3>
          <HTImage src="https://picsum.photos/120/120" width="120" height="120" alt="正方形图片" />
        </div>
      </div>
    </section>

    <!-- 填充模式 -->
    <section class="space-y-4">
      <h2 class="text-xl font-semibold">填充模式</h2>
      <div class="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-5">
        <div class="rounded-lg border p-4" v-for="fit in fits" :key="fit">
          <h3 class="mb-2 text-sm font-medium">{{ fit }}</h3>
          <HTImage
            :src="`https://picsum.photos/150/100?random=${fit}`"
            width="150"
            height="100"
            :fit="fit"
            :alt="`fit: ${fit}`"
          />
        </div>
      </div>
    </section>

    <!-- 圆形和圆角 -->
    <section class="space-y-4">
      <h2 class="text-xl font-semibold">圆形和圆角</h2>
      <div class="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-4">
        <div class="rounded-lg border p-4">
          <h3 class="mb-2 text-sm font-medium">默认</h3>
          <HTImage src="https://picsum.photos/100/100" width="100" height="100" alt="默认" />
        </div>
        <div class="rounded-lg border p-4">
          <h3 class="mb-2 text-sm font-medium">圆形 (round)</h3>
          <HTImage src="https://picsum.photos/100/100" width="100" height="100" round alt="圆形" />
        </div>
        <div class="rounded-lg border p-4">
          <h3 class="mb-2 text-sm font-medium">圆形 (variant)</h3>
          <HTImage src="https://picsum.photos/100/100" width="100" height="100" variant="circle" alt="变体圆形" />
        </div>
        <div class="rounded-lg border p-4">
          <h3 class="mb-2 text-sm font-medium">圆角 (radius)</h3>
          <HTImage src="https://picsum.photos/100/100" width="100" height="100" :radius="12" alt="圆角" />
        </div>
      </div>
    </section>

    <!-- 状态控制 -->
    <section class="space-y-4">
      <h2 class="text-xl font-semibold">加载和错误状态</h2>
      <div class="grid grid-cols-1 gap-4 md:grid-cols-2">
        <div class="rounded-lg border p-4">
          <h3 class="mb-2 text-sm font-medium">加载状态</h3>
          <HTImage src="https://picsum.photos/150/150" width="150" height="150" :show-loading="true" alt="加载状态" />
        </div>
        <div class="rounded-lg border p-4">
          <h3 class="mb-2 text-sm font-medium">错误状态</h3>
          <HTImage src="https://invalid-url.com/error.jpg" width="150" height="150" :show-error="true" alt="错误状态" />
        </div>
        <div class="rounded-lg border p-4">
          <h3 class="mb-2 text-sm font-medium">自定义加载</h3>
          <HTImage src="https://picsum.photos/150/150" width="150" height="150" :show-loading="true" alt="自定义加载">
            <template #loading>
              <div class="custom-loading">
                <div class="loading-spinner"></div>
                <p>自定义加载中...</p>
              </div>
            </template>
          </HTImage>
        </div>
        <div class="rounded-lg border p-4">
          <h3 class="mb-2 text-sm font-medium">自定义错误</h3>
          <HTImage src="https://invalid-url.com/error.jpg" width="150" height="150" :show-error="true" alt="自定义错误">
            <template #error>
              <div class="custom-error">
                <p>😔</p>
                <p>图片加载失败</p>
              </div>
            </template>
          </HTImage>
        </div>
      </div>
    </section>

    <!-- 懒加载 -->
    <section class="space-y-4">
      <h2 class="text-xl font-semibold">懒加载</h2>
      <div class="grid grid-cols-1 gap-4 md:grid-cols-2">
        <div class="rounded-lg border p-4">
          <h3 class="mb-2 text-sm font-medium">懒加载图片</h3>
          <HTImage src="https://picsum.photos/200/200" width="200" height="200" :lazy-load="true" alt="懒加载图片" />
        </div>
        <div class="rounded-lg border p-4">
          <h3 class="mb-2 text-sm font-medium">自定义占位符</h3>
          <HTImage src="https://picsum.photos/200/200" width="200" height="200" :lazy-load="true" alt="自定义占位符">
            <template #placeholder>
              <div class="lazy-placeholder">
                <p>📷</p>
                <p>点击加载图片</p>
              </div>
            </template>
          </HTImage>
        </div>
      </div>
    </section>

    <!-- 定位控制 -->
    <section class="space-y-4">
      <h2 class="text-xl font-semibold">定位控制</h2>
      <div class="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-5">
        <div class="rounded-lg border p-4" v-for="position in positions" :key="position">
          <h3 class="mb-2 text-sm font-medium">{{ position }}</h3>
          <HTImage
            :src="`https://picsum.photos/150/100?random=${position}`"
            width="150"
            height="100"
            fit="cover"
            :position="position"
            :alt="`position: ${position}`"
          />
        </div>
      </div>
    </section>

    <!-- Vant API 兼容性演示 -->
    <section class="space-y-4">
      <h2 class="text-xl font-semibold">Vant API 兼容性</h2>
      <div class="rounded-lg border bg-gray-50 p-4">
        <h3 class="mb-2 text-sm font-medium">完全兼容 Vant Image API</h3>
        <pre class="overflow-x-auto rounded border bg-white p-2 text-xs"><code>{{ vantApiExample }}</code></pre>
      </div>
    </section>

    <!-- 事件演示 -->
    <section class="space-y-4">
      <h2 class="text-xl font-semibold">事件处理</h2>
      <div class="grid grid-cols-1 gap-4 md:grid-cols-2">
        <div class="rounded-lg border p-4">
          <h3 class="mb-2 text-sm font-medium">事件监听</h3>
          <HTImage
            src="https://picsum.photos/150/150"
            width="150"
            height="150"
            alt="事件演示"
            @load="handleLoad"
            @error="handleError"
            @click="handleClick"
          />
          <div class="mt-4 text-xs">
            <p class="mb-1">事件日志:</p>
            <div v-for="(log, index) in eventLogs.slice(0, 3)" :key="index" class="text-gray-600">
              {{ log }}
            </div>
          </div>
        </div>
        <div class="rounded-lg border p-4">
          <h3 class="mb-2 text-sm font-medium">状态检查</h3>
          <div class="space-y-2 text-sm">
            <div class="flex justify-between">
              <span>加载中:</span>
              <span :class="loading ? 'text-blue-500' : 'text-gray-400'">{{ loading ? '是' : '否' }}</span>
            </div>
            <div class="flex justify-between">
              <span>已加载:</span>
              <span :class="loaded ? 'text-green-500' : 'text-gray-400'">{{ loaded ? '是' : '否' }}</span>
            </div>
            <div class="flex justify-between">
              <span>错误:</span>
              <span :class="error ? 'text-red-500' : 'text-gray-400'">{{ error ? '是' : '否' }}</span>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- 响应式测试 -->
    <section class="space-y-4">
      <h2 class="text-xl font-semibold">响应式测试</h2>
      <div class="rounded-lg border p-4">
        <p class="mb-2 text-sm text-gray-600">调整浏览器大小查看响应式效果</p>
        <div class="w-full max-w-md">
          <HTImage src="https://picsum.photos/400/300" width="100%" height="auto" fit="cover" alt="响应式图片" />
        </div>
      </div>
    </section>

    <!-- 无障碍演示 -->
    <section class="space-y-4">
      <h2 class="text-xl font-semibold">无障碍支持</h2>
      <div class="rounded-lg border p-4">
        <p class="mb-2 text-sm text-gray-600">屏幕阅读器支持说明</p>
        <HTImage
          src="https://picsum.photos/200/150"
          width="200"
          height="150"
          alt="一张美丽的风景图片，展示了山川和湖泊"
          role="img"
        />
        <p class="mt-2 text-xs text-gray-500">支持键盘导航和屏幕阅读器</p>
      </div>
    </section>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import { HTImage } from '@/components';

// 演示数据
const fits: ('fill' | 'contain' | 'cover' | 'none' | 'scale-down')[] = [
  'fill',
  'contain',
  'cover',
  'none',
  'scale-down',
];

const positions: ('top' | 'bottom' | 'left' | 'right' | 'center')[] = ['top', 'bottom', 'left', 'right', 'center'];

// 事件日志
const eventLogs = ref<string[]>([]);

// 状态演示
const loading = ref(false);
const loaded = ref(false);
const error = ref(false);

const addLog = (message: string) => {
  const time = new Date().toLocaleTimeString();
  eventLogs.value.unshift(`${time}: ${message}`);
  if (eventLogs.value.length > 10) {
    eventLogs.value.pop();
  }
};

// 事件处理
const handleLoad = (event: Event) => {
  loading.value = false;
  loaded.value = true;
  error.value = false;
  addLog('图片加载成功');
  console.log('图片加载成功:', event);
};

const handleError = (event: Event) => {
  loading.value = false;
  loaded.value = false;
  error.value = true;
  addLog('图片加载失败');
  console.log('图片加载失败:', event);
};

const handleClick = (event: Event) => {
  addLog('图片被点击');
  console.log('图片被点击:', event);
};

// Vant API 示例代码
const vantApiExample = `// Vant 兼容的 API
<HTImage
  src="https://example.com/image.jpg"
  width="200"
  height="200"
  fit="cover"
  round
  :lazy-load="true"
  :show-error="true"
  :show-loading="true"
  @load="handleLoad"
  @error="handleError"
  @click="handleClick"
  alt="示例图片"
/>

// 完全兼容 Vant 的 props 命名和默认值
// 支持 src, alt, fit, position, width, height
// 支持 round, radius, block, lazy-load
// 支持 show-error, show-loading, icon-size
// 支持 error-icon, loading-icon, icon-prefix
// 支持 crossorigin, referrerpolicy, decoding`;
</script>

<style scoped>
.image-demo {
  max-width: 1200px;
  margin: 0 auto;
}

/* 自定义加载样式 */
.custom-loading {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  height: 100%;
  background: linear-gradient(45deg, #f3f4f6, #e5e7eb);
}

.loading-spinner {
  width: 24px;
  height: 24px;
  border: 2px solid #d1d5db;
  border-top: 2px solid #3b82f6;
  border-radius: 50%;
  animation: spin 1s linear infinite;
  margin-bottom: 8px;
}

@keyframes spin {
  0% {
    transform: rotate(0deg);
  }
  100% {
    transform: rotate(360deg);
  }
}

.custom-loading p {
  font-size: 12px;
  color: #6b7280;
  margin: 0;
}

.custom-loading p {
  font-size: 12px;
  color: #6b7280;
  margin: 0;
}

/* 自定义错误样式 */
.custom-error {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  height: 100%;
  background: #fef2f2;
  color: #dc2626;
}

.custom-error p:first-child {
  font-size: 24px;
  margin: 0 0 8px 0;
}

.custom-error p:last-child {
  font-size: 12px;
  margin: 0;
}

/* 懒加载占位符样式 */
.lazy-placeholder {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  height: 100%;
  background: #f5f5f5;
  color: #999;
}

.lazy-placeholder p:first-child {
  font-size: 32px;
  margin: 0;
}

.lazy-placeholder p:last-child {
  font-size: 14px;
  margin: 8px 0 0 0;
}

/* Tailwind CSS 类 */
.grid {
  display: grid;
}

.grid-cols-1 {
  grid-template-columns: repeat(1, minmax(0, 1fr));
}

@media (min-width: 768px) {
  .md\:grid-cols-2 {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }
}

@media (min-width: 1024px) {
  .lg\:grid-cols-4 {
    grid-template-columns: repeat(4, minmax(0, 1fr));
  }

  .lg\:grid-cols-5 {
    grid-template-columns: repeat(5, minmax(0, 1fr));
  }
}

.gap-4 {
  gap: 1rem;
}

.p-4,
.p-6 {
  padding: 1rem / 1.5rem;
}

.border {
  border-width: 1px;
  border-color: #e5e7eb;
}

.rounded-lg {
  border-radius: 0.5rem;
}

.space-y-4 > :not([hidden]) ~ :not([hidden]) {
  margin-top: 1rem;
}

.space-y-8 > :not([hidden]) ~ :not([hidden]) {
  margin-top: 2rem;
}

.text-2xl,
.text-xl,
.text-sm {
  font-size: 1.5rem / 1.25rem / 0.875rem;
  line-height: 2rem / 1.75rem / 1.25rem;
}

.font-bold,
.font-semibold,
.font-medium {
  font-weight: 700 / 600 / 500;
}

.mb-2,
.mb-6,
.mt-2,
.mt-4 {
  margin-bottom: 0.5rem / 1.5rem;
  margin-top: 0.5rem / 1rem;
}

.bg-gray-50,
.bg-white {
  background-color: #f9fafb / #ffffff;
}

.text-gray-600,
.text-gray-500,
.text-gray-400 {
  color: #4b5563 / #6b7280 / #9ca3af;
}

.text-blue-500,
.text-green-500,
.text-red-500 {
  color: #3b82f6 / #10b981 / #ef4444;
}

.overflow-x-auto {
  overflow-x: auto;
}

.text-xs {
  font-size: 0.75rem;
  line-height: 1rem;
}

.max-w-md {
  max-width: 28rem;
}

@media (min-width: 1024px) {
  .lg\:grid-cols-4 {
    grid-template-columns: repeat(4, minmax(0, 1fr));
  }

  .lg\:grid-cols-5 {
    grid-template-columns: repeat(5, minmax(0, 1fr));
  }
}

.gap-4 {
  gap: 1rem;
}

.p-4,
.p-6 {
  padding: 1rem / 1.5rem;
}

.border {
  border-width: 1px;
  border-color: #e5e7eb;
}

.rounded-lg {
  border-radius: 0.5rem;
}

.space-y-4 > :not([hidden]) ~ :not([hidden]) {
  margin-top: 1rem;
}

.space-y-8 > :not([hidden]) ~ :not([hidden]) {
  margin-top: 2rem;
}

.text-2xl,
.text-xl,
.text-sm {
  font-size: 1.5rem / 1.25rem / 0.875rem;
  line-height: 2rem / 1.75rem / 1.25rem;
}

.font-bold,
.font-semibold,
.font-medium {
  font-weight: 700 / 600 / 500;
}

.mb-2,
.mb-6,
.mt-2,
.mt-4 {
  margin-bottom: 0.5rem / 1.5rem;
  margin-top: 0.5rem / 1rem;
}

.bg-gray-50,
.bg-white {
  background-color: #f9fafb / #ffffff;
}

.text-gray-600,
.text-gray-500,
.text-gray-400 {
  color: #4b5563 / #6b7280 / #9ca3af;
}

.text-blue-500,
.text-green-500,
.text-red-500 {
  color: #3b82f6 / #10b981 / #ef4444;
}

.overflow-x-auto {
  overflow-x: auto;
}

.text-xs {
  font-size: 0.75rem;
  line-height: 1rem;
}

.max-w-md {
  max-width: 28rem;
}
</style>
