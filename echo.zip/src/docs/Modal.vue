<template>
  <div class="flex gap-4">
    <HTButton theme="primary" plain @click="show = !show">通过状态打开</HTButton>
    <HTButton theme="primary" plain @click="showDetail">通过方法打开</HTButton>
  </div>
  <HTModal v-model:show="show">
    <template #title>{{ mock('@title') }}</template>
    <div>{{ mock('@paragraph') }}</div>
  </HTModal>
</template>

<script setup lang="tsx">
import { ref } from 'vue';
import { mock } from 'mockjs';
import { HTButton, HTModal } from '@/components';

const show = ref(false);
const showDetail = () => {
  HTModal.showModal({
    title: mock('@title'),
    children: <div>{mock('@paragraph')}</div>,
  });
};
</script>
