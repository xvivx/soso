<template>
  <div class="tabs-demo">
    <!-- 页面标题 -->
    <header class="demo-header">
      <h1 class="demo-title">HTTabs 标签页组件</h1>
      <p class="demo-description">完全兼容 Vant Tabs API 的标签页组件，支持多种样式和交互方式</p>
    </header>

    <!-- 基础用法 -->
    <section class="demo-section">
      <h2 class="section-title">基础用法</h2>
      <div class="demo-grid">
        <div class="demo-item">
          <h3 class="item-title">基础标签页</h3>
          <HTTabs v-model:active="active1">
            <HTTab title="标签 1" name="tab1">
              <div class="demo-content">内容 1</div>
            </HTTab>
            <HTTab title="标签 2" name="tab2">
              <div class="demo-content">内容 2</div>
            </HTTab>
            <HTTab title="标签 3" name="tab3">
              <div class="demo-content">内容 3</div>
            </HTTab>
            <HTTab title="标签 4" name="tab4">
              <div class="demo-content">内容 4</div>
            </HTTab>
          </HTTabs>
        </div>

        <div class="demo-item">
          <h3 class="item-title">卡片类型</h3>
          <HTTabs v-model:active="active2" type="card">
            <HTTab title="标签 1" name="tab1">
              <div class="demo-content">卡片内容 1</div>
            </HTTab>
            <HTTab title="标签 2" name="tab2">
              <div class="demo-content">卡片内容 2</div>
            </HTTab>
            <HTTab title="标签 3" name="tab3">
              <div class="demo-content">卡片内容 3</div>
            </HTTab>
          </HTTabs>
        </div>
      </div>
    </section>

    <!-- 功能特性 -->
    <section class="demo-section">
      <h2 class="section-title">功能特性</h2>
      <div class="demo-grid">
        <div class="demo-item">
          <h3 class="item-title">徽章和红点</h3>
          <HTTabs v-model:active="active3">
            <HTTab title="标签 1" badge="5">
              <div class="demo-content">带徽章的内容</div>
            </HTTab>
            <HTTab title="标签 2" dot>
              <div class="demo-content">带红点的内容</div>
            </HTTab>
            <HTTab title="标签 3">
              <div class="demo-content">普通内容</div>
            </HTTab>
          </HTTabs>
        </div>

        <div class="demo-item">
          <h3 class="item-title">禁用标签</h3>
          <HTTabs v-model:active="active4">
            <HTTab title="标签 1">
              <div class="demo-content">内容 1</div>
            </HTTab>
            <HTTab title="标签 2" disabled>
              <div class="demo-content">内容 2（禁用）</div>
            </HTTab>
            <HTTab title="标签 3">
              <div class="demo-content">内容 3</div>
            </HTTab>
          </HTTabs>
        </div>

        <div class="demo-item">
          <h3 class="item-title">点击事件</h3>
          <HTTabs v-model:active="active8" @click-tab="onClickTab">
            <HTTab title="标签 1">
              <div class="demo-content">内容 1</div>
            </HTTab>
            <HTTab title="标签 2">
              <div class="demo-content">内容 2</div>
            </HTTab>
            <HTTab title="标签 3">
              <div class="demo-content">内容 3</div>
            </HTTab>
          </HTTabs>
          <div class="demo-message">{{ message }}</div>
        </div>

        <div class="demo-item">
          <h3 class="item-title">收缩布局</h3>
          <HTTabs v-model:active="active6" shrink>
            <HTTab title="标签 1">
              <div class="demo-content">内容 1</div>
            </HTTab>
            <HTTab title="标签 2">
              <div class="demo-content">内容 2</div>
            </HTTab>
            <HTTab title="标签 3">
              <div class="demo-content">内容 3</div>
            </HTTab>
            <HTTab title="标签 4">
              <div class="demo-content">内容 4</div>
            </HTTab>
            <HTTab title="标签 5">
              <div class="demo-content">内容 5</div>
            </HTTab>
            <HTTab title="标签 6">
              <div class="demo-content">内容 6</div>
            </HTTab>
          </HTTabs>
        </div>
      </div>
    </section>

    <!-- 样式定制 -->
    <section class="demo-section">
      <h2 class="section-title">样式定制</h2>
      <div class="demo-grid">
        <div class="demo-item">
          <h3 class="item-title">自定义颜色</h3>
          <HTTabs v-model:active="active5" color="#07c160">
            <HTTab title="标签 1">
              <div class="demo-content">绿色主题</div>
            </HTTab>
            <HTTab title="标签 2">
              <div class="demo-content">绿色主题</div>
            </HTTab>
            <HTTab title="标签 3">
              <div class="demo-content">绿色主题</div>
            </HTTab>
          </HTTabs>
        </div>

        <div class="demo-item">
          <h3 class="item-title">自定义标题颜色</h3>
          <HTTabs v-model:active="active13" title-active-color="#ee0a24" title-inactive-color="#999" color="#ee0a24">
            <HTTab title="标签 1">
              <div class="demo-content">红色主题</div>
            </HTTab>
            <HTTab title="标签 2">
              <div class="demo-content">红色主题</div>
            </HTTab>
            <HTTab title="标签 3">
              <div class="demo-content">红色主题</div>
            </HTTab>
          </HTTabs>
        </div>

        <div class="demo-item">
          <h3 class="item-title">带边框</h3>
          <HTTabs v-model:active="active14" type="line" border>
            <HTTab title="标签 1">
              <div class="demo-content">带边框样式</div>
            </HTTab>
            <HTTab title="标签 2">
              <div class="demo-content">带边框样式</div>
            </HTTab>
            <HTTab title="标签 3">
              <div class="demo-content">带边框样式</div>
            </HTTab>
          </HTTabs>
        </div>

        <div class="demo-item">
          <h3 class="item-title">自定义指示器</h3>
          <HTTabs v-model:active="active15" color="#1989fa" :line-width="60" :line-height="4">
            <HTTab title="标签 1">
              <div class="demo-content">自定义指示器</div>
            </HTTab>
            <HTTab title="标签 2">
              <div class="demo-content">自定义指示器</div>
            </HTTab>
            <HTTab title="标签 3">
              <div class="demo-content">自定义指示器</div>
            </HTTab>
          </HTTabs>
        </div>
      </div>
    </section>

    <!-- 高级特性 -->
    <section class="demo-section">
      <h2 class="section-title">高级特性</h2>
      <div class="demo-grid">
        <div class="demo-item">
          <h3 class="item-title">滚动标签</h3>
          <HTTabs v-model:active="active7" :swipe-threshold="3">
            <HTTab v-for="i in 10" :key="i" :title="`标签 ${i}`">
              <div class="demo-content">内容 {{ i }}</div>
            </HTTab>
          </HTTabs>
        </div>

        <div class="demo-item">
          <h3 class="item-title">滑动切换</h3>
          <HTTabs v-model:active="active10" swipeable>
            <HTTab title="标签 1">
              <div class="demo-content">左右滑动切换</div>
            </HTTab>
            <HTTab title="标签 2">
              <div class="demo-content">左右滑动切换</div>
            </HTTab>
            <HTTab title="标签 3">
              <div class="demo-content">左右滑动切换</div>
            </HTTab>
            <HTTab title="标签 4">
              <div class="demo-content">左右滑动切换</div>
            </HTTab>
          </HTTabs>
        </div>

        <div class="demo-item">
          <h3 class="item-title">动画切换</h3>
          <HTTabs v-model:active="active11" animated>
            <HTTab title="标签 1">
              <div class="demo-content">带切换动画</div>
            </HTTab>
            <HTTab title="标签 2">
              <div class="demo-content">带切换动画</div>
            </HTTab>
            <HTTab title="标签 3">
              <div class="demo-content">带切换动画</div>
            </HTTab>
          </HTTabs>
        </div>

        <div class="demo-item">
          <h3 class="item-title">滑动 + 动画</h3>
          <HTTabs v-model:active="active12" swipeable animated :duration="0.5">
            <HTTab title="标签 1">
              <div class="demo-content">滑动+动画</div>
            </HTTab>
            <HTTab title="标签 2">
              <div class="demo-content">滑动+动画</div>
            </HTTab>
            <HTTab title="标签 3">
              <div class="demo-content">滑动+动画</div>
            </HTTab>
            <HTTab title="标签 4">
              <div class="demo-content">滑动+动画</div>
            </HTTab>
          </HTTabs>
        </div>
      </div>
    </section>

    <!-- 粘性定位 -->
    <section class="demo-section">
      <h2 class="section-title">粘性定位</h2>
      <div class="demo-sticky-container">
        <HTTabs v-model:active="active9" sticky :offset-top="50">
          <HTTab title="标签 1">
            <div class="demo-content demo-content--tall">内容 1（向下滚动查看粘性效果）</div>
          </HTTab>
          <HTTab title="标签 2">
            <div class="demo-content demo-content--tall">内容 2（向下滚动查看粘性效果）</div>
          </HTTab>
          <HTTab title="标签 3">
            <div class="demo-content demo-content--tall">内容 3（向下滚动查看粘性效果）</div>
          </HTTab>
          <HTTab title="标签 4">
            <div class="demo-content demo-content--tall">内容 4（向下滚动查看粘性效果）</div>
          </HTTab>
        </HTTabs>
      </div>
    </section>

    <!-- Vant API 兼容性说明 -->
    <section class="demo-section">
      <h2 class="section-title">Vant API 兼容性</h2>
      <div class="compatibility-info">
        <h3>✅ 完全兼容的 Vant Tabs API</h3>
        <ul class="compatibility-list">
          <li><code>type</code> - 支持 line、card 类型</li>
          <li><code>color</code> - 自定义主题色</li>
          <li><code>swipeable</code> - 手势滑动切换</li>
          <li><code>animated</code> - 切换动画</li>
          <li><code>sticky</code> - 粘性定位</li>
          <li><code>border</code> - 边框显示</li>
          <li><code>shrink</code> - 收缩布局</li>
          <li><code>ellipsis</code> - 标题省略</li>
          <li><code>swipeThreshold</code> - 滚动阈值</li>
          <li><code>beforeChange</code> - 切换前钩子</li>
          <li>所有事件（clickTab、change、scroll、rendered）</li>
          <li>所有插槽（default、nav-left、nav-right）</li>
        </ul>
      </div>
    </section>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import { HTTab, HTTabs } from '@/components/tabs';

// 响应式数据
const active1 = ref('tab1');
const active2 = ref('tab1');
const active3 = ref(0);
const active4 = ref(0);
const active5 = ref(0);
const active6 = ref(0);
const active7 = ref(0);
const active8 = ref(0);
const active9 = ref(0);
const active10 = ref(0);
const active11 = ref(0);
const active12 = ref(0);
const active13 = ref(0);
const active14 = ref(0);
const active15 = ref(0);
const message = ref('');

// 事件处理
const onClickTab = ({ name, title }: { name: string | number; title: string }) => {
  message.value = `点击了 ${title}，name 为 ${name}`;
  console.log('标签点击事件:', { name, title });
};
</script>

<style scoped>
.tabs-demo {
  max-width: 1200px;
  margin: 0 auto;
  padding: 24px;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
}

/* 页面标题 */
.demo-header {
  text-align: center;
  margin-bottom: 48px;
  padding-bottom: 24px;
  border-bottom: 2px solid #f0f0f0;
}

.demo-title {
  margin: 0 0 16px 0;
  font-size: 32px;
  font-weight: 700;
  color: #1a1a1a;
  line-height: 1.2;
}

.demo-description {
  margin: 0;
  font-size: 16px;
  color: #666;
  line-height: 1.6;
  max-width: 600px;
  margin: 0 auto;
}

/* 区块样式 */
.demo-section {
  margin-bottom: 56px;
}

.section-title {
  margin: 0 0 24px 0;
  font-size: 24px;
  font-weight: 600;
  color: #1a1a1a;
  position: relative;
  padding-left: 16px;
}

.section-title::before {
  content: '';
  position: absolute;
  left: 0;
  top: 4px;
  bottom: 4px;
  width: 4px;
  background: #1890ff;
  border-radius: 2px;
}

/* 网格布局 */
.demo-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(360px, 1fr));
  gap: 24px;
}

/* 单个演示项 */
.demo-item {
  background: #fff;
  border: 1px solid #e8e8e8;
  border-radius: 12px;
  padding: 20px;
  transition: all 0.3s ease;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.06);
}

.demo-item:hover {
  border-color: #1890ff;
  box-shadow: 0 4px 16px rgba(24, 144, 255, 0.12);
  transform: translateY(-2px);
}

.item-title {
  margin: 0 0 16px 0;
  font-size: 16px;
  font-weight: 600;
  color: #262626;
}

/* 内容区域 */
.demo-content {
  padding: 24px;
  text-align: center;
  color: #666;
  background: #fafafa;
  border-radius: 8px;
  min-height: 80px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 14px;
  line-height: 1.5;
  border: 1px dashed #d9d9d9;
  transition: all 0.3s ease;
}

.demo-content:hover {
  background: #f0f9ff;
  border-color: #91d5ff;
  color: #1890ff;
}

/* 消息提示 */
.demo-message {
  margin-top: 12px;
  padding: 12px 16px;
  color: #1890ff;
  font-size: 14px;
  background: #e6f7ff;
  border: 1px solid #91d5ff;
  border-radius: 6px;
  animation: slideInUp 0.3s ease;
}

/* 粘性定位容器 */
.demo-sticky-container {
  height: 400px;
  overflow-y: auto;
  background: #f5f5f5;
  padding: 20px;
  border-radius: 12px;
  border: 1px solid #e8e8e8;
}

.demo-content--tall {
  min-height: 300px;
  background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 16px;
  font-weight: 500;
  color: #333;
}

/* 兼容性信息 */
.compatibility-info {
  background: #f6ffed;
  border: 1px solid #b7eb8f;
  border-radius: 12px;
  padding: 24px;
}

.compatibility-info h3 {
  margin: 0 0 16px 0;
  font-size: 18px;
  font-weight: 600;
  color: #389e0d;
}

.compatibility-list {
  margin: 0;
  padding: 0 0 0 20px;
  list-style: none;
}

.compatibility-list li {
  margin-bottom: 8px;
  font-size: 14px;
  color: #52c41a;
  position: relative;
  padding-left: 20px;
}

.compatibility-list li::before {
  content: '✓';
  position: absolute;
  left: 0;
  color: #52c41a;
  font-weight: bold;
}

.compatibility-list code {
  padding: 2px 6px;
  background: #fff;
  border: 1px solid #d9d9d9;
  border-radius: 4px;
  font-family: 'SFMono-Regular', Consolas, 'Liberation Mono', Menlo, monospace;
  font-size: 12px;
  color: #1890ff;
}

/* 动画效果 */
@keyframes slideInUp {
  from {
    transform: translateY(10px);
    opacity: 0;
  }
  to {
    transform: translateY(0);
    opacity: 1;
  }
}

/* 响应式设计 */
@media (max-width: 768px) {
  .tabs-demo {
    padding: 16px;
  }

  .demo-header {
    margin-bottom: 32px;
  }

  .demo-title {
    font-size: 24px;
  }

  .demo-description {
    font-size: 14px;
  }

  .section-title {
    font-size: 20px;
    margin-bottom: 16px;
  }

  .demo-grid {
    grid-template-columns: 1fr;
    gap: 16px;
  }

  .demo-item {
    padding: 16px;
  }

  .demo-content {
    padding: 16px;
    min-height: 60px;
    font-size: 13px;
  }

  .demo-sticky-container {
    height: 300px;
    padding: 16px;
  }

  .demo-content--tall {
    min-height: 200px;
    font-size: 14px;
  }

  .compatibility-info {
    padding: 16px;
  }

  .compatibility-info h3 {
    font-size: 16px;
  }

  .compatibility-list li {
    font-size: 13px;
  }
}

@media (max-width: 480px) {
  .tabs-demo {
    padding: 12px;
  }

  .demo-item {
    padding: 12px;
  }

  .demo-content {
    padding: 12px;
    min-height: 50px;
    font-size: 12px;
  }

  .demo-message {
    font-size: 13px;
    padding: 10px 12px;
  }
}

/* 深色模式支持 */
@media (prefers-color-scheme: dark) {
  .tabs-demo {
    background: #141414;
    color: #fff;
  }

  .demo-header {
    border-bottom-color: #434343;
  }

  .demo-title {
    color: #fff;
  }

  .demo-description {
    color: #a6a6a6;
  }

  .section-title {
    color: #fff;
  }

  .demo-item {
    background: #1f1f1f;
    border-color: #434343;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2);
  }

  .demo-item:hover {
    border-color: #1890ff;
    box-shadow: 0 4px 16px rgba(24, 144, 255, 0.2);
  }

  .item-title {
    color: #fff;
  }

  .demo-content {
    background: #262626;
    border-color: #434343;
    color: #a6a6a6;
  }

  .demo-content:hover {
    background: #001529;
    border-color: #1890ff;
    color: #1890ff;
  }

  .demo-sticky-container {
    background: #1f1f1f;
    border-color: #434343;
  }

  .demo-content--tall {
    background: linear-gradient(135deg, #262626 0%, #434343 100%);
    color: #fff;
  }

  .compatibility-info {
    background: #162312;
    border-color: #274916;
  }

  .compatibility-info h3 {
    color: #52c41a;
  }

  .compatibility-list li {
    color: #52c41a;
  }

  .compatibility-list code {
    background: #1f1f1f;
    border-color: #434343;
    color: #1890ff;
  }
}

.demo-content:hover {
  background: #f0f9ff;
  border-color: #91d5ff;
  color: #1890ff;
}

/* 消息提示 */
.demo-message {
  margin-top: 12px;
  padding: 12px 16px;
  color: #1890ff;
  font-size: 14px;
  background: #e6f7ff;
  border: 1px solid #91d5ff;
  border-radius: 6px;
  animation: slideInUp 0.3s ease;
}

/* 粘性定位容器 */
.demo-sticky-container {
  height: 400px;
  overflow-y: auto;
  background: #f5f5f5;
  padding: 20px;
  border-radius: 12px;
  border: 1px solid #e8e8e8;
}

.demo-content--tall {
  min-height: 300px;
  background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 16px;
  font-weight: 500;
  color: #333;
}

/* 兼容性信息 */
.compatibility-info {
  background: #f6ffed;
  border: 1px solid #b7eb8f;
  border-radius: 12px;
  padding: 24px;
}

.compatibility-info h3 {
  margin: 0 0 16px 0;
  font-size: 18px;
  font-weight: 600;
  color: #389e0d;
}

.compatibility-list {
  margin: 0;
  padding: 0 0 0 20px;
  list-style: none;
}

.compatibility-list li {
  margin-bottom: 8px;
  font-size: 14px;
  color: #52c41a;
  position: relative;
  padding-left: 20px;
}

.compatibility-list li::before {
  content: '✓';
  position: absolute;
  left: 0;
  color: #52c41a;
  font-weight: bold;
}

.compatibility-list code {
  padding: 2px 6px;
  background: #fff;
  border: 1px solid #d9d9d9;
  border-radius: 4px;
  font-family: 'SFMono-Regular', Consolas, 'Liberation Mono', Menlo, monospace;
  font-size: 12px;
  color: #1890ff;
}

/* 动画效果 */
@keyframes slideInUp {
  from {
    transform: translateY(10px);
    opacity: 0;
  }
  to {
    transform: translateY(0);
    opacity: 1;
  }
}

/* 响应式设计 */
@media (max-width: 768px) {
  .tabs-demo {
    padding: 16px;
  }

  .demo-header {
    margin-bottom: 32px;
  }

  .demo-title {
    font-size: 24px;
  }

  .demo-description {
    font-size: 14px;
  }

  .section-title {
    font-size: 20px;
    margin-bottom: 16px;
  }

  .demo-grid {
    grid-template-columns: 1fr;
    gap: 16px;
  }

  .demo-item {
    padding: 16px;
  }

  .demo-content {
    padding: 16px;
    min-height: 60px;
    font-size: 13px;
  }

  .demo-sticky-container {
    height: 300px;
    padding: 16px;
  }

  .demo-content--tall {
    min-height: 200px;
    font-size: 14px;
  }

  .compatibility-info {
    padding: 16px;
  }

  .compatibility-info h3 {
    font-size: 16px;
  }

  .compatibility-list li {
    font-size: 13px;
  }
}

@media (max-width: 480px) {
  .tabs-demo {
    padding: 12px;
  }

  .demo-item {
    padding: 12px;
  }

  .demo-content {
    padding: 12px;
    min-height: 50px;
    font-size: 12px;
  }

  .demo-message {
    font-size: 13px;
    padding: 10px 12px;
  }
}

/* 深色模式支持 */
@media (prefers-color-scheme: dark) {
  .tabs-demo {
    background: #141414;
    color: #fff;
  }

  .demo-header {
    border-bottom-color: #434343;
  }

  .demo-title {
    color: #fff;
  }

  .demo-description {
    color: #a6a6a6;
  }

  .section-title {
    color: #fff;
  }

  .demo-item {
    background: #1f1f1f;
    border-color: #434343;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2);
  }

  .demo-item:hover {
    border-color: #1890ff;
    box-shadow: 0 4px 16px rgba(24, 144, 255, 0.2);
  }

  .item-title {
    color: #fff;
  }

  .demo-content {
    background: #262626;
    border-color: #434343;
    color: #a6a6a6;
  }

  .demo-content:hover {
    background: #001529;
    border-color: #1890ff;
    color: #1890ff;
  }

  .demo-sticky-container {
    background: #1f1f1f;
    border-color: #434343;
  }

  .demo-content--tall {
    background: linear-gradient(135deg, #262626 0%, #434343 100%);
    color: #fff;
  }

  .compatibility-info {
    background: #162312;
    border-color: #274916;
  }

  .compatibility-info h3 {
    color: #52c41a;
  }

  .compatibility-list li {
    color: #52c41a;
  }

  .compatibility-list code {
    background: #1f1f1f;
    border-color: #434343;
    color: #1890ff;
  }
}
</style>
