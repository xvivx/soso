<template>
  <div class="space-y-4 p-4">
    <HTCellGroup title="默认容器" border>
      <HTCell title="单元格 A" value="内容 A" />
      <HTCell title="单元格 B" value="内容 B" />
    </HTCellGroup>

    <HTCellGroup title="卡片容器（inset）" border inset>
      <HTCell title="单元格 C" label="卡片内容" value="内容 C" />
      <HTCell title="单元格 D" value="内容 D" />
    </HTCellGroup>
  </div>
</template>

<script setup lang="ts">
import { HTCell, HTCellGroup } from '@/components';
</script>
