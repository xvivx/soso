<template>
  <div class="space-y-4 p-4">
    <HTCellGroup title="基础用法" border>
      <HTCell title="单元格" value="内容" />
      <HTCell title="带描述" label="描述信息" />
      <HTCell title="可点击" value="查看详情" isLink clickable required />
    </HTCellGroup>

    <HTCellGroup title="大号尺寸" border>
      <HTCell size="large" title="单元格" value="内容" />
      <HTCell size="large" title="带描述" label="更大字号" />
    </HTCellGroup>
  </div>
</template>

<script setup lang="ts">
import { HTCell, HTCellGroup } from '@/components';
</script>
