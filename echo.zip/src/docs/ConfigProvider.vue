<template>
  <div class="config-provider-demo">
    <h1>ConfigProvider 演示</h1>

    <div class="demo-section">
      <h2>基础用法</h2>
      <HTConfigProvider theme="light">
        <div class="demo-content">
          <HTButton type="primary">默认主题按钮</HTButton>
          <HTButton type="success">成功按钮</HTButton>
        </div>
      </HTConfigProvider>
    </div>

    <div class="demo-section">
      <h2>深色模式</h2>
      <HTConfigProvider theme="dark">
        <div class="demo-content dark">
          <HTButton type="primary">深色模式按钮</HTButton>
          <HTButton type="success">深色成功按钮</HTButton>
        </div>
      </HTConfigProvider>
    </div>

    <div class="demo-section">
      <h2>自定义主题变量</h2>
      <HTConfigProvider :theme-vars="customThemeVars">
        <div class="demo-content">
          <HTButton type="primary">自定义主色按钮</HTButton>
          <HTButton type="success">自定义成功按钮</HTButton>
        </div>
      </HTConfigProvider>
    </div>

    <div class="demo-section">
      <h2>动态主题切换</h2>
      <div class="controls">
        <HTButton @click="toggleTheme">切换主题</HTButton>
        <HTButton @click="randomPrimaryColor">随机主色</HTButton>
      </div>

      <HTConfigProvider :theme="currentTheme" :theme-vars="dynamicThemeVars">
        <div class="demo-content">
          <HTButton type="primary">动态主题按钮</HTButton>
          <HTButton type="success">动态成功按钮</HTButton>
          <p>当前主题: {{ currentTheme }}</p>
        </div>
      </HTConfigProvider>
    </div>
  </div>
</template>

<script setup lang="ts">
import { computed, ref } from 'vue';
import { HTButton, HTConfigProvider, type ConfigProviderTheme, type ThemeVars } from '@/components';

// 当前主题
const currentTheme = ref<ConfigProviderTheme>('light');

// 自定义主题变量
const customThemeVars: ThemeVars = {
  primaryColor: '#722ed1',
  successColor: '#52c41a',
  buttonBgColorPrimary: '#722ed1',
  buttonBgColorSuccess: '#52c41a',
  buttonTextFontSizeDefault: '18px',
};

// 动态主题变量
const primaryColor = ref('#1677ff');
const dynamicThemeVars = computed<ThemeVars>(() => ({
  primaryColor: primaryColor.value,
  buttonBgColorPrimary: primaryColor.value,
}));

// 切换主题
const toggleTheme = () => {
  currentTheme.value = currentTheme.value === 'light' ? 'dark' : 'light';
};

// 随机主色
const randomPrimaryColor = () => {
  const colors = ['#f5222d', '#fa8c16', '#fadb14', '#52c41a', '#1890ff', '#722ed1', '#eb2f96'];
  const randomColor = colors[Math.floor(Math.random() * colors.length)]!;
  primaryColor.value = randomColor;
};
</script>

<style scoped>
.config-provider-demo {
  padding: 20px;
  max-width: 800px;
  margin: 0 auto;
}

.demo-section {
  margin-bottom: 40px;
  padding: 20px;
  border: 1px solid #e8e8e8;
  border-radius: 8px;
}

.demo-section h2 {
  margin-top: 0;
  margin-bottom: 16px;
  color: #333;
}

.demo-content {
  display: flex;
  gap: 16px;
  align-items: center;
  flex-wrap: wrap;
}

.demo-content.dark {
  background-color: #f5f5f5;
  padding: 16px;
  border-radius: 8px;
}

.controls {
  margin-bottom: 16px;
  display: flex;
  gap: 16px;
}

p {
  margin: 16px 0 0 0;
  font-size: 14px;
  color: #666;
}
</style>
