<template>
  <div class="mx-auto w-full max-w-md">
    <HTSwipe :autoplay="3000" :duration="400" :loop="true" :height="160">
      <HTSwipeItem>
        <div class="flex h-full w-full items-center justify-center bg-blue-100">Slide 1</div>
      </HTSwipeItem>
      <HTSwipeItem>
        <div class="flex h-full w-full items-center justify-center bg-green-100">Slide 2</div>
      </HTSwipeItem>
      <HTSwipeItem>
        <div class="flex h-full w-full items-center justify-center bg-yellow-100">Slide 3</div>
      </HTSwipeItem>
    </HTSwipe>
  </div>
</template>

<script setup lang="ts">
import { HTSwipe, HTSwipeItem } from '@/components';
</script>
