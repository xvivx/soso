import { type Component } from 'vue';
import { type RouteRecordRaw } from 'vue-router';

const context = import.meta.glob<{ default: Component }>('./*.vue');

console.log('🚀 ~ context:', context);

export default Object.keys(context)
  .filter((dir) => dir !== './index.vue')
  .map((dir) => {
    const name = dir.slice(2).replace(/\.vue$/, '');
    return {
      path: `/${name}`,
      name,
      component: context[dir],
    };
  }) as RouteRecordRaw[];
