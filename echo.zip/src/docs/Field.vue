<template>
  <HTField
    label="Username"
    placeholder="Enter your username"
    :clearable="true"
    v-model="value"
    :show-word-limit="true"
    :maxlength="10"
  />
</template>

<script setup lang="ts">
import { ref } from 'vue';
import { HTField } from '@/components';

const value = ref('');
</script>

<style lang="scss" scoped></style>
