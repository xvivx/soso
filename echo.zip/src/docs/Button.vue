<template>
  <div class="button-demo space-y-8 p-6">
    <h1 class="mb-6 text-2xl font-bold">HTButton 按钮组件</h1>

    <!-- 基础用法 -->
    <section class="space-y-4">
      <h2 class="text-xl font-semibold">基础用法</h2>
      <div class="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-4">
        <div class="rounded-lg border p-4">
          <h3 class="mb-2 text-sm font-medium">默认按钮</h3>
          <HTButton @click="handleClick('default')">默认按钮</HTButton>
        </div>
        <div class="rounded-lg border p-4">
          <h3 class="mb-2 text-sm font-medium">主要按钮</h3>
          <HTButton type="primary" @click="handleClick('primary')">主要按钮</HTButton>
        </div>
        <div class="rounded-lg border p-4">
          <h3 class="mb-2 text-sm font-medium">成功按钮</h3>
          <HTButton type="success" @click="handleClick('success')">成功按钮</HTButton>
        </div>
        <div class="rounded-lg border p-4">
          <h3 class="mb-2 text-sm font-medium">警告按钮</h3>
          <HTButton type="warning" @click="handleClick('warning')">警告按钮</HTButton>
        </div>
      </div>
    </section>

    <!-- 按钮类型 -->
    <section class="space-y-4">
      <h2 class="text-xl font-semibold">按钮类型</h2>
      <div class="grid grid-cols-1 gap-4 md:grid-cols-2">
        <div class="rounded-lg border p-4">
          <h3 class="mb-2 text-sm font-medium">所有类型</h3>
          <div class="flex flex-wrap gap-2">
            <HTButton type="default">默认</HTButton>
            <HTButton type="primary">主要</HTButton>
            <HTButton type="success">成功</HTButton>
            <HTButton type="warning">警告</HTButton>
            <HTButton type="danger">危险</HTButton>
          </div>
        </div>
        <div class="rounded-lg border p-4">
          <h3 class="mb-2 text-sm font-medium">朴素按钮</h3>
          <div class="flex flex-wrap gap-2">
            <HTButton plain type="default">朴素默认</HTButton>
            <HTButton plain type="primary">朴素主要</HTButton>
            <HTButton plain type="success">朴素成功</HTButton>
            <HTButton plain type="danger">朴素危险</HTButton>
          </div>
        </div>
      </div>
    </section>

    <!-- 按钮尺寸 -->
    <section class="space-y-4">
      <h2 class="text-xl font-semibold">按钮尺寸</h2>
      <div class="grid grid-cols-1 gap-4 md:grid-cols-2">
        <div class="rounded-lg border p-4">
          <h3 class="mb-2 text-sm font-medium">不同尺寸</h3>
          <div class="flex flex-wrap items-center gap-2">
            <HTButton size="large" type="primary">大号</HTButton>
            <HTButton size="normal" type="primary">普通</HTButton>
            <HTButton size="small" type="primary">小号</HTButton>
            <HTButton size="mini" type="primary">迷你</HTButton>
          </div>
        </div>
        <div class="rounded-lg border p-4">
          <h3 class="mb-2 text-sm font-medium">块级按钮</h3>
          <div class="space-y-2">
            <HTButton block size="large" type="primary">大号块级</HTButton>
            <HTButton block size="normal" type="success">普通块级</HTButton>
          </div>
        </div>
      </div>
    </section>

    <!-- 按钮形状 -->
    <section class="space-y-4">
      <h2 class="text-xl font-semibold">按钮形状</h2>
      <div class="grid grid-cols-1 gap-4 md:grid-cols-2">
        <div class="rounded-lg border p-4">
          <h3 class="mb-2 text-sm font-medium">形状变体</h3>
          <div class="flex flex-wrap gap-2">
            <HTButton type="primary">默认</HTButton>
            <HTButton round type="primary">圆形</HTButton>
            <HTButton square type="primary">方形</HTButton>
          </div>
        </div>
        <div class="rounded-lg border p-4">
          <h3 class="mb-2 text-sm font-medium">发际线按钮</h3>
          <div class="flex flex-wrap gap-2">
            <HTButton hairline type="default">发际线默认</HTButton>
            <HTButton hairline type="primary">发际线主要</HTButton>
            <HTButton hairline round type="success">发际线圆形</HTButton>
          </div>
        </div>
      </div>
    </section>

    <!-- 图标按钮 -->
    <section class="space-y-4">
      <h2 class="text-xl font-semibold">图标按钮</h2>
      <div class="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3">
        <div class="rounded-lg border p-4">
          <h3 class="mb-2 text-sm font-medium">左侧图标</h3>
          <div class="flex flex-wrap gap-2">
            <HTButton icon="plus" type="primary">添加</HTButton>
            <HTButton icon="edit" type="warning">编辑</HTButton>
            <HTButton icon="delete" type="danger">删除</HTButton>
          </div>
        </div>
        <div class="rounded-lg border p-4">
          <h3 class="mb-2 text-sm font-medium">右侧图标</h3>
          <div class="flex flex-wrap gap-2">
            <HTButton icon-position="right" icon="arrow" type="primary">下一步</HTButton>
            <HTButton icon-position="right" icon="download" type="success">下载</HTButton>
          </div>
        </div>
        <div class="rounded-lg border p-4">
          <h3 class="mb-2 text-sm font-medium">纯图标</h3>
          <div class="flex flex-wrap gap-2">
            <HTButton icon="plus" type="primary" />
            <HTButton icon="edit" type="warning" />
            <HTButton icon="delete" type="danger" />
            <HTButton icon="heart" type="default" />
          </div>
        </div>
      </div>
    </section>

    <!-- 状态控制 -->
    <section class="space-y-4">
      <h2 class="text-xl font-semibold">状态控制</h2>
      <div class="grid grid-cols-1 gap-4 md:grid-cols-2">
        <div class="rounded-lg border p-4">
          <h3 class="mb-2 text-sm font-medium">按钮状态</h3>
          <div class="flex flex-wrap gap-2">
            <HTButton @click="handleNormalClick">正常</HTButton>
            <HTButton disabled @click="handleDisabledClick">禁用</HTButton>
            <HTButton :loading="isLoading" @click="handleLoadingClick">
              {{ isLoading ? '加载中...' : '点击加载' }}
            </HTButton>
          </div>
        </div>
        <div class="rounded-lg border p-4">
          <h3 class="mb-2 text-sm font-medium">加载状态</h3>
          <div class="flex flex-wrap gap-2">
            <HTButton loading loading-text="提交中..." type="primary">提交</HTButton>
            <HTButton loading loading-type="spinner" type="success">保存</HTButton>
            <HTButton loading :loading-size="24" type="warning">上传</HTButton>
          </div>
        </div>
      </div>
    </section>

    <!-- 自定义颜色 -->
    <section class="space-y-4">
      <h2 class="text-xl font-semibold">自定义颜色</h2>
      <div class="grid grid-cols-1 gap-4 md:grid-cols-2">
        <div class="rounded-lg border p-4">
          <h3 class="mb-2 text-sm font-medium">单色自定义</h3>
          <div class="flex flex-wrap gap-2">
            <HTButton color="#722ed1">紫色</HTButton>
            <HTButton color="#13c2c2">青色</HTButton>
            <HTButton color="#eb2f96">粉色</HTButton>
            <HTButton plain color="#722ed1">朴素紫色</HTButton>
          </div>
        </div>
        <div class="rounded-lg border p-4">
          <h3 class="mb-2 text-sm font-medium">渐变色</h3>
          <div class="flex flex-wrap gap-2">
            <HTButton color="linear-gradient(to right, #ff6b6b, #4ecdc4)">渐变1</HTButton>
            <HTButton color="linear-gradient(135deg, #667eea 0%, #764ba2 100%)">渐变2</HTButton>
            <HTButton color="linear-gradient(to bottom, #ff9a9e, #fecfef)">渐变3</HTButton>
          </div>
        </div>
      </div>
    </section>

    <!-- 高级特性 -->
    <section class="space-y-4">
      <h2 class="text-xl font-semibold">高级特性</h2>
      <div class="grid grid-cols-1 gap-4 md:grid-cols-2">
        <div class="rounded-lg border p-4">
          <h3 class="mb-2 text-sm font-medium">组合属性</h3>
          <div class="space-y-2">
            <HTButton round block type="primary" icon="plus">添加新项目</HTButton>
            <HTButton round plain type="danger" icon="delete">删除操作</HTButton>
          </div>
        </div>
        <div class="rounded-lg border p-4">
          <h3 class="mb-2 text-sm font-medium">导航功能</h3>
          <div class="space-y-2">
            <div class="flex flex-wrap gap-2">
              <HTButton url="https://example.com" type="primary">外部链接</HTButton>
              <HTButton url="https://example.com" replace type="warning">替换链接</HTButton>
            </div>
            <div class="rounded border border-blue-200 bg-blue-50 p-2 text-xs text-blue-700">
              <strong>注意：</strong>内部路由跳转需要自行使用 vue-router 实现，例如：<br />
              <code class="rounded bg-blue-100 px-1"
                >&lt;router-link to="/about"&gt;&lt;HTButton
                type="success"&gt;内部路由&lt;/HTButton&gt;&lt;/router-link&gt;</code
              >
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- Vant API 兼容性演示 -->
    <section class="space-y-4">
      <h2 class="text-xl font-semibold">Vant API 兼容性</h2>
      <div class="rounded-lg border bg-gray-50 p-4">
        <h3 class="mb-2 text-sm font-medium">完全兼容 Vant Button API</h3>
        <pre class="overflow-x-auto rounded border bg-white p-2 text-xs"><code>{{ vantApiExample }}</code></pre>
      </div>
    </section>

    <!-- 响应式测试 -->
    <section class="space-y-4">
      <h2 class="text-xl font-semibold">响应式测试</h2>
      <div class="rounded-lg border p-4">
        <p class="mb-2 text-sm text-gray-600">调整浏览器大小查看响应式效果</p>
        <div class="grid grid-cols-1 gap-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
          <HTButton size="small" type="primary">响应式按钮</HTButton>
          <HTButton size="normal" type="success">响应式按钮</HTButton>
          <HTButton size="large" type="warning">响应式按钮</HTButton>
          <HTButton block type="danger">块级响应式</HTButton>
        </div>
      </div>
    </section>

    <!-- 无障碍演示 -->
    <section class="space-y-4">
      <h2 class="text-xl font-semibold">无障碍支持</h2>
      <div class="rounded-lg border p-4">
        <p class="mb-2 text-sm text-gray-600">屏幕阅读器支持说明</p>
        <div class="flex flex-wrap gap-2">
          <HTButton :aria-label="accessibilityLabel" type="primary" @click="handleAccessibleClick">
            无障碍按钮
          </HTButton>
          <HTButton icon="heart" type="default" aria-label="收藏按钮" @click="handleAccessibleClick" />
          <HTButton disabled aria-label="禁用按钮，无法点击" @click="handleAccessibleClick"> 禁用按钮 </HTButton>
        </div>
        <p class="mt-2 text-xs text-gray-500">支持键盘导航和屏幕阅读器</p>
      </div>
    </section>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import { HTButton } from '@/components/button';

// 响应式数据
const isLoading = ref(false);
const accessibilityLabel = ref('这是一个无障碍友好的按钮');
const clickCount = ref(0);

// 事件处理
const handleClick = (type: string) => {
  console.log(`${type} 按钮被点击`);
  clickCount.value++;
};

const handleNormalClick = () => {
  console.log('正常按钮点击');
};

const handleDisabledClick = () => {
  console.log('禁用按钮不会触发点击事件');
};

const handleLoadingClick = () => {
  if (!isLoading.value) {
    isLoading.value = true;
    setTimeout(() => {
      isLoading.value = false;
      console.log('加载完成');
    }, 2000);
  }
};

const handleAccessibleClick = () => {
  console.log('无障碍按钮点击');
};

// Vant API 示例代码
const vantApiExample = `// Vant 兼容的 API
<HTButton
  type="primary"
  size="large"
  plain
  round
  block
  loading
  disabled
  icon="plus"
  icon-position="left"
  loading-text="加载中..."
  color="#1677ff"
  url="/path"
  replace
  @click="handleClick"
  @touchstart="handleTouchstart"
/>

// 完全兼容 Vant 的 props 命名和默认值
// 支持 type, size, plain, block, round, square, loading, disabled
// 支持 icon, icon-prefix, icon-position, loading-text, loading-type
// 支持 color, url, replace, native-type, tag, hairline
// 注意：不支持 to 属性，如需路由跳转请自行使用 vue-router

// 导航功能说明：
// - url: 外部链接跳转，支持绝对 URL
// - replace: 是否替换当前历史记录（默认 false，仅对 url 有效）
// - tag: 自定义渲染的 HTML 标签（默认 button）
//
// 示例：
// <HTButton url="https://example.com">外部链接</HTButton>
// <HTButton url="https://example.com" replace>替换链接</HTButton>
//
// 内部路由需要自行使用 vue-router：
// <router-link to="/home">
//   <HTButton type="primary">内部路由</HTButton>
// </router-link>`;
</script>

<style scoped>
.button-demo {
  max-width: 1200px;
  margin: 0 auto;
}

/* Tailwind CSS 类 */
.grid {
  display: grid;
}

.grid-cols-1 {
  grid-template-columns: repeat(1, minmax(0, 1fr));
}

@media (min-width: 640px) {
  .sm\:grid-cols-2 {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }
}

@media (min-width: 768px) {
  .md\:grid-cols-2 {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }
}

@media (min-width: 1024px) {
  .lg\:grid-cols-3 {
    grid-template-columns: repeat(3, minmax(0, 1fr));
  }
}

@media (min-width: 1280px) {
  .lg\:grid-cols-4 {
    grid-template-columns: repeat(4, minmax(0, 1fr));
  }
}

.gap-2 {
  gap: 0.5rem;
}

.gap-4 {
  gap: 1rem;
}

.p-4,
.p-6 {
  padding: 1rem / 1.5rem;
}

.border {
  border-width: 1px;
  border-color: #e5e7eb;
}

.rounded-lg {
  border-radius: 0.5rem;
}

.space-y-2 > :not([hidden]) ~ :not([hidden]) {
  margin-top: 0.5rem;
}

.space-y-4 > :not([hidden]) ~ :not([hidden]) {
  margin-top: 1rem;
}

.space-y-8 > :not([hidden]) ~ :not([hidden]) {
  margin-top: 2rem;
}

.text-2xl,
.text-xl,
.text-sm,
.text-xs {
  font-size: 1.5rem / 1.25rem / 0.875rem / 0.75rem;
  line-height: 2rem / 1.75rem / 1.25rem / 1rem;
}

.font-bold,
.font-semibold,
.font-medium {
  font-weight: 700 / 600 / 500;
}

.mb-2,
.mb-6,
.mt-2 {
  margin-bottom: 0.5rem / 1.5rem;
  margin-top: 0.5rem;
}

.bg-gray-50,
.bg-white {
  background-color: #f9fafb / #ffffff;
}

.text-gray-600,
.text-gray-500 {
  color: #4b5563 / #6b7280;
}

.flex-wrap {
  flex-wrap: wrap;
}

.items-center {
  align-items: center;
}

.overflow-x-auto {
  overflow-x: auto;
}
</style>
