<template>
  <div class="config-provider-demo space-y-8 p-6">
    <h1 class="mb-6 text-2xl font-bold">HTConfigProvider 全局配置组件</h1>

    <!-- 基础用法 -->
    <section class="space-y-4">
      <h2 class="text-xl font-semibold">基础用法</h2>
      <div class="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-4">
        <div class="rounded-lg border p-4">
          <h3 class="mb-2 text-sm font-medium">默认配置</h3>
          <HTConfigProvider theme="light" locale="zh-CN">
            <div class="space-y-2">
              <button class="w-full rounded bg-blue-500 px-3 py-2 text-white hover:bg-blue-600">主要按钮</button>
              <p class="text-xs text-gray-600">浅色主题 + 中文</p>
            </div>
          </HTConfigProvider>
        </div>

        <div class="rounded-lg border p-4">
          <h3 class="mb-2 text-sm font-medium">深色主题</h3>
          <HTConfigProvider theme="dark" locale="zh-CN">
            <div class="space-y-2">
              <button class="w-full rounded bg-blue-600 px-3 py-2 text-white hover:bg-blue-700">主要按钮</button>
              <p class="text-xs text-gray-600">深色主题 + 中文</p>
            </div>
          </HTConfigProvider>
        </div>

        <div class="rounded-lg border p-4">
          <h3 class="mb-2 text-sm font-medium">英文环境</h3>
          <HTConfigProvider theme="light" locale="en-US">
            <div class="space-y-2">
              <button class="w-full rounded bg-blue-500 px-3 py-2 text-white hover:bg-blue-600">Primary</button>
              <p class="text-xs text-gray-600">Light theme + English</p>
            </div>
          </HTConfigProvider>
        </div>

        <div class="rounded-lg border p-4">
          <h3 class="mb-2 text-sm font-medium">自动主题</h3>
          <HTConfigProvider theme="auto" locale="zh-CN">
            <div class="space-y-2">
              <button class="w-full rounded bg-blue-500 px-3 py-2 text-white hover:bg-blue-600">自适应主题</button>
              <p class="text-xs text-gray-600">跟随系统设置</p>
            </div>
          </HTConfigProvider>
        </div>
      </div>
    </section>

    <!-- 主题配置 -->
    <section class="space-y-4">
      <h2 class="text-xl font-semibold">主题配置</h2>
      <div class="rounded-lg border p-4">
        <h3 class="mb-4 text-sm font-medium">实时主题切换</h3>
        <div class="mb-4 flex flex-wrap gap-2">
          <button
            v-for="theme in themes"
            :key="theme.value"
            @click="currentTheme = theme.value"
            :class="[
              'rounded px-4 py-2 transition-colors',
              currentTheme === theme.value ? 'bg-blue-500 text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200',
            ]"
          >
            {{ theme.label }}
          </button>
        </div>

        <HTConfigProvider :theme="currentTheme" :theme-vars="currentThemeVars">
          <div class="grid grid-cols-1 gap-4 md:grid-cols-2">
            <div class="space-y-3">
              <h4 class="text-sm font-medium">按钮组件</h4>
              <div class="flex flex-wrap gap-2">
                <button
                  class="rounded px-3 py-2 text-white hover:opacity-90"
                  :style="{ backgroundColor: currentThemeVars.primaryColor }"
                >
                  主要按钮
                </button>
                <button
                  class="rounded px-3 py-2 text-white hover:opacity-90"
                  :style="{ backgroundColor: currentThemeVars.successColor }"
                >
                  成功按钮
                </button>
                <button
                  class="rounded px-3 py-2 text-white hover:opacity-90"
                  :style="{ backgroundColor: currentThemeVars.warningColor }"
                >
                  警告按钮
                </button>
                <button
                  class="rounded px-3 py-2 text-white hover:opacity-90"
                  :style="{ backgroundColor: currentThemeVars.dangerColor }"
                >
                  危险按钮
                </button>
              </div>
            </div>

            <div class="space-y-3">
              <h4 class="text-sm font-medium">标签组件</h4>
              <div class="flex flex-wrap gap-2">
                <span
                  class="rounded-full px-2 py-1 text-xs font-medium"
                  :style="{
                    backgroundColor: `${currentThemeVars.primaryColor}20`,
                    color: currentThemeVars.primaryColor,
                  }"
                >
                  主要标签
                </span>
                <span
                  class="rounded-full px-2 py-1 text-xs font-medium"
                  :style="{
                    backgroundColor: `${currentThemeVars.successColor}20`,
                    color: currentThemeVars.successColor,
                  }"
                >
                  成功标签
                </span>
                <span
                  class="rounded-full px-2 py-1 text-xs font-medium"
                  :style="{
                    backgroundColor: `${currentThemeVars.warningColor}20`,
                    color: currentThemeVars.warningColor,
                  }"
                >
                  警告标签
                </span>
              </div>
            </div>
          </div>
        </HTConfigProvider>
      </div>
    </section>

    <!-- CSS变量定制 -->
    <section class="space-y-4">
      <h2 class="text-xl font-semibold">CSS变量定制</h2>
      <div class="rounded-lg border p-4">
        <h3 class="mb-4 text-sm font-medium">自定义主题色</h3>
        <div class="mb-4 grid grid-cols-2 gap-4 md:grid-cols-4">
          <div>
            <label class="mb-1 block text-xs font-medium">主色</label>
            <input v-model="customVars.primaryColor" type="color" class="h-8 w-full cursor-pointer rounded" />
          </div>
          <div>
            <label class="mb-1 block text-xs font-medium">成功色</label>
            <input v-model="customVars.successColor" type="color" class="h-8 w-full cursor-pointer rounded" />
          </div>
          <div>
            <label class="mb-1 block text-xs font-medium">警告色</label>
            <input v-model="customVars.warningColor" type="color" class="h-8 w-full cursor-pointer rounded" />
          </div>
          <div>
            <label class="mb-1 block text-xs font-medium">危险色</label>
            <input v-model="customVars.dangerColor" type="color" class="h-8 w-full cursor-pointer rounded" />
          </div>
        </div>

        <HTConfigProvider :theme-vars="customVars">
          <div class="grid grid-cols-1 gap-4 md:grid-cols-3">
            <div class="rounded border p-3">
              <div class="mb-2 h-12 rounded" :style="{ backgroundColor: customVars.primaryColor }"></div>
              <p class="text-center font-mono text-xs">{{ customVars.primaryColor }}</p>
            </div>
            <div class="rounded border p-3">
              <div class="mb-2 h-12 rounded" :style="{ backgroundColor: customVars.successColor }"></div>
              <p class="text-center font-mono text-xs">{{ customVars.successColor }}</p>
            </div>
            <div class="rounded border p-3">
              <div class="mb-2 h-12 rounded" :style="{ backgroundColor: customVars.warningColor }"></div>
              <p class="text-center font-mono text-xs">{{ customVars.warningColor }}</p>
            </div>
          </div>
        </HTConfigProvider>
      </div>
    </section>

    <!-- 国际化配置 -->
    <section class="space-y-4">
      <h2 class="text-xl font-semibold">国际化配置</h2>
      <div class="grid grid-cols-1 gap-4 md:grid-cols-2">
        <div class="rounded-lg border p-4">
          <h3 class="mb-4 text-sm font-medium">语言切换</h3>
          <div class="space-y-2">
            <select v-model="currentLocale" class="w-full rounded border px-3 py-2 text-sm">
              <option value="zh-CN">简体中文</option>
              <option value="zh-TW">繁體中文</option>
              <option value="en-US">English</option>
              <option value="ja-JP">日本語</option>
            </select>

            <HTConfigProvider :locale="currentLocale">
              <div class="mt-4 space-y-3">
                <div class="flex justify-between rounded bg-gray-50 p-2">
                  <span class="text-sm">确认按钮</span>
                  <span class="text-sm font-medium">{{ getLocaleText('confirm') }}</span>
                </div>
                <div class="flex justify-between rounded bg-gray-50 p-2">
                  <span class="text-sm">取消按钮</span>
                  <span class="text-sm font-medium">{{ getLocaleText('cancel') }}</span>
                </div>
                <div class="flex justify-between rounded bg-gray-50 p-2">
                  <span class="text-sm">删除操作</span>
                  <span class="text-sm font-medium">{{ getLocaleText('delete') }}</span>
                </div>
                <div class="flex justify-between rounded bg-gray-50 p-2">
                  <span class="text-sm">加载状态</span>
                  <span class="text-sm font-medium">{{ getLocaleText('loading') }}</span>
                </div>
              </div>
            </HTConfigProvider>
          </div>
        </div>

        <div class="rounded-lg border p-4">
          <h3 class="mb-4 text-sm font-medium">日期格式化</h3>
          <HTConfigProvider :locale="currentLocale">
            <div class="space-y-2">
              <div class="rounded bg-gray-50 p-2">
                <p class="text-xs text-gray-600">短日期</p>
                <p class="font-mono text-sm">{{ formatDate('short') }}</p>
              </div>
              <div class="rounded bg-gray-50 p-2">
                <p class="text-xs text-gray-600">长日期</p>
                <p class="font-mono text-sm">{{ formatDate('long') }}</p>
              </div>
              <div class="rounded bg-gray-50 p-2">
                <p class="text-xs text-gray-600">时间</p>
                <p class="font-mono text-sm">{{ formatDate('time') }}</p>
              </div>
              <div class="rounded bg-gray-50 p-2">
                <p class="text-xs text-gray-600">货币</p>
                <p class="font-mono text-sm">{{ formatCurrency(1234.56) }}</p>
              </div>
            </div>
          </HTConfigProvider>
        </div>
      </div>
    </section>

    <!-- 高级配置 -->
    <section class="space-y-4">
      <h2 class="text-xl font-semibold">高级配置</h2>
      <div class="rounded-lg border p-4">
        <h3 class="mb-4 text-sm font-medium">Z-index 和图标前缀</h3>
        <div class="mb-4 grid grid-cols-1 gap-4 md:grid-cols-2">
          <div>
            <label class="mb-1 block text-xs font-medium">Z-index 基础值</label>
            <input v-model.number="zIndexBase" type="number" class="w-full rounded border px-3 py-2 text-sm" />
          </div>
          <div>
            <label class="mb-1 block text-xs font-medium">图标前缀</label>
            <input v-model="iconPrefix" type="text" class="w-full rounded border px-3 py-2 text-sm" />
          </div>
        </div>

        <HTConfigProvider :z-index="zIndexBase" :icon-prefix="iconPrefix">
          <div class="grid grid-cols-1 gap-4 md:grid-cols-2">
            <div class="space-y-3">
              <h4 class="text-sm font-medium">层级演示 (Z-index: {{ zIndexBase }})</h4>
              <div class="relative h-32 rounded bg-gray-100">
                <div
                  class="absolute rounded bg-blue-500 p-2 text-xs text-white"
                  :style="{
                    zIndex: zIndexBase + 1,
                    top: '10px',
                    left: '10px',
                  }"
                >
                  层级 {{ zIndexBase + 1 }}
                </div>
                <div
                  class="absolute rounded bg-green-500 p-2 text-xs text-white"
                  :style="{
                    zIndex: zIndexBase + 2,
                    top: '25px',
                    left: '25px',
                  }"
                >
                  层级 {{ zIndexBase + 2 }}
                </div>
                <div
                  class="absolute rounded bg-red-500 p-2 text-xs text-white"
                  :style="{
                    zIndex: zIndexBase + 3,
                    top: '40px',
                    left: '40px',
                  }"
                >
                  层级 {{ zIndexBase + 3 }}
                </div>
              </div>
            </div>

            <div class="space-y-3">
              <h4 class="text-sm font-medium">图标前缀 ({{ iconPrefix }})</h4>
              <div class="space-y-2">
                <div class="flex items-center gap-2">
                  <div class="flex h-6 w-6 items-center justify-center rounded bg-blue-500 text-xs text-white">
                    <i :class="`${iconPrefix}-user`">👤</i>
                  </div>
                  <span class="text-sm">用户图标</span>
                </div>
                <div class="flex items-center gap-2">
                  <div class="flex h-6 w-6 items-center justify-center rounded bg-green-500 text-xs text-white">
                    <i :class="`${iconPrefix}-settings`">⚙️</i>
                  </div>
                  <span class="text-sm">设置图标</span>
                </div>
                <div class="flex items-center gap-2">
                  <div class="flex h-6 w-6 items-center justify-center rounded bg-red-500 text-xs text-white">
                    <i :class="`${iconPrefix}-bell`">🔔</i>
                  </div>
                  <span class="text-sm">通知图标</span>
                </div>
              </div>
            </div>
          </div>
        </HTConfigProvider>
      </div>
    </section>

    <!-- Vant API 兼容性演示 -->
    <section class="space-y-4">
      <h2 class="text-xl font-semibold">Vant API 兼容性</h2>
      <div class="rounded-lg border bg-gray-50 p-4">
        <h3 class="mb-2 text-sm font-medium">完全兼容 Vant ConfigProvider API</h3>
        <pre class="overflow-x-auto rounded border bg-white p-2 text-xs"><code>{{ vantApiExample }}</code></pre>
        <div class="mt-4 grid grid-cols-1 gap-4 md:grid-cols-2">
          <div class="rounded border bg-white p-3">
            <h4 class="mb-2 text-xs font-medium">支持的 Props</h4>
            <ul class="space-y-1 text-xs">
              <li>✅ theme - 主题模式</li>
              <li>✅ theme-vars - CSS 变量</li>
              <li>✅ theme-vars-scope - 作用域</li>
              <li>✅ locale - 语言配置</li>
              <li>✅ z-index - 层级基础</li>
              <li>✅ icon-prefix - 图标前缀</li>
              <li>✅ tag - 根标签类型</li>
            </ul>
          </div>
          <div class="rounded border bg-white p-3">
            <h4 class="mb-2 text-xs font-medium">功能特性</h4>
            <ul class="space-y-1 text-xs">
              <li>✅ 完整的主题系统</li>
              <li>✅ CSS 变量定制</li>
              <li>✅ 国际化支持</li>
              <li>✅ 响应式设计</li>
              <li>✅ TypeScript 支持</li>
              <li>✅ 无障碍支持</li>
            </ul>
          </div>
        </div>
      </div>
    </section>

    <!-- 响应式测试 -->
    <section class="space-y-4">
      <h2 class="text-xl font-semibold">响应式测试</h2>
      <div class="rounded-lg border p-4">
        <p class="mb-4 text-sm text-gray-600">调整浏览器大小查看响应式效果</p>
        <HTConfigProvider theme="light" locale="zh-CN">
          <div class="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            <div v-for="i in 8" :key="i" class="rounded border bg-gray-50 p-4">
              <div class="mb-2 h-16 rounded bg-gradient-to-r from-blue-400 to-purple-500"></div>
              <h4 class="text-sm font-medium">响应式卡片 {{ i }}</h4>
              <p class="text-xs text-gray-600">
                {{ i <= 4 ? '在大屏幕上显示4列' : '在小屏幕上堆叠显示' }}
              </p>
            </div>
          </div>
        </HTConfigProvider>
      </div>
    </section>

    <!-- 无障碍演示 -->
    <section class="space-y-4">
      <h2 class="text-xl font-semibold">无障碍支持</h2>
      <div class="rounded-lg border p-4">
        <p class="mb-4 text-sm text-gray-600">屏幕阅读器支持说明</p>
        <HTConfigProvider theme="light" locale="zh-CN" :aria-label="accessibilityLabel">
          <div class="space-y-4">
            <div class="rounded border bg-blue-50 p-4">
              <h4 class="mb-2 text-sm font-medium">语义化标签</h4>
              <p class="text-xs text-gray-600">ConfigProvider 使用语义化的标签，提供良好的可访问性支持。</p>
            </div>
            <div class="rounded border bg-green-50 p-4">
              <h4 class="mb-2 text-sm font-medium">键盘导航</h4>
              <p class="text-xs text-gray-600">所有交互元素都支持键盘导航和焦点管理。</p>
            </div>
            <div class="rounded border bg-yellow-50 p-4">
              <h4 class="mb-2 text-sm font-medium">屏幕阅读器</h4>
              <p class="text-xs text-gray-600">支持 ARIA 标签和属性，提供完整的屏幕阅读器支持。</p>
            </div>
          </div>
        </HTConfigProvider>
        <p class="mt-2 text-xs text-gray-500">支持键盘导航和屏幕阅读器</p>
      </div>
    </section>
  </div>
</template>

<script setup lang="ts">
import { computed, ref } from 'vue';
import { HTConfigProvider } from '@/components/config-provider';

// 响应式数据
const currentTheme = ref<'light' | 'dark' | 'auto'>('light');
const currentLocale = ref('zh-CN');
const zIndexBase = ref(1000);
const iconPrefix = ref('ht-icon');
const accessibilityLabel = ref('全局配置组件，提供主题、国际化等功能');

const themes = [
  { value: 'light', label: '浅色主题' },
  { value: 'dark', label: '深色主题' },
  { value: 'auto', label: '跟随系统' },
];

const customVars = ref({
  primaryColor: '#1677ff',
  successColor: '#52c41a',
  warningColor: '#faad14',
  dangerColor: '#ff4d4f',
});

const currentThemeVars = computed(() => {
  const baseVars = {
    fontSizeMd: '14px',
    paddingMd: '12px',
    radiusMd: '4px',
  };

  switch (currentTheme.value) {
    case 'light':
      return {
        ...baseVars,
        primaryColor: '#1677ff',
        successColor: '#52c41a',
        warningColor: '#faad14',
        dangerColor: '#ff4d4f',
        textColor: '#333333',
        background: '#ffffff',
      };
    case 'dark':
      return {
        ...baseVars,
        primaryColor: '#1890ff',
        successColor: '#52c41a',
        warningColor: '#faad14',
        dangerColor: '#ff4d4f',
        textColor: '#ffffff',
        background: '#1f1f1f',
      };
    default:
      return {
        ...baseVars,
        primaryColor: '#1677ff',
        successColor: '#52c41a',
        warningColor: '#faad14',
        dangerColor: '#ff4d4f',
      };
  }
});

// 事件处理
const _handleThemeChange = (theme: string) => {
  console.log('主题变更:', theme);
};

const _handleLocaleChange = (locale: string) => {
  console.log('语言变更:', locale);
};

// 国际化文本
const getLocaleText = (key: string) => {
  const texts = {
    'zh-CN': { confirm: '确认', cancel: '取消', delete: '删除', loading: '加载中...' },
    'zh-TW': { confirm: '確認', cancel: '取消', delete: '刪除', loading: '載入中...' },
    'en-US': { confirm: 'Confirm', cancel: 'Cancel', delete: 'Delete', loading: 'Loading...' },
    'ja-JP': { confirm: '確認', cancel: 'キャンセル', delete: '削除', loading: '読み込み中...' },
  };
  return texts[currentLocale.value as keyof typeof texts]?.[key] || key;
};

const formatDate = (type: string) => {
  const now = new Date();
  const options = {
    short: { year: 'numeric', month: '2-digit', day: '2-digit' },
    long: { year: 'numeric', month: 'long', day: 'numeric', weekday: 'long' },
    time: { hour: '2-digit', minute: '2-digit', second: '2-digit' },
  }[type] as Intl.DateTimeFormatOptions;

  return now.toLocaleDateString(currentLocale.value, options);
};

const formatCurrency = (amount: number) => {
  const symbols = {
    'zh-CN': '¥',
    'zh-TW': 'NT$',
    'en-US': '$',
    'ja-JP': '¥',
  };
  const symbol = symbols[currentLocale.value as keyof typeof symbols] || '¥';
  return `${symbol}${amount.toFixed(2)}`;
};

// Vant API 示例代码
const vantApiExample = `// Vant 兼容的 API
<HTConfigProvider
  theme="light"
  :theme-vars="{
    primaryColor: '#1677ff',
    successColor: '#52c41a'
  }"
  theme-vars-scope="local"
  locale="zh-CN"
  :z-index="1000"
  icon-prefix="ht-icon"
  tag="div"
>
  <App />
</HTConfigProvider>

// 完全兼容 Vant 的 props 命名和默认值
// 支持所有 Vant ConfigProvider 的功能特性`;
</script>

<style scoped>
/* 样式使用 Tailwind CSS 为主，配合 CSS 变量 */
.config-provider-demo {
  max-width: 1200px;
  margin: 0 auto;
}

/* 深色主题样式适配 */
@media (prefers-color-scheme: dark) {
  .config-provider-demo {
    background-color: #1f1f1f;
    color: #ffffff;
  }
}

/* 响应式字体大小 */
@media (max-width: 768px) {
  .config-provider-demo h1 {
    font-size: 1.5rem;
  }

  .config-provider-demo h2 {
    font-size: 1.25rem;
  }
}

/* 聚焦样式 */
input:focus,
select:focus,
button:focus {
  outline: 2px solid #1677ff;
  outline-offset: 2px;
}

/* 过渡动画 */
* {
  transition-property: color, background-color, border-color;
  transition-duration: 0.2s;
  transition-timing-function: ease-in-out;
}
</style>
