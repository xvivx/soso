<template>
  <HTPopover>
    <template #reference>
      <div class="text-primary">非受控</div>
    </template>

    <div>非受控</div>
    <div>{{ mock('@paragraph') }}</div>
  </HTPopover>

  <br />

  <HTPopover v-model:open="show">
    <template #reference="{ open }">
      <div>受控({{ open ? '打开状态' : '关闭状态' }})</div>
    </template>
    <div>受控模式</div>
    <div>{{ mock('@paragraph') }}</div>
  </HTPopover>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import { mock } from 'mockjs';
import { HTPopover } from '@/components';

const show = ref(false);
</script>
