<script setup lang="ts">
import { HTCol as Col, HTCellGroup, HTSticky, HTSwipe, HTSwipeItem, HTRow as Row } from '@/components';
</script>

<template>
  <div class="space-y-4 p-4">
    <h2>栅格布局</h2>
    <div class="demo-block">
      <h3>基础布局</h3>
      <Row>
        <Col :span="8"><div class="demo-col">span: 8</div></Col>
        <Col :span="8"><div class="demo-col">span: 8</div></Col>
        <Col :span="8"><div class="demo-col">span: 8</div></Col>
      </Row>
      <Row>
        <Col :span="4"><div class="demo-col">span: 4</div></Col>
        <Col :span="10"><div class="demo-col">span: 10</div></Col>
        <Col :span="10"><div class="demo-col">span: 10</div></Col>
      </Row>
    </div>

    <div class="demo-block">
      <h3>列偏移</h3>
      <Row>
        <Col :span="8"><div class="demo-col">span: 8</div></Col>
        <Col :span="8" :offset="8"><div class="demo-col">span: 8 offset: 8</div></Col>
      </Row>
      <Row>
        <Col :span="6" :offset="6"><div class="demo-col">span: 6 offset: 6</div></Col>
        <Col :span="6" :offset="6"><div class="demo-col">span: 6 offset: 6</div></Col>
      </Row>
    </div>

    <div class="demo-block">
      <h3>对齐方式</h3>
      <Row align="top">
        <Col :span="8"
          ><div class="demo-col-tall">span: 8<br />align: top</div></Col
        >
        <Col :span="8"><div class="demo-col">span: 8</div></Col>
        <Col :span="8"><div class="demo-col-short">span: 8</div></Col>
      </Row>
      <Row align="middle">
        <Col :span="8"
          ><div class="demo-col-tall">span: 8<br />align: middle</div></Col
        >
        <Col :span="8"><div class="demo-col">span: 8</div></Col>
        <Col :span="8"><div class="demo-col-short">span: 8</div></Col>
      </Row>
      <Row align="bottom">
        <Col :span="8"
          ><div class="demo-col-tall">span: 8<br />align: bottom</div></Col
        >
        <Col :span="8"><div class="demo-col">span: 8</div></Col>
        <Col :span="8"><div class="demo-col-short">span: 8</div></Col>
      </Row>
    </div>

    <div class="demo-block">
      <h3>响应式布局</h3>
      <Row :gutter="10">
        <Col :span="6"><div class="demo-col">span: 6</div></Col>
        <Col :span="6"><div class="demo-col">span: 6</div></Col>
        <Col :span="6"><div class="demo-col">span: 6</div></Col>
        <Col :span="6"><div class="demo-col">span: 6</div></Col>
      </Row>
      <Row :gutter="20">
        <Col :span="12"><div class="demo-col">span: 12</div></Col>
        <Col :span="12"><div class="demo-col">span: 12</div></Col>
      </Row>
      <Row :gutter="30">
        <Col :span="8"><div class="demo-col">span: 8</div></Col>
        <Col :span="8"><div class="demo-col">span: 8</div></Col>
        <Col :span="4"><div class="demo-col">span: 4</div></Col>
        <Col :span="4"><div class="demo-col">span: 4</div></Col>
      </Row>
    </div>

    <div class="demo-block">
      <h3>Flex 排序</h3>
      <Row type="flex" justify="space-between">
        <Col :span="6"><div class="demo-col">1 | span: 6</div></Col>
        <Col :span="6"><div class="demo-col">2 | span: 6</div></Col>
        <Col :span="6"><div class="demo-col">3 | span: 6</div></Col>
      </Row>
      <Row type="flex" justify="space-around">
        <Col :span="6"><div class="demo-col">1 | span: 6</div></Col>
        <Col :span="6"><div class="demo-col">2 | span: 6</div></Col>
        <Col :span="6"><div class="demo-col">3 | span: 6</div></Col>
      </Row>
      <Row type="flex" justify="center">
        <Col :span="6"><div class="demo-col">1 | span: 6</div></Col>
        <Col :span="6"><div class="demo-col">2 | span: 6</div></Col>
        <Col :span="6"><div class="demo-col">3 | span: 6</div></Col>
      </Row>
    </div>

    <h2>粘性布局</h2>
    <div class="demo-block">
      <h3>基础用法</h3>
      <HTSticky :offset-top="50">
        <div class="demo-sticky">基础用法</div>
      </HTSticky>
    </div>

    <div class="demo-block">
      <h3>吸顶距离</h3>
      <HTSticky :offset-top="100">
        <div class="demo-sticky">吸顶距离100px</div>
      </HTSticky>
    </div>

    <div class="demo-block">
      <h3>吸底距离</h3>
      <HTSticky position="bottom" :offset-bottom="50">
        <div class="demo-sticky">吸底距离50px</div>
      </HTSticky>
    </div>

    <h2>轮播</h2>
    <div class="demo-swipe">
      <h4>基础用法</h4>
      <HTSwipe class="demo-swipe-box" :autoplay="3000">
        <HTSwipeItem v-for="(color, index) in ['#39a9ed', '#66c6f2', '#dff0fd']" :key="color">
          <div class="demo-swipe-item" :style="{ background: color }">{{ index }}</div>
        </HTSwipeItem>
      </HTSwipe>

      <h4>垂直滚动</h4>
      <HTSwipe vertical class="demo-swipe-box" :autoplay="3000" height="150">
        <HTSwipeItem v-for="color in ['#39a9ed', '#66c6f2', 'red']" :key="color">
          <div class="demo-swipe-item" :style="{ background: color }">{{ color }}</div>
        </HTSwipeItem>
      </HTSwipe>

      <h4>自定义指示器</h4>
      <HTSwipe class="demo-swipe-box" :autoplay="3000" indicator-color="white">
        <HTSwipeItem v-for="color in ['#39a9ed', '#66c6f2', 'red']" :key="color">
          <div class="demo-swipe-item" :style="{ background: color }">{{ color }}</div>
        </HTSwipeItem>
      </HTSwipe>

      <h4>3D 效果</h4>
      <HTSwipe class="demo-swipe-box" :autoplay="3000" effect3d>
        <HTSwipeItem v-for="color in ['#39a9ed', '#66c6f2', 'red']" :key="color">
          <div class="demo-swipe-item" :style="{ background: color }">{{ color }}</div>
        </HTSwipeItem>
      </HTSwipe>
    </div>

    <h2>单元格</h2>
    <!-- Cell 组件测试 -->
    <HTCellGroup title="基础用法" :border="true">
      <HTCell title="主要单元格" value="内容" type="primary" />
      <HTCell title="成功单元格" value="内容" type="success" />
      <HTCell title="单元格" value="内容" label="描述信息" />
    </HTCellGroup>

    <HTCellGroup title="展示图标" :border="true">
      <HTCell title="单元格" value="内容" icon="location-o" />
      <HTCell title="单元格" value="内容" icon="phone-o" />
    </HTCellGroup>

    <HTCellGroup title="只设置 value" :border="true">
      <HTCell value="内容" />
    </HTCellGroup>

    <HTCellGroup title="展示箭头" :border="true">
      <HTCell title="单元格" is-link />
      <HTCell title="单元格" is-link value="内容" />
      <HTCell title="单元格" is-link arrow-direction="down" value="内容" />
    </HTCellGroup>

    <HTCellGroup title="分组标题" :border="true">
      <HTCell title="单元格" value="内容" />
      <HTCell title="单元格" value="内容" />
    </HTCellGroup>

    <HTCellGroup title="单元格大小" :border="true">
      <HTCell title="单元格" value="内容" size="large" />
      <HTCell title="单元格" value="内容" size="large" label="描述信息" />
    </HTCellGroup>

    <HTCellGroup title="必填项" :border="true">
      <HTCell title="用户名" :required="true" />
      <HTCell title="密码" :required="true" />
    </HTCellGroup>

    <HTCellGroup title="内边距" :inset="true" :border="true">
      <HTCell title="单元格" value="内容" />
      <HTCell title="单元格" value="内容" />
    </HTCellGroup>
  </div>
</template>

<style scoped>
.demo-col {
  margin-bottom: 10px;
  color: #fff;
  font-size: 13px;
  line-height: 30px;
  text-align: center;
  background: var(--van-primary-color);
  border-radius: 4px;
}

.demo-col-tall {
  margin-bottom: 10px;
  height: 80px;
  color: #fff;
  font-size: 13px;
  line-height: 30px;
  text-align: center;
  background: var(--van-primary-color);
  border-radius: 4px;
}

.demo-col-short {
  margin-bottom: 10px;
  height: 30px;
  color: #fff;
  font-size: 13px;
  line-height: 30px;
  text-align: center;
  background: var(--van-primary-color);
  border-radius: 4px;
}
.demo-sticky {
  padding: 16px;
  background: var(--van-primary-color);
  color: #000;
  font-size: 14px;
  text-align: center;
  border-radius: 4px;
}

.demo-swipe {
  padding: var(--van-padding-sm);
}

.demo-swipe-box {
  width: 100%;
  height: 150px;
  margin-bottom: var(--van-padding-md);
  background: var(--van-background-2);
  border-radius: var(--van-radius-md);
}

.demo-swipe-item {
  width: 100%;
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
  color: var(--van-text-color);
  font-size: var(--van-font-size-lg);
  border-radius: var(--van-radius-md);
}

.demo-sticky-container {
  height: 300px;
  background: #fff;
  border-radius: 8px;
  overflow: auto;
}
</style>
