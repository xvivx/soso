<script setup lang="ts"></script>

<template>
  <div class="space-y-4 p-4"></div>
</template>

<style scoped></style>
