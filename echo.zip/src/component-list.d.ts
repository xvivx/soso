/* eslint-disable */
// 自动生成的文件, 不要修改它, 会被覆盖
import type { GlobalComponents } from 'vue';

export {};

/* prettier-ignore */
declare module 'vue' {
  export interface GlobalComponents {
    HtButton: typeof import('@hytech/ht-ui')['HTButton']
    'ht-button': typeof import('@hytech/ht-ui')['HTButton']
    HtSelect: typeof import('@hytech/ht-ui')['HTSelect']
    'ht-select': typeof import('@hytech/ht-ui')['HTSelect']
    HtOption: typeof import('@hytech/ht-ui')['HTOption']
    'ht-option': typeof import('@hytech/ht-ui')['HTOption']
    HtModal: typeof import('@hytech/ht-ui')['HTModal']
    'ht-modal': typeof import('@hytech/ht-ui')['HTModal']
    HtPopover: typeof import('@hytech/ht-ui')['HTPopover']
    'ht-popover': typeof import('@hytech/ht-ui')['HTPopover']
    HtCellGroup: typeof import('@hytech/ht-ui')['HTCellGroup']
    'ht-cell-group': typeof import('@hytech/ht-ui')['HTCellGroup']
    HtCell: typeof import('@hytech/ht-ui')['HTCell']
    'ht-cell': typeof import('@hytech/ht-ui')['HTCell']
    HtField: typeof import('@hytech/ht-ui')['HTField']
    'ht-field': typeof import('@hytech/ht-ui')['HTField']
    HtCollapseItem: typeof import('@hytech/ht-ui')['HTCollapseItem']
    'ht-collapse-item': typeof import('@hytech/ht-ui')['HTCollapseItem']
    HtCollapse: typeof import('@hytech/ht-ui')['HTCollapse']
    'ht-collapse': typeof import('@hytech/ht-ui')['HTCollapse']
    HtRadio: typeof import('@hytech/ht-ui')['HTRadio']
    'ht-radio': typeof import('@hytech/ht-ui')['HTRadio']
    HtRadioGroup: typeof import('@hytech/ht-ui')['HTRadioGroup']
    'ht-radio-group': typeof import('@hytech/ht-ui')['HTRadioGroup']
    HtList: typeof import('@hytech/ht-ui')['HTList']
    'ht-list': typeof import('@hytech/ht-ui')['HTList']
    HtForm: typeof import('@hytech/ht-ui')['HTForm']
    'ht-form': typeof import('@hytech/ht-ui')['HTForm']
    HtRow: typeof import('@hytech/ht-ui')['HTRow']
    'ht-row': typeof import('@hytech/ht-ui')['HTRow']
    HtCol: typeof import('@hytech/ht-ui')['HTCol']
    'ht-col': typeof import('@hytech/ht-ui')['HTCol']
    HtDivider: typeof import('@hytech/ht-ui')['HTDivider']
    'ht-divider': typeof import('@hytech/ht-ui')['HTDivider']
    HtSticky: typeof import('@hytech/ht-ui')['HTSticky']
    'ht-sticky': typeof import('@hytech/ht-ui')['HTSticky']
    HtSwipe: typeof import('@hytech/ht-ui')['HTSwipe']
    'ht-swipe': typeof import('@hytech/ht-ui')['HTSwipe']
    HtSwipeItem: typeof import('@hytech/ht-ui')['HTSwipeItem']
    'ht-swipe-item': typeof import('@hytech/ht-ui')['HTSwipeItem']
    HtPullRefresh: typeof import('@hytech/ht-ui')['HTPullRefresh']
    'ht-pull-refresh': typeof import('@hytech/ht-ui')['HTPullRefresh']
    HtLoading: typeof import('@hytech/ht-ui')['HTLoading']
    'ht-loading': typeof import('@hytech/ht-ui')['HTLoading']
    HtImage: typeof import('@hytech/ht-ui')['HTImage']
    'ht-image': typeof import('@hytech/ht-ui')['HTImage']
    HtTabs: typeof import('@hytech/ht-ui')['HTTabs']
    'ht-tabs': typeof import('@hytech/ht-ui')['HTTabs']
    HtTab: typeof import('@hytech/ht-ui')['HTTab']
    'ht-tab': typeof import('@hytech/ht-ui')['HTTab']
    HtToast: typeof import('@hytech/ht-ui')['HTToast']
    'ht-toast': typeof import('@hytech/ht-ui')['HTToast']
    HtTooltip: typeof import('@hytech/ht-ui')['HTTooltip']
    'ht-tooltip': typeof import('@hytech/ht-ui')['HTTooltip']
    HtCheckboxGroup: typeof import('@hytech/ht-ui')['HTCheckboxGroup']
    'ht-checkbox-group': typeof import('@hytech/ht-ui')['HTCheckboxGroup']
    HtSwitch: typeof import('@hytech/ht-ui')['HTSwitch']
    'ht-switch': typeof import('@hytech/ht-ui')['HTSwitch']
    HtActionSheet: typeof import('@hytech/ht-ui')['HTActionSheet']
    'ht-action-sheet': typeof import('@hytech/ht-ui')['HTActionSheet']
    HtDatePicker: typeof import('@hytech/ht-ui')['HTDatePicker']
    'ht-date-picker': typeof import('@hytech/ht-ui')['HTDatePicker']
    HtNumberKeyboard: typeof import('@hytech/ht-ui')['HTNumberKeyboard']
    'ht-number-keyboard': typeof import('@hytech/ht-ui')['HTNumberKeyboard']
    HtSkeleton: typeof import('@hytech/ht-ui')['HTSkeleton']
    'ht-skeleton': typeof import('@hytech/ht-ui')['HTSkeleton']
    HtTag: typeof import('@hytech/ht-ui')['HTTag']
    'ht-tag': typeof import('@hytech/ht-ui')['HTTag']
    HtPinInput: typeof import('@hytech/ht-ui')['HTPinInput']
    'ht-pin-input': typeof import('@hytech/ht-ui')['HTPinInput']
  }
}

// For TSX support
declare global {
  const HtButton: (typeof import('@hytech/ht-ui'))['HTButton'];
  const HtSelect: (typeof import('@hytech/ht-ui'))['HTSelect'];
  const HtOption: (typeof import('@hytech/ht-ui'))['HTOption'];
  const HtModal: (typeof import('@hytech/ht-ui'))['HTModal'];
  const HtPopover: (typeof import('@hytech/ht-ui'))['HTPopover'];
  const HtCellGroup: (typeof import('@hytech/ht-ui'))['HTCellGroup'];
  const HtCell: (typeof import('@hytech/ht-ui'))['HTCell'];
  const HtField: (typeof import('@hytech/ht-ui'))['HTField'];
  const HtCollapseItem: (typeof import('@hytech/ht-ui'))['HTCollapseItem'];
  const HtCollapse: (typeof import('@hytech/ht-ui'))['HTCollapse'];
  const HtRadio: (typeof import('@hytech/ht-ui'))['HTRadio'];
  const HtRadioGroup: (typeof import('@hytech/ht-ui'))['HTRadioGroup'];
  const HtList: (typeof import('@hytech/ht-ui'))['HTList'];
  const HtForm: (typeof import('@hytech/ht-ui'))['HTForm'];
  const HtRow: (typeof import('@hytech/ht-ui'))['HTRow'];
  const HtCol: (typeof import('@hytech/ht-ui'))['HTCol'];
  const HtDivider: (typeof import('@hytech/ht-ui'))['HTDivider'];
  const HtSticky: (typeof import('@hytech/ht-ui'))['HTSticky'];
  const HtSwipe: (typeof import('@hytech/ht-ui'))['HTSwipe'];
  const HtSwipeItem: (typeof import('@hytech/ht-ui'))['HTSwipeItem'];
  const HtPullRefresh: (typeof import('@hytech/ht-ui'))['HTPullRefresh'];
  const HtLoading: (typeof import('@hytech/ht-ui'))['HTLoading'];
  const HtImage: (typeof import('@hytech/ht-ui'))['HTImage'];
  const HtTabs: (typeof import('@hytech/ht-ui'))['HTTabs'];
  const HtTab: (typeof import('@hytech/ht-ui'))['HTTab'];
  const HtToast: (typeof import('@hytech/ht-ui'))['HTToast'];
  const HtTooltip: (typeof import('@hytech/ht-ui'))['HTTooltip'];
  const HtCheckboxGroup: (typeof import('@hytech/ht-ui'))['HTCheckboxGroup'];
  const HtSwitch: (typeof import('@hytech/ht-ui'))['HTSwitch'];
  const HtActionSheet: (typeof import('@hytech/ht-ui'))['HTActionSheet'];
  const HtDatePicker: (typeof import('@hytech/ht-ui'))['HTDatePicker'];
  const HtNumberKeyboard: (typeof import('@hytech/ht-ui'))['HTNumberKeyboard'];
  const HtSkeleton: (typeof import('@hytech/ht-ui'))['HTSkeleton'];
  const HtTag: (typeof import('@hytech/ht-ui'))['HTTag'];
  const HtPinInput: (typeof import('@hytech/ht-ui'))['HTPinInput'];
}