const fs = require("fs");
const https = require("https");

const dirs = fs.readdirSync("./source");
dirs.forEach((file) => {
  if (file.endsWith(".js")) {
    fs.writeFileSync(
      __dirname + "/js/" + file,
      fs.readFileSync(__dirname + "/source/" + file) +
        "\n//# sourceMappingURL=/js/" +
        file +
        ".map"
    );
  }
});

function download() {
  dirs.forEach((file) => {
    https.get("https://trade.playnance.com/js/" + file + ".map", (res) => {
      let data = "";

      res.on("data", (chunk) => (data += chunk));
      res.on("end", () => {
        fs.writeFileSync(__dirname + "/js/" + file + ".map", data);
      });
    });
  });
}

download();
